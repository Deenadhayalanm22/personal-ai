import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SectionState.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

SectionState[$.FILENAME] = 'src/SectionState.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root_1 = $.add_locations($.from_html(`<article class="panel skeleton-panel"><i></i><b></b><b></b></article>`), SectionState[$.FILENAME], [[8, 2, [[8, 72], [8, 79], [8, 86]]]]);
var root_3 = $.add_locations($.from_html(`<article class="panel section-error" role="alert"><h2> </h2><p> </p> <button class="secondary">Try again</button></article>`), SectionState[$.FILENAME], [[10, 2, [[11, 4], [11, 32], [12, 4]]]]);

function SectionState($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, SectionState);

	let section = $.prop($$props, 'section', 8);
	let title = $.prop($$props, 'title', 8);
	let retry = $.prop($$props, 'retry', 8);
	var $$exports = { ...$.legacy_api() };

	$.init();

	var fragment = $.comment();
	var node = $.first_child(fragment);

	{
		var consequent = ($$anchor) => {
			var article = root_1();

			$.template_effect(() => $.set_attribute(article, 'aria-label', `Loading ${title()}`));
			$.append($$anchor, article);
		};

		var alternate_1 = ($$anchor) => {
			var fragment_1 = $.comment();
			var node_1 = $.first_child(fragment_1);

			{
				var consequent_1 = ($$anchor) => {
					var article_1 = root_3();
					var h2 = $.child(article_1);
					var text = $.child(h2);

					$.reset(h2);

					var p = $.sibling(h2);
					var text_1 = $.child(p, true);

					$.reset(p);

					var button = $.sibling(p, 2);

					$.reset(article_1);

					$.template_effect(() => {
						$.set_text(text, `${title() ?? ''} unavailable`);

						$.set_text(text_1, (
							$.deep_read_state(section()),
							$.untrack(() => section().error)
						));
					});

					$.event('click', button, function (...$$args) {
						$.apply(retry, this, $$args, SectionState, [12, 40]);
					});

					$.append($$anchor, article_1);
				};

				var alternate = ($$anchor) => {
					var fragment_2 = $.comment();
					var node_2 = $.first_child(fragment_2);

					$.slot(node_2, $$props, 'default', {}, null);
					$.append($$anchor, fragment_2);
				};

				$.add_svelte_meta(
					() => $.if(
						node_1,
						($$render) => {
							if ((
								$.deep_read_state(section()),
								$.untrack(() => $.strict_equals(section().status, 'error'))
							)) $$render(consequent_1); else $$render(alternate, false);
						},
						true
					),
					'if',
					SectionState,
					9,
					0
				);
			}

			$.append($$anchor, fragment_1);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if ((
					$.deep_read_state(section()),
					$.untrack(() => $.strict_equals(section().status, 'loading'))
				)) $$render(consequent); else $$render(alternate_1, false);
			}),
			'if',
			SectionState,
			7,
			0
		);
	}

	$.append($$anchor, fragment);

	return $.pop($$exports);
}

if (import.meta.hot) {
	SectionState = $.hmr(SectionState, () => SectionState[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = SectionState[$.HMR].source;
		$.set(SectionState[$.HMR].source, module.default[$.HMR].original);
	});
}

export default SectionState;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozt5Q0FBQSxDQUFDOzs7O0tBQ1ksT0FBTztLQUNQLEtBQUs7S0FDTCxLQUFLOzs7Ozs7Ozs7O09BSWYsT0FBTzs7MkNBQVAsT0FBTywyQkFBcUQsS0FBSztzQkFBakUsT0FBTzs7Ozs7Ozs7O1NBRVAsU0FBTztTQUNMLEVBQUUsV0FESixTQUFPO3dCQUNMLEVBQUU7O2FBQUYsRUFBRTs7U0FBMEIsQ0FBQyxhQUE3QixFQUFFOzBCQUEwQixDQUFDOzthQUFELENBQUM7O1NBQzdCLE1BQU0sYUFEc0IsQ0FBQzs7YUFEL0IsU0FBTzs7OzBCQUNELEtBQUs7Ozt5QkFURCxPQUFPO3VCQVNnQixPQUFPLEdBQUMsS0FBSzs7OztzQkFDNUMsTUFBTTtjQUE2QixLQUFLOzs7d0JBRjFDLFNBQU87Ozs7Ozs7Ozs7Ozs7Ozs7MEJBUkcsT0FBTzt3Q0FPVixPQUFPLEdBQUMsTUFBTSxFQUFLLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFQdkIsT0FBTztxQ0FLZixPQUFPLEdBQUMsTUFBTSxFQUFLLFNBQVM7Ozs7Ozs7Ozs7Ozs7Q0FGakMiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlY3Rpb25TdGF0ZS5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdD5cbiAgZXhwb3J0IGxldCBzZWN0aW9uO1xuICBleHBvcnQgbGV0IHRpdGxlO1xuICBleHBvcnQgbGV0IHJldHJ5O1xuPC9zY3JpcHQ+XG5cbnsjaWYgc2VjdGlvbi5zdGF0dXMgPT09ICdsb2FkaW5nJ31cbiAgPGFydGljbGUgY2xhc3M9XCJwYW5lbCBza2VsZXRvbi1wYW5lbFwiIGFyaWEtbGFiZWw9e2BMb2FkaW5nICR7dGl0bGV9YH0+PGk+PC9pPjxiPjwvYj48Yj48L2I+PC9hcnRpY2xlPlxuezplbHNlIGlmIHNlY3Rpb24uc3RhdHVzID09PSAnZXJyb3InfVxuICA8YXJ0aWNsZSBjbGFzcz1cInBhbmVsIHNlY3Rpb24tZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICA8aDI+e3RpdGxlfSB1bmF2YWlsYWJsZTwvaDI+PHA+e3NlY3Rpb24uZXJyb3J9PC9wPlxuICAgIDxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17cmV0cnl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuICA8L2FydGljbGU+XG57OmVsc2V9XG4gIDxzbG90Pjwvc2xvdD5cbnsvaWZ9XG4iXSwiZmlsZSI6Ii9Vc2Vycy9kZWVuYS9Eb2N1bWVudHMvR2l0SHViL3BlcnNvbmFsLWFpL2Zyb250ZW5kL3NyYy9TZWN0aW9uU3RhdGUuc3ZlbHRlIn0=