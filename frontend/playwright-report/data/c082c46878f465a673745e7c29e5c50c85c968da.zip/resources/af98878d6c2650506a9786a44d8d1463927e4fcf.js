import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Normalization.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

Normalization[$.FILENAME] = 'src/Normalization.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

import {
	createReferencePreference,
	getReferenceEntityTypes,
	getReferencePreferences,
	mergeReferencePreferences
} from "/src/lib/api.js";

var root_1 = $.add_locations($.from_html(`<label><input type="checkbox"/> <span class="merge-label-icon"> </span><span><strong> </strong><small> </small></span></label>`), Normalization[$.FILENAME], [
	[79, 8, [[80, 10], [81, 10], [81, 63, [[81, 69], [81, 101]]]]]
]);

var root_2 = $.add_locations($.from_html(`<p class="merge-type-note">Add at least two references of the same type before merging them.</p>`), Normalization[$.FILENAME], [[85, 57]]);
var root_3 = $.add_locations($.from_html(`<p class="merge-type-note"> </p>`), Normalization[$.FILENAME], [[87, 28]]);
var root_4 = $.add_locations($.from_html(`<p class="merge-success" role="status"> </p>`), Normalization[$.FILENAME], [[88, 21]]);
var root_5 = $.add_locations($.from_html(`<div class="skeleton-panel normalization-skeleton"><i></i><b></b><b></b><b></b></div>`), Normalization[$.FILENAME], [[94, 4, [[94, 55], [94, 62], [94, 69], [94, 76]]]]);
var root_7 = $.add_locations($.from_html(`<div class="section-error"><h2>Normalization is unavailable</h2><p> </p><button>Try again</button></div>`), Normalization[$.FILENAME], [[96, 4, [[96, 31], [96, 68], [96, 82]]]]);
var root_12 = $.add_locations($.from_html(`<span> </span>`), Normalization[$.FILENAME], [[107, 163]]);
var root_11 = $.add_locations($.from_html(`<div class="alias-details"><div class="alias-label"><span>Your preferred aliases</span></div><div class="alias-pills"></div></div>`), Normalization[$.FILENAME], [[107, 12, [[107, 39, [[107, 64]]], [107, 105]]]]);

var root_10 = $.add_locations($.from_html(`<article><button class="normalization-main"><span> </span> <span class="entity-copy"><strong> </strong><small> </small></span> <span>⌄</span></button> <!></article>`), Normalization[$.FILENAME], [
	[
		100,
		8,

		[
			[
				101,
				10,
				[[102, 12], [103, 12, [[103, 38], [103, 78]]], [104, 12]]
			]
		]
	]
]);

var root_9 = $.add_locations($.from_html(`<div class="normalization-list"></div>`), Normalization[$.FILENAME], [[98, 4]]);
var root_13 = $.add_locations($.from_html(`<div class="empty-state normalization-empty"><span>≋</span><h2>Add your first preferred name</h2><p>Choose a reference type, then enter its primary name and the aliases you use.</p><button class="wide-button">＋ Add a preference</button></div>`), Normalization[$.FILENAME], [[113, 4, [[113, 49], [113, 63], [113, 101], [113, 185]]]]);
var root_15 = $.add_locations($.from_html(`<option> </option>`), Normalization[$.FILENAME], [[123, 143]]);
var root_16 = $.add_locations($.from_html(`<p class="form-error" role="alert"> </p>`), Normalization[$.FILENAME], [[126, 21]]);

var root_14 = $.add_locations($.from_html(`<div class="modal-backdrop normalization-modal-backdrop"><form class="modal"><button class="close" type="button">×</button><p class="micro-label">ADD PREFERENCE</p><h2>Add a preferred name</h2> <label>Reference type<select required><option disabled>Select a type</option><!></select></label> <label>Primary reference<input placeholder="e.g. Amazon" required/></label> <label>Aliases <span class="optional">Separate with commas</span><input placeholder="e.g. AMZN, Amazon India, Amazon Store" required/></label> <!> <div class="modal-actions"><button class="secondary" type="button">Cancel</button><button class="primary" type="submit"> </button></div></form></div>`), Normalization[$.FILENAME], [
	[
		120,
		2,

		[
			[
				121,
				4,

				[
					[122, 6],
					[122, 74],
					[122, 115],
					[123, 6, [[123, 27, [[123, 68]]]]],
					[124, 6, [[124, 30]]],
					[125, 6, [[125, 21], [125, 71]]],
					[127, 6, [[127, 33], [127, 110]]]
				]
			]
		]
	]
]);

var root_18 = $.add_locations($.from_html(`<p class="form-error" role="alert"> </p>`), Normalization[$.FILENAME], [[139, 22]]);

var root_17 = $.add_locations($.from_html(`<div class="modal-backdrop normalization-modal-backdrop"><div class="modal merge-modal" role="dialog" aria-modal="true" aria-labelledby="merge-modal-title" tabindex="-1"><button class="close" type="button">×</button><p class="micro-label"> </p><h2 id="merge-modal-title">Choose the name to keep</h2> <p class="merge-modal-copy"> </p> <label class="merge-name-field"> <input placeholder="e.g. HDFC Bank" autocomplete="off"/></label> <div class="merge-modal-selected"><span>Selected names</span><p> </p></div> <!> <div class="modal-actions"><button class="secondary" type="button">Cancel</button><button class="primary" type="button"> </button></div></div></div>`), Normalization[$.FILENAME], [
	[
		133,
		2,

		[
			[
				134,
				4,

				[
					[135, 6],
					[135, 74],
					[135, 160],
					[136, 6],
					[137, 6, [[137, 98]]],
					[138, 6, [[138, 40], [138, 67]]],
					[140, 6, [[140, 33], [140, 129]]]
				]
			]
		]
	]
]);

var root = $.add_locations($.from_html(`<section class="normalization-page"><div class="normalization-heading"><div><p class="micro-label">FIX YOUR ACCOUNTS</p><h1>Account repair</h1><p>Edit, add, or merge merchant, beneficiary, and account names so your records stay clean and consistent.</p></div> <button class="add-normalization" type="button" aria-label="Add reference preference">＋</button></div> <section class="merge-workspace" aria-labelledby="merchant-merge-title"><div class="merge-title-row"><div><p class="micro-label">REFERENCE CLEANUP</p><h2 id="merchant-merge-title">Merge matching names</h2><p>Select two or more names of the same type, then choose the name to keep.</p></div></div> <div class="merchant-selection" aria-label="Select merchants to merge"></div> <!> <div class="merge-selection-footer"><span> </span><button class="merge-button" type="button">Merge selected</button></div> <!> <!></section> <div class="saved-preferences-heading"><p class="micro-label">SAVED NAMES</p><h2>Your normalization rules</h2></div> <!> <aside class="normalization-tip"><span>✦</span><p><strong>How aliases work</strong> “HDFC credit card” can also respond to “credit card” or “cc”. Enter multiple aliases separated by commas.</p></aside></section> <!> <!>`, 1), Normalization[$.FILENAME], [
	[
		67,
		0,

		[
			[68, 2, [[69, 4, [[69, 9], [69, 53], [69, 76]]], [70, 4]]],

			[
				73,
				2,

				[
					[74, 4, [[75, 6, [[75, 11], [75, 55], [75, 110]]]]],
					[77, 4],
					[86, 4, [[86, 40], [86, 244]]]
				]
			],

			[91, 2, [[91, 41], [91, 79]]],
			[116, 2, [[116, 35], [116, 49, [[116, 52]]]]]
		]
	]
]);

function Normalization($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, Normalization);

	const merchantsForMerge = $.mutable_source();
	const selectedMerchants = $.mutable_source();
	const selectedTransactionCount = $.mutable_source();
	const selectedEntityType = $.mutable_source();
	let status = $.mutable_source('loading');
	let error = $.mutable_source('');
	let entityTypes = $.mutable_source([]);
	let savedPreferences = $.mutable_source([]);
	let expanded = $.mutable_source(null);
	let showModal = $.mutable_source(false);
	let saving = $.mutable_source(false);
	let formError = $.mutable_source('');
	let selectedMerchantIds = $.mutable_source([]);
	let preferredMerchantName = $.mutable_source('');
	let showMergeModal = $.mutable_source(false);
	let mergeNotice = $.mutable_source('');
	let merging = $.mutable_source(false);
	let mergeError = $.mutable_source('');
	let entityType = $.mutable_source('');
	let primaryReference = $.mutable_source('');
	let alias = $.mutable_source('');

	const labels = {
		MERCHANT: 'Merchant',
		BENEFICIARY: 'Beneficiary',
		ACCOUNT: 'Account'
	};

	const icons = { MERCHANT: 'M', BENEFICIARY: 'B', ACCOUNT: '₹' };
	const typeLabel = (type) => labels[type] || type.replaceAll('_', ' ').toLowerCase().replace(/^./, (value) => value.toUpperCase());
	const aliasesFor = (item) => (item.aliases || []).map((value) => $.strict_equals(typeof value, 'string') ? value : value.alias).filter(Boolean);

	const preferencesFrom = (data) => Array.isArray(data)
		? data
		: data?.references || data?.referencePreferences || data?.preferences || data?.items || [];

	function toggleMerchant(id) {
		$.set(selectedMerchantIds, $.get(selectedMerchantIds).includes(id)
			? $.get(selectedMerchantIds).filter((value) => $.strict_equals(value, id, false))
			: [...$.get(selectedMerchantIds), id]);

		$.set(mergeNotice, '');
	}

	function openMerge() {
		if ($.get(selectedMerchants).length < 2) return;

		$.set(preferredMerchantName, $.get(selectedMerchants)[0].name);
		$.set(mergeError, '');
		$.set(showMergeModal, true);
	}

	function closeMerge() {
		if (!$.get(merging)) $.set(showMergeModal, false);
	}

	async function confirmMerge() {
		const name = $.get(preferredMerchantName).trim();

		if (!name || $.get(merging)) return;

		$.set(merging, true);
		$.set(mergeError, '');

		try {
			const result = (await $.track_reactivity_loss(mergeReferencePreferences({
				entityType: $.get(selectedEntityType),
				referenceIds: $.get(selectedMerchantIds),
				canonicalName: name
			})))();

			const transactionCount = result?.updatedTransactionCount ?? $.get(selectedTransactionCount);

			$.set(mergeNotice, `${transactionCount} transactions are now grouped under ${result?.canonicalReference?.name || name}.`);
			$.set(selectedMerchantIds, []);
			$.set(showMergeModal, false);
			(await $.track_reactivity_loss(refreshPreferences()))();
		} catch(cause) {
			$.set(mergeError, cause?.message || 'Could not merge these references.');
		} finally {
			$.set(merging, false);
		}
	}

	async function loadScreen() {
		$.set(status, 'loading');
		$.set(error, '');

		try {
			const [typeData, preferenceData] = (await $.track_reactivity_loss(Promise.all([getReferenceEntityTypes(), getReferencePreferences()])))();

			$.set(entityTypes, typeData?.entityTypes || []);
			$.set(savedPreferences, preferencesFrom(preferenceData));
			$.set(entityType, $.get(entityType) || $.get(entityTypes)[0] || '');
			$.set(status, 'ready');
		} catch(cause) {
			$.set(status, 'error');
			$.set(error, cause?.message || 'Could not load reference preferences.');
		}
	}

	async function refreshPreferences() {
		$.set(savedPreferences, preferencesFrom((await $.track_reactivity_loss(getReferencePreferences()))()));
	}

	function openCreate() {
		$.set(entityType, $.get(entityTypes)[0] || '');
		$.set(primaryReference, '');
		$.set(alias, '');
		$.set(formError, '');
		$.set(showModal, true);
	}

	function closeModal() {
		$.set(showModal, false);
	}

	async function save() {
		const primary = $.get(primaryReference).trim(),
			aliasValue = $.get(alias).trim();

		if (!$.get(entityType) || !primary || !aliasValue) {
			$.set(formError, 'Complete all three fields and provide at least one alias.');

			return;
		}

		$.set(saving, true);
		$.set(formError, '');

		try {
			(await $.track_reactivity_loss(createReferencePreference({
				entityType: $.get(entityType),
				primaryReference: primary,
				alias: aliasValue
			})))();

			(await $.track_reactivity_loss(refreshPreferences()))();
			closeModal();
		} catch(cause) {
			$.set(formError, cause?.message || 'Could not save this preference.');
		} finally {
			$.set(saving, false);
		}
	}

	loadScreen();

	$.legacy_pre_effect(() => ($.get(savedPreferences)), () => {
		$.set(merchantsForMerge, $.get(savedPreferences).filter((item) => $.equals(item.referenceId, null, false) && $.strict_equals(item.status, 'INACTIVE', false) && $.strict_equals(item.status, 'MERGED', false)).map((item) => ({
			id: item.referenceId,
			name: item.primaryReference,
			entityType: item.entityType,
			transactionCount: Number(item.transactionCount || 0),
			icon: icons[item.entityType] || item.primaryReference?.[0]?.toUpperCase() || 'R'
		})));
	});

	$.legacy_pre_effect(() => ($.get(merchantsForMerge), $.get(selectedMerchantIds)), () => {
		$.set(selectedMerchants, $.get(merchantsForMerge).filter((merchant) => $.get(selectedMerchantIds).includes(merchant.id)));
	});

	$.legacy_pre_effect(() => ($.get(selectedMerchants)), () => {
		$.set(selectedTransactionCount, $.get(selectedMerchants).reduce((total, merchant) => total + merchant.transactionCount, 0));
	});

	$.legacy_pre_effect(() => ($.get(selectedMerchants)), () => {
		$.set(selectedEntityType, $.get(selectedMerchants)[0]?.entityType || '');
	});

	$.legacy_pre_effect_reset();

	var $$exports = { ...$.legacy_api() };

	$.init();

	var fragment = root();
	var section = $.first_child(fragment);
	var div = $.child(section);
	var button = $.sibling($.child(div), 2);

	$.reset(div);

	var section_1 = $.sibling(div, 2);
	var div_1 = $.sibling($.child(section_1), 2);

	$.add_svelte_meta(
		() => $.each(div_1, 5, () => $.get(merchantsForMerge), $.index, ($$anchor, merchant) => {
			var label = root_1();
			let classes;
			var input = $.child(label);

			$.remove_input_defaults(input);

			var span = $.sibling(input, 2);
			var text = $.child(span, true);

			$.reset(span);

			var span_1 = $.sibling(span);
			var strong = $.child(span_1);
			var text_1 = $.child(strong, true);

			$.reset(strong);

			var small = $.sibling(strong);
			var text_2 = $.child(small);

			$.reset(small);
			$.reset(span_1);
			$.reset(label);

			$.template_effect(
				($0, $1, $2) => {
					classes = $.set_class(label, 1, 'merchant-option', null, classes, $0);
					input.disabled = $1;
					$.set_checked(input, $2);
					$.set_text(text, ($.get(merchant), $.untrack(() => $.get(merchant).icon)));
					$.set_text(text_1, ($.get(merchant), $.untrack(() => $.get(merchant).name)));

					$.set_text(text_2, `${(
						$.get(merchant),
						$.untrack(() => $.strict_equals($.get(merchant).entityType, 'ACCOUNT') ? 'Account' : 'Merchant')
					) ?? ''} · ${(
						$.get(merchant),
						$.untrack(() => $.get(merchant).transactionCount)
					) ?? ''} ${(
						$.get(merchant),
						$.untrack(() => $.strict_equals($.get(merchant).transactionCount, 1) ? 'transaction' : 'transactions')
					) ?? ''}`);
				},
				[
					() => ({
						selected: $.get(selectedMerchantIds).includes($.get(merchant).id),
						blocked: Boolean($.get(selectedEntityType) && $.strict_equals($.get(selectedEntityType), $.get(merchant).entityType, false))
					}),

					() => (
						$.get(selectedEntityType),
						$.get(merchant),
						$.untrack(() => Boolean($.get(selectedEntityType) && $.strict_equals($.get(selectedEntityType), $.get(merchant).entityType, false)))
					),

					() => (
						$.get(selectedMerchantIds),
						$.get(merchant),
						$.untrack(() => $.get(selectedMerchantIds).includes($.get(merchant).id))
					)
				]
			);

			$.event('change', input, () => toggleMerchant($.get(merchant).id));
			$.append($$anchor, label);
		}),
		'each',
		Normalization,
		78,
		6
	);

	$.reset(div_1);

	var node = $.sibling(div_1, 2);

	{
		var consequent = ($$anchor) => {
			var p = root_2();

			$.append($$anchor, p);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if ((
					$.get(merchantsForMerge),
					$.get(status),
					$.untrack(() => !$.get(merchantsForMerge).length && $.strict_equals($.get(status), 'ready'))
				)) $$render(consequent);
			}),
			'if',
			Normalization,
			85,
			4
		);
	}

	var div_2 = $.sibling(node, 2);
	var span_2 = $.child(div_2);
	var text_3 = $.child(span_2, true);

	$.reset(span_2);

	var button_1 = $.sibling(span_2);

	$.reset(div_2);

	var node_1 = $.sibling(div_2, 2);

	{
		var consequent_1 = ($$anchor) => {
			var p_1 = root_3();
			var text_4 = $.child(p_1);

			$.reset(p_1);

			$.template_effect(($0) => $.set_text(text_4, `You’re selecting ${$0 ?? ''} references. Deselect them before choosing a different reference type.`), [
				() => (
					$.get(selectedEntityType),
					$.untrack(() => $.get(selectedEntityType).toLowerCase())
				)
			]);

			$.append($$anchor, p_1);
		};

		$.add_svelte_meta(
			() => $.if(node_1, ($$render) => {
				if ($.get(selectedEntityType)) $$render(consequent_1);
			}),
			'if',
			Normalization,
			87,
			4
		);
	}

	var node_2 = $.sibling(node_1, 2);

	{
		var consequent_2 = ($$anchor) => {
			var p_2 = root_4();
			var text_5 = $.child(p_2);

			$.reset(p_2);
			$.template_effect(() => $.set_text(text_5, `✓ ${$.get(mergeNotice) ?? ''}`));
			$.append($$anchor, p_2);
		};

		$.add_svelte_meta(
			() => $.if(node_2, ($$render) => {
				if ($.get(mergeNotice)) $$render(consequent_2);
			}),
			'if',
			Normalization,
			88,
			4
		);
	}

	$.reset(section_1);

	var node_3 = $.sibling(section_1, 4);

	{
		var consequent_3 = ($$anchor) => {
			var div_3 = root_5();

			$.append($$anchor, div_3);
		};

		var alternate_2 = ($$anchor) => {
			var fragment_1 = $.comment();
			var node_4 = $.first_child(fragment_1);

			{
				var consequent_4 = ($$anchor) => {
					var div_4 = root_7();
					var p_3 = $.sibling($.child(div_4));
					var text_6 = $.child(p_3, true);

					$.reset(p_3);

					var button_2 = $.sibling(p_3);

					$.reset(div_4);
					$.template_effect(() => $.set_text(text_6, $.get(error)));
					$.event('click', button_2, loadScreen);
					$.append($$anchor, div_4);
				};

				var alternate_1 = ($$anchor) => {
					var fragment_2 = $.comment();
					var node_5 = $.first_child(fragment_2);

					{
						var consequent_6 = ($$anchor) => {
							var div_5 = root_9();

							$.add_svelte_meta(
								() => $.each(div_5, 5, () => $.get(savedPreferences), $.index, ($$anchor, item) => {
									var article = root_10();
									let classes_1;
									var button_3 = $.child(article);
									var span_3 = $.child(button_3);
									var text_7 = $.child(span_3, true);

									$.reset(span_3);

									var span_4 = $.sibling(span_3, 2);
									var strong_1 = $.child(span_4);
									var text_8 = $.child(strong_1, true);

									$.reset(strong_1);

									var small_1 = $.sibling(strong_1);
									var text_9 = $.child(small_1);

									$.reset(small_1);
									$.reset(span_4);

									var span_5 = $.sibling(span_4, 2);
									let classes_2;

									$.reset(button_3);

									var node_6 = $.sibling(button_3, 2);

									{
										var consequent_5 = ($$anchor) => {
											var div_6 = root_11();
											var div_7 = $.sibling($.child(div_6));

											$.add_svelte_meta(
												() => $.each(div_7, 5, () => ($.get(item), $.untrack(() => aliasesFor($.get(item)))), $.index, ($$anchor, value) => {
													var span_6 = root_12();
													var text_10 = $.child(span_6, true);

													$.reset(span_6);
													$.template_effect(() => $.set_text(text_10, $.get(value)));
													$.append($$anchor, span_6);
												}),
												'each',
												Normalization,
												107,
												130
											);

											$.reset(div_7);
											$.reset(div_6);
											$.append($$anchor, div_6);
										};

										$.add_svelte_meta(
											() => $.if(node_6, ($$render) => {
												if ((
													$.get(expanded),
													$.get(item),
													$.untrack(() => $.strict_equals($.get(expanded), $.get(item).referenceId))
												)) $$render(consequent_5);
											}),
											'if',
											Normalization,
											106,
											10
										);
									}

									$.reset(article);

									$.template_effect(
										($0, $1, $2) => {
											classes_1 = $.set_class(article, 1, 'normalization-row', null, classes_1, {
												expanded: $.strict_equals($.get(expanded), $.get(item).referenceId)
											});

											$.set_attribute(button_3, 'aria-expanded', (
												$.get(expanded),
												$.get(item),
												$.untrack(() => $.strict_equals($.get(expanded), $.get(item).referenceId))
											));

											$.set_class(span_3, 1, (
												$.get(item),
												$.untrack(() => `entity-icon ${$.strict_equals($.get(item).entityType, 'ACCOUNT') ? 'account' : ''}`)
											));

											$.set_text(text_7, (
												$.get(item),
												$.untrack(() => icons[$.get(item).entityType] || 'R')
											));

											$.set_text(text_8, ($.get(item), $.untrack(() => $.get(item).primaryReference)));
											$.set_text(text_9, `${$0 ?? ''} · ${$1 ?? ''} ${$2 ?? ''}`);

											classes_2 = $.set_class(span_5, 1, 'normalization-chevron', null, classes_2, {
												open: $.strict_equals($.get(expanded), $.get(item).referenceId)
											});
										},
										[
											() => (
												$.get(item),
												$.untrack(() => typeLabel($.get(item).entityType))
											),

											() => ($.get(item), $.untrack(() => aliasesFor($.get(item)).length)),

											() => (
												$.get(item),
												$.untrack(() => $.strict_equals(aliasesFor($.get(item)).length, 1) ? 'alias' : 'aliases')
											)
										]
									);

									$.event('click', button_3, () => $.set(expanded, $.strict_equals($.get(expanded), $.get(item).referenceId) ? null : $.get(item).referenceId));
									$.append($$anchor, article);
								}),
								'each',
								Normalization,
								99,
								6
							);

							$.reset(div_5);
							$.append($$anchor, div_5);
						};

						var alternate = ($$anchor) => {
							var div_8 = root_13();
							var button_4 = $.sibling($.child(div_8), 3);

							$.reset(div_8);
							$.event('click', button_4, openCreate);
							$.append($$anchor, div_8);
						};

						$.add_svelte_meta(
							() => $.if(
								node_5,
								($$render) => {
									if ((
										$.get(savedPreferences),
										$.untrack(() => $.get(savedPreferences).length)
									)) $$render(consequent_6); else $$render(alternate, false);
								},
								true
							),
							'if',
							Normalization,
							97,
							2
						);
					}

					$.append($$anchor, fragment_2);
				};

				$.add_svelte_meta(
					() => $.if(
						node_4,
						($$render) => {
							if ($.strict_equals($.get(status), 'error')) $$render(consequent_4); else $$render(alternate_1, false);
						},
						true
					),
					'if',
					Normalization,
					95,
					2
				);
			}

			$.append($$anchor, fragment_1);
		};

		$.add_svelte_meta(
			() => $.if(node_3, ($$render) => {
				if ($.strict_equals($.get(status), 'loading')) $$render(consequent_3); else $$render(alternate_2, false);
			}),
			'if',
			Normalization,
			93,
			2
		);
	}

	$.next(2);
	$.reset(section);

	var node_7 = $.sibling(section, 2);

	{
		var consequent_8 = ($$anchor) => {
			var div_9 = root_14();
			var form = $.child(div_9);
			var button_5 = $.child(form);
			var label_1 = $.sibling(button_5, 4);
			var select = $.sibling($.child(label_1));

			$.template_effect(() => {
				$.get(entityType);

				$.invalidate_inner_signals(() => {
					$.get(entityTypes);
					typeLabel;
				});
			});

			var option = $.child(select);

			option.value = option.__value = '';

			var node_8 = $.sibling(option);

			$.add_svelte_meta(
				() => $.each(node_8, 1, () => $.get(entityTypes), $.index, ($$anchor, type) => {
					var option_1 = root_15();
					var text_11 = $.child(option_1, true);

					$.reset(option_1);

					var option_1_value = {};

					$.template_effect(
						($0) => {
							$.set_text(text_11, $0);

							if (option_1_value !== (option_1_value = $.get(type))) {
								option_1.value = (option_1.__value = $.get(type)) ?? '';
							}
						},
						[() => ($.get(type), $.untrack(() => typeLabel($.get(type))))]
					);

					$.append($$anchor, option_1);
				}),
				'each',
				Normalization,
				123,
				116
			);

			$.reset(select);
			$.reset(label_1);

			var label_2 = $.sibling(label_1, 2);
			var input_1 = $.sibling($.child(label_2));

			$.remove_input_defaults(input_1);
			$.reset(label_2);

			var label_3 = $.sibling(label_2, 2);
			var input_2 = $.sibling($.child(label_3), 2);

			$.remove_input_defaults(input_2);
			$.reset(label_3);

			var node_9 = $.sibling(label_3, 2);

			{
				var consequent_7 = ($$anchor) => {
					var p_4 = root_16();
					var text_12 = $.child(p_4, true);

					$.reset(p_4);
					$.template_effect(() => $.set_text(text_12, $.get(formError)));
					$.append($$anchor, p_4);
				};

				$.add_svelte_meta(
					() => $.if(node_9, ($$render) => {
						if ($.get(formError)) $$render(consequent_7);
					}),
					'if',
					Normalization,
					126,
					6
				);
			}

			var div_10 = $.sibling(node_9, 2);
			var button_6 = $.child(div_10);
			var button_7 = $.sibling(button_6);
			var text_13 = $.child(button_7, true);

			$.reset(button_7);
			$.reset(div_10);
			$.reset(form);
			$.reset(div_9);

			$.template_effect(
				($0) => {
					button_7.disabled = $0;
					$.set_text(text_13, $.get(saving) ? 'Saving…' : 'Save preference');
				},
				[
					() => (
						$.get(saving),
						$.get(entityType),
						$.get(primaryReference),
						$.get(alias),
						$.untrack(() => $.get(saving) || !$.get(entityType) || !$.get(primaryReference).trim() || !$.get(alias).trim())
					)
				]
			);

			$.event('click', button_5, closeModal);

			$.bind_select_value(
				select,
				function get() {
					return $.get(entityType);
				},
				function set($$value) {
					$.set(entityType, $$value);
				}
			);

			$.bind_value(
				input_1,
				function get() {
					return $.get(primaryReference);
				},
				function set($$value) {
					$.set(primaryReference, $$value);
				}
			);

			$.bind_value(
				input_2,
				function get() {
					return $.get(alias);
				},
				function set($$value) {
					$.set(alias, $$value);
				}
			);

			$.event('click', button_6, closeModal);
			$.event('submit', form, $.preventDefault(save));
			$.append($$anchor, div_9);
		};

		$.add_svelte_meta(
			() => $.if(node_7, ($$render) => {
				if ($.get(showModal)) $$render(consequent_8);
			}),
			'if',
			Normalization,
			119,
			0
		);
	}

	var node_10 = $.sibling(node_7, 2);

	{
		var consequent_10 = ($$anchor) => {
			var div_11 = root_17();
			var div_12 = $.child(div_11);
			var button_8 = $.child(div_12);
			var p_5 = $.sibling(button_8);
			var text_14 = $.child(p_5);

			$.reset(p_5);

			var p_6 = $.sibling(p_5, 3);
			var text_15 = $.child(p_6);

			$.reset(p_6);

			var label_4 = $.sibling(p_6, 2);
			var text_16 = $.child(label_4);
			var input_3 = $.sibling(text_16);

			$.remove_input_defaults(input_3);
			$.reset(label_4);

			var div_13 = $.sibling(label_4, 2);
			var p_7 = $.sibling($.child(div_13));
			var text_17 = $.child(p_7, true);

			$.reset(p_7);
			$.reset(div_13);

			var node_11 = $.sibling(div_13, 2);

			{
				var consequent_9 = ($$anchor) => {
					var p_8 = root_18();
					var text_18 = $.child(p_8, true);

					$.reset(p_8);
					$.template_effect(() => $.set_text(text_18, $.get(mergeError)));
					$.append($$anchor, p_8);
				};

				$.add_svelte_meta(
					() => $.if(node_11, ($$render) => {
						if ($.get(mergeError)) $$render(consequent_9);
					}),
					'if',
					Normalization,
					139,
					6
				);
			}

			var div_14 = $.sibling(node_11, 2);
			var button_9 = $.child(div_14);
			var button_10 = $.sibling(button_9);
			var text_19 = $.child(button_10, true);

			$.reset(button_10);
			$.reset(div_14);
			$.reset(div_12);
			$.reset(div_11);

			$.template_effect(
				($0, $1, $2, $3) => {
					$.set_text(text_14, `MERGE ${(
						$.get(selectedMerchants),
						$.untrack(() => $.get(selectedMerchants).length)
					) ?? ''} ${$.get(selectedEntityType) ?? ''} NAMES`);

					$.set_text(text_15, `Enter one name to use across all ${$.get(selectedTransactionCount) ?? ''} selected transactions. The selected labels will remain as aliases.`);
					$.set_text(text_16, `Preferred ${$0 ?? ''} name`);
					$.set_text(text_17, $1);
					button_9.disabled = $.get(merging);
					button_10.disabled = $2;
					$.set_text(text_19, $3);
				},
				[
					() => (
						$.get(selectedEntityType),
						$.untrack(() => typeLabel($.get(selectedEntityType)).toLowerCase())
					),

					() => (
						$.get(selectedMerchants),
						$.untrack(() => $.get(selectedMerchants).map((merchant) => merchant.name).join(' · '))
					),

					() => (
						$.get(merging),
						$.get(preferredMerchantName),
						$.untrack(() => $.get(merging) || !$.get(preferredMerchantName).trim())
					),

					() => (
						$.get(merging),
						$.get(selectedEntityType),

						$.untrack(() => $.get(merging)
							? 'Merging…'
							: `Merge ${typeLabel($.get(selectedEntityType)).toLowerCase()}s`)
					)
				]
			);

			$.event('click', button_8, closeMerge);

			$.bind_value(
				input_3,
				function get() {
					return $.get(preferredMerchantName);
				},
				function set($$value) {
					$.set(preferredMerchantName, $$value);
				}
			);

			$.event('click', button_9, closeMerge);
			$.event('click', button_10, confirmMerge);
			$.append($$anchor, div_11);
		};

		$.add_svelte_meta(
			() => $.if(node_10, ($$render) => {
				if ($.get(showMergeModal)) $$render(consequent_10);
			}),
			'if',
			Normalization,
			132,
			0
		);
	}

	$.template_effect(
		($0) => {
			button.disabled = (
				$.get(status),
				$.get(entityTypes),
				$.untrack(() => $.strict_equals($.get(status), 'ready', false) || !$.get(entityTypes).length)
			);

			$.set_text(text_3, $0);

			button_1.disabled = (
				$.get(selectedMerchants),
				$.untrack(() => $.get(selectedMerchants).length < 2)
			);
		},
		[
			() => (
				$.get(selectedMerchants),
				$.get(selectedEntityType),
				$.get(selectedTransactionCount),

				$.untrack(() => $.get(selectedMerchants).length
					? `${$.get(selectedMerchants).length} ${$.get(selectedEntityType).toLowerCase()} names · ${$.get(selectedTransactionCount)} transactions selected`
					: 'Select at least two names to merge')
			)
		]
	);

	$.event('click', button, openCreate);
	$.event('click', button_1, openMerge);
	$.append($$anchor, fragment);

	return $.pop($$exports);
}

if (import.meta.hot) {
	Normalization = $.hmr(Normalization, () => Normalization[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = Normalization[$.HMR].source;
		$.set(Normalization[$.HMR].source, module.default[$.HMR].original);
	});
}

export default Normalization;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Q0FFVyx5QkFBeUI7Q0FBRSx1QkFBdUI7Q0FBRSx1QkFBdUI7Q0FBRSx5QkFBeUI7T0FBUSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUZ2SSxDQUFDOzs7Ozs7OztLQUlLLE1BQU0sb0JBQUcsU0FBUztLQUFFLEtBQUssb0JBQUcsRUFBRTtLQUFFLFdBQVc7S0FBTyxnQkFBZ0I7S0FDbEUsUUFBUSxvQkFBRyxJQUFJO0tBQUUsU0FBUyxvQkFBRyxLQUFLO0tBQUUsTUFBTSxvQkFBRyxLQUFLO0tBQUUsU0FBUyxvQkFBRyxFQUFFO0tBQ2xFLG1CQUFtQjtLQUFPLHFCQUFxQixvQkFBRyxFQUFFO0tBQUUsY0FBYyxvQkFBRyxLQUFLO0tBQUUsV0FBVyxvQkFBRyxFQUFFO0tBQUUsT0FBTyxvQkFBRyxLQUFLO0tBQUUsVUFBVSxvQkFBRyxFQUFFO0tBQ2hJLFVBQVUsb0JBQUcsRUFBRTtLQUFFLGdCQUFnQixvQkFBRyxFQUFFO0tBQUUsS0FBSyxvQkFBRyxFQUFFOztPQUVoRCxNQUFNO0VBQUssUUFBUSxFQUFFLFVBQVU7RUFBRSxXQUFXLEVBQUUsYUFBYTtFQUFFLE9BQU8sRUFBRSxTQUFTOzs7T0FDL0UsS0FBSyxLQUFLLFFBQVEsRUFBRSxHQUFHLEVBQUUsV0FBVyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsR0FBRztPQUN2RCxTQUFTLElBQUcsSUFBSSxLQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLFdBQVcsR0FBRyxPQUFPLENBQUMsSUFBSSxHQUFFLEtBQUssS0FBSSxLQUFLLENBQUMsV0FBVztPQUNwSCxVQUFVLElBQUcsSUFBSSxNQUFLLElBQUksQ0FBQyxPQUFPLFFBQVEsR0FBRyxFQUFDLEtBQUssNEJBQVcsS0FBSyxFQUFLLFFBQVEsSUFBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsT0FBTzs7T0FDdEgsZUFBZSxJQUFHLElBQUksS0FBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUk7SUFBSSxJQUFJO0lBQUksSUFBSSxFQUFFLFVBQVUsSUFBSSxJQUFJLEVBQUUsb0JBQW9CLElBQUksSUFBSSxFQUFFLFdBQVcsSUFBSSxJQUFJLEVBQUUsS0FBSzs7VUFPdkksY0FBYyxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQUMsbUJBQW1CLFFBQUcsbUJBQW1CLEVBQUMsUUFBUSxDQUFDLEVBQUU7V0FBSSxtQkFBbUIsRUFBQyxNQUFNLEVBQUMsS0FBSyxxQkFBSSxLQUFLLEVBQUssRUFBRTtlQUFRLG1CQUFtQixHQUFFLEVBQUU7O1FBQUcsV0FBVyxFQUFHLEVBQUU7Q0FBRTs7VUFDbEwsU0FBUyxHQUFHLENBQUM7WUFBSyxpQkFBaUIsRUFBQyxNQUFNLEdBQUcsQ0FBQzs7UUFBVSxxQkFBcUIsUUFBRyxpQkFBaUIsRUFBQyxDQUFDLEVBQUUsSUFBSTtRQUFFLFVBQVUsRUFBRyxFQUFFO1FBQUUsY0FBYyxFQUFHLElBQUk7Q0FBRTs7VUFDbkosVUFBVSxHQUFHLENBQUM7YUFBTSxPQUFPLFNBQUUsY0FBYyxFQUFHLEtBQUs7Q0FBRTs7Z0JBQy9DLFlBQVksR0FBRztRQUN0QixJQUFJLFNBQUcscUJBQXFCLEVBQUMsSUFBSTs7T0FBUyxJQUFJLFVBQUksT0FBTzs7UUFDL0QsT0FBTyxFQUFHLElBQUk7UUFBRSxVQUFVLEVBQUcsRUFBRTs7TUFDM0I7U0FDSSxNQUFNLGtDQUFTLHlCQUF5QjtJQUFHLFVBQVUsUUFBRSxrQkFBa0I7SUFBRSxZQUFZLFFBQUUsbUJBQW1CO0lBQUUsYUFBYSxFQUFFLElBQUk7OztTQUNqSSxnQkFBZ0IsR0FBRyxNQUFNLEVBQUUsdUJBQXVCLFVBQUksd0JBQXdCOztTQUNwRixXQUFXLEtBQU0sZ0JBQWdCLHVDQUF1QyxNQUFNLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxJQUFJLElBQUk7U0FDaEgsbUJBQW1CO1NBQU8sY0FBYyxFQUFHLEtBQUs7a0NBQVEsa0JBQWtCO0VBQzVFLENBQUMsT0FBUSxLQUFLLEVBQUUsQ0FBQztTQUFDLFVBQVUsRUFBRyxLQUFLLEVBQUUsT0FBTyxJQUFJLG1DQUFtQztFQUFFLFVBQzlFLENBQUM7U0FBQyxPQUFPLEVBQUcsS0FBSztFQUFFO0NBQzdCOztnQkFFZSxVQUFVLEdBQUc7UUFDMUIsTUFBTSxFQUFHLFNBQVM7UUFBRSxLQUFLLEVBQUcsRUFBRTs7TUFDMUI7VUFDSyxRQUFRLEVBQUUsY0FBYyxtQ0FBVSxPQUFPLENBQUMsR0FBRyxFQUFFLHVCQUF1QixJQUFJLHVCQUF1Qjs7U0FDeEcsV0FBVyxFQUFHLFFBQVEsRUFBRSxXQUFXO1NBQ25DLGdCQUFnQixFQUFHLGVBQWUsQ0FBQyxjQUFjO1NBQ2pELFVBQVUsUUFBRyxVQUFVLFdBQUksV0FBVyxFQUFDLENBQUMsS0FBSyxFQUFFO1NBQy9DLE1BQU0sRUFBRyxPQUFPO0VBQ2xCLENBQUMsT0FBUSxLQUFLLEVBQUUsQ0FBQztTQUFDLE1BQU0sRUFBRyxPQUFPO1NBQUUsS0FBSyxFQUFHLEtBQUssRUFBRSxPQUFPLElBQUksdUNBQXVDO0VBQUU7Q0FDekc7O2dCQUVlLGtCQUFrQixHQUFHLENBQUM7UUFBQyxnQkFBZ0IsRUFBRyxlQUFlLGdDQUFPLHVCQUF1QjtDQUFLOztVQUVsRyxVQUFVLEdBQUcsQ0FBQztRQUFDLFVBQVUsUUFBRyxXQUFXLEVBQUMsQ0FBQyxLQUFLLEVBQUU7UUFBRSxnQkFBZ0IsRUFBRyxFQUFFO1FBQUUsS0FBSyxFQUFHLEVBQUU7UUFBRSxTQUFTLEVBQUcsRUFBRTtRQUFFLFNBQVMsRUFBRyxJQUFJO0NBQUU7O1VBQ3ZILFVBQVUsR0FBRyxDQUFDO1FBQUMsU0FBUyxFQUFHLEtBQUs7Q0FBRTs7Z0JBRTVCLElBQUksR0FBRztRQUNkLE9BQU8sU0FBRyxnQkFBZ0IsRUFBQyxJQUFJO0dBQUksVUFBVSxTQUFHLEtBQUssRUFBQyxJQUFJOzthQUMzRCxVQUFVLE1BQUssT0FBTyxLQUFLLFVBQVUsRUFBRSxDQUFDO1NBQUMsU0FBUyxFQUFHLDJEQUEyRDs7O0VBQVU7O1FBQy9ILE1BQU0sRUFBRyxJQUFJO1FBQUUsU0FBUyxFQUFHLEVBQUU7O01BQ3pCO2tDQUNJLHlCQUF5QjtJQUFHLFVBQVUsUUFBVixVQUFVO0lBQUUsZ0JBQWdCLEVBQUUsT0FBTztJQUFFLEtBQUssRUFBRSxVQUFVOzs7a0NBQ3BGLGtCQUFrQjtHQUN4QixVQUFVO0VBQ1osQ0FBQyxPQUFRLEtBQUssRUFBRSxDQUFDO1NBQUMsU0FBUyxFQUFHLEtBQUssRUFBRSxPQUFPLElBQUksaUNBQWlDO0VBQUUsVUFDM0UsQ0FBQztTQUFDLE1BQU0sRUFBRyxLQUFLO0VBQUU7Q0FDNUI7O0NBRUEsVUFBVTs7O1FBakRQLGlCQUFpQixRQUFHLGtCQUNwQixNQUFNLEVBQUMsSUFBSSxjQUFJLElBQUksQ0FBQyxXQUFXLEVBQUksSUFBSSw0QkFBSSxJQUFJLENBQUMsTUFBTSxFQUFLLFVBQVUsNEJBQUksSUFBSSxDQUFDLE1BQU0sRUFBSyxRQUFRLFVBQ2pHLEdBQUcsRUFBQyxJQUFJO0dBQU8sRUFBRSxFQUFFLElBQUksQ0FBQyxXQUFXO0dBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0I7R0FBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7R0FBRSxnQkFBZ0IsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFJLENBQUM7R0FBRyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLGdCQUFnQixHQUFHLENBQUMsR0FBRyxXQUFXLE1BQU0sR0FBRzs7Ozs7UUFDck8saUJBQWlCLFFBQUcsaUJBQWlCLEVBQUMsTUFBTSxFQUFDLFFBQVEsV0FBSSxtQkFBbUIsRUFBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7Ozs7UUFDakcsd0JBQXdCLFFBQUcsaUJBQWlCLEVBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEtBQUssS0FBSyxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDOzs7O1FBQzdHLGtCQUFrQixRQUFHLGlCQUFpQixFQUFDLENBQUMsR0FBRyxVQUFVLElBQUksRUFBRTs7Ozs7Ozs7OztLQStDL0QsT0FBTztLQUNMLEdBQUcsV0FETCxPQUFPO0tBR0gsTUFBTSxxQkFGUixHQUFHOztTQUFILEdBQUc7O0tBS0gsU0FBTyxhQUxQLEdBQUc7S0FTRCxLQUFHLHFCQUpMLFNBQU87OztlQUlMLEtBQUcsaUJBQ0ssaUJBQWlCLHVCQUFJLFFBQVE7T0FDakMsS0FBSzs7T0FDSCxLQUFLLFdBRFAsS0FBSzs7MkJBQ0gsS0FBSzs7T0FDTCxJQUFJLGFBREosS0FBSztzQkFDTCxJQUFJOztXQUFKLElBQUk7O09BQWlELE1BQUksYUFBekQsSUFBSTtPQUF1RCxNQUFNLFdBQVosTUFBSTt3QkFBRSxNQUFNOztXQUFOLE1BQU07O09BQTBCLEtBQUssYUFBckMsTUFBTTt3QkFBMEIsS0FBSzs7V0FBTCxLQUFLO1dBQTNDLE1BQUk7V0FGM0QsS0FBSzs7OzsyQkFBTCxLQUFLO0tBQ0gsS0FBSzttQkFBTCxLQUFLOzZCQUZrQixRQUFRLHlCQUdBLFFBQVEsRUFBQyxJQUFJOytCQUhyQixRQUFRLHlCQUdvQyxRQUFRLEVBQUMsSUFBSTs7O1lBSHpELFFBQVE7NENBR21FLFFBQVEsRUFBQyxVQUFVLEVBQUssU0FBUyxJQUFHLFNBQVMsR0FBRyxVQUFVOztZQUhySSxRQUFROzRCQUdrSSxRQUFRLEVBQUMsZ0JBQWdCOztZQUhuSyxRQUFROzRDQUc4SixRQUFRLEVBQUMsZ0JBQWdCLEVBQUssQ0FBQyxJQUFHLGFBQWEsR0FBRyxjQUFjOzs7OztzQkFGek8sbUJBQW1CLEVBQUMsUUFBUSxPQUFDLFFBQVEsRUFBQyxFQUFFO2VBQWtCLE9BQU8sT0FBQyxrQkFBa0IsMkJBQUksa0JBQWtCLFNBQUssUUFBUSxFQUFDLFVBQVU7Ozs7WUEzRDVKLGtCQUFrQjtZQTBEVyxRQUFRO3NCQUVDLE9BQU8sT0FBQyxrQkFBa0IsMkJBQUksa0JBQWtCLFNBQUssUUFBUSxFQUFDLFVBQVU7Ozs7WUF6RTdHLG1CQUFtQjtZQXVFUyxRQUFROzRCQUVxRixtQkFBbUIsRUFBQyxRQUFRLE9BQUMsUUFBUSxFQUFDLEVBQUU7Ozs7O3FCQUE1SixLQUFLLFFBQTJLLGNBQWMsT0FBQyxRQUFRLEVBQUMsRUFBRTtzQkFENU0sS0FBSzs7Ozs7Ozs7U0FGVCxLQUFHOztzQkFBSCxLQUFHOzs7O09BUWtELENBQUM7O3NCQUFELENBQUM7Ozs7OztXQXRFdEQsaUJBQWlCO1dBVmhCLE1BQU07NEJBZ0ZGLGlCQUFpQixFQUFDLE1BQU0sMEJBQUksTUFBTSxHQUFLLE9BQU87Ozs7Ozs7Ozs7S0FDbkQsS0FBRztLQUFpQyxNQUFJLFdBQXhDLEtBQUc7c0JBQWlDLE1BQUk7O1NBQUosTUFBSTs7S0FBd00sUUFBTSxhQUFsTixNQUFJOztTQUF4QyxLQUFHOzt3QkFBSCxLQUFHOzs7O09BQ3FCLEdBQUM7d0JBQUQsR0FBQzs7V0FBRCxHQUFDOzs7O1dBbkV6QixrQkFBa0I7MkJBbUVrRCxrQkFBa0IsRUFBQyxXQUFXOzs7O3NCQUExRSxHQUFDOzs7OztjQUFyQixrQkFBa0I7Ozs7Ozs7Ozs7Ozs7T0FDTCxHQUFDO3dCQUFELEdBQUM7O1dBQUQsR0FBQzt5REFBd0MsV0FBVztzQkFBcEQsR0FBQzs7Ozs7Y0FBZCxXQUFXOzs7Ozs7Ozs7U0FmakIsU0FBTzs7d0JBQVAsU0FBTzs7OztPQXFCTCxLQUFHOztzQkFBSCxLQUFHOzs7Ozs7Ozs7U0FFSCxLQUFHO1NBQTZELEdBQUMscUJBQWpFLEtBQUc7MEJBQTZELEdBQUM7O2FBQUQsR0FBQzs7U0FBYSxRQUFNLGFBQXBCLEdBQUM7O2FBQWpFLEtBQUc7c0RBQWdFLEtBQUs7c0JBQU0sUUFBTSxFQUFXLFVBQVU7d0JBQXpHLEtBQUc7Ozs7Ozs7OztXQUVILEtBQUc7OztxQkFBSCxLQUFHLGlCQUNLLGdCQUFnQix1QkFBSSxJQUFJO2FBQzVCLE9BQU87O2FBQ0wsUUFBTSxXQURSLE9BQU87YUFFSCxNQUFJLFdBRE4sUUFBTTs4QkFDSixNQUFJOztpQkFBSixNQUFJOzthQUNKLE1BQUksYUFESixNQUFJO2FBQ3NCLFFBQU0sV0FBaEMsTUFBSTs4QkFBc0IsUUFBTTs7aUJBQU4sUUFBTTs7YUFBa0MsT0FBSyxhQUE3QyxRQUFNOzhCQUFrQyxPQUFLOztpQkFBTCxPQUFLO2lCQUF2RSxNQUFJOzthQUNKLE1BQUksYUFESixNQUFJOzs7aUJBRk4sUUFBTTs7Z0NBQU4sUUFBTTs7OztlQU1KLEtBQUc7ZUFBMEYsS0FBRyxxQkFBaEcsS0FBRzs7O3lCQUEwRixLQUFHLGtCQVI1RSxJQUFJLG1CQVFvRyxVQUFVLE9BQUMsSUFBSSwwQkFBSyxLQUFLO2lCQUFFLE1BQUk7bUNBQUosTUFBSTs7cUJBQUosTUFBSTsrREFBRSxLQUFLO2dDQUFYLE1BQUk7Ozs7Ozs7O21CQUE5RCxLQUFHO21CQUFoRyxLQUFHOzhCQUFILEtBQUc7Ozs7OzttQkFyR1YsUUFBUTttQkE2Rm1CLElBQUk7bURBT3RCLFFBQVEsU0FBSyxJQUFJLEVBQUMsV0FBVzs7Ozs7Ozs7OztpQkFObkMsT0FBTzs7OzttQ0FBUCxPQUFPOzRDQUFpQixRQUFRLFNBQUssSUFBSSxFQUFDLFdBQVc7OzsyQkFDbkQsUUFBTTtrQkEvRlgsUUFBUTtrQkE2Rm1CLElBQUk7a0RBRTJHLFFBQVEsU0FBSyxJQUFJLEVBQUMsV0FBVzs7O3VCQUNoSyxNQUFJO2tCQUhnQixJQUFJO2lFQUdHLElBQUksRUFBQyxVQUFVLEVBQUssU0FBUyxJQUFHLFNBQVMsR0FBRyxFQUFFOzs7O2tCQUhyRCxJQUFJOzRCQUdzRCxLQUFLLE9BQUMsSUFBSSxFQUFDLFVBQVUsS0FBSyxHQUFHOzs7cUNBSHZGLElBQUkseUJBSVUsSUFBSSxFQUFDLGdCQUFnQjs7O21DQUN2RCxNQUFJO3dDQUFhLFFBQVEsU0FBSyxJQUFJLEVBQUMsV0FBVzs7Ozs7a0JBTDFCLElBQUk7NEJBSWlELFNBQVMsT0FBQyxJQUFJLEVBQUMsVUFBVTs7O3dCQUo5RSxJQUFJLG1CQUlnRixVQUFVLE9BQUMsSUFBSSxHQUFFLE1BQU07OztrQkFKM0csSUFBSTs0Q0FJMEcsVUFBVSxPQUFDLElBQUksR0FBRSxNQUFNLEVBQUssQ0FBQyxJQUFHLE9BQU8sR0FBRyxTQUFTOzs7OzswQkFGdkwsUUFBTSxjQUE0QyxRQUFRLHdCQUFHLFFBQVEsU0FBSyxJQUFJLEVBQUMsV0FBVyxJQUFHLElBQUksU0FBRyxJQUFJLEVBQUMsV0FBVzs0QkFEdEgsT0FBTzs7Ozs7Ozs7ZUFGWCxLQUFHOzBCQUFILEtBQUc7Ozs7V0FlSCxLQUFHO1dBQWtMLFFBQU0scUJBQTNMLEtBQUc7O2VBQUgsS0FBRzt3QkFBa0wsUUFBTSxFQUErQixVQUFVOzBCQUFwTyxLQUFHOzs7Ozs7OztnQkE1R2dELGdCQUFnQjtnQ0E0RjVELGdCQUFnQixFQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNBRnZCLE1BQU0sR0FBSyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7OzhCQUZ2QixNQUFNLEdBQUssU0FBUzs7Ozs7Ozs7OztTQTFCMUIsT0FBTzs7d0JBQVAsT0FBTzs7OztPQXFETCxLQUFHO09BQ0QsSUFBSSxXQUROLEtBQUc7T0FFQyxRQUFNLFdBRFIsSUFBSTtPQUVGLE9BQUssYUFETCxRQUFNO09BQ2UsTUFBTSxxQkFBM0IsT0FBSzs7O1VBQW1DLFVBQVU7Ozs7Ozs7O09BQVksTUFBTSxXQUEvQyxNQUFNOztHQUFtQyxNQUFNLFNBQU4sTUFBTTs7MEJBQU4sTUFBTTs7O3dDQUFnRCxXQUFXLHVCQUFJLElBQUk7U0FBRSxRQUFNOzJCQUFOLFFBQU07O2FBQU4sUUFBTTs7Ozs7Ozs7c0RBQVEsSUFBSTtRQUFsQixRQUFNLFVBQU4sUUFBTSxpQkFBUSxJQUFJOzs7b0JBQXhCLElBQUksbUJBQXVCLFNBQVMsT0FBQyxJQUFJOzs7d0JBQW5DLFFBQU07Ozs7Ozs7O1dBQTFILE1BQU07V0FBM0IsT0FBSzs7T0FDTCxPQUFLLGFBREwsT0FBSztPQUNtQixPQUFLLHFCQUE3QixPQUFLOzsyQkFBbUIsT0FBSztXQUE3QixPQUFLOztPQUNMLE9BQUssYUFETCxPQUFLO09BQzRELE9BQUsscUJBQXRFLE9BQUs7OzJCQUE0RCxPQUFLO1dBQXRFLE9BQUs7OzBCQUFMLE9BQUs7Ozs7U0FDVSxHQUFDOzJCQUFELEdBQUM7O2FBQUQsR0FBQzt1REFBa0MsU0FBUzt3QkFBNUMsR0FBQzs7Ozs7Z0JBQVosU0FBUzs7Ozs7Ozs7O09BQ2IsTUFBRztPQUF3QixRQUFNLFdBQWpDLE1BQUc7T0FBcUcsUUFBTSxhQUFuRixRQUFNO3lCQUF1RSxRQUFNOztXQUFOLFFBQU07V0FBOUcsTUFBRztXQU5MLElBQUk7V0FETixLQUFHOzs7O0tBT3lHLFFBQU07K0JBQThHLE1BQU0sSUFBRyxTQUFTLEdBQUcsaUJBQWlCOzs7O1lBekgvTixNQUFNO1lBRTFDLFVBQVU7WUFBTyxnQkFBZ0I7WUFBTyxLQUFLOzRCQXVIMkcsTUFBTSxZQUFLLFVBQVUsWUFBSyxnQkFBZ0IsRUFBQyxJQUFJLGFBQU8sS0FBSyxFQUFDLElBQUk7Ozs7O29CQUx2TixRQUFNLEVBQXVDLFVBQVU7OztJQUNsQyxNQUFNO2FBQUMsR0FBVTtrQkFBRSxVQUFVOzthQUF0QixHQUFVO1dBQUUsVUFBVTs7Ozs7SUFDMUIsT0FBSzthQUFDLEdBQVU7a0JBQUUsZ0JBQWdCOzthQUE1QixHQUFVO1dBQUUsZ0JBQWdCOzs7OztJQUNPLE9BQUs7YUFBQyxHQUFVO2tCQUFFLEtBQUs7O2FBQWpCLEdBQVU7V0FBRSxLQUFLOzs7O29CQUU3RCxRQUFNLEVBQTJDLFVBQVU7cUJBTnhGLElBQUksbUJBQXlDLElBQUk7c0JBRG5ELEtBQUc7Ozs7O2NBREQsU0FBUzs7Ozs7Ozs7Ozs7OztPQWNYLE1BQUc7T0FDRCxNQUFHLFdBREwsTUFBRztPQUVDLFFBQU0sV0FEUixNQUFHO09BQ21FLEdBQUMsYUFBckUsUUFBTTt5QkFBOEQsR0FBQzs7V0FBRCxHQUFDOztPQUNyRSxHQUFDLGFBRG1FLEdBQUM7eUJBQ3JFLEdBQUM7O1dBQUQsR0FBQzs7T0FDRCxPQUFLLGFBREwsR0FBQzt5QkFDRCxPQUFLO09BQXVGLE9BQUs7OzJCQUFMLE9BQUs7V0FBakcsT0FBSzs7T0FDTCxNQUFHLGFBREgsT0FBSztPQUN3RCxHQUFDLHFCQUE5RCxNQUFHO3lCQUEwRCxHQUFDOztXQUFELEdBQUM7V0FBOUQsTUFBRzs7MkJBQUgsTUFBRzs7OztTQUNhLEdBQUM7MkJBQUQsR0FBQzs7YUFBRCxHQUFDO3VEQUFrQyxVQUFVO3dCQUE3QyxHQUFDOzs7OztnQkFBYixVQUFVOzs7Ozs7Ozs7T0FDZCxNQUFHO09BQXdCLFFBQU0sV0FBakMsTUFBRztPQUF3SCxTQUFNLGFBQXRHLFFBQU07eUJBQTBGLFNBQU07O1dBQU4sU0FBTTtXQUFqSSxNQUFHO1dBTkwsTUFBRztXQURMLE1BQUc7Ozs7O1lBbkhELGlCQUFpQjs0QkFxSGtGLGlCQUFpQixFQUFDLE1BQU07c0JBQUcsa0JBQWtCOzttRUFDakYsd0JBQXdCOzs7S0FJMUQsUUFBTSxrQkFBaUUsT0FBTztLQUFrQixTQUFNOzs7OztZQXhIbkksa0JBQWtCO3NCQXFIMEIsU0FBUyxPQUFDLGtCQUFrQixHQUFFLFdBQVc7Ozs7WUF2SHJGLGlCQUFpQjs0QkF3SGlELGlCQUFpQixFQUFDLEdBQUcsRUFBQyxRQUFRLEtBQUksUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSzs7OztZQW5JNUIsT0FBTztZQUE3RSxxQkFBcUI7NEJBcUk0SCxPQUFPLFlBQUsscUJBQXFCLEVBQUMsSUFBSTs7OztZQXJJakgsT0FBTztZQWF4RyxrQkFBa0I7OzRCQXdINk4sT0FBTztTQUFHLFVBQVU7a0JBQVksU0FBUyxPQUFDLGtCQUFrQixHQUFFLFdBQVc7Ozs7O29CQUx0VCxRQUFNLEVBQXVDLFVBQVU7OztJQUVxQyxPQUFLO2FBQUMsR0FBVTtrQkFBRSxxQkFBcUI7O2FBQWpDLEdBQVU7V0FBRSxxQkFBcUI7Ozs7b0JBR3hHLFFBQU0sRUFBMkMsVUFBVTtvQkFBcUMsU0FBTSxFQUE2RixZQUFZO3NCQVA5TyxNQUFHOzs7OztjQURELGNBQWM7Ozs7Ozs7Ozs7O0dBOURkLE1BQU07VUFqRUwsTUFBTTtVQUEwQixXQUFXOzBDQWlFeUUsTUFBTSxHQUFLLE9BQU8sbUJBQUssV0FBVyxFQUFDLE1BQU07Ozs7O0dBZ0JrRixRQUFNO1VBcEV0UCxpQkFBaUI7MEJBb0VtUixpQkFBaUIsRUFBQyxNQUFNLEdBQUcsQ0FBQzs7Ozs7VUFwRWhVLGlCQUFpQjtVQUVqQixrQkFBa0I7VUFEbEIsd0JBQXdCOzswQkFtRWtCLGlCQUFpQixFQUFDLE1BQU07Z0JBQU0saUJBQWlCLEVBQUMsTUFBTSxVQUFJLGtCQUFrQixFQUFDLFdBQVcsb0JBQWMsd0JBQXdCO09BQTJCLG9DQUFvQzs7Ozs7a0JBaEJ2TyxNQUFNLEVBQXlGLFVBQVU7a0JBZ0J1SSxRQUFNLEVBQXNGLFNBQVM7Ozs7Q0FyQjFWIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb3JtYWxpemF0aW9uLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8IS0tIEZJTi1FUElDLTAwMjogZG9jcy9qaXJhL3BlcnNvbmFsLWV4cGVuc2UvRklOLUVQSUMtMDAyLWNvcnJlY3RuZXNzLm1kIC0tPlxuPHNjcmlwdD5cbiAgaW1wb3J0IHsgY3JlYXRlUmVmZXJlbmNlUHJlZmVyZW5jZSwgZ2V0UmVmZXJlbmNlRW50aXR5VHlwZXMsIGdldFJlZmVyZW5jZVByZWZlcmVuY2VzLCBtZXJnZVJlZmVyZW5jZVByZWZlcmVuY2VzIH0gZnJvbSAnLi9saWIvYXBpLmpzJztcblxuICBsZXQgc3RhdHVzID0gJ2xvYWRpbmcnLCBlcnJvciA9ICcnLCBlbnRpdHlUeXBlcyA9IFtdLCBzYXZlZFByZWZlcmVuY2VzID0gW107XG4gIGxldCBleHBhbmRlZCA9IG51bGwsIHNob3dNb2RhbCA9IGZhbHNlLCBzYXZpbmcgPSBmYWxzZSwgZm9ybUVycm9yID0gJyc7XG4gIGxldCBzZWxlY3RlZE1lcmNoYW50SWRzID0gW10sIHByZWZlcnJlZE1lcmNoYW50TmFtZSA9ICcnLCBzaG93TWVyZ2VNb2RhbCA9IGZhbHNlLCBtZXJnZU5vdGljZSA9ICcnLCBtZXJnaW5nID0gZmFsc2UsIG1lcmdlRXJyb3IgPSAnJztcbiAgbGV0IGVudGl0eVR5cGUgPSAnJywgcHJpbWFyeVJlZmVyZW5jZSA9ICcnLCBhbGlhcyA9ICcnO1xuXG4gIGNvbnN0IGxhYmVscyA9IHsgTUVSQ0hBTlQ6ICdNZXJjaGFudCcsIEJFTkVGSUNJQVJZOiAnQmVuZWZpY2lhcnknLCBBQ0NPVU5UOiAnQWNjb3VudCcgfTtcbiAgY29uc3QgaWNvbnMgPSB7IE1FUkNIQU5UOiAnTScsIEJFTkVGSUNJQVJZOiAnQicsIEFDQ09VTlQ6ICfigrknIH07XG4gIGNvbnN0IHR5cGVMYWJlbCA9IHR5cGUgPT4gbGFiZWxzW3R5cGVdIHx8IHR5cGUucmVwbGFjZUFsbCgnXycsICcgJykudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9eLi8sIHZhbHVlID0+IHZhbHVlLnRvVXBwZXJDYXNlKCkpO1xuICBjb25zdCBhbGlhc2VzRm9yID0gaXRlbSA9PiAoaXRlbS5hbGlhc2VzIHx8IFtdKS5tYXAodmFsdWUgPT4gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlIDogdmFsdWUuYWxpYXMpLmZpbHRlcihCb29sZWFuKTtcbiAgY29uc3QgcHJlZmVyZW5jZXNGcm9tID0gZGF0YSA9PiBBcnJheS5pc0FycmF5KGRhdGEpID8gZGF0YSA6IChkYXRhPy5yZWZlcmVuY2VzIHx8IGRhdGE/LnJlZmVyZW5jZVByZWZlcmVuY2VzIHx8IGRhdGE/LnByZWZlcmVuY2VzIHx8IGRhdGE/Lml0ZW1zIHx8IFtdKTtcbiAgJDogbWVyY2hhbnRzRm9yTWVyZ2UgPSBzYXZlZFByZWZlcmVuY2VzXG4gICAgLmZpbHRlcihpdGVtID0+IGl0ZW0ucmVmZXJlbmNlSWQgIT0gbnVsbCAmJiBpdGVtLnN0YXR1cyAhPT0gJ0lOQUNUSVZFJyAmJiBpdGVtLnN0YXR1cyAhPT0gJ01FUkdFRCcpXG4gICAgLm1hcChpdGVtID0+ICh7IGlkOiBpdGVtLnJlZmVyZW5jZUlkLCBuYW1lOiBpdGVtLnByaW1hcnlSZWZlcmVuY2UsIGVudGl0eVR5cGU6IGl0ZW0uZW50aXR5VHlwZSwgdHJhbnNhY3Rpb25Db3VudDogTnVtYmVyKGl0ZW0udHJhbnNhY3Rpb25Db3VudCB8fCAwKSwgaWNvbjogaWNvbnNbaXRlbS5lbnRpdHlUeXBlXSB8fCBpdGVtLnByaW1hcnlSZWZlcmVuY2U/LlswXT8udG9VcHBlckNhc2UoKSB8fCAnUicgfSkpO1xuICAkOiBzZWxlY3RlZE1lcmNoYW50cyA9IG1lcmNoYW50c0Zvck1lcmdlLmZpbHRlcihtZXJjaGFudCA9PiBzZWxlY3RlZE1lcmNoYW50SWRzLmluY2x1ZGVzKG1lcmNoYW50LmlkKSk7XG4gICQ6IHNlbGVjdGVkVHJhbnNhY3Rpb25Db3VudCA9IHNlbGVjdGVkTWVyY2hhbnRzLnJlZHVjZSgodG90YWwsIG1lcmNoYW50KSA9PiB0b3RhbCArIG1lcmNoYW50LnRyYW5zYWN0aW9uQ291bnQsIDApO1xuICAkOiBzZWxlY3RlZEVudGl0eVR5cGUgPSBzZWxlY3RlZE1lcmNoYW50c1swXT8uZW50aXR5VHlwZSB8fCAnJztcbiAgZnVuY3Rpb24gdG9nZ2xlTWVyY2hhbnQoaWQpIHsgc2VsZWN0ZWRNZXJjaGFudElkcyA9IHNlbGVjdGVkTWVyY2hhbnRJZHMuaW5jbHVkZXMoaWQpID8gc2VsZWN0ZWRNZXJjaGFudElkcy5maWx0ZXIodmFsdWUgPT4gdmFsdWUgIT09IGlkKSA6IFsuLi5zZWxlY3RlZE1lcmNoYW50SWRzLCBpZF07IG1lcmdlTm90aWNlID0gJyc7IH1cbiAgZnVuY3Rpb24gb3Blbk1lcmdlKCkgeyBpZiAoc2VsZWN0ZWRNZXJjaGFudHMubGVuZ3RoIDwgMikgcmV0dXJuOyBwcmVmZXJyZWRNZXJjaGFudE5hbWUgPSBzZWxlY3RlZE1lcmNoYW50c1swXS5uYW1lOyBtZXJnZUVycm9yID0gJyc7IHNob3dNZXJnZU1vZGFsID0gdHJ1ZTsgfVxuICBmdW5jdGlvbiBjbG9zZU1lcmdlKCkgeyBpZiAoIW1lcmdpbmcpIHNob3dNZXJnZU1vZGFsID0gZmFsc2U7IH1cbiAgYXN5bmMgZnVuY3Rpb24gY29uZmlybU1lcmdlKCkge1xuICAgIGNvbnN0IG5hbWUgPSBwcmVmZXJyZWRNZXJjaGFudE5hbWUudHJpbSgpOyBpZiAoIW5hbWUgfHwgbWVyZ2luZykgcmV0dXJuO1xuICAgIG1lcmdpbmcgPSB0cnVlOyBtZXJnZUVycm9yID0gJyc7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG1lcmdlUmVmZXJlbmNlUHJlZmVyZW5jZXMoeyBlbnRpdHlUeXBlOiBzZWxlY3RlZEVudGl0eVR5cGUsIHJlZmVyZW5jZUlkczogc2VsZWN0ZWRNZXJjaGFudElkcywgY2Fub25pY2FsTmFtZTogbmFtZSB9KTtcbiAgICAgIGNvbnN0IHRyYW5zYWN0aW9uQ291bnQgPSByZXN1bHQ/LnVwZGF0ZWRUcmFuc2FjdGlvbkNvdW50ID8/IHNlbGVjdGVkVHJhbnNhY3Rpb25Db3VudDtcbiAgICAgIG1lcmdlTm90aWNlID0gYCR7dHJhbnNhY3Rpb25Db3VudH0gdHJhbnNhY3Rpb25zIGFyZSBub3cgZ3JvdXBlZCB1bmRlciAke3Jlc3VsdD8uY2Fub25pY2FsUmVmZXJlbmNlPy5uYW1lIHx8IG5hbWV9LmA7XG4gICAgICBzZWxlY3RlZE1lcmNoYW50SWRzID0gW107IHNob3dNZXJnZU1vZGFsID0gZmFsc2U7IGF3YWl0IHJlZnJlc2hQcmVmZXJlbmNlcygpO1xuICAgIH0gY2F0Y2ggKGNhdXNlKSB7IG1lcmdlRXJyb3IgPSBjYXVzZT8ubWVzc2FnZSB8fCAnQ291bGQgbm90IG1lcmdlIHRoZXNlIHJlZmVyZW5jZXMuJzsgfVxuICAgIGZpbmFsbHkgeyBtZXJnaW5nID0gZmFsc2U7IH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRTY3JlZW4oKSB7XG4gICAgc3RhdHVzID0gJ2xvYWRpbmcnOyBlcnJvciA9ICcnO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBbdHlwZURhdGEsIHByZWZlcmVuY2VEYXRhXSA9IGF3YWl0IFByb21pc2UuYWxsKFtnZXRSZWZlcmVuY2VFbnRpdHlUeXBlcygpLCBnZXRSZWZlcmVuY2VQcmVmZXJlbmNlcygpXSk7XG4gICAgICBlbnRpdHlUeXBlcyA9IHR5cGVEYXRhPy5lbnRpdHlUeXBlcyB8fCBbXTtcbiAgICAgIHNhdmVkUHJlZmVyZW5jZXMgPSBwcmVmZXJlbmNlc0Zyb20ocHJlZmVyZW5jZURhdGEpO1xuICAgICAgZW50aXR5VHlwZSA9IGVudGl0eVR5cGUgfHwgZW50aXR5VHlwZXNbMF0gfHwgJyc7XG4gICAgICBzdGF0dXMgPSAncmVhZHknO1xuICAgIH0gY2F0Y2ggKGNhdXNlKSB7IHN0YXR1cyA9ICdlcnJvcic7IGVycm9yID0gY2F1c2U/Lm1lc3NhZ2UgfHwgJ0NvdWxkIG5vdCBsb2FkIHJlZmVyZW5jZSBwcmVmZXJlbmNlcy4nOyB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiByZWZyZXNoUHJlZmVyZW5jZXMoKSB7IHNhdmVkUHJlZmVyZW5jZXMgPSBwcmVmZXJlbmNlc0Zyb20oYXdhaXQgZ2V0UmVmZXJlbmNlUHJlZmVyZW5jZXMoKSk7IH1cblxuICBmdW5jdGlvbiBvcGVuQ3JlYXRlKCkgeyBlbnRpdHlUeXBlID0gZW50aXR5VHlwZXNbMF0gfHwgJyc7IHByaW1hcnlSZWZlcmVuY2UgPSAnJzsgYWxpYXMgPSAnJzsgZm9ybUVycm9yID0gJyc7IHNob3dNb2RhbCA9IHRydWU7IH1cbiAgZnVuY3Rpb24gY2xvc2VNb2RhbCgpIHsgc2hvd01vZGFsID0gZmFsc2U7IH1cblxuICBhc3luYyBmdW5jdGlvbiBzYXZlKCkge1xuICAgIGNvbnN0IHByaW1hcnkgPSBwcmltYXJ5UmVmZXJlbmNlLnRyaW0oKSwgYWxpYXNWYWx1ZSA9IGFsaWFzLnRyaW0oKTtcbiAgICBpZiAoIWVudGl0eVR5cGUgfHwgIXByaW1hcnkgfHwgIWFsaWFzVmFsdWUpIHsgZm9ybUVycm9yID0gJ0NvbXBsZXRlIGFsbCB0aHJlZSBmaWVsZHMgYW5kIHByb3ZpZGUgYXQgbGVhc3Qgb25lIGFsaWFzLic7IHJldHVybjsgfVxuICAgIHNhdmluZyA9IHRydWU7IGZvcm1FcnJvciA9ICcnO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjcmVhdGVSZWZlcmVuY2VQcmVmZXJlbmNlKHsgZW50aXR5VHlwZSwgcHJpbWFyeVJlZmVyZW5jZTogcHJpbWFyeSwgYWxpYXM6IGFsaWFzVmFsdWUgfSk7XG4gICAgICBhd2FpdCByZWZyZXNoUHJlZmVyZW5jZXMoKTtcbiAgICAgIGNsb3NlTW9kYWwoKTtcbiAgICB9IGNhdGNoIChjYXVzZSkgeyBmb3JtRXJyb3IgPSBjYXVzZT8ubWVzc2FnZSB8fCAnQ291bGQgbm90IHNhdmUgdGhpcyBwcmVmZXJlbmNlLic7IH1cbiAgICBmaW5hbGx5IHsgc2F2aW5nID0gZmFsc2U7IH1cbiAgfVxuXG4gIGxvYWRTY3JlZW4oKTtcbjwvc2NyaXB0PlxuXG48c2VjdGlvbiBjbGFzcz1cIm5vcm1hbGl6YXRpb24tcGFnZVwiPlxuICA8ZGl2IGNsYXNzPVwibm9ybWFsaXphdGlvbi1oZWFkaW5nXCI+XG4gICAgPGRpdj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+RklYIFlPVVIgQUNDT1VOVFM8L3A+PGgxPkFjY291bnQgcmVwYWlyPC9oMT48cD5FZGl0LCBhZGQsIG9yIG1lcmdlIG1lcmNoYW50LCBiZW5lZmljaWFyeSwgYW5kIGFjY291bnQgbmFtZXMgc28geW91ciByZWNvcmRzIHN0YXkgY2xlYW4gYW5kIGNvbnNpc3RlbnQuPC9wPjwvZGl2PlxuICAgIDxidXR0b24gY2xhc3M9XCJhZGQtbm9ybWFsaXphdGlvblwiIHR5cGU9XCJidXR0b25cIiBhcmlhLWxhYmVsPVwiQWRkIHJlZmVyZW5jZSBwcmVmZXJlbmNlXCIgb246Y2xpY2s9e29wZW5DcmVhdGV9IGRpc2FibGVkPXtzdGF0dXMgIT09ICdyZWFkeScgfHwgIWVudGl0eVR5cGVzLmxlbmd0aH0+77yLPC9idXR0b24+XG4gIDwvZGl2PlxuXG4gIDxzZWN0aW9uIGNsYXNzPVwibWVyZ2Utd29ya3NwYWNlXCIgYXJpYS1sYWJlbGxlZGJ5PVwibWVyY2hhbnQtbWVyZ2UtdGl0bGVcIj5cbiAgICA8ZGl2IGNsYXNzPVwibWVyZ2UtdGl0bGUtcm93XCI+XG4gICAgICA8ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5SRUZFUkVOQ0UgQ0xFQU5VUDwvcD48aDIgaWQ9XCJtZXJjaGFudC1tZXJnZS10aXRsZVwiPk1lcmdlIG1hdGNoaW5nIG5hbWVzPC9oMj48cD5TZWxlY3QgdHdvIG9yIG1vcmUgbmFtZXMgb2YgdGhlIHNhbWUgdHlwZSwgdGhlbiBjaG9vc2UgdGhlIG5hbWUgdG8ga2VlcC48L3A+PC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cIm1lcmNoYW50LXNlbGVjdGlvblwiIGFyaWEtbGFiZWw9XCJTZWxlY3QgbWVyY2hhbnRzIHRvIG1lcmdlXCI+XG4gICAgICB7I2VhY2ggbWVyY2hhbnRzRm9yTWVyZ2UgYXMgbWVyY2hhbnR9XG4gICAgICAgIDxsYWJlbCBjbGFzczpzZWxlY3RlZD17c2VsZWN0ZWRNZXJjaGFudElkcy5pbmNsdWRlcyhtZXJjaGFudC5pZCl9IGNsYXNzOmJsb2NrZWQ9e0Jvb2xlYW4oc2VsZWN0ZWRFbnRpdHlUeXBlICYmIHNlbGVjdGVkRW50aXR5VHlwZSAhPT0gbWVyY2hhbnQuZW50aXR5VHlwZSl9IGNsYXNzPVwibWVyY2hhbnQtb3B0aW9uXCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRpc2FibGVkPXtCb29sZWFuKHNlbGVjdGVkRW50aXR5VHlwZSAmJiBzZWxlY3RlZEVudGl0eVR5cGUgIT09IG1lcmNoYW50LmVudGl0eVR5cGUpfSBjaGVja2VkPXtzZWxlY3RlZE1lcmNoYW50SWRzLmluY2x1ZGVzKG1lcmNoYW50LmlkKX0gb246Y2hhbmdlPXsoKSA9PiB0b2dnbGVNZXJjaGFudChtZXJjaGFudC5pZCl9IC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJtZXJnZS1sYWJlbC1pY29uXCI+e21lcmNoYW50Lmljb259PC9zcGFuPjxzcGFuPjxzdHJvbmc+e21lcmNoYW50Lm5hbWV9PC9zdHJvbmc+PHNtYWxsPnttZXJjaGFudC5lbnRpdHlUeXBlID09PSAnQUNDT1VOVCcgPyAnQWNjb3VudCcgOiAnTWVyY2hhbnQnfSDCtyB7bWVyY2hhbnQudHJhbnNhY3Rpb25Db3VudH0ge21lcmNoYW50LnRyYW5zYWN0aW9uQ291bnQgPT09IDEgPyAndHJhbnNhY3Rpb24nIDogJ3RyYW5zYWN0aW9ucyd9PC9zbWFsbD48L3NwYW4+XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICB7L2VhY2h9XG4gICAgPC9kaXY+XG4gICAgeyNpZiAhbWVyY2hhbnRzRm9yTWVyZ2UubGVuZ3RoICYmIHN0YXR1cyA9PT0gJ3JlYWR5J308cCBjbGFzcz1cIm1lcmdlLXR5cGUtbm90ZVwiPkFkZCBhdCBsZWFzdCB0d28gcmVmZXJlbmNlcyBvZiB0aGUgc2FtZSB0eXBlIGJlZm9yZSBtZXJnaW5nIHRoZW0uPC9wPnsvaWZ9XG4gICAgPGRpdiBjbGFzcz1cIm1lcmdlLXNlbGVjdGlvbi1mb290ZXJcIj48c3Bhbj57c2VsZWN0ZWRNZXJjaGFudHMubGVuZ3RoID8gYCR7c2VsZWN0ZWRNZXJjaGFudHMubGVuZ3RofSAke3NlbGVjdGVkRW50aXR5VHlwZS50b0xvd2VyQ2FzZSgpfSBuYW1lcyDCtyAke3NlbGVjdGVkVHJhbnNhY3Rpb25Db3VudH0gdHJhbnNhY3Rpb25zIHNlbGVjdGVkYCA6ICdTZWxlY3QgYXQgbGVhc3QgdHdvIG5hbWVzIHRvIG1lcmdlJ308L3NwYW4+PGJ1dHRvbiBjbGFzcz1cIm1lcmdlLWJ1dHRvblwiIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17c2VsZWN0ZWRNZXJjaGFudHMubGVuZ3RoIDwgMn0gb246Y2xpY2s9e29wZW5NZXJnZX0+TWVyZ2Ugc2VsZWN0ZWQ8L2J1dHRvbj48L2Rpdj5cbiAgICB7I2lmIHNlbGVjdGVkRW50aXR5VHlwZX08cCBjbGFzcz1cIm1lcmdlLXR5cGUtbm90ZVwiPllvdeKAmXJlIHNlbGVjdGluZyB7c2VsZWN0ZWRFbnRpdHlUeXBlLnRvTG93ZXJDYXNlKCl9IHJlZmVyZW5jZXMuIERlc2VsZWN0IHRoZW0gYmVmb3JlIGNob29zaW5nIGEgZGlmZmVyZW50IHJlZmVyZW5jZSB0eXBlLjwvcD57L2lmfVxuICAgIHsjaWYgbWVyZ2VOb3RpY2V9PHAgY2xhc3M9XCJtZXJnZS1zdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPuKckyB7bWVyZ2VOb3RpY2V9PC9wPnsvaWZ9XG4gIDwvc2VjdGlvbj5cblxuICA8ZGl2IGNsYXNzPVwic2F2ZWQtcHJlZmVyZW5jZXMtaGVhZGluZ1wiPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5TQVZFRCBOQU1FUzwvcD48aDI+WW91ciBub3JtYWxpemF0aW9uIHJ1bGVzPC9oMj48L2Rpdj5cblxuICB7I2lmIHN0YXR1cyA9PT0gJ2xvYWRpbmcnfVxuICAgIDxkaXYgY2xhc3M9XCJza2VsZXRvbi1wYW5lbCBub3JtYWxpemF0aW9uLXNrZWxldG9uXCI+PGk+PC9pPjxiPjwvYj48Yj48L2I+PGI+PC9iPjwvZGl2PlxuICB7OmVsc2UgaWYgc3RhdHVzID09PSAnZXJyb3InfVxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWVycm9yXCI+PGgyPk5vcm1hbGl6YXRpb24gaXMgdW5hdmFpbGFibGU8L2gyPjxwPntlcnJvcn08L3A+PGJ1dHRvbiBvbjpjbGljaz17bG9hZFNjcmVlbn0+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+XG4gIHs6ZWxzZSBpZiBzYXZlZFByZWZlcmVuY2VzLmxlbmd0aH1cbiAgICA8ZGl2IGNsYXNzPVwibm9ybWFsaXphdGlvbi1saXN0XCI+XG4gICAgICB7I2VhY2ggc2F2ZWRQcmVmZXJlbmNlcyBhcyBpdGVtfVxuICAgICAgICA8YXJ0aWNsZSBjbGFzczpleHBhbmRlZD17ZXhwYW5kZWQgPT09IGl0ZW0ucmVmZXJlbmNlSWR9IGNsYXNzPVwibm9ybWFsaXphdGlvbi1yb3dcIj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwibm9ybWFsaXphdGlvbi1tYWluXCIgb246Y2xpY2s9eygpID0+IGV4cGFuZGVkID0gZXhwYW5kZWQgPT09IGl0ZW0ucmVmZXJlbmNlSWQgPyBudWxsIDogaXRlbS5yZWZlcmVuY2VJZH0gYXJpYS1leHBhbmRlZD17ZXhwYW5kZWQgPT09IGl0ZW0ucmVmZXJlbmNlSWR9PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9e2BlbnRpdHktaWNvbiAke2l0ZW0uZW50aXR5VHlwZSA9PT0gJ0FDQ09VTlQnID8gJ2FjY291bnQnIDogJyd9YH0+e2ljb25zW2l0ZW0uZW50aXR5VHlwZV0gfHwgJ1InfTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZW50aXR5LWNvcHlcIj48c3Ryb25nPntpdGVtLnByaW1hcnlSZWZlcmVuY2V9PC9zdHJvbmc+PHNtYWxsPnt0eXBlTGFiZWwoaXRlbS5lbnRpdHlUeXBlKX0gwrcge2FsaWFzZXNGb3IoaXRlbSkubGVuZ3RofSB7YWxpYXNlc0ZvcihpdGVtKS5sZW5ndGggPT09IDEgPyAnYWxpYXMnIDogJ2FsaWFzZXMnfTwvc21hbGw+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M6b3Blbj17ZXhwYW5kZWQgPT09IGl0ZW0ucmVmZXJlbmNlSWR9IGNsYXNzPVwibm9ybWFsaXphdGlvbi1jaGV2cm9uXCI+4oyEPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIHsjaWYgZXhwYW5kZWQgPT09IGl0ZW0ucmVmZXJlbmNlSWR9XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWxpYXMtZGV0YWlsc1wiPjxkaXYgY2xhc3M9XCJhbGlhcy1sYWJlbFwiPjxzcGFuPllvdXIgcHJlZmVycmVkIGFsaWFzZXM8L3NwYW4+PC9kaXY+PGRpdiBjbGFzcz1cImFsaWFzLXBpbGxzXCI+eyNlYWNoIGFsaWFzZXNGb3IoaXRlbSkgYXMgdmFsdWV9PHNwYW4+e3ZhbHVlfTwvc3Bhbj57L2VhY2h9PC9kaXY+PC9kaXY+XG4gICAgICAgICAgey9pZn1cbiAgICAgICAgPC9hcnRpY2xlPlxuICAgICAgey9lYWNofVxuICAgIDwvZGl2PlxuICB7OmVsc2V9XG4gICAgPGRpdiBjbGFzcz1cImVtcHR5LXN0YXRlIG5vcm1hbGl6YXRpb24tZW1wdHlcIj48c3Bhbj7iiYs8L3NwYW4+PGgyPkFkZCB5b3VyIGZpcnN0IHByZWZlcnJlZCBuYW1lPC9oMj48cD5DaG9vc2UgYSByZWZlcmVuY2UgdHlwZSwgdGhlbiBlbnRlciBpdHMgcHJpbWFyeSBuYW1lIGFuZCB0aGUgYWxpYXNlcyB5b3UgdXNlLjwvcD48YnV0dG9uIGNsYXNzPVwid2lkZS1idXR0b25cIiBvbjpjbGljaz17b3BlbkNyZWF0ZX0+77yLIEFkZCBhIHByZWZlcmVuY2U8L2J1dHRvbj48L2Rpdj5cbiAgey9pZn1cblxuICA8YXNpZGUgY2xhc3M9XCJub3JtYWxpemF0aW9uLXRpcFwiPjxzcGFuPuKcpjwvc3Bhbj48cD48c3Ryb25nPkhvdyBhbGlhc2VzIHdvcms8L3N0cm9uZz4g4oCcSERGQyBjcmVkaXQgY2FyZOKAnSBjYW4gYWxzbyByZXNwb25kIHRvIOKAnGNyZWRpdCBjYXJk4oCdIG9yIOKAnGNj4oCdLiBFbnRlciBtdWx0aXBsZSBhbGlhc2VzIHNlcGFyYXRlZCBieSBjb21tYXMuPC9wPjwvYXNpZGU+XG48L3NlY3Rpb24+XG5cbnsjaWYgc2hvd01vZGFsfVxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3Agbm9ybWFsaXphdGlvbi1tb2RhbC1iYWNrZHJvcFwiPlxuICAgIDxmb3JtIGNsYXNzPVwibW9kYWxcIiBvbjpzdWJtaXR8cHJldmVudERlZmF1bHQ9e3NhdmV9PlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgdHlwZT1cImJ1dHRvblwiIG9uOmNsaWNrPXtjbG9zZU1vZGFsfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5BREQgUFJFRkVSRU5DRTwvcD48aDI+QWRkIGEgcHJlZmVycmVkIG5hbWU8L2gyPlxuICAgICAgPGxhYmVsPlJlZmVyZW5jZSB0eXBlPHNlbGVjdCBiaW5kOnZhbHVlPXtlbnRpdHlUeXBlfSByZXF1aXJlZD48b3B0aW9uIHZhbHVlPVwiXCIgZGlzYWJsZWQ+U2VsZWN0IGEgdHlwZTwvb3B0aW9uPnsjZWFjaCBlbnRpdHlUeXBlcyBhcyB0eXBlfTxvcHRpb24gdmFsdWU9e3R5cGV9Pnt0eXBlTGFiZWwodHlwZSl9PC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+XG4gICAgICA8bGFiZWw+UHJpbWFyeSByZWZlcmVuY2U8aW5wdXQgYmluZDp2YWx1ZT17cHJpbWFyeVJlZmVyZW5jZX0gcGxhY2Vob2xkZXI9XCJlLmcuIEFtYXpvblwiIHJlcXVpcmVkIC8+PC9sYWJlbD5cbiAgICAgIDxsYWJlbD5BbGlhc2VzIDxzcGFuIGNsYXNzPVwib3B0aW9uYWxcIj5TZXBhcmF0ZSB3aXRoIGNvbW1hczwvc3Bhbj48aW5wdXQgYmluZDp2YWx1ZT17YWxpYXN9IHBsYWNlaG9sZGVyPVwiZS5nLiBBTVpOLCBBbWF6b24gSW5kaWEsIEFtYXpvbiBTdG9yZVwiIHJlcXVpcmVkIC8+PC9sYWJlbD5cbiAgICAgIHsjaWYgZm9ybUVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiIHJvbGU9XCJhbGVydFwiPntmb3JtRXJyb3J9PC9wPnsvaWZ9XG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiB0eXBlPVwiYnV0dG9uXCIgb246Y2xpY2s9e2Nsb3NlTW9kYWx9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtzYXZpbmcgfHwgIWVudGl0eVR5cGUgfHwgIXByaW1hcnlSZWZlcmVuY2UudHJpbSgpIHx8ICFhbGlhcy50cmltKCl9PntzYXZpbmcgPyAnU2F2aW5n4oCmJyA6ICdTYXZlIHByZWZlcmVuY2UnfTwvYnV0dG9uPjwvZGl2PlxuICAgIDwvZm9ybT5cbiAgPC9kaXY+XG57L2lmfVxuXG57I2lmIHNob3dNZXJnZU1vZGFsfVxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3Agbm9ybWFsaXphdGlvbi1tb2RhbC1iYWNrZHJvcFwiPlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbCBtZXJnZS1tb2RhbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIGFyaWEtbGFiZWxsZWRieT1cIm1lcmdlLW1vZGFsLXRpdGxlXCIgdGFiaW5kZXg9XCItMVwiPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgdHlwZT1cImJ1dHRvblwiIG9uOmNsaWNrPXtjbG9zZU1lcmdlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5NRVJHRSB7c2VsZWN0ZWRNZXJjaGFudHMubGVuZ3RofSB7c2VsZWN0ZWRFbnRpdHlUeXBlfSBOQU1FUzwvcD48aDIgaWQ9XCJtZXJnZS1tb2RhbC10aXRsZVwiPkNob29zZSB0aGUgbmFtZSB0byBrZWVwPC9oMj5cbiAgICAgIDxwIGNsYXNzPVwibWVyZ2UtbW9kYWwtY29weVwiPkVudGVyIG9uZSBuYW1lIHRvIHVzZSBhY3Jvc3MgYWxsIHtzZWxlY3RlZFRyYW5zYWN0aW9uQ291bnR9IHNlbGVjdGVkIHRyYW5zYWN0aW9ucy4gVGhlIHNlbGVjdGVkIGxhYmVscyB3aWxsIHJlbWFpbiBhcyBhbGlhc2VzLjwvcD5cbiAgICAgIDxsYWJlbCBjbGFzcz1cIm1lcmdlLW5hbWUtZmllbGRcIj5QcmVmZXJyZWQge3R5cGVMYWJlbChzZWxlY3RlZEVudGl0eVR5cGUpLnRvTG93ZXJDYXNlKCl9IG5hbWU8aW5wdXQgYmluZDp2YWx1ZT17cHJlZmVycmVkTWVyY2hhbnROYW1lfSBwbGFjZWhvbGRlcj1cImUuZy4gSERGQyBCYW5rXCIgYXV0b2NvbXBsZXRlPVwib2ZmXCIgLz48L2xhYmVsPlxuICAgICAgPGRpdiBjbGFzcz1cIm1lcmdlLW1vZGFsLXNlbGVjdGVkXCI+PHNwYW4+U2VsZWN0ZWQgbmFtZXM8L3NwYW4+PHA+e3NlbGVjdGVkTWVyY2hhbnRzLm1hcChtZXJjaGFudCA9PiBtZXJjaGFudC5uYW1lKS5qb2luKCcgwrcgJyl9PC9wPjwvZGl2PlxuICAgICAgeyNpZiBtZXJnZUVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiIHJvbGU9XCJhbGVydFwiPnttZXJnZUVycm9yfTwvcD57L2lmfVxuICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgdHlwZT1cImJ1dHRvblwiIG9uOmNsaWNrPXtjbG9zZU1lcmdlfSBkaXNhYmxlZD17bWVyZ2luZ30+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e21lcmdpbmcgfHwgIXByZWZlcnJlZE1lcmNoYW50TmFtZS50cmltKCl9IG9uOmNsaWNrPXtjb25maXJtTWVyZ2V9PnttZXJnaW5nID8gJ01lcmdpbmfigKYnIDogYE1lcmdlICR7dHlwZUxhYmVsKHNlbGVjdGVkRW50aXR5VHlwZSkudG9Mb3dlckNhc2UoKX1zYH08L2J1dHRvbj48L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG57L2lmfVxuIl0sImZpbGUiOiIvVXNlcnMvZGVlbmEvRG9jdW1lbnRzL0dpdEh1Yi9wZXJzb25hbC1haS9mcm9udGVuZC9zcmMvTm9ybWFsaXphdGlvbi5zdmVsdGUifQ==