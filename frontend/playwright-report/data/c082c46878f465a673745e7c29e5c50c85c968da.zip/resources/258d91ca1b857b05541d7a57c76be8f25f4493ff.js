import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DueReminder.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

DueReminder[$.FILENAME] = 'src/components/DueReminder.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root_1 = $.add_locations($.from_html(`<button type="button" class="due-reminder-action s-zNkWtnn4i3-J"> </button>`), DueReminder[$.FILENAME], [[19, 4]]);
var root = $.add_locations($.from_html(`<div class="due-reminder s-zNkWtnn4i3-J" role="status"><span class="due-reminder-detail s-zNkWtnn4i3-J"><span aria-hidden="true" class="s-zNkWtnn4i3-J">●</span> </span> <!></div>`), DueReminder[$.FILENAME], [[16, 0, [[17, 2, [[17, 36]]]]]]);

function DueReminder($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, DueReminder);

	let detail = $.prop($$props, 'detail', 8);
	let actionLabel = $.prop($$props, 'actionLabel', 8, '');
	let onAction = $.prop($$props, 'onAction', 8, () => {});
	let testId = $.prop($$props, 'testId', 8, undefined);

	function handleKeydown(event) {
		if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
			event.preventDefault();
			event.stopPropagation();
			onAction()();
		}
	}

	var $$exports = { ...$.legacy_api() };

	$.init();

	var div = root();
	var span = $.child(div);
	var text = $.sibling($.child(span));

	$.reset(span);

	var node = $.sibling(span, 2);

	{
		var consequent = ($$anchor) => {
			var button = root_1();
			var text_1 = $.child(button, true);

			$.reset(button);
			$.template_effect(() => $.set_text(text_1, actionLabel()));

			$.event('click', button, $.stopPropagation(function (...$$args) {
				$.apply(onAction, this, $$args, DueReminder, [19, 80]);
			}));

			$.event('keydown', button, handleKeydown);
			$.append($$anchor, button);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if (actionLabel()) $$render(consequent);
			}),
			'if',
			DueReminder,
			18,
			2
		);
	}

	$.reset(div);

	$.template_effect(() => {
		$.set_attribute(div, 'data-testid', testId());
		$.set_text(text, ` ${detail() ?? ''}`);
	});

	$.append($$anchor, div);

	return $.pop($$exports);
}

if (import.meta.hot) {
	DueReminder = $.hmr(DueReminder, () => DueReminder[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		$.cleanup_styles('s-zNkWtnn4i3-J');
		module.default[$.HMR].source = DueReminder[$.HMR].source;
		$.set(DueReminder[$.HMR].source, module.default[$.HMR].original);
	});
}

export default DueReminder;
import "/src/components/DueReminder.svelte?svelte&type=style&lang.css";

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozt3Q0FBQSxDQUFDOzs7O0tBQ1ksTUFBTTtLQUNOLFdBQVcscUNBQUcsRUFBRTtLQUNoQixRQUFRLHdDQUFTLENBQUMsQ0FBQztLQUNuQixNQUFNLGdDQUFHLFNBQVM7O1VBRXBCLGFBQWEsQ0FBQyxLQUFLLEVBQUU7c0JBQ3hCLEtBQUssQ0FBQyxHQUFHLEVBQUssT0FBTyxxQkFBSSxLQUFLLENBQUMsR0FBRyxFQUFLLEdBQUcsR0FBRTtHQUM5QyxLQUFLLENBQUMsY0FBYztHQUNwQixLQUFLLENBQUMsZUFBZTtHQUNyQixRQUFRO0VBQ1Y7Q0FDRjs7Ozs7O0tBR0QsR0FBRztLQUNELElBQUksV0FETixHQUFHOzhCQUNELElBQUk7O1NBQUosSUFBSTs7c0JBQUosSUFBSTs7OztPQUVGLE1BQU07d0JBQU4sTUFBTTs7V0FBTixNQUFNOzhDQUEyRyxXQUFXOztvQkFBNUgsTUFBTTtZQUFxRSxRQUFROzs7c0JBQW5GLE1BQU0sRUFBMkYsYUFBYTtzQkFBOUcsTUFBTTs7Ozs7UUFESixXQUFXOzs7Ozs7Ozs7U0FGakIsR0FBRzs7O2tCQUFILEdBQUcsaUJBQW1DLE1BQU07dUJBQzBCLE1BQU07OztvQkFENUUsR0FBRzs7O0NBRkoiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkR1ZVJlbWluZGVyLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0PlxuICBleHBvcnQgbGV0IGRldGFpbDtcbiAgZXhwb3J0IGxldCBhY3Rpb25MYWJlbCA9ICcnO1xuICBleHBvcnQgbGV0IG9uQWN0aW9uID0gKCkgPT4ge307XG4gIGV4cG9ydCBsZXQgdGVzdElkID0gdW5kZWZpbmVkO1xuXG4gIGZ1bmN0aW9uIGhhbmRsZUtleWRvd24oZXZlbnQpIHtcbiAgICBpZiAoZXZlbnQua2V5ID09PSAnRW50ZXInIHx8IGV2ZW50LmtleSA9PT0gJyAnKSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICBvbkFjdGlvbigpO1xuICAgIH1cbiAgfVxuPC9zY3JpcHQ+XG5cbjxkaXYgY2xhc3M9XCJkdWUtcmVtaW5kZXJcIiBkYXRhLXRlc3RpZD17dGVzdElkfSByb2xlPVwic3RhdHVzXCI+XG4gIDxzcGFuIGNsYXNzPVwiZHVlLXJlbWluZGVyLWRldGFpbFwiPjxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKXjzwvc3Bhbj4ge2RldGFpbH08L3NwYW4+XG4gIHsjaWYgYWN0aW9uTGFiZWx9XG4gICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJkdWUtcmVtaW5kZXItYWN0aW9uXCIgb246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uPXtvbkFjdGlvbn0gb246a2V5ZG93bj17aGFuZGxlS2V5ZG93bn0+e2FjdGlvbkxhYmVsfTwvYnV0dG9uPlxuICB7L2lmfVxuPC9kaXY+XG5cbjxzdHlsZT5cbiAgLmR1ZS1yZW1pbmRlcntkaXNwbGF5OmZsZXg7d2lkdGg6MTAwJTttYXgtd2lkdGg6MTAwJTthbGlnbi1pdGVtczpjZW50ZXI7anVzdGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47Z2FwOjEwcHg7bWFyZ2luOjEwcHggMCAwO3BhZGRpbmc6OXB4IDEwcHg7Ym9yZGVyOjFweCBzb2xpZCAjZTRhNDljO2JvcmRlci1yYWRpdXM6MTBweDtiYWNrZ3JvdW5kOiNmZmY0ZjE7Y29sb3I6I2EzNDYzNTtmb250OjcwMCA5cHgvMS4zNSAnRE0gU2Fucycsc2Fucy1zZXJpZjt2ZXJ0aWNhbC1hbGlnbjp0b3B9XG4gIC5kdWUtcmVtaW5kZXItZGV0YWlse21pbi13aWR0aDowfVxuICAuZHVlLXJlbWluZGVyLWFjdGlvbntmbGV4OjAgMCBhdXRvO21hcmdpbjowO3BhZGRpbmc6MDtib3JkZXI6MDtib3JkZXItcmFkaXVzOjA7YmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjppbmhlcml0O2ZvbnQ6ODAwIDlweC8xLjM1ICdETSBTYW5zJyxzYW5zLXNlcmlmO3doaXRlLXNwYWNlOm5vd3JhcDt0ZXh0LWRlY29yYXRpb246dW5kZXJsaW5lO3RleHQtdW5kZXJsaW5lLW9mZnNldDozcHg7Y3Vyc29yOnBvaW50ZXJ9XG4gIC5kdWUtcmVtaW5kZXItYWN0aW9uOmZvY3VzLXZpc2libGV7b3V0bGluZToycHggc29saWQgY3VycmVudENvbG9yO291dGxpbmUtb2Zmc2V0OjNweDtib3JkZXItcmFkaXVzOjJweH1cbjwvc3R5bGU+XG4iXSwiZmlsZSI6Ii9Vc2Vycy9kZWVuYS9Eb2N1bWVudHMvR2l0SHViL3BlcnNvbmFsLWFpL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0R1ZVJlbWluZGVyLnN2ZWx0ZSJ9