import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Home.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

Home[$.FILENAME] = 'src/Home.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";
import "/src/commitment.css";
import "/src/components/detail-sheet.css";
import { onMount, tick } from "/node_modules/.vite/deps/svelte.js?v=e89ac925";

import {
	ApiError,
	completeAction,
	completeRecurringCommitment,
	confirmSipOccurrence,
	confirmStockMonthlyPlan,
	createCreditCard,
	createLoan,
	createMissingDateContext,
	createMutualFund,
	createMutualFundLumpSum,
	createMutualFundSip,
	createStock,
	createStockMonthlyPlan,
	createRecurringCommitment,
	deleteExpense,
	deleteLoan,
	deleteMutualFund,
	deleteRecurringCommitment,
	deleteStock,
	getActions,
	getCommitmentReview,
	getCreditCards,
	getExpenseOptions,
	getExpensesForDate,
	getIncomeOutlook,
	getLoanHistory,
	getLoans,
	getMutualFund,
	getMutualFunds,
	getRecurringCommitmentHistory,
	getRecurringCommitments,
	getStock,
	getStocks,
	logout,
	markLoanEmiPaid,
	resolveCommitmentReview,
	saveIncomeProfile,
	searchMutualFunds,
	searchStocks,
	updateCreditCard,
	updateExpense,
	updateLoan,
	updateRecurringCommitment,
	updateSipOccurrence,
	updateMutualFundTransaction
} from "/src/lib/api.js";

import SectionState from "/src/SectionState.svelte";
import Normalization from "/src/Normalization.svelte";
import AppHeader from "/src/components/AppHeader.svelte";
import BottomNav from "/src/components/BottomNav.svelte";
import DueReminder from "/src/components/DueReminder.svelte";
import ViewDetailsLink from "/src/components/ViewDetailsLink.svelte";
import ClosedLoanRow from "/src/components/ClosedLoanRow.svelte";
import ProfileSettings from "/src/features/profile/ProfileSettings.svelte";

var root_2 = $.add_locations($.from_html(`<p>Loading payment history…</p>`), Home[$.FILENAME], [[165, 300]]);
var root_4 = $.add_locations($.from_html(`<p> </p>`), Home[$.FILENAME], [[165, 369]]);
var root_8 = $.add_locations($.from_html(`<div class="loan-history-action"><!></div>`), Home[$.FILENAME], [[165, 929]]);

var root_7 = $.add_locations($.from_html(`<div><span> </span><strong> </strong><span class="history-amount"><b> </b></span><small> </small><!></div>`), Home[$.FILENAME], [
	[
		165,
		527,
		[[165, 596], [165, 635], [165, 681, [[165, 710]]], [165, 770]]
	]
]);

var root_9 = $.add_locations($.from_html(`<p>No payments recorded yet.</p>`), Home[$.FILENAME], [[165, 1155]]);
var root_5 = $.add_locations($.from_html(`<section class="investment-history"><h3>EMI timeline</h3><!></section>`), Home[$.FILENAME], [[165, 401, [[165, 437]]]]);
var root_1 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">LOAN DETAILS</p><h2> </h2><!></section></div>`), Home[$.FILENAME], [[165, 17, [[165, 64, [[165, 131], [165, 195], [165, 234]]]]]]);
var root_11 = $.add_locations($.from_html(`<p>Loading payment history…</p>`), Home[$.FILENAME], [[166, 327]]);
var root_13 = $.add_locations($.from_html(`<p> </p>`), Home[$.FILENAME], [[166, 402]]);

var root_16 = $.add_locations($.from_html(`<div class="investment-history-row"><span> </span><strong> </strong><span class="history-amount"><b> </b></span><small> </small></div>`), Home[$.FILENAME], [
	[
		166,
		581,
		[[166, 617], [166, 656], [166, 706, [[166, 735]]], [166, 790]]
	]
]);

var root_17 = $.add_locations($.from_html(`<p>No payments recorded yet.</p>`), Home[$.FILENAME], [[166, 863]]);
var root_14 = $.add_locations($.from_html(`<section class="investment-history"><h3>Payment history</h3><!></section>`), Home[$.FILENAME], [[166, 440, [[166, 476]]]]);
var root_10 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">COMMITMENT DETAILS</p><h2> </h2><!></section></div>`), Home[$.FILENAME], [[166, 23, [[166, 70, [[166, 137], [166, 207], [166, 252]]]]]]);

var root_18 = $.add_locations($.from_html(`<section class="offline-notice"><span>◌</span><div><strong> </strong><p> </p></div><button>Retry</button></section>`), Home[$.FILENAME], [
	[
		170,
		34,
		[[170, 66], [170, 80, [[170, 85], [170, 166]]], [170, 323]]
	]
]);

var root_20 = $.add_locations($.from_html(`<button class="spending-hero"><span>MONTHLY SPENDING</span><strong> <small>spent</small></strong><b> </b></button>`), Home[$.FILENAME], [
	[173, 92, [[173, 162], [173, 191, [[173, 224]]], [173, 253]]]
]);

var root_23 = $.add_locations($.from_html(`<button></button>`), Home[$.FILENAME], [[174, 475]]);

var root_24 = $.add_locations($.from_html(`<button><span class="story-source"> </span><strong> </strong><b> </b><i>›</i></button>`), Home[$.FILENAME], [
	[
		174,
		1088,
		[[174, 1217], [174, 1271], [174, 1318], [174, 1360]]
	]
]);

var root_22 = $.add_locations($.from_html(`<div class="story-carousel" aria-label="Your stories"><div class="story-dots" aria-label="Choose a story"><!><span> </span></div><div class="story-carousel-viewport"><div class="story-carousel-track"></div></div></div>`), Home[$.FILENAME], [
	[
		174,
		335,
		[[174, 389, [[174, 723]]], [174, 783, [[174, 957]]]]
	]
]);

var root_25 = $.add_locations($.from_html(`<div class="story-rail-empty">Your stories will appear here as you add expenses.</div>`), Home[$.FILENAME], [[174, 1409]]);

var root_26 = $.add_locations($.from_html(`<button class="row-main"><div><strong> </strong><span> </span></div><b> </b></button>`), Home[$.FILENAME], [
	[175, 293, [[175, 377, [[175, 382], [175, 415]]], [175, 487]]]
]);

var root_27 = $.add_locations($.from_html(`<p class="empty-copy">No expenses recorded yet.</p>`), Home[$.FILENAME], [[175, 532]]);

var root_19 = $.add_locations($.from_html(`<section class="app-heading"><div><p class="micro-label"> </p><h1> </h1><p>Here’s how your month is unfolding.</p></div></section> <!> <section class="home-section"><div class="section-title"><div><p class="micro-label">YOUR STORIES</p><h2>Small signals, clearly told</h2></div><button class="text-link">See all</button></div><!></section> <section class="home-section"><div class="section-title"><div><p class="micro-label">RECENT ACTIVITY</p><h2>Your latest expenses</h2></div><button class="text-link">See all</button></div><div class="compact-list"></div></section> <button class="your-money-card"><span>◒</span><div><strong>Your money</strong><small>See your incoming and outgoing plan, only when you’re ready.</small></div><b>Explore ›</b></button>`, 1), Home[$.FILENAME], [
	[172, 2, [[172, 31, [[172, 36], [172, 104], [172, 125]]]]],

	[
		174,
		2,
		[[174, 32, [[174, 59, [[174, 64], [174, 103]]], [174, 145]]]]
	],

	[
		175,
		2,

		[
			[175, 32, [[175, 59, [[175, 64], [175, 106]]], [175, 141]]],
			[175, 229]
		]
	],

	[
		176,
		2,
		[[176, 55], [176, 69, [[176, 74], [176, 101]]], [176, 182]]
	]
]);

var root_31 = $.add_locations($.from_html(`<span> </span>`), Home[$.FILENAME], [[179, 467]]);
var root_32 = $.add_locations($.from_html(`<span></span>`), Home[$.FILENAME], [[179, 554]]);
var root_33 = $.add_locations($.from_html(`<button> </button>`), Home[$.FILENAME], [[179, 600]]);
var root_34 = $.add_locations($.from_html(`<i></i>`), Home[$.FILENAME], [[179, 851]]);

var root_30 = $.add_locations($.from_html(`<section class="month-card"><div class="month-summary"><div><span>Total recorded</span><strong> </strong></div><div><span>Transactions</span><strong> </strong></div><div><span>Highest day</span><strong> </strong></div></div><div class="weekdays"></div><div class="calendar"><!><!></div><div class="legend"><span>Lower spend</span><div></div><span>Higher spend</span></div></section>`), Home[$.FILENAME], [
	[
		179,
		92,

		[
			[
				179,
				120,

				[
					[179, 147, [[179, 152], [179, 179]]],
					[179, 226, [[179, 231], [179, 256]]],
					[179, 305, [[179, 310], [179, 334]]]
				]
			],

			[179, 389],
			[179, 496],
			[179, 778, [[179, 798], [179, 822], [179, 892]]]
		]
	]
]);

var root_35 = $.add_locations($.from_html(`<div class="activity-loading">Loading transactions…</div>`), Home[$.FILENAME], [[180, 368]]);
var root_37 = $.add_locations($.from_html(`<div class="section-error"><p>Could not load this date.</p><button>Try again</button></div>`), Home[$.FILENAME], [[180, 476, [[180, 503], [180, 535]]]]);
var root_40 = $.add_locations($.from_html(`<div class="row-actions"><button>Edit transaction</button><button class="danger">Delete</button></div>`), Home[$.FILENAME], [[180, 1441, [[180, 1466], [180, 1530]]]]);

var root_39 = $.add_locations($.from_html(`<article><button class="row-main"><div><strong> </strong><span> </span></div><div class="row-value"><b> </b><span>⌄</span></div></button><!></article>`), Home[$.FILENAME], [
	[
		180,
		1018,

		[
			[
				180,
				1085,

				[
					[180, 1170, [[180, 1175], [180, 1208]]],
					[180, 1280, [[180, 1303], [180, 1332]]]
				]
			]
		]
	]
]);

var root_41 = $.add_locations($.from_html(`<p class="empty-copy">No transactions for this view.</p>`), Home[$.FILENAME], [[180, 1625]]);
var root_42 = $.add_locations($.from_html(`<button class="view-all"> </button>`), Home[$.FILENAME], [[180, 1720]]);
var root_38 = $.add_locations($.from_html(`<div class="activity-summary"><p class="micro-label"> </p><h2> </h2></div><div class="compact-list"></div><!>`, 1), Home[$.FILENAME], [[180, 593, [[180, 623], [180, 764]]], [180, 964]]);

var root_29 = $.add_locations($.from_html(`<section class="workspace-heading"><div><p class="micro-label">EXPENSE WORKSPACE</p><h1>Transactions</h1><p>AI-captured expenses, ready for your review.</p></div><label class="month-switcher"><button type="button">←</button><input type="month"/><button type="button">→</button></label></section> <!> <section class="activity-panel adaptive-activity"><div class="activity-tabs"><button>Recent</button><button> </button></div><!></section> <button class="wide-button"> </button><button class="cleanup-card"><span>✦</span><div><strong>Expense cleanup</strong><small>Fix merchant and account names captured by AI.</small></div><b>Open ›</b></button>`, 1), Home[$.FILENAME], [
	[
		178,
		2,

		[
			[178, 37, [[178, 42], [178, 86], [178, 107]]],
			[178, 164, [[178, 194], [178, 257], [178, 378]]]
		]
	],

	[180, 2, [[180, 52, [[180, 79], [180, 176]]]]],
	[181, 2],

	[
		181,
		205,
		[[181, 272], [181, 286, [[181, 291], [181, 323]]], [181, 390]]
	]
]);

var root_45 = $.add_locations($.from_html(`<button> </button>`), Home[$.FILENAME], [[183, 267]]);
var root_48 = $.add_locations($.from_html(`<button></button>`), Home[$.FILENAME], [[183, 969]]);
var root_50 = $.add_locations($.from_html(`<span class="commitment-icon"> </span>`), Home[$.FILENAME], [[183, 1924]]);

var root_49 = $.add_locations($.from_html(`<button><span class="story-source"> </span><!><strong> </strong><b> </b><i>›</i></button>`), Home[$.FILENAME], [
	[
		183,
		1608,
		[[183, 1848], [183, 1984], [183, 2022], [183, 2064]]
	]
]);

var root_47 = $.add_locations($.from_html(`<div class="story-carousel story-carousel-full"><div class="story-dots" aria-label="Choose a story"><!><span> </span></div><div class="story-carousel-viewport"><div class="story-carousel-track"></div></div></div>`), Home[$.FILENAME], [
	[
		183,
		793,
		[[183, 879, [[183, 1227]]], [183, 1293, [[183, 1471]]]]
	]
]);

var root_51 = $.add_locations($.from_html(`<div class="empty-state"><span>✦</span><h2> </h2><p>As you choose to add more information, relevant stories will appear here.</p></div>`), Home[$.FILENAME], [[183, 2113, [[183, 2138], [183, 2152], [183, 2203]]]]);

var root_44 = $.add_locations($.from_html(`<section class="workspace-heading"><div><p class="micro-label">YOUR MONEY, EXPLAINED</p><h1>Stories</h1><p>Insights across the information you choose to share.</p></div></section><div class="story-filters"></div><div class="commitment-style-control"><span>Commitment style</span><button>Calm</button><button>Playful ✨</button></div><!>`, 1), Home[$.FILENAME], [
	[183, 2, [[183, 37, [[183, 42], [183, 90], [183, 106]]]]],
	[183, 181],
	[183, 397, [[183, 435], [183, 464], [183, 567]]]
]);

var root_54 = $.add_locations($.from_html(`<p>Loading your private outlook…</p>`), Home[$.FILENAME], [[197, 256]]);
var root_56 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[197, 325, [[197, 355], [197, 381]]]]);
var root_58 = $.add_locations($.from_html(`<div class="income-summary masked"><span>Salary saved</span><strong> </strong><button class="income-edit" aria-label="Update salary outlook" title="Update salary outlook">🔧</button><small>Masked before it reaches this screen.</small></div>`), Home[$.FILENAME], [[197, 473, [[197, 508], [197, 533], [197, 584], [197, 714]]]]);
var root_59 = $.add_locations($.from_html(`<div class="income-summary"><strong>Start with a range</strong><small>Only you decide whether to share a range or an exact amount.</small></div><button class="add-fund-row">Set up salary outlook</button>`, 1), Home[$.FILENAME], [[197, 779, [[197, 807], [197, 842]]], [197, 923]]);
var root_60 = $.add_locations($.from_html(`<p class="loan-state">Loading commitments…</p>`), Home[$.FILENAME], [[198, 266]]);
var root_62 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[198, 349, [[198, 379], [198, 409]]]]);
var root_66 = $.add_locations($.from_html(`<div class="loan-due-action"><!></div>`), Home[$.FILENAME], [[198, 1604]]);
var root_68 = $.add_locations($.from_html(`<div class="loan-due-action"><small> </small></div>`), Home[$.FILENAME], [[198, 1852, [[198, 1881]]]]);

var root_65 = $.add_locations($.from_html(`<article><span>↻</span><div><strong class="loan-name"> <button class="loan-edit" title="Edit monthly commitment">🔧</button><button class="loan-delete" title="Delete monthly commitment"> </button></strong><small> </small></div><div><b> </b><small> </small></div><!><!></article>`), Home[$.FILENAME], [
	[
		198,
		530,

		[
			[198, 675],

			[
				198,
				689,
				[[198, 694, [[198, 738], [198, 893]]], [198, 1145]]
			],

			[198, 1326, [[198, 1331], [198, 1375]]]
		]
	]
]);

var root_69 = $.add_locations($.from_html(`<p class="loan-state">No recurring commitments yet.</p>`), Home[$.FILENAME], [[198, 2006]]);
var root_70 = $.add_locations($.from_html(`<p class="loan-state">Loading credit cards…</p>`), Home[$.FILENAME], [[199, 214]]);
var root_72 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[199, 298, [[199, 328], [199, 358]]]]);

var root_75 = $.add_locations($.from_html(`<article class="loan-row"><span>▣</span><div><strong class="loan-name"> <button class="loan-edit" title="Edit credit card">🔧</button></strong><small> </small></div><div><b> </b><small> </small></div></article>`), Home[$.FILENAME], [
	[
		199,
		473,

		[
			[199, 499],
			[199, 513, [[199, 518, [[199, 559]]], [199, 707]]],
			[199, 778, [[199, 783], [199, 807]]]
		]
	]
]);

var root_76 = $.add_locations($.from_html(`<p class="loan-state">Add a card once it appears as an account in your captured expenses.</p>`), Home[$.FILENAME], [[199, 881]]);

var root_77 = $.add_locations($.from_html(`<button class="module-row"><span> </span><div><strong> </strong><small> </small></div><b>Coming soon</b></button>`), Home[$.FILENAME], [
	[
		201,
		8,
		[[201, 57], [201, 81, [[201, 86], [201, 114]]], [201, 146]]
	]
]);

var root_78 = $.add_locations($.from_html(`<p>Loading your funds…</p>`), Home[$.FILENAME], [[203, 255]]);
var root_80 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[203, 318, [[203, 348], [203, 378]]]]);
var root_83 = $.add_locations($.from_html(`<strong> </strong><small> </small>`, 1), Home[$.FILENAME], [[203, 569], [203, 618]]);
var root_84 = $.add_locations($.from_html(`<strong> </strong><small>Current valuation is temporarily unavailable</small>`, 1), Home[$.FILENAME], [[203, 810], [203, 860]]);
var root_87 = $.add_locations($.from_html(`<span class="stock-recurring-bell" role="button" tabindex="0" title="Set SIP">🔔</span>`), Home[$.FILENAME], [[203, 2225]]);

var root_86 = $.add_locations($.from_html(`<div class="fund-card-values"><div><span>P&amp;L</span><b> </b><small> </small></div><div><span>Invested</span><b> </b></div><div><span>Current</span><b> </b></div></div><p class="fund-card-nav"> <!></p>`, 1), Home[$.FILENAME], [
	[
		203,
		1658,

		[
			[203, 1688, [[203, 1784], [203, 1804], [203, 1881]]],
			[203, 1992, [[203, 1997], [203, 2018]]],
			[203, 2060, [[203, 2065], [203, 2085]]]
		]
	],

	[203, 2137]
]);

var root_88 = $.add_locations($.from_html(`<p class="fund-valuation-unavailable"> </p>`), Home[$.FILENAME], [[203, 2555]]);

var root_85 = $.add_locations($.from_html(`<button><span class="fund-card-orb"></span><div class="fund-card-title"><strong> </strong><span class="fund-delete" role="button" tabindex="0" title="Delete mutual fund"> </span><small> </small></div><!><footer><span class="fund-sip-summary"> </span><span class="fund-actions"><span>View details →</span><span class="fund-lump-sum" role="button" tabindex="0">＋ Lump sum</span></span></footer><!></button>`), Home[$.FILENAME], [
	[
		203,
		989,

		[
			[203, 1126],
			[203, 1161, [[203, 1190], [203, 1224], [203, 1576]]],

			[
				203,
				2695,
				[[203, 2703], [203, 2957, [[203, 2984], [203, 3011]]]]
			]
		]
	]
]);

var root_82 = $.add_locations($.from_html(`<section class="portfolio-total"><span>Total portfolio value</span><!></section><div class="fund-card-list"></div>`, 1), Home[$.FILENAME], [[203, 466, [[203, 499]]], [203, 934]]);
var root_90 = $.add_locations($.from_html(`<p>Choose one verified scheme, then add its existing holding, an SIP, or occasional lump sums whenever you need.</p>`), Home[$.FILENAME], [[203, 3415]]);
var root_91 = $.add_locations($.from_html(`<p>Loading your stocks…</p>`), Home[$.FILENAME], [[206, 37]]);
var root_93 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[207, 40, [[207, 70], [207, 95]]]]);
var root_96 = $.add_locations($.from_html(`<strong> </strong><small> </small>`, 1), Home[$.FILENAME], [[209, 108], [209, 156]]);
var root_97 = $.add_locations($.from_html(`<strong> </strong><small>Current valuation is temporarily unavailable</small>`, 1), Home[$.FILENAME], [[209, 328], [209, 377]]);

var root_99 = $.add_locations($.from_html(`<div class="fund-card-values"><div><span>P&amp;L</span><b> </b><small> </small></div><div><span>Invested</span><b> </b></div><div><span>Current</span><b> </b></div></div><p class="fund-card-nav"> <button class="stock-recurring-bell" title="Set monthly recurring plan">🔔</button></p>`, 1), Home[$.FILENAME], [
	[
		212,
		43,

		[
			[212, 73, [[212, 171], [212, 191], [212, 270]]],
			[212, 383, [[212, 388], [212, 409]]],
			[212, 452, [[212, 457], [212, 477]]]
		]
	],

	[212, 530, [[212, 647]]]
]);

var root_100 = $.add_locations($.from_html(`<p class="fund-valuation-unavailable"> </p>`), Home[$.FILENAME], [[212, 837]]);

var root_98 = $.add_locations($.from_html(`<article><span class="fund-card-orb"></span><div class="fund-card-title"><strong> </strong><span class="fund-delete" role="button" tabindex="0" title="Delete stock"> </span><small> </small></div> <!> <footer><span class="fund-sip-summary"> </span><!></footer> <!></article>`), Home[$.FILENAME], [
	[
		210,
		61,

		[
			[211, 12],
			[211, 47, [[211, 76], [211, 105], [211, 402]]],
			[213, 12, [[213, 20]]]
		]
	]
]);

var root_95 = $.add_locations($.from_html(`<section class="portfolio-total"><span>Total stock value</span><!></section> <div class="fund-card-list"></div>`, 1), Home[$.FILENAME], [[209, 10, [[209, 43]]], [210, 10]]);
var root_102 = $.add_locations($.from_html(`<p>Search a listed stock, then add the shares and amount you already invested.</p>`), Home[$.FILENAME], [[216, 15]]);
var root_103 = $.add_locations($.from_html(`<div class="loan-total"><span>Total monthly EMI</span><b> </b></div>`), Home[$.FILENAME], [[219, 203, [[219, 227], [219, 257]]]]);
var root_104 = $.add_locations($.from_html(`<p class="loan-state">Loading your loans…</p>`), Home[$.FILENAME], [[220, 36]]);
var root_106 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[220, 112, [[220, 142], [220, 166]]]]);
var root_110 = $.add_locations($.from_html(`<div class="loan-progress"><div><span> </span></div><i></i></div>`), Home[$.FILENAME], [[220, 1075, [[220, 1102, [[220, 1107]]], [220, 1193]]]]);
var root_111 = $.add_locations($.from_html(`<div class="loan-due-action"><strong>Final EMI due</strong><p>Confirm you paid the final EMI before closing this loan.</p><button class="primary" data-testid="mark-final-emi-paid"> </button></div>`), Home[$.FILENAME], [[220, 1330, [[220, 1359], [220, 1389], [220, 1452]]]]);

var root_109 = $.add_locations($.from_html(`<article><span>₹</span><div><strong class="loan-name"> <button class="loan-edit" title="Edit loan">🔧</button><button class="loan-delete" title="Delete loan"> </button></strong><small> </small></div><div><b> </b><small> </small></div><!><!><!></article>`), Home[$.FILENAME], [
	[
		220,
		311,

		[
			[220, 398],
			[220, 412, [[220, 417, [[220, 458], [220, 584]]], [220, 789]]],
			[220, 899, [[220, 904], [220, 944]]]
		]
	]
]);

var root_112 = $.add_locations($.from_html(`<p class="loan-state">No active loans.</p>`), Home[$.FILENAME], [[220, 1740]]);
var root_114 = $.add_locations($.from_html(`<div class="closed-loans-list"></div>`), Home[$.FILENAME], [[221, 285]]);
var root_113 = $.add_locations($.from_html(`<button class="closed-loans-toggle" data-testid="closed-loans-toggle"> <span> </span></button><!>`, 1), Home[$.FILENAME], [[221, 32, [[221, 217]]]]);

var root_53 = $.add_locations($.from_html(`<div class="modal-backdrop" role="presentation"><section class="modal money-modal" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button> <p class="micro-label">OPTIONAL, PRIVATE, YOURS</p><h2>Build your complete money picture</h2> <p class="module-reassurance">You choose what to add. Nothing is required, and you can remove a module anytime.</p> <section class="income-module"><div class="loans-heading"><div><strong>Salary outlook</strong><small>Private estimate — never treated as your account balance</small></div><span class="verified-pill">Optional</span></div><!></section> <section class="loans-module" data-testid="monthly-commitments-section"><div class="loans-heading"><div><strong>Monthly commitments</strong><small>Rent, bills, subscriptions and other repeatable obligations</small></div></div><!><button class="add-loan-row">＋ Add a monthly commitment</button></section> <section class="loans-module"><div class="loans-heading"><div><strong>Credit cards</strong><small>Turn captured card spending into the bill due next month</small></div></div><!><button class="add-loan-row">＋ Add a credit card</button></section> <!> <section class="mutual-funds-module"><div class="loans-heading"><div><strong>Mutual funds</strong><small>Portfolio value from the latest available NAV</small></div><span class="verified-pill">Scheme API</span></div><!><button class="add-fund-row">＋ Add a mutual fund</button></section> <section class="mutual-funds-module stocks-module"><div class="loans-heading"><div><strong>Stocks</strong><small>Portfolio value from the latest available market price</small></div><span class="verified-pill">Market data</span></div> <!> <button class="add-fund-row">＋ Add a stock</button></section> <section class="loans-module" data-testid="loans-section"><div class="loans-heading"><div><strong>Loans</strong><small>Track repayments and monthly commitments</small></div><!></div> <!> <!> <button class="add-loan-row">＋ Add another loan</button></section> <p class="module-footnote">These modules use normal forms—not AI cleanup—and only inform stories if you turn that on.</p></section></div>`), Home[$.FILENAME], [
	[
		192,
		2,

		[
			[
				193,
				4,

				[
					[194, 6],
					[195, 6],
					[195, 57],
					[196, 6],

					[
						197,
						6,
						[[197, 37, [[197, 64, [[197, 69], [197, 100]]], [197, 177]]]]
					],

					[
						198,
						6,

						[
							[198, 78, [[198, 105, [[198, 110], [198, 146]]]]],
							[198, 2066]
						]
					],

					[
						199,
						6,
						[[199, 36, [[199, 63, [[199, 68], [199, 97]]]]], [199, 979]]
					],

					[
						203,
						6,

						[
							[203, 43, [[203, 70, [[203, 75], [203, 104]]], [203, 170]]],
							[203, 3536]
						]
					],

					[
						204,
						6,

						[
							[205, 8, [[205, 35, [[205, 40], [205, 63]]], [205, 138]]],
							[217, 8]
						]
					],

					[
						219,
						6,
						[[219, 64, [[219, 91, [[219, 96], [219, 118]]]]], [222, 8]]
					],

					[224, 6]
				]
			]
		]
	]
]);

var root_117 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[228, 998]]);

var root_116 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal loan-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY COMMITMENT</p><h2> </h2><p class="module-reassurance">This is a planning estimate, not proof that a bill was paid.</p><label>Name<input placeholder="e.g. Home rent" maxlength="120"/></label><label>Monthly planning amount<input type="number" inputmode="decimal" min="0.01"/></label><label>Expected day <span class="optional">Optional</span><input type="number" min="1" max="28"/></label><label>Amount basis<select><option>Fixed amount</option><option>My estimate</option></select></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		228,
		24,

		[
			[
				228,
				52,

				[
					[228, 117],
					[228, 189],
					[228, 234],
					[228, 327],
					[228, 421, [[228, 432]]],
					[228, 527, [[228, 557]]],
					[228, 661, [[228, 681], [228, 719]]],
					[228, 801, [[228, 820, [[228, 867], [228, 910]]]]],
					[228, 1046, [[228, 1073], [228, 1154]]]
				]
			]
		]
	]
]);

var root_119 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[229, 625]]);
var root_120 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[229, 1182]]);

var root_118 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal loan-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">CREDIT-CARD BILLING</p><h2> </h2><p class="module-reassurance">We add only expenses captured against this account between statement dates to the bill due in that month.</p><label>Captured account<select><option disabled>Select the card account</option><!></select></label><label>Card name<input placeholder="e.g. Millennia" maxlength="120"/></label><label>Issuer / vendor<input placeholder="e.g. HDFC Bank" maxlength="120"/></label><label>Bill generation day<input type="number" min="1" max="28"/></label><label>Payment due day<input type="number" min="1" max="28"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		229,
		24,

		[
			[
				229,
				52,

				[
					[229, 117],
					[229, 189],
					[229, 235],
					[229, 311],
					[229, 450, [[229, 473, [[229, 528]]]]],
					[229, 707, [[229, 723]]],
					[229, 821, [[229, 843]]],
					[229, 943, [[229, 969]]],
					[229, 1057, [[229, 1079]]],
					[229, 1230, [[229, 1257], [229, 1338]]]
				]
			]
		]
	]
]);

var root_122 = $.add_locations($.from_html(`<button> </button>`), Home[$.FILENAME], [[230, 566]]);
var root_123 = $.add_locations($.from_html(`<label>Monthly take-home salary<input type="number" min="1" inputmode="decimal" placeholder="Optional exact amount"/></label>`), Home[$.FILENAME], [[230, 1088, [[230, 1119]]]]);
var root_124 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[230, 1410]]);
var root_125 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[230, 1531]]);

var root_121 = $.add_locations($.from_html(`<div class="modal-backdrop income-flow-backdrop"><section class="modal income-flow" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">PRIVATE SALARY CONTEXT</p><h2>What range feels comfortable to share?</h2><p class="module-reassurance">A range is enough. This is not a request for a payslip, and it never changes your balance.</p><div class="range-options"></div><button class="text-link income-exact-toggle"> </button><!><label>How often does it arrive?<select></select></label><!><div class="modal-actions"><button class="secondary">Skip for now</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		230,
		20,

		[
			[
				230,
				69,

				[
					[230, 136],
					[230, 204],
					[230, 253],
					[230, 300],
					[230, 424],
					[230, 789],
					[230, 1261, [[230, 1293]]],
					[230, 1575, [[230, 1602], [230, 1742]]]
				]
			]
		]
	]
]);

var root_127 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[232, 651]]);
var root_128 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[232, 1541]]);

var root_126 = $.add_locations($.from_html(`<div class="modal-backdrop loan-form-backdrop" role="presentation"><section class="modal loan-form" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">LOAN DETAILS</p><h2> </h2><p class="module-reassurance">Your loan information is stored securely in your account.</p><label>Loan name<input placeholder="e.g. HDFC Home Loan" maxlength="255"/></label><label>Loan type<select></select></label><label>Original loan principal<input type="number" inputmode="decimal" min="1" placeholder="e.g. 4200000"/></label><label>Monthly EMI amount<input type="number" inputmode="decimal" min="1" placeholder="e.g. 38600"/></label><label>Total tenure in months<input type="number" inputmode="numeric" min="1" placeholder="e.g. 240"/></label><label>First EMI due date<input type="date"/></label><label>Bank / lender<input placeholder="e.g. HDFC Bank" maxlength="255"/></label><label>Notes <span class="optional">Optional</span><input placeholder="e.g. Primary residence"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		232,
		2,

		[
			[
				232,
				69,

				[
					[232, 148],
					[232, 214],
					[232, 253],
					[232, 308],
					[232, 399, [[232, 415]]],
					[232, 513, [[232, 529]]],
					[232, 731, [[232, 761]]],
					[232, 887, [[232, 912]]],
					[232, 1035, [[232, 1064]]],
					[232, 1186, [[232, 1211]]],
					[232, 1278, [[232, 1298]]],
					[232, 1393, [[232, 1406], [232, 1444]]],
					[232, 1583, [[232, 1610], [232, 1685]]]
				]
			]
		]
	]
]);

var root_130 = $.add_locations($.from_html(`<div class="fund-success"><span>✓</span><p class="micro-label"> </p><h2> </h2><p> </p><button class="primary">Done</button></div>`), Home[$.FILENAME], [
	[
		236,
		19,
		[[236, 45], [236, 59], [236, 136], [236, 212], [236, 520]]
	]
]);

var root_133 = $.add_locations($.from_html(`<p>Searching schemes…</p>`), Home[$.FILENAME], [[238, 389]]);
var root_135 = $.add_locations($.from_html(`<p>Type at least 2 characters to search.</p>`), Home[$.FILENAME], [[238, 452]]);
var root_137 = $.add_locations($.from_html(`<button type="button"><strong> </strong><small> </small></button>`), Home[$.FILENAME], [[238, 534, [[238, 611], [238, 647]]]]);
var root_138 = $.add_locations($.from_html(`<p>No matching scheme found.</p>`), Home[$.FILENAME], [[238, 808]]);
var root_132 = $.add_locations($.from_html(`<div class="scheme-menu"><!></div>`), Home[$.FILENAME], [[238, 328]]);

var root_139 = $.add_locations($.from_html(`<div class="scheme-validated"><span>✓</span><div><strong>Verified by scheme master</strong><small> </small></div></div>`), Home[$.FILENAME], [
	[238, 891, [[238, 921], [238, 935, [[238, 940], [238, 982]]]]]
]);

var root_141 = $.add_locations($.from_html(`<option></option>`), Home[$.FILENAME], [[239, 622]]);

var root_140 = $.add_locations($.from_html(`<label>Monthly SIP amount<input type="number" inputmode="decimal" min="1"/></label><div class="fund-field-pair"><label>SIP date<select></select></label><label>Start month<input type="month"/></label></div>`, 1), Home[$.FILENAME], [
	[239, 396, [[239, 421]]],

	[
		239,
		512,
		[[239, 541, [[239, 556]]], [239, 754, [[239, 772]]]]
	]
]);

var root_142 = $.add_locations($.from_html(`<div class="fund-field-pair"><label>Current units<input type="number" inputmode="decimal" min="0.001" step="0.001"/></label><label>Total amount invested<input type="number" inputmode="decimal" min="0.01"/></label></div><p class="fund-disclaimer">Average purchase cost is calculated by the backend after the opening balance is recorded.</p>`, 1), Home[$.FILENAME], [
	[
		240,
		411,
		[[240, 440, [[240, 460]]], [240, 571, [[240, 599]]]]
	],

	[240, 703]
]);

var root_143 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[241, 21]]);

var root_131 = $.add_locations($.from_html(`<p class="micro-label">MUTUAL FUND</p><h2>Add a mutual fund</h2><p class="module-reassurance">Search the official scheme master. A returned name is one verified fund, plan and option.</p> <div class="fund-section"><span class="fund-section-label">1 · FUND</span><label class="scheme-picker">Search and select scheme<input placeholder="Type at least 2 characters" autocomplete="off"/><!></label><!></div> <div class="fund-section"><span class="fund-section-label">2 · SIP <em>OPTIONAL</em></span><fieldset><legend>Do you have an actual SIP for this fund?</legend><label class="choice"><input type="radio"/> Yes</label><label class="choice"><input type="radio"/> No</label></fieldset><!></div> <div class="fund-section"><span class="fund-section-label">3 · EXISTING HOLDING <em>OPTIONAL</em></span><fieldset><legend>Do you already hold this fund?</legend><label class="choice"><input type="radio"/> No</label><label class="choice"><input type="radio"/> Yes</label></fieldset><!></div> <!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div>`, 1), Home[$.FILENAME], [
	[237, 11],
	[237, 49],
	[237, 75],
	[238, 6, [[238, 32], [238, 80, [[238, 133]]]]],

	[
		239,
		6,

		[
			[239, 32, [[239, 73]]],

			[
				239,
				97,

				[
					[239, 107],
					[239, 164, [[239, 186]]],
					[239, 261, [[239, 283]]]
				]
			]
		]
	],

	[
		240,
		6,

		[
			[240, 32, [[240, 86]]],

			[
				240,
				110,

				[
					[240, 120],
					[240, 167, [[240, 189]]],
					[240, 266, [[240, 288]]]
				]
			]
		]
	],

	[241, 63, [[241, 90], [241, 171]]]
]);

var root_129 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop" role="presentation"><section class="modal fund-form" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button> <!></section></div>`), Home[$.FILENAME], [[235, 2, [[235, 69, [[235, 148]]]]]]);
var root_146 = $.add_locations($.from_html(`<p>Searching stock symbols…</p>`), Home[$.FILENAME], [[245, 816]]);
var root_148 = $.add_locations($.from_html(`<p>Could not search stocks.</p>`), Home[$.FILENAME], [[245, 885]]);
var root_150 = $.add_locations($.from_html(`<button type="button"><strong> </strong><small> </small></button>`), Home[$.FILENAME], [[245, 952, [[245, 1027], [245, 1070]]]]);
var root_151 = $.add_locations($.from_html(`<p>No matching listed stock found.</p>`), Home[$.FILENAME], [[245, 1262]]);
var root_145 = $.add_locations($.from_html(`<div class="scheme-menu"><!></div>`), Home[$.FILENAME], [[245, 756]]);

var root_152 = $.add_locations($.from_html(`<div class="scheme-validated"><span>✓</span><div><strong>Verified market symbol</strong><small> </small></div></div>`), Home[$.FILENAME], [
	[
		245,
		1350,
		[[245, 1380], [245, 1394, [[245, 1399], [245, 1438]]]]
	]
]);

var root_153 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[245, 2064]]);

var root_144 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop" role="presentation"><section class="modal fund-form" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">STOCK HOLDING</p><h2>Add a stock</h2><p class="module-reassurance">Search market symbols, then record the shares and total amount you already invested. Editing and selling will follow in a later update.</p><div class="fund-section"><span class="fund-section-label">1 · STOCK</span><label class="scheme-picker">Search and select stock<input placeholder="Type at least 2 characters" autocomplete="off"/><!></label><!></div><div class="fund-section"><span class="fund-section-label">2 · HOLDING</span><div class="fund-field-pair"><label>Shares held<input type="number" inputmode="decimal" min="0.001" step="0.001"/></label><label>Total amount invested<input type="number" inputmode="decimal" min="0.01"/></label></div></div><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		245,
		2,

		[
			[
				245,
				69,

				[
					[245, 148],
					[245, 215],
					[245, 255],
					[245, 275],
					[245, 444, [[245, 470], [245, 519, [[245, 571]]]]],

					[
						245,
						1677,

						[
							[245, 1703],

							[
								245,
								1754,
								[[245, 1783, [[245, 1801]]], [245, 1909, [[245, 1937]]]]
							]
						]
					],

					[245, 2107, [[245, 2134], [245, 2210]]]
				]
			]
		]
	]
]);

var root_155 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[247, 668]]);

var root_154 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY SIP</p><h2> </h2><p class="module-reassurance">This creates a monthly plan. Occasional lump sums remain separate.</p><label>Monthly amount<input type="number" min="0.01"/></label><label>SIP date<input type="number" min="1" max="28"/></label><label>Start month<input type="month"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		247,
		19,

		[
			[
				247,
				66,

				[
					[247, 131],
					[247, 197],
					[247, 235],
					[247, 285],
					[247, 385, [[247, 406]]],
					[247, 479, [[247, 494]]],
					[247, 570, [[247, 588]]],
					[247, 710, [[247, 737], [247, 812]]]
				]
			]
		]
	]
]);

var root_156 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY ETF PLAN</p><h2> </h2><label>Monthly amount<input type="number" min="0.01"/></label><label>Investment day<input type="number" min="1" max="28"/></label><label>Start month<input type="month"/></label><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		248,
		21,

		[
			[
				248,
				68,

				[
					[248, 133],
					[248, 201],
					[248, 244],
					[248, 280, [[248, 301]]],
					[248, 376, [[248, 397]]],
					[248, 475, [[248, 493]]],
					[248, 560, [[248, 587], [248, 664]]]
				]
			]
		]
	]
]);

var root_157 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">CONFIRM ETF INVESTMENT</p><h2>Was this investment processed?</h2><label>Amount invested<input type="number" min="0.01"/></label><label>Executed market price<input type="number" min="0.0001"/></label><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary">Confirm investment</button></div></section></div>`), Home[$.FILENAME], [
	[
		249,
		33,

		[
			[
				249,
				80,

				[
					[249, 145],
					[249, 225],
					[249, 274],
					[249, 313, [[249, 335]]],
					[249, 418, [[249, 446]]],
					[249, 530, [[249, 557], [249, 646]]]
				]
			]
		]
	]
]);

var root_159 = $.add_locations($.from_html(`<h2>Loading stock details…</h2>`), Home[$.FILENAME], [[250, 230]]);
var root_161 = $.add_locations($.from_html(`<h2>Couldn’t load this stock</h2>`), Home[$.FILENAME], [[250, 299]]);

var root_163 = $.add_locations($.from_html(`<div class="investment-history-row"><span> </span><strong> </strong><span class="history-amount"><b> </b></span><small> </small></div>`), Home[$.FILENAME], [
	[
		250,
		700,
		[[250, 736], [250, 783], [250, 861, [[250, 890]]], [250, 925]]
	]
]);

var root_162 = $.add_locations($.from_html(`<p class="micro-label">STOCK DETAILS</p><h2> </h2><div class="detail-grid"><div><span>Invested</span><b> </b></div><div><span>Shares</span><b> </b></div></div><section class="investment-history"><h3>Investment history</h3><!></section>`, 1), Home[$.FILENAME], [
	[250, 339],
	[250, 379],

	[
		250,
		412,

		[
			[250, 437, [[250, 442], [250, 463]]],
			[250, 511, [[250, 516], [250, 535]]]
		]
	],

	[250, 601, [[250, 637]]]
]);

var root_158 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><!></section></div>`), Home[$.FILENAME], [[250, 17, [[250, 64, [[250, 131]]]]]]);
var root_165 = $.add_locations($.from_html(`<p class="micro-label">FUND DETAILS</p><h2>Loading fund details…</h2>`, 1), Home[$.FILENAME], [[252, 227], [252, 266]]);
var root_167 = $.add_locations($.from_html(`<p class="micro-label">FUND DETAILS</p><h2>Couldn’t load this fund</h2><p> </p><button class="primary">Try again</button>`, 1), Home[$.FILENAME], [[252, 333], [252, 372], [252, 404], [252, 428]]);

var root_170 = $.add_locations($.from_html(`<div class="investment-history-row"><span> </span><strong> </strong><span class="history-amount"><b> </b><button class="history-edit" aria-label="Edit this investment" title="Edit this investment">🔧</button></span><small> </small></div>`), Home[$.FILENAME], [
	[
		252,
		1568,

		[
			[252, 1604],
			[252, 1651],
			[252, 1746, [[252, 1775], [252, 1803]]],
			[252, 1965]
		]
	]
]);

var root_169 = $.add_locations($.from_html(`<section class="investment-history"><h3>Investment history</h3><!></section>`), Home[$.FILENAME], [[252, 1470, [[252, 1506]]]]);

var root_168 = $.add_locations($.from_html(`<p class="micro-label">FUND DETAILS</p><h2> </h2><div class="detail-value"><span>Current value</span><strong> </strong></div><div><span>Total P&amp;L</span><strong> </strong><b> </b></div><div class="detail-grid"><div><span>Invested</span><b> </b></div><div><span>Units</span><b> </b></div><div><span>Average NAV</span><b> </b></div><div><span>Current NAV</span><b> </b></div></div><!><p class="fund-disclaimer">Average NAV is based on confirmed investments. Current NAV is the latest available MFAPI value.</p>`, 1), Home[$.FILENAME], [
	[252, 571],
	[252, 610],
	[252, 642, [[252, 668], [252, 694]]],
	[252, 749, [[252, 876], [252, 902], [252, 994]]],

	[
		252,
		1109,

		[
			[252, 1134, [[252, 1139], [252, 1160]]],
			[252, 1201, [[252, 1206], [252, 1224]]],
			[252, 1274, [[252, 1279], [252, 1303]]],
			[252, 1353, [[252, 1358], [252, 1382]]]
		]
	],

	[252, 2078]
]);

var root_164 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><!></section></div>`), Home[$.FILENAME], [[252, 16, [[252, 63, [[252, 130]]]]]]);
var root_172 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[253, 736]]);

var root_171 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">LUMP-SUM INVESTMENT</p><h2> </h2><p class="module-reassurance">This adds confirmed units to this fund only. It does not change the monthly SIP plan.</p><label>Amount invested<input type="number" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><label>NAV<input type="number" min="0.0001" step="0.0001" placeholder="e.g. 87.25"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		253,
		17,

		[
			[
				253,
				64,

				[
					[253, 129],
					[253, 193],
					[253, 239],
					[253, 279],
					[253, 398, [[253, 420]]],
					[253, 505, [[253, 528]]],
					[253, 597, [[253, 607]]],
					[253, 781, [[253, 808], [253, 881]]]
				]
			]
		]
	]
]);

var root_174 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[254, 952]]);

var root_173 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">CONFIRM SIP INVESTMENT</p><h2>Was this SIP processed?</h2><p class="module-reassurance">Units will be estimated from the NAV and marked as an estimate until you correct them from your statement.</p><div class="source-note"><strong> </strong><span> </span></div><label>Amount invested<input type="number" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><label>NAV <span class="optional">Estimated</span><input type="number" min="0.0001" step="0.0001" placeholder="e.g. 87.25"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		254,
		19,

		[
			[
				254,
				66,

				[
					[254, 131],
					[254, 197],
					[254, 246],
					[254, 278],
					[254, 418, [[254, 443], [254, 491]]],
					[254, 562, [[254, 584]]],
					[254, 672, [[254, 695]]],
					[254, 767, [[254, 778], [254, 817]]],
					[254, 1000, [[254, 1027], [254, 1102]]]
				]
			]
		]
	]
]);

var root_176 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[255, 876]]);

var root_175 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">EDIT INVESTMENT</p><h2> </h2><p class="module-reassurance">Update this recorded investment. Your fund totals will recalculate automatically.</p><label>Amount invested<input type="number" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><label>NAV<input type="number" min="0.0001" step="0.0001"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		255,
		28,

		[
			[
				255,
				75,

				[
					[255, 140],
					[255, 215],
					[255, 257],
					[255, 416],
					[255, 531, [[255, 553]]],
					[255, 646, [[255, 669]]],
					[255, 746, [[255, 756]]],
					[255, 929, [[255, 956], [255, 1040]]]
				]
			]
		]
	]
]);

var root_177 = $.add_locations($.from_html(`<div class="account-repair-backdrop" role="presentation"><section class="account-repair-dialog" role="dialog" aria-modal="true" tabindex="-1"><header class="account-repair-bar"><div><span class="repair-symbol">✦</span><span><p>EXPENSE DATA ONLY</p><strong>Expense cleanup</strong></span></div><button>×</button></header><div class="account-repair-content"><!></div></section></div>`), Home[$.FILENAME], [
	[
		257,
		23,

		[
			[
				257,
				189,

				[
					[
						257,
						299,

						[
							[257, 334, [[257, 339], [257, 375, [[257, 381], [257, 405]]]]],
							[257, 450]
						]
					],

					[257, 516]
				]
			]
		]
	]
]);

var root_181 = $.add_locations($.from_html(`<i></i>`), Home[$.FILENAME], [[259, 680]]);
var root_180 = $.add_locations($.from_html(`<div class="story-progress"></div>`), Home[$.FILENAME], [[259, 628]]);
var root_182 = $.add_locations($.from_html(`<p class="slide-eyebrow"> </p>`), Home[$.FILENAME], [[259, 964]]);
var root_183 = $.add_locations($.from_html(`<div class="story-amount"><span> </span><strong> </strong></div>`), Home[$.FILENAME], [[259, 1086, [[259, 1112], [259, 1158]]]]);
var root_185 = $.add_locations($.from_html(`<div><span> </span><strong> </strong></div>`), Home[$.FILENAME], [[259, 1394, [[259, 1399], [259, 1429]]]]);
var root_184 = $.add_locations($.from_html(`<div class="observation-components"></div>`), Home[$.FILENAME], [[259, 1315]]);
var root_187 = $.add_locations($.from_html(`<button class="story-action" data-testid="view-included-commitments"> </button>`), Home[$.FILENAME], [[259, 1570]]);
var root_189 = $.add_locations($.from_html(`<button class="story-action"> </button>`), Home[$.FILENAME], [[259, 1741]]);
var root_191 = $.add_locations($.from_html(`<button class="story-action" data-testid="review-final-emi"> </button>`), Home[$.FILENAME], [[259, 1880]]);
var root_192 = $.add_locations($.from_html(`<div class="story-deck-controls"><button>←</button><span> </span><button>Next →</button></div>`), Home[$.FILENAME], [[259, 2037, [[259, 2070], [259, 2143], [259, 2188]]]]);
var root_179 = $.add_locations($.from_html(`<div class="story-deck"><!><article><!><!><h1> </h1><p> </p><!><!></article><!></div>`), Home[$.FILENAME], [[259, 584, [[259, 739, [[259, 1226], [259, 1254]]]]]]);
var root_178 = $.add_locations($.from_html(`<div class="story-reader-backdrop" role="presentation"><section class="story-detail" role="dialog" aria-modal="true" tabindex="-1"><button class="back-button">← Back to stories</button><p class="micro-label"> </p><!></section></div>`), Home[$.FILENAME], [[259, 17, [[259, 167, [[259, 268], [259, 354]]]]]]);
var root_194 = $.add_locations($.from_html(`<p>Loading payment choices…</p>`), Home[$.FILENAME], [[261, 421]]);
var root_196 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[261, 495]]);
var root_199 = $.add_locations($.from_html(`<button class="story-action"> </button>`), Home[$.FILENAME], [[261, 826]]);

var root_198 = $.add_locations($.from_html(`<div class="source-note"><strong> </strong><span> </span></div><p>Which commitment is this for?</p><!><button class="secondary">This is not a commitment</button>`, 1), Home[$.FILENAME], [
	[261, 582, [[261, 607], [261, 698]]],
	[261, 755],
	[261, 1008]
]);

var root_200 = $.add_locations($.from_html(`<p>Everything is reviewed for this month.</p>`), Home[$.FILENAME], [[261, 1222]]);
var root_197 = $.add_locations($.from_html(`<!><!>`, 1), Home[$.FILENAME], []);

var root_193 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY COMMITMENT</p><h2>Help match this payment</h2><p class="module-reassurance">Your expense was saved normally. Link it only if it belongs to one of your commitments.</p><!></section></div>`), Home[$.FILENAME], [
	[
		261,
		26,
		[[261, 54, [[261, 109], [261, 183], [261, 228], [261, 260]]]]
	]
]);

var root_204 = $.add_locations($.from_html(`<button class="secondary" data-testid="included-loan-commitment">Review</button>`), Home[$.FILENAME], [[262, 1487]]);
var root_206 = $.add_locations($.from_html(`<button class="secondary">Review</button>`), Home[$.FILENAME], [[262, 1614]]);
var root_208 = $.add_locations($.from_html(`<button class="secondary">Review</button>`), Home[$.FILENAME], [[262, 1784]]);
var root_210 = $.add_locations($.from_html(`<button class="secondary">Review</button>`), Home[$.FILENAME], [[262, 1947]]);

var root_203 = $.add_locations($.from_html(`<div><div><strong> </strong><span> </span></div><b> </b><!></div>`), Home[$.FILENAME], [
	[
		262,
		959,
		[[262, 1336, [[262, 1341], [262, 1373]]], [262, 1453]]
	]
]);

var root_202 = $.add_locations($.from_html(`<p class="evidence-total"> </p><div class="evidence-list"></div>`, 1), Home[$.FILENAME], [[262, 503], [262, 618]]);
var root_211 = $.add_locations($.from_html(`<div class="empty-state evidence-empty"><span>◌</span><h2>No commitments attached</h2><p>This story does not include sources to display.</p></div>`), Home[$.FILENAME], [[262, 2126, [[262, 2166], [262, 2180], [262, 2212]]]]);

var root_201 = $.add_locations($.from_html(`<div class="modal-backdrop" role="presentation"><section class="modal" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">INCLUDED COMMITMENTS</p><h2> </h2><!></section></div>`), Home[$.FILENAME], [
	[262, 23, [[262, 180, [[262, 274], [262, 345], [262, 392]]]]]
]);

var root_213 = $.add_locations($.from_html(`<p class="edit-options-status">Loading categories, merchants, and accounts…</p>`), Home[$.FILENAME], [[263, 624]]);
var root_215 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[263, 737]]);
var root_217 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[263, 951]]);
var root_218 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[263, 1195]]);
var root_219 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[263, 1401]]);
var root_220 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[263, 1627]]);

var root_216 = $.add_locations($.from_html(`<label>Category<select><option disabled>Select a category</option><!></select></label><label>Subcategory<select><option disabled>Select a subcategory</option><!></select></label><label>Merchant<select><option disabled>Select a merchant</option><!></select></label><label>Source account<select><option disabled>Select an account</option><!></select></label>`, 1), Home[$.FILENAME], [
	[263, 784, [[263, 799, [[263, 859]]]]],
	[263, 1025, [[263, 1043, [[263, 1105]]]]],
	[263, 1259, [[263, 1274, [[263, 1310]]]]],
	[263, 1481, [[263, 1502, [[263, 1537]]]]]
]);

var root_221 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[263, 1729]]);

var root_212 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">AI-CAPTURED EXPENSE</p><h2>Edit transaction</h2><div class="source-note"><strong>Captured from your message</strong><span>Review the details below before saving.</span></div><label>Amount<input type="number" inputmode="decimal" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><!><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		263,
		13,

		[
			[
				263,
				41,

				[
					[263, 110],
					[263, 170],
					[263, 216],
					[263, 241, [[263, 266], [263, 309]]],
					[263, 367, [[263, 380]]],
					[263, 477, [[263, 500]]],
					[263, 1773, [[263, 1800], [263, 1869]]]
				]
			]
		]
	]
]);

var root_222 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal" role="alertdialog" aria-modal="true" tabindex="-1"><p class="micro-label">DELETE TRANSACTION</p><h2> </h2><p>This updates the calendar and monthly totals.</p><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary delete-confirm">Delete</button></div></section></div>`), Home[$.FILENAME], [
	[
		264,
		14,

		[
			[
				264,
				42,

				[
					[264, 116],
					[264, 161],
					[264, 198],
					[264, 250, [[264, 277], [264, 347]]]
				]
			]
		]
	]
]);

var root_224 = $.add_locations($.from_html(`<a class="center-action whatsapp-action" target="_blank" rel="noopener">Open WhatsApp</a>`), Home[$.FILENAME], [[265, 362]]);

var root_223 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal whatsapp-handoff" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">WHATSAPP READY</p><h2>Continue in WhatsApp</h2><p> </p><!><button class="auth-secondary">Done</button></section></div>`), Home[$.FILENAME], [
	[
		265,
		13,

		[
			[
				265,
				41,
				[[265, 127], [265, 187], [265, 228], [265, 257], [265, 483]]
			]
		]
	]
]);

var root = $.add_locations($.from_html(`<!> <!> <!> <main class="app-shell"><!> <!></main> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!>`, 1), Home[$.FILENAME], [[169, 0]]);

function Home($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, Home);

	const data = $.mutable_source();
	const currency = $.mutable_source();
	const calendar = $.mutable_source();
	const recentData = $.mutable_source();
	const recentItems = $.mutable_source();
	const storyData = $.mutable_source();
	const stories = $.mutable_source();
	const filteredStories = $.mutable_source();
	const homeStories = $.mutable_source();
	const selected = $.mutable_source();
	const activeItems = $.mutable_source();
	const visibleItems = $.mutable_source();
	const editSubcategories = $.mutable_source();
	const activeLoans = $.mutable_source();
	const closedLoans = $.mutable_source();
	const totalMonthlyEmi = $.mutable_source();
	const mutualPortfolio = $.mutable_source();
	const stockPortfolio = $.mutable_source();
	const visibleActions = $.mutable_source();
	const highlightedLoanAction = $.mutable_source();
	const connectionLabel = $.mutable_source();
	const evidenceItems = $.mutable_source();
	const binding_group = [];
	const binding_group_1 = [];
	let calendarSection = $.prop($$props, 'calendarSection', 8);
	let recentSection = $.prop($$props, 'recentSection', 8);
	let storiesSection = $.prop($$props, 'storiesSection', 8);
	let selectedMonth = $.prop($$props, 'selectedMonth', 8);
	let connectionStatus = $.prop($$props, 'connectionStatus', 8);
	let cacheUpdatedAt = $.prop($$props, 'cacheUpdatedAt', 8);
	let demoMode = $.prop($$props, 'demoMode', 8);
	let onDemoModeChange = $.prop($$props, 'onDemoModeChange', 8);
	let onMonthChange = $.prop($$props, 'onMonthChange', 8);
	let refreshCalendar = $.prop($$props, 'refreshCalendar', 8);
	let refreshRecent = $.prop($$props, 'refreshRecent', 8);
	let refreshStories = $.prop($$props, 'refreshStories', 8);
	let onRetryConnection = $.prop($$props, 'onRetryConnection', 8);
	let onLogout = $.prop($$props, 'onLogout', 8);
	let view = $.mutable_source('home');
	let showMoney = $.mutable_source(false);
	let showNormalization = $.mutable_source(false);
	let selectedDay = $.mutable_source(null);
	let activityTab = $.mutable_source('recent');
	let dayItems = $.mutable_source([]);
	let dayStatus = $.mutable_source('idle');
	let showAll = $.mutable_source(false);
	let expandedId = $.mutable_source(null);
	let openedStory = $.mutable_source(null);
	let handoff = $.mutable_source(null);
	let addingContext = $.mutable_source(false);
	let actionError = $.mutable_source('');
	let loggingOut = $.mutable_source(false);
	let signOutError = $.mutable_source('');
	let demoSwitching = $.mutable_source(false);
	let demoError = $.mutable_source('');
	let storySlide = $.mutable_source(0);
	let storyTouchStart = $.mutable_source(null);
	let showStoryEvidence = $.mutable_source(false);
	let storyFilter = $.mutable_source('All');
	let homeStoryIndex = $.mutable_source(0);
	let storiesRailIndex = $.mutable_source(0);
	let storyRailTouchStart = $.mutable_source(null);
	let commitmentStyle = $.mutable_source('playful');
	let editing = $.mutable_source(null);
	let editAmount = $.mutable_source('');
	let editDate = $.mutable_source('');
	let editCategory = $.mutable_source('');
	let editSubcategory = $.mutable_source('');
	let editMerchantId = $.mutable_source('');
	let editAccountId = $.mutable_source('');
	let saving = $.mutable_source(false);
	let deleting = $.mutable_source(null);
	let editOptions = $.mutable_source({ categories: [], merchants: [], accounts: [] });
	let optionsStatus = $.mutable_source('idle');
	let optionsError = $.mutable_source('');
	let storyControls = { spending: true, investments: true, planning: true };
	let showLoanForm = $.mutable_source(false);
	let loanError = $.mutable_source('');
	let loanStatus = $.mutable_source('idle');
	let loanEditingId = $.mutable_source(null);
	let loanSaving = $.mutable_source(false);
	let loanDeletingId = $.mutable_source(null);
	let showClosedLoans = $.mutable_source(false);

	let loanForm = $.mutable_source({
		loanName: '',
		loanType: 'HOME',
		lenderName: '',
		originalPrincipal: '',
		monthlyEmiAmount: '',
		totalTenureMonths: '',
		firstEmiDueDate: '',
		notes: ''
	});

	let loans = $.mutable_source([]);
	let loanHistory = $.mutable_source(null);
	let loanHistoryStatus = $.mutable_source('idle');
	let loanHistoryError = $.mutable_source('');
	let commitments = $.mutable_source([]);
	let commitmentStatus = $.mutable_source('idle');
	let commitmentError = $.mutable_source('');
	let showCommitmentForm = $.mutable_source(false);
	let commitmentSaving = $.mutable_source(false);
	let commitmentEditingId = $.mutable_source(null);
	let commitmentDeletingId = $.mutable_source(null);
	let completingCommitmentId = null;
	let commitmentHistory = $.mutable_source(null);
	let commitmentHistoryStatus = $.mutable_source('idle');
	let commitmentHistoryError = $.mutable_source('');

	let commitmentForm = $.mutable_source({
		label: '',
		planningAmount: '',
		dueDay: '',
		amountMode: 'FIXED'
	});

	let creditCards = $.mutable_source([]);
	let creditCardStatus = $.mutable_source('idle');
	let creditCardError = $.mutable_source('');
	let showCreditCardForm = $.mutable_source(false);
	let creditCardSaving = $.mutable_source(false);
	let creditCardEditingId = $.mutable_source(null);

	let creditCardForm = $.mutable_source({
		accountReferenceId: '',
		cardName: '',
		issuerName: '',
		statementDay: '',
		dueDay: ''
	});

	let showCommitmentReview = $.mutable_source(false);
	let commitmentReview = $.mutable_source([]);
	let commitmentReviewStatus = $.mutable_source('idle');
	let resolvingCandidate = $.mutable_source(null);
	let incomeOutlook = $.mutable_source({ salary: null });
	let incomeStatus = $.mutable_source('idle');
	let incomeError = $.mutable_source('');
	let incomeSaving = $.mutable_source(false);
	let showIncomeFlow = $.mutable_source(false);

	let salaryForm = $.mutable_source({
		salaryVisibility: 'RANGE',
		salaryRange: 'FROM_50000_TO_100000',
		exactMonthlySalary: '',
		salaryFrequency: 'MONTHLY'
	});

	let showMutualFundForm = $.mutable_source(false);
	let schemeQuery = $.mutable_source('');
	let showSchemeMenu = $.mutable_source(false);
	let selectedScheme = $.mutable_source(null);
	let fundError = $.mutable_source('');
	let fundSaved = $.mutable_source(false);
	let fundSaving = $.mutable_source(false);
	let schemeSearchStatus = $.mutable_source('idle');
	let schemeResults = $.mutable_source([]);
	let schemeSearchRequest = 0;
	let mutualFunds = $.mutable_source([]);
	let mutualFundStatus = $.mutable_source('idle');
	let mutualFundError = $.mutable_source('');
	let mutualFundDeletingId = $.mutable_source(null);
	let stocks = $.mutable_source([]);
	let stockStatus = $.mutable_source('idle');
	let stockError = $.mutable_source('');
	let showStockForm = $.mutable_source(false);
	let stockQuery = $.mutable_source('');
	let selectedStock = $.mutable_source(null);
	let stockResults = $.mutable_source([]);
	let stockSearchStatus = $.mutable_source('idle');
	let stockSearchRequest = 0;
	let stockSaving = $.mutable_source(false);
	let stockDeletingId = $.mutable_source(null);
	let stockPlanTarget = $.mutable_source(null);
	let stockPlanForm = $.mutable_source({ amount: '', day: '', startMonth: '' });
	let stockPlanSaving = $.mutable_source(false);
	let stockPlanConfirmationTarget = $.mutable_source(null);
	let stockPlanConfirmation = $.mutable_source({ amount: '', price: '' });
	let stockDetail = $.mutable_source(null);
	let stockDetailStatus = $.mutable_source('idle');
	let highlightedStockId = $.mutable_source(null);
	let stockForm = $.mutable_source({ quantity: '', totalInvested: '' });
	let actions = $.mutable_source([]);
	let actionsStatus = 'idle';
	let actionsError = '';
	let completingActionId = $.mutable_source(null);
	let highlightedLoanId = $.mutable_source(null);
	let highlightedFundId = null;
	let confirmingSip = $.mutable_source(null);
	let sipConfirmError = $.mutable_source('');
	let sipConfirmSaving = $.mutable_source(false);

	let sipConfirmForm = $.mutable_source({
		amount: '',
		transactionDate: new Date().toISOString().slice(0, 10),
		nav: ''
	});

	let fundDetail = $.mutable_source(null);
	let fundDetailStatus = $.mutable_source('idle');
	let fundDetailError = $.mutable_source('');
	let lumpSumFund = $.mutable_source(null);
	let lumpSumSaving = $.mutable_source(false);
	let lumpSumError = $.mutable_source('');
	let lumpSumForm = $.mutable_source({ amount: '', transactionDate: '', nav: '' });
	let editingFundTransaction = $.mutable_source(null);
	let fundTransactionSaving = $.mutable_source(false);
	let fundTransactionError = $.mutable_source('');
	let fundTransactionForm = $.mutable_source({ amount: '', transactionDate: '', nav: '' });
	const MONEY_MODULES_CACHE_KEY = 'money-stories.money-modules-cache.v1';

	let fundForm = $.mutable_source({
		hasSip: 'YES',
		sipAmount: '25000',
		sipDate: '5',
		startMonth: '2026-10',
		hasHolding: 'YES',
		currentUnits: '128.456',
		totalInvested: '10000'
	});

	let fundSipTarget = $.mutable_source(null);
	let fundSipForm = $.mutable_source({ amount: '', day: '', startMonth: '' });
	let fundSipSaving = $.mutable_source(false);

	const money = (value) => new Intl.NumberFormat('en-IN', {
		style: 'currency',
		currency: $.get(currency),
		maximumFractionDigits: 0
	}).format(Number(value || 0));

	const moneyDecimal = (value) => new Intl.NumberFormat('en-IN', {
		style: 'currency',
		currency: $.get(currency),
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(Number(value || 0));

	const compactMoney = (value) => new Intl.NumberFormat('en-IN', {
		style: 'currency',
		currency: $.get(currency),
		notation: 'compact',
		maximumFractionDigits: 2
	}).format(Number(value || 0));

	const fundSubtitle = (name) => (/growth/i).test(name) ? 'Growth · Direct plan' : 'Verified scheme';
	const fundAccent = (id) => ['coral', 'gold', 'violet', 'blue'][Number(id || 0) % 4];
	const merchant = (item) => item.merchant || item.merchantName || item.description || item.originalMessage || 'Expense';
	const category = (item) => item.category?.name || item.category || 'Uncategorised';
	const transactionDate = (item) => item.transactionDate || item.transactionTime || item.date;

	const dateLabel = (value) => value
		? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short' }).format(new Date(value))
		: '';

	const monthLabel = (value) => {
		const [y, m] = value.split('-').map(Number);

		return new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(new Date(y, m - 1));
	};

	const greeting = () => new Date().getHours() < 12
		? 'Good morning'
		: new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';

	const isoDate = (day) => `${selectedMonth()}-${String(day).padStart(2, '0')}`;
	const hasDeck = (story) => Array.isArray(story.cards) && story.cards.length > 0;
	const storyName = (story) => String(story.storyType || story.type || 'Money story').replaceAll('_', ' ');
	const storyTone = (story) => story.cardFace?.theme || 'calm';
	const storyCardFace = (story) => story.cardFace || { heading: 'Money story', displayValue: 'View', theme: 'calm' };
	const storySource = (story) => story.source || story.domain || ($.strict_equals(story.storyType, 'MONTHLY_COMMITMENT') ? 'Planning' : 'Spending');
	const isCommitment = (story) => $.strict_equals(story?.storyType, 'MONTHLY_COMMITMENT');
	const storyIcon = (story) => isCommitment(story) ? '🎬' : '';
	const storyHeading = (story) => storyCardFace(story).heading;

	function setCommitmentStyle(style) {
		$.set(commitmentStyle, style);

		try {
			localStorage.setItem('money-stories.commitment-style', style);
		} catch {}
	}

	function localInputDate(value) {
		if (!value) return '';

		const text = String(value);

		if ((/^\d{4}-\d{2}-\d{2}$/).test(text)) return text;

		const date = new Date(text);

		return Number.isNaN(date.getTime())
			? text.slice(0, 10)
			: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
	}

	function evidenceFor(story, slide = 0) {
		const card = story?.cards?.slice().sort((a, b) => (a.sequence || 0) - (b.sequence || 0))[slide];
		const evidence = story?.evidence?.byCard?.[card?.cardId] || story?.evidence;

		const raw = Array.isArray(evidence)
			? evidence
			: evidence?.transactions || evidence?.items || story?.transactions || [];

		return raw.map((item) => {
			const [idType, id] = String(item.transactionId || item.id || '').split(':');

			return {
				sourceType: idType,
				sourceId: id,
				merchant: item.merchantLabel || item.merchant || item.merchantName || item.description || 'Expense',
				category: item.categoryLabel || item.category?.name || item.category || 'Uncategorised',
				detail: item.subcategoryLabel || item.detail || '',
				date: item.dateLabel || dateLabel(item.transactionDate || item.transactionTime || item.date),
				amount: item.amount?.displayValue || item.displayAmount || money(item.amount)
			};
		});
	}

	function loanSchedule(loan) {
		const first = new Date(`${loan.firstEmiDueDate}T12:00:00`);

		if (Number.isNaN(first.getTime())) return null;

		const tenure = Number(loan.totalTenureMonths) || 0,
			due = Number.isInteger(loan.completedEmiCount) ? loan.completedEmiCount : 0,
			remaining = Number.isInteger(loan.remainingEmiCount) ? loan.remainingEmiCount : Math.max(0, tenure - due),
			finalDue = new Date(first.getFullYear(), first.getMonth() + Math.max(0, tenure - 1), first.getDate());

		return {
			due,
			remaining,
			tenure,
			percent: tenure ? Math.round(due / tenure * 100) : 0,
			endLabel: new Intl.DateTimeFormat(undefined, { month: 'short', year: 'numeric' }).format(finalDue)
		};
	}

	function actionPresentation(action) {
		if ($.strict_equals(action.actionType, 'LOAN_CLOSURE_CONFIRMATION')) {
			const scheduled = action.scheduledCompletionDate
				? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${action.scheduledCompletionDate}T12:00:00`))
				: '';

			const description = (action.description || `EMI was scheduled to finish on ${scheduled}.`).replace(action.scheduledCompletionDate || '', scheduled).replace(/\s*Mark it closed if the final EMI was paid\.?\s*$/i, '');

			return {
				title: 'Loan closure confirmation',
				description,
				cta: 'Review loan'
			};
		}

		return null;
	}

	const moneyModulesCacheKey = () => `${MONEY_MODULES_CACHE_KEY}.${demoMode() ? 'demo' : 'real'}`;

	function readMoneyModulesCache() {
		try {
			const cached = JSON.parse(localStorage.getItem(moneyModulesCacheKey()) || 'null');

			if (!cached) return false;

			if (Array.isArray(cached.loans)) {
				$.set(loans, cached.loans);
				$.set(loanStatus, 'ready');
			}

			if (Array.isArray(cached.mutualFunds)) {
				$.set(mutualFunds, cached.mutualFunds);
				$.set(mutualFundStatus, 'ready');
			}

			if (Array.isArray(cached.stocks)) {
				$.set(stocks, cached.stocks);
				$.set(stockStatus, 'ready');
			}

			return true;
		} catch {
			return false;
		}
	}

	function saveMoneyModulesCache() {
		try {
			localStorage.setItem(moneyModulesCacheKey(), JSON.stringify({
				updatedAt: new Date().toISOString(),
				loans: $.get(loans /* The live modules still work if storage is unavailable. */),
				mutualFunds: $.get(mutualFunds),
				stocks: $.get(stocks)
			}));
		} catch {
			/* The live modules still work if storage is unavailable. */
		}
	}

	async function loadLoans() {
		$.set(loanStatus, $.get(loans).length ? 'refreshing' : 'loading');

		try {
			const result = (await $.track_reactivity_loss(getLoans()))();

			$.set(loans, result.loans || []);
			$.set(loanStatus, 'ready');
			saveMoneyModulesCache();
		} catch(cause) {
			if ($.get(loans).length) {
				$.set(loanStatus, 'ready');

				return;
			}

			$.set(loanStatus, 'error');
			$.set(loanError, cause?.message || 'Could not load loans.');
		}
	}

	async function loadCommitments() {
		$.set(commitmentStatus, 'loading');
		$.set(commitmentError, '');

		try {
			const result = (await $.track_reactivity_loss(getRecurringCommitments()))();

			$.set(commitments, result.items || []);
			$.set(commitmentStatus, 'ready');
		} catch(cause) {
			$.set(commitmentStatus, 'error');
			$.set(commitmentError, cause?.message || 'Could not load commitments.');
		}
	}

	function openCommitmentForm(item = null) {
		const editingExisting = Boolean(item && 'planningAmount' in item);

		$.set(commitmentError, '');
		$.set(commitmentEditingId, editingExisting ? item.id : null);

		$.set(commitmentForm, item
			? {
				label: editingExisting ? item.label : merchant(item),
				planningAmount: String(editingExisting ? item.planningAmount : item.amount || ''),

				dueDay: String(editingExisting
					? item.dueDay ?? ''
					: new Date(transactionDate(item)).getDate() || ''),

				amountMode: editingExisting ? item.amountMode || 'FIXED' : 'FIXED',
				...editingExisting ? {} : { sourceTransactionId: item.id }
			}
			: {
				label: '',
				planningAmount: '',
				dueDay: '',
				amountMode: 'FIXED'
			});

		$.set(showCommitmentForm, true);
	}

	async function saveCommitment() {
		const planningAmount = Number($.get(commitmentForm).planningAmount),
			dueDay = $.get(commitmentForm).dueDay ? Number($.get(commitmentForm).dueDay) : null;

		if (!$.get(commitmentForm).label.trim() || !(planningAmount > 0) || $.strict_equals(dueDay, null, false) && (dueDay < 1 || dueDay > 28)) {
			$.set(commitmentError, 'Add a name, a positive planning amount, and an optional due day from 1 to 28.');

			return;
		}

		$.set(commitmentSaving, true);

		try {
			const payload = {
				...$.get(commitmentForm),
				label: $.get(commitmentForm).label.trim(),
				planningAmount,
				dueDay,
				effectiveMonth: selectedMonth()
			};

			if ($.strict_equals($.get(commitmentEditingId), null, false)) delete payload.sourceTransactionId;

			(await $.track_reactivity_loss($.strict_equals($.get(commitmentEditingId), null)
				? createRecurringCommitment(payload)
				: updateRecurringCommitment($.get(commitmentEditingId), payload)))();

			$.set(showCommitmentForm, false);
			(await $.track_reactivity_loss(Promise.all([loadCommitments(), refreshStories()()])))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not save this commitment.');
		} finally {
			$.set(commitmentSaving, false);
		}
	}

	async function removeCommitment(commitment) {
		if ($.strict_equals($.get(commitmentDeletingId), null, false)) return;

		$.set(commitmentDeletingId, commitment.id);
		$.set(commitmentError, '');

		try {
			(await $.track_reactivity_loss(deleteRecurringCommitment(commitment.id)))();
			$.set(commitments, $.get(commitments).filter((item) => $.strict_equals(item.id, commitment.id, false)));
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not delete this commitment.');
		} finally {
			$.set(commitmentDeletingId, null);
		}
	}

	async function loadMutualFunds() {
		$.set(mutualFundStatus, $.get(mutualFunds).length ? 'refreshing' : 'loading');
		$.set(mutualFundError, '');

		try {
			const result = (await $.track_reactivity_loss(getMutualFunds()))();

			$.set(mutualFunds, result.mutualFunds || []);
			$.set(mutualFundStatus, 'ready');
			saveMoneyModulesCache();
		} catch(cause) {
			if ($.get(mutualFunds).length) {
				$.set(mutualFundStatus, 'ready');

				return;
			}

			$.set(mutualFundStatus, 'error');
			$.set(mutualFundError, cause?.message || 'Could not load mutual funds.');
		}
	}

	async function loadStocks() {
		$.set(stockStatus, $.get(stocks).length ? 'refreshing' : 'loading');
		$.set(stockError, '');

		try {
			const result = (await $.track_reactivity_loss(getStocks()))();

			$.set(stocks, result.stocks || []);
			$.set(stockStatus, 'ready');
			saveMoneyModulesCache();
		} catch(cause) {
			if ($.get(stocks).length) {
				$.set(stockStatus, 'ready');

				return;
			}

			$.set(stockStatus, 'error');
			$.set(stockError, cause?.message || 'Could not load stocks.');
		}
	}

	async function loadActions() {
		actionsStatus = $.get(actions).length ? 'refreshing' : 'loading';
		actionsError = '';

		try {
			const result = (await $.track_reactivity_loss(getActions()))();

			$.set(actions, result.actions || []);
			actionsStatus = 'ready';
		} catch(cause) {
			actionsStatus = 'error';
			actionsError = cause?.message || 'Could not load actions.';
		}
	}

	async function completeOpenAction(action) {
		if ($.strict_equals($.get(completingActionId), null, false)) return;

		$.set(completingActionId, action.id);
		actionsError = '';

		try {
			(await $.track_reactivity_loss(completeAction(action.id)))();
			$.set(actions, $.get(actions).filter((item) => $.strict_equals(item.id, action.id, false)));
			(await $.track_reactivity_loss(Promise.all([loadLoans(), loadActions()])))();
		} catch(cause) {
			actionsError = cause?.message || 'Could not complete this action.';
		} finally {
			$.set(completingActionId, null);
		}
	}

	function moneyReviewTarget(type, id) {
		if ($.strict_equals(type, 'loan')) {
			const loan = $.get(loans).find((item) => $.strict_equals(String(item.id), String(id)));

			return loan && [
				...document.querySelectorAll('[data-testid="loans-section"] .loan-row')
			].find((row) => row.querySelector('.loan-name')?.textContent.trim().startsWith(loan.loanName));
		}

		if ($.strict_equals(type, 'commitment')) return document.querySelector(`[data-testid="monthly-commitment-${id}"]`);
		if ($.strict_equals(type, 'stock')) return document.querySelector(`[data-testid="stock-card-${id}"]`);

		const fund = fundSummary(id);

		return fund && [
			...document.querySelectorAll('.mutual-funds-module:not(.stocks-module) .fund-card')
		].find((card) => $.strict_equals(card.getAttribute('aria-label'), `Open ${fund.schemeName} details`));
	}

	async function focusMoneyTarget(type, id) {
		(await $.track_reactivity_loss(tick()))();
		(await $.track_reactivity_loss(new Promise((resolve) => requestAnimationFrame(resolve))))();

		const target = moneyReviewTarget(type, id);

		if (!target) return;

		target.tabIndex = -1;
		target.scrollIntoView({ behavior: 'smooth', block: 'center' });
		target.focus({ preventScroll: true });
	}

	async function openLoanDueAction(action) {
		$.set(highlightedLoanId, action.referenceId);
		$.set(showMoney, true);
		(await $.track_reactivity_loss(Promise.all([loadLoans(), loadActions()])))();
		(await $.track_reactivity_loss(focusMoneyTarget('loan', action.referenceId)))();
	}

	async function openCommitmentSources() {
		$.set(showStoryEvidence, true);
		(await $.track_reactivity_loss(Promise.all([loadMutualFunds(), loadCommitments()])))();
	}

	async function openIncludedLoan(event) {
		const loanItems = $.get(evidenceItems).filter((item) => (/loan/i).test(item.category));

		const buttons = [
			...document.querySelectorAll('[data-testid="included-loan-commitment"]')
		];

		const item = loanItems[buttons.indexOf(event.currentTarget)];

		if (!item) return;

		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('loan', item.sourceId)))();
	}

	async function openIncludedMutualFund(item) {
		highlightedFundId = item.sourceId;
		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('fund', item.sourceId)))();
	}

	async function openIncludedStock(item) {
		$.set(highlightedStockId, item.sourceId);
		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('stock', item.sourceId)))();
	}

	async function openIncludedCommitment(item) {
		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('commitment', item.sourceId)))();
	}

	const recurringOccurrence = (item) => {
		const id = $.strict_equals(typeof item, 'object') ? item.sourceId : item;
		const match = $.get(commitments).find((value) => $.strict_equals(String(value.id), String(id))) || $.get(commitments).find((value) => $.strict_equals(value.label, item?.merchant));

		return (match || $.strict_equals($.get(commitments).length, 1) && $.get(commitments)[0])?.currentOccurrence;
	};

	async function markCommitmentDone(commitment) {
		if ($.strict_equals(completingCommitmentId, null, false)) return;

		const occurrence = commitment.currentOccurrence;

		if (!occurrence?.month) return;

		completingCommitmentId = commitment.id;
		$.set(commitmentError, '');

		try {
			(await $.track_reactivity_loss(completeRecurringCommitment(commitment.id, occurrence.month)))();
			(await $.track_reactivity_loss(Promise.all([loadCommitments(), refreshStories()()])))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not mark this commitment done.');
		} finally {
			completingCommitmentId = null;
		}
	}

	function sipIsDue(item) {
		return $.strict_equals($.get(mutualFunds).find((fund) => $.strict_equals(String(fund.id), String(item.sourceId)))?.currentSip?.status, 'DUE');
	}

	function sipIsConfirmed(item) {
		return $.strict_equals($.get(mutualFunds).find((fund) => $.strict_equals(String(fund.id), String(item.sourceId)))?.currentSip?.status, 'CONFIRMED');
	}

	function currentCommitmentIsDue() {
		const card = $.get(openedStory)?.cards?.slice().sort((a, b) => (a.sequence || 0) - (b.sequence || 0))[$.get(storySlide)];

		return card?.components?.some((component) => $.strict_equals(component.label, 'This month') && component.displayValue?.startsWith('Due'));
	}

	const incomeRangeLabel = (value) => ({
		UNDER_25000: 'Under ₹25k',
		FROM_25000_TO_50000: '₹25k–₹50k',
		FROM_50000_TO_100000: '₹50k–₹1L',
		FROM_100000_TO_200000: '₹1L–₹2L',
		OVER_200000: 'Over ₹2L'
	})[value] || 'Not shared';

	async function loadIncomeOutlook() {
		$.set(incomeStatus, 'loading');
		$.set(incomeError, '');

		try {
			$.set(incomeOutlook, (await $.track_reactivity_loss(getIncomeOutlook()))());
			$.set(incomeStatus, 'ready');
		} catch(cause) {
			$.set(incomeStatus, 'error');
			$.set(incomeError, cause?.message || 'Could not load your income outlook.');
		}
	}

	async function openMoney() {
		$.set(showMoney, true);
		readMoneyModulesCache();

		(await $.track_reactivity_loss(Promise.all([
			loadLoans(),
			loadMutualFunds(),
			loadStocks(),
			loadIncomeOutlook(),
			loadCommitments(),
			loadCreditCards(),
			loadExpenseOptions()
		])))();
	}

	function closeMoney() {
		$.set(showMoney, false);
		$.set(highlightedLoanId, null);
		highlightedFundId = null;
	}

	const fundSummary = (id) => $.get(mutualFunds).find((fund) => $.strict_equals(String(fund.id), String(id)));

	async function loadCreditCards() {
		$.set(creditCardStatus, 'loading');
		$.set(creditCardError, '');

		try {
			const result = (await $.track_reactivity_loss(getCreditCards()))();

			$.set(creditCards, result.cards || []);
			$.set(creditCardStatus, 'ready');
		} catch(cause) {
			$.set(creditCardStatus, 'error');
			$.set(creditCardError, cause?.message || 'Could not load credit cards.');
		}
	}

	async function loadExpenseOptions() {
		if ($.strict_equals($.get(optionsStatus), 'loading')) return;

		try {
			const result = (await $.track_reactivity_loss(getExpenseOptions()))();

			$.set(editOptions, {
				categories: result.categories || [],
				merchants: result.merchants || [],
				accounts: result.accounts || []
			});

			$.set(optionsStatus, 'ready');
		} catch(cause) {
			$.set(optionsStatus, 'error');
			$.set(optionsError, cause?.message || 'Could not load accounts.');
		}
	}

	function openCreditCardForm(card = null) {
		$.set(creditCardError, '');
		$.set(creditCardEditingId, card?.id ?? null);

		$.set(creditCardForm, card
			? {
				accountReferenceId: String(card.accountReferenceId),
				cardName: card.cardName,
				issuerName: card.issuerName,
				statementDay: String(card.statementDay),
				dueDay: String(card.dueDay)
			}
			: {
				accountReferenceId: '',
				cardName: '',
				issuerName: '',
				statementDay: '',
				dueDay: ''
			});

		$.set(showCreditCardForm, true);
	}

	async function saveCreditCard() {
		const statementDay = Number($.get(creditCardForm).statementDay),
			dueDay = Number($.get(creditCardForm).dueDay);

		if (!$.get(creditCardForm).accountReferenceId || !$.get(creditCardForm).cardName.trim() || !$.get(creditCardForm).issuerName.trim() || statementDay < 1 || statementDay > 28 || dueDay < 1 || dueDay > 28) {
			$.set(creditCardError, 'Choose the captured card account and enter days from 1 to 28.');

			return;
		}

		$.set(creditCardSaving, true);
		$.set(creditCardError, '');

		const payload = {
			accountReferenceId: Number($.get(creditCardForm).accountReferenceId),
			cardName: $.get(creditCardForm).cardName.trim(),
			issuerName: $.get(creditCardForm).issuerName.trim(),
			statementDay,
			dueDay
		};

		try {
			const saved = $.strict_equals($.get(creditCardEditingId), null)
				? (await $.track_reactivity_loss(createCreditCard(payload)))()
				: (await $.track_reactivity_loss(updateCreditCard($.get(creditCardEditingId), payload)))();

			$.set(creditCards, $.strict_equals($.get(creditCardEditingId), null)
				? [saved, ...$.get(creditCards)]
				: $.get(creditCards).map((card) => $.strict_equals(card.id, saved.id) ? saved : card));

			$.set(creditCardStatus, 'ready');
			$.set(showCreditCardForm, false);
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(creditCardError, cause?.message || 'Could not save this credit card.');
		} finally {
			$.set(creditCardSaving, false);
		}
	}

	function openIncomeFlow() {
		$.set(incomeError, '');

		$.set(salaryForm, {
			salaryVisibility: 'RANGE',
			salaryRange: 'FROM_50000_TO_100000',
			exactMonthlySalary: '',
			salaryFrequency: 'MONTHLY'
		});

		$.set(showIncomeFlow, true);
	}

	async function saveSalary() {
		$.set(incomeSaving, true);
		$.set(incomeError, '');

		try {
			(await $.track_reactivity_loss(saveIncomeProfile({
				...$.get(salaryForm),
				exactMonthlySalary: $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT') ? Number($.get(salaryForm).exactMonthlySalary) : null
			})))();

			(await $.track_reactivity_loss(loadIncomeOutlook()))();
			$.set(showIncomeFlow, false);
		} catch(cause) {
			$.set(incomeError, cause?.message || 'Could not save this preference.');
		} finally {
			$.set(incomeSaving, false);
		}
	}

	function openLoanForm(loan = null) {
		$.set(loanError, '');
		$.set(loanEditingId, loan?.id ?? null);

		$.set(loanForm, loan
			? {
				loanName: loan.loanName || '',
				loanType: loan.loanType || 'HOME',
				lenderName: loan.lenderName || '',
				originalPrincipal: String(loan.originalPrincipal ?? ''),
				monthlyEmiAmount: String(loan.monthlyEmiAmount ?? ''),
				totalTenureMonths: String(loan.totalTenureMonths ?? ''),
				firstEmiDueDate: localInputDate(loan.firstEmiDueDate),
				notes: loan.notes || ''
			}
			: {
				loanName: '',
				loanType: 'HOME',
				lenderName: '',
				originalPrincipal: '',
				monthlyEmiAmount: '',
				totalTenureMonths: '',
				firstEmiDueDate: '',
				notes: ''
			});

		$.set(showLoanForm, true);
	}

	async function saveLoan() {
		const originalPrincipal = Number($.get(loanForm).originalPrincipal),
			monthlyEmiAmount = Number($.get(loanForm).monthlyEmiAmount),
			totalTenureMonths = Number($.get(loanForm).totalTenureMonths);

		if (!$.get(loanForm).loanName.trim() || !$.get(loanForm).lenderName.trim() || !$.get(loanForm).firstEmiDueDate || originalPrincipal <= 0 || monthlyEmiAmount <= 0 || !Number.isInteger(totalTenureMonths) || totalTenureMonths <= 0) {
			$.set(loanError, 'Complete every required loan detail with valid positive amounts.');

			return;
		}

		const payload = {
			loanName: $.get(loanForm).loanName.trim(),
			loanType: $.get(loanForm).loanType,
			lenderName: $.get(loanForm).lenderName.trim(),
			originalPrincipal,
			monthlyEmiAmount,
			totalTenureMonths,
			firstEmiDueDate: $.get(loanForm).firstEmiDueDate,
			notes: $.get(loanForm).notes
		};

		$.set(loanSaving, true);
		$.set(loanError, '');

		try {
			const saved = $.equals($.get(loanEditingId), null)
				? (await $.track_reactivity_loss(createLoan(payload)))()
				: (await $.track_reactivity_loss(updateLoan($.get(loanEditingId), payload)))();

			$.set(loans, $.equals($.get(loanEditingId), null)
				? [...$.get(loans), saved]
				: $.get(loans).map((loan) => $.strict_equals(loan.id, saved.id) ? saved : loan));

			$.set(showLoanForm, false);
			$.set(loanStatus, 'ready');
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(loanError, cause?.message || 'Could not save this loan.');
		} finally {
			$.set(loanSaving, false);
		}
	}

	async function removeLoan(loan) {
		if ($.strict_equals($.get(loanDeletingId), null, false)) return;

		$.set(loanDeletingId, loan.id);
		$.set(loanError, '');

		try {
			(await $.track_reactivity_loss(deleteLoan(loan.id)))();
			$.set(loans, $.get(loans).filter((item) => $.strict_equals(item.id, loan.id, false)));
			saveMoneyModulesCache();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(loanError, cause?.message || 'Could not delete this loan.');
		} finally {
			$.set(loanDeletingId, null);
		}
	}

	async function payLoanEmi(loan, occurrence) {
		try {
			(await $.track_reactivity_loss(markLoanEmiPaid(loan.id, occurrence.month)))();
			(await $.track_reactivity_loss(Promise.all([loadLoans(), refreshStories()()])))();
		} catch(cause) {
			$.set(loanError, cause?.message || 'Could not mark this EMI paid.');
		}
	}

	async function openLoanHistory(loan) {
		$.set(loanHistory, { loanName: loan.loanName });
		$.set(loanHistoryStatus, 'loading');
		$.set(loanHistoryError, '');

		try {
			$.set(loanHistory, (await $.track_reactivity_loss(getLoanHistory(loan.id)))());
			$.set(loanHistoryStatus, 'ready');
		} catch(cause) {
			$.set(loanHistoryStatus, 'error');
			$.set(loanHistoryError, cause?.message || 'Could not load payment history.');
		}
	}

	async function payLoanHistoryEmi(occurrence) {
		if (!$.get(loanHistory)) return;

		try {
			(await $.track_reactivity_loss(markLoanEmiPaid($.get(loanHistory).id, occurrence.month)))();

			(await $.track_reactivity_loss(Promise.all([
				loadLoans(),
				openLoanHistory($.get(loanHistory)),
				refreshStories()()
			])))();
		} catch(cause) {
			$.set(loanHistoryError, cause?.message || 'Could not mark this EMI paid.');
		}
	}

	async function openCommitmentHistory(commitment) {
		$.set(commitmentHistory, { label: commitment.label });
		$.set(commitmentHistoryStatus, 'loading');
		$.set(commitmentHistoryError, '');

		try {
			$.set(commitmentHistory, (await $.track_reactivity_loss(getRecurringCommitmentHistory(commitment.id)))());
			$.set(commitmentHistoryStatus, 'ready');
		} catch(cause) {
			$.set(commitmentHistoryStatus, 'error');
			$.set(commitmentHistoryError, cause?.message || 'Could not load payment history.');
		}
	}

	function openMutualFundForm() {
		$.set(fundError, '');
		$.set(fundSaved, false);
		$.set(schemeQuery, '');
		$.set(selectedScheme, null);
		$.set(showSchemeMenu, false);

		$.set(fundForm, {
			hasSip: 'YES',
			sipAmount: '25000',
			sipDate: '5',
			startMonth: '2026-10',
			hasHolding: 'YES',
			currentUnits: '128.456',
			totalInvested: '10000'
		});

		$.set(showMutualFundForm, true);
	}

	async function searchSchemes(value) {
		$.set(schemeQuery, value);
		$.set(selectedScheme, null);
		$.set(showSchemeMenu, true);
		$.set(fundError, '');

		if (value.trim().length < 2) {
			$.set(schemeResults, []);
			$.set(schemeSearchStatus, 'idle');

			return;
		}

		const requestId = ++schemeSearchRequest;

		$.set(schemeSearchStatus, 'loading');

		try {
			const result = (await $.track_reactivity_loss(searchMutualFunds(value.trim())))();

			if ($.strict_equals(requestId, schemeSearchRequest, false)) return;

			$.set(schemeResults, Array.isArray(result) ? result : result.schemes || []);
			$.set(schemeSearchStatus, 'ready');
		} catch(cause) {
			if ($.strict_equals(requestId, schemeSearchRequest, false)) return;

			$.set(schemeResults, []);
			$.set(schemeSearchStatus, 'error');
			$.set(fundError, cause?.message || 'Could not search the scheme master.');
		}
	}

	function selectScheme(scheme) {
		$.set(selectedScheme, scheme);
		$.set(schemeQuery, scheme.schemeName);
		$.set(showSchemeMenu, false);
		$.set(fundError, '');
	}

	async function saveMutualFund() {
		const sipAmount = Number($.get(fundForm).sipAmount),
			units = Number($.get(fundForm).currentUnits),
			invested = Number($.get(fundForm).totalInvested);

		if (!$.get(selectedScheme)) {
			$.set(fundError, 'Choose a scheme from the verified scheme master.');

			return;
		}

		if ($.strict_equals($.get(fundForm).hasSip, 'YES') && (sipAmount <= 0 || !$.get(fundForm).sipDate || !$.get(fundForm).startMonth)) {
			$.set(fundError, 'Add a valid monthly amount, SIP date, and start month.');

			return;
		}

		if ($.strict_equals($.get(fundForm).hasHolding, 'YES') && (!(units > 0) || !(invested > 0))) {
			$.set(fundError, 'Enter current units and invested amount greater than zero.');

			return;
		}

		const payload = {
			schemeCode: $.get(selectedScheme).schemeCode,
			schemeName: $.get(selectedScheme).schemeName,

			...$.strict_equals($.get(fundForm).hasSip, 'YES')
				? {
					monthlySipAmount: sipAmount,
					sipDay: Number($.get(fundForm).sipDate),
					startMonth: $.get(fundForm).startMonth
				}
				: {},

			...$.get(selectedScheme).isin ? { isin: $.get(selectedScheme).isin } : {},

			...$.strict_equals($.get(fundForm).hasHolding, 'YES')
				? {
					existingHolding: { currentUnits: units, totalInvestedAmount: invested }
				}
				: {}
		};

		$.set(fundSaving, true);
		$.set(fundError, '');

		try {
			(await $.track_reactivity_loss(createMutualFund(payload)))();
			$.set(fundSaved, true);
			(await $.track_reactivity_loss(loadMutualFunds()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(fundError, cause?.message || 'Could not create this mutual fund.');
		} finally {
			$.set(fundSaving, false);
		}
	}

	async function removeMutualFund(fund) {
		if ($.strict_equals($.get(mutualFundDeletingId), null, false)) return;

		$.set(mutualFundDeletingId, fund.id);
		$.set(mutualFundError, '');

		try {
			(await $.track_reactivity_loss(deleteMutualFund(fund.id)))();
			$.set(mutualFunds, $.get(mutualFunds).filter((item) => $.strict_equals(item.id, fund.id, false)));
			saveMoneyModulesCache();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(mutualFundError, cause?.message || 'Could not delete this mutual fund.');
		} finally {
			$.set(mutualFundDeletingId, null);
		}
	}

	function openFundSipPlan(fund) {
		$.set(fundSipTarget, fund);

		$.set(fundSipForm, {
			amount: '',
			day: '',
			startMonth: new Date().toISOString().slice(0, 7)
		});

		$.set(fundError, '');
	}

	async function saveFundSipPlan() {
		const amount = Number($.get(fundSipForm).amount),
			day = Number($.get(fundSipForm).day);

		if (!(amount > 0) || !(day >= 1 && day <= 28) || !$.get(fundSipForm).startMonth) {
			$.set(fundError, 'Enter a positive monthly amount, a day from 1 to 28, and a start month.');

			return;
		}

		$.set(fundSipSaving, true);

		try {
			(await $.track_reactivity_loss(createMutualFundSip($.get(fundSipTarget).id, { amount, day, startMonth: $.get(fundSipForm).startMonth })))();
			$.set(fundSipTarget, null);
			(await $.track_reactivity_loss(loadMutualFunds()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(fundError, cause?.message || 'Could not save this SIP.');
		} finally {
			$.set(fundSipSaving, false);
		}
	}

	function openStockForm() {
		$.set(stockError, '');
		$.set(stockQuery, '');
		$.set(selectedStock, null);
		$.set(stockResults, []);
		$.set(stockForm, { quantity: '', totalInvested: '' });
		$.set(showStockForm, true);
	}

	async function findStocks(value) {
		$.set(stockQuery, value);
		$.set(selectedStock, null);
		$.set(stockError, '');

		if (value.trim().length < 2) {
			$.set(stockResults, []);
			$.set(stockSearchStatus, 'idle');

			return;
		}

		const requestId = ++stockSearchRequest;

		$.set(stockSearchStatus, 'loading');

		try {
			const result = (await $.track_reactivity_loss(searchStocks(value.trim())))();

			if ($.strict_equals(requestId, stockSearchRequest, false)) return;

			$.set(stockResults, Array.isArray(result) ? result : []);
			$.set(stockSearchStatus, 'ready');
		} catch(cause) {
			if ($.strict_equals(requestId, stockSearchRequest, false)) return;

			$.set(stockResults, []);
			$.set(stockSearchStatus, 'error');
			$.set(stockError, cause?.message || 'Could not search stock symbols.');
		}
	}

	function selectStock(stock) {
		$.set(selectedStock, stock);
		$.set(stockQuery, `${stock.name} (${stock.symbol})`);
		$.set(stockResults, []);
		$.set(stockError, '');
	}

	async function saveStock() {
		const quantity = Number($.get(stockForm).quantity),
			totalInvestedAmount = Number($.get(stockForm).totalInvested);

		if (!$.get(selectedStock)) {
			$.set(stockError, 'Choose a stock from the search results.');

			return;
		}

		if (!(quantity > 0) || !(totalInvestedAmount > 0)) {
			$.set(stockError, 'Enter valid positive quantity and total invested amount.');

			return;
		}

		$.set(stockSaving, true);
		$.set(stockError, '');

		try {
			(await $.track_reactivity_loss(createStock({
				symbol: $.get(selectedStock).symbol,
				name: $.get(selectedStock).name,
				exchange: $.get(selectedStock).exchange,
				quantity,
				totalInvestedAmount
			})))();

			$.set(showStockForm, false);
			(await $.track_reactivity_loss(loadStocks()))();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not add this stock.');
		} finally {
			$.set(stockSaving, false);
		}
	}

	async function removeStock(stock) {
		if ($.strict_equals($.get(stockDeletingId), null, false)) return;

		$.set(stockDeletingId, stock.id);
		$.set(stockError, '');

		try {
			(await $.track_reactivity_loss(deleteStock(stock.id)))();
			$.set(stocks, $.get(stocks).filter((item) => $.strict_equals(item.id, stock.id, false)));
			saveMoneyModulesCache();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not delete this stock.');
		} finally {
			$.set(stockDeletingId, null);
		}
	}

	function openStockPlan(stock) {
		$.set(stockPlanTarget, stock);

		$.set(stockPlanForm, {
			amount: stock.activeMonthlyPlan?.amount || '',
			day: stock.activeMonthlyPlan?.day || '',
			startMonth: stock.activeMonthlyPlan?.startMonth || new Date().toISOString().slice(0, 7)
		});

		$.set(stockError, '');
	}

	async function saveStockPlan() {
		const amount = Number($.get(stockPlanForm).amount),
			day = Number($.get(stockPlanForm).day);

		if (!(amount > 0) || !(day >= 1 && day <= 28) || !$.get(stockPlanForm).startMonth) {
			$.set(stockError, 'Enter a positive amount, a day from 1 to 28, and a start month.');

			return;
		}

		$.set(stockPlanSaving, true);

		try {
			(await $.track_reactivity_loss(createStockMonthlyPlan($.get(stockPlanTarget).id, { amount, day, startMonth: $.get(stockPlanForm).startMonth })))();
			$.set(stockPlanTarget, null);
			(await $.track_reactivity_loss(loadStocks()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not save this monthly plan.');
		} finally {
			$.set(stockPlanSaving, false);
		}
	}

	async function confirmStockPlan() {
		const amount = Number($.get(stockPlanConfirmation).amount),
			executionPrice = Number($.get(stockPlanConfirmation).price);

		if (!(amount > 0) || !(executionPrice > 0)) return;

		try {
			(await $.track_reactivity_loss(confirmStockMonthlyPlan($.get(stockPlanConfirmationTarget).id, $.get(stockPlanConfirmationTarget).currentMonthlyPlan.month, {
				amount,
				executionPrice,
				transactionDate: new Date().toISOString().slice(0, 10)
			})))();

			$.set(stockPlanConfirmationTarget, null);
			(await $.track_reactivity_loss(loadStocks()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not confirm this ETF investment.');
		}
	}

	async function openStockDetail(id) {
		$.set(stockDetail, { id });
		$.set(stockDetailStatus, 'loading');

		try {
			$.set(stockDetail, (await $.track_reactivity_loss(getStock(id)))());
			$.set(stockDetailStatus, 'ready');
		} catch(cause) {
			$.set(stockDetailStatus, 'error');
			$.set(stockError, cause?.message || 'Could not load this stock.');
		}
	}

	function openSipConfirmation(fund, occurrence) {
		$.set(confirmingSip, { fund, occurrence });
		$.set(sipConfirmError, '');

		$.set(sipConfirmForm, {
			amount: String(occurrence.amount || fund.monthlySipAmount || ''),
			transactionDate: occurrence.transactionDate || new Date().toISOString().slice(0, 10),
			nav: $.equals(occurrence.nav, null) ? '' : String(occurrence.nav)
		});
	}

	async function saveSipConfirmation() {
		const amount = Number($.get(sipConfirmForm).amount),
			nav = Number($.get(sipConfirmForm).nav);

		if (!(amount > 0) || !$.get(sipConfirmForm).transactionDate || !(nav > 0)) {
			$.set(sipConfirmError, 'Enter a valid amount, transaction date, and NAV.');

			return;
		}

		$.set(sipConfirmSaving, true);
		$.set(sipConfirmError, '');

		try {
			const payload = {
				amount,
				transactionDate: $.get(sipConfirmForm).transactionDate,
				nav,
				calculationSource: 'NAV_ESTIMATED'
			};

			if ($.strict_equals($.get(confirmingSip).occurrence.status, 'CONFIRMED')) (await $.track_reactivity_loss(updateSipOccurrence($.get(confirmingSip).fund.id, $.get(confirmingSip).occurrence.scheduledMonth, payload)))(); else (await $.track_reactivity_loss(confirmSipOccurrence($.get(confirmingSip).fund.id, $.get(confirmingSip).occurrence.scheduledMonth, payload)))();

			$.set(confirmingSip, null);
			(await $.track_reactivity_loss(loadMutualFunds()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(sipConfirmError, cause?.message || 'Could not save this SIP allocation.');
		} finally {
			$.set(sipConfirmSaving, false);
		}
	}

	async function openFundDetail(id) {
		$.set(fundDetail, { id });
		$.set(fundDetailStatus, 'loading');
		$.set(fundDetailError, '');

		try {
			$.set(fundDetail, (await $.track_reactivity_loss(getMutualFund(id)))());
			$.set(fundDetailStatus, 'ready');
		} catch(cause) {
			$.set(fundDetailStatus, 'error');
			$.set(fundDetailError, cause?.message || 'Could not load this fund.');
		}
	}

	function openLumpSum(fund) {
		$.set(lumpSumFund, fund);
		$.set(lumpSumError, '');

		$.set(lumpSumForm, {
			amount: '',
			transactionDate: new Date().toISOString().slice(0, 10),
			nav: ''
		});
	}

	function openHistoryEdit(fund, entry) {
		$.set(editingFundTransaction, { fund, entry });
		$.set(fundTransactionError, '');

		$.set(fundTransactionForm, {
			amount: String(entry.amount || ''),
			transactionDate: entry.transactionDate || '',
			nav: $.equals(entry.nav, null) ? '' : String(entry.nav)
		});
	}

	async function saveFundTransaction() {
		const amount = Number($.get(fundTransactionForm).amount),
			nav = Number($.get(fundTransactionForm).nav);

		if (!(amount > 0) || !$.get(fundTransactionForm).transactionDate || !(nav > 0)) {
			$.set(fundTransactionError, 'Enter a valid amount, transaction date, and NAV.');

			return;
		}

		$.set(fundTransactionSaving, true);
		$.set(fundTransactionError, '');

		try {
			(await $.track_reactivity_loss(updateMutualFundTransaction($.get(editingFundTransaction).fund.id, $.get(editingFundTransaction).entry.id, {
				amount,
				transactionDate: $.get(fundTransactionForm).transactionDate,
				nav,
				calculationSource: 'USER_ENTERED'
			})))();

			const id = $.get(editingFundTransaction).fund.id;

			$.set(editingFundTransaction, null);
			(await $.track_reactivity_loss(Promise.all([loadMutualFunds(), openFundDetail(id), refreshStories()()])))();
		} catch(cause) {
			$.set(fundTransactionError, cause?.message || 'Could not update this investment.');
		} finally {
			$.set(fundTransactionSaving, false);
		}
	}

	async function saveLumpSum() {
		const amount = Number($.get(lumpSumForm).amount),
			nav = Number($.get(lumpSumForm).nav);

		if (!(amount > 0) || !$.get(lumpSumForm).transactionDate || !(nav > 0)) {
			$.set(lumpSumError, 'Enter a positive amount, transaction date, and NAV.');

			return;
		}

		$.set(lumpSumSaving, true);

		try {
			(await $.track_reactivity_loss(createMutualFundLumpSum($.get(lumpSumFund).id, {
				amount,
				transactionDate: $.get(lumpSumForm).transactionDate,
				nav,
				calculationSource: 'NAV_ESTIMATED'
			})))();

			$.set(lumpSumFund, null);
			(await $.track_reactivity_loss(Promise.all([loadMutualFunds(), refreshStories()()])))();
		} catch(cause) {
			$.set(lumpSumError, cause?.message || 'Could not add this lump sum.');
		} finally {
			$.set(lumpSumSaving, false);
		}
	}

	function navigate(next) {
		$.set(view, next);

		if ($.strict_equals(next, 'transactions', false)) {
			$.set(selectedDay, null);
			$.set(activityTab, 'recent');
		}

		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

	function currentLocalMonth() {
		const now = new Date();

		return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
	}

	function changeMonth(offset) {
		const [y, m] = selectedMonth().split('-').map(Number),
			next = new Date(Date.UTC(y, m - 1 + offset, 1)).toISOString().slice(0, 7);

		if (next <= currentLocalMonth()) {
			$.set(selectedDay, null);
			$.set(dayItems, []);
			$.set(activityTab, 'recent');
			onMonthChange()(next);
		}
	}

	function buildCalendar(monthValue, apiDays) {
		const [y, m] = monthValue.split('-').map(Number),
			count = new Date(y, m, 0).getDate(),
			leading = (new Date(y, m - 1, 1).getDay() + 6) % 7,
			values = new Map(apiDays.map((x) => [Number(String(x.date).slice(-2)), x])),
			today = new Date(),
			current = $.strict_equals(today.getFullYear(), y) && $.strict_equals(today.getMonth() + 1, m);

		return {
			leading,

			days: Array.from({ length: count }, (_, i) => {
				const day = i + 1, v = values.get(day) || {};

				return {
					day,
					totalSpend: Number(v.totalSpend || 0),
					transactionCount: Number(v.transactionCount || 0),
					intensity: Math.max(0, Math.min(4, Number(v.intensity || 0))),
					future: current && day > today.getDate()
				};
			})
		};
	}

	async function selectDate(day) {
		if (!day || day.future) return;

		$.set(selectedDay, day.day);
		$.set(activityTab, 'day');
		$.set(showAll, false);
		$.set(expandedId, null);
		(await $.track_reactivity_loss(loadDay()))();
	}

	async function loadDay() {
		if ($.equals($.get(selectedDay), null)) return;

		$.set(dayStatus, 'loading');

		try {
			const page = (await $.track_reactivity_loss(getExpensesForDate(selectedMonth(), isoDate($.get(selectedDay)), 50)))();

			$.set(dayItems, page.items || page.expenses || []);
			$.set(dayStatus, 'ready');
		} catch {
			$.set(dayStatus, 'error');
		}
	}

	async function openStory(story) {
		$.set(openedStory, story);
		$.set(storySlide, 0);
		$.set(showStoryEvidence, false);

		const hasReview = (story.cards || []).some((card) => (card.actions || []).some((action) => $.strict_equals(action.type, 'OPEN_COMMITMENT_REVIEW')));

		if (hasReview) {
			$.set(commitmentReviewStatus, 'loading');
			$.set(showCommitmentReview, true);

			try {
				const result = (await $.track_reactivity_loss(getCommitmentReview(selectedMonth())))();

				$.set(commitmentReview, result.items || []);
				$.set(commitmentReviewStatus, 'ready');
			} catch(cause) {
				$.set(commitmentReviewStatus, 'error');
				$.set(commitmentError, cause?.message || 'Could not load payments needing review.');
			}
		}
	}

	function storyHasLoan(story) {
		return isCommitment(story) && evidenceFor(story, $.get(storySlide)).some((item) => (/loan/i).test(item.category));
	}

	async function resolveCandidate(transactionId, commitmentId) {
		$.set(resolvingCandidate, transactionId);

		try {
			(await $.track_reactivity_loss(resolveCommitmentReview(transactionId, commitmentId)))();
			$.set(commitmentReview, $.get(commitmentReview).filter((item) => $.strict_equals(item.transactionId, transactionId, false)));
			(await $.track_reactivity_loss(refreshStories()()))();

			if (!$.get(commitmentReview).length) $.set(showCommitmentReview, false);
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not save this review.');
		} finally {
			$.set(resolvingCandidate, null);
		}
	}

	function endStorySwipe(event, length) {
		if ($.strict_equals($.get(storyTouchStart), null)) return;

		const distance = event.changedTouches[0].clientX - $.get(storyTouchStart);

		if (Math.abs(distance) > 45) $.set(storySlide, Math.max(0, Math.min(length - 1, $.get(storySlide) + (distance < 0 ? 1 : -1))));

		$.set(storyTouchStart, null);
	}

	function endRailSwipe(event, length, rail) {
		if ($.strict_equals($.get(storyRailTouchStart), null)) return;

		const distance = event.changedTouches[0].clientX - $.get(storyRailTouchStart);

		if (Math.abs(distance) > 45) {
			const next = Math.max(0, Math.min(length - 1, ($.strict_equals(rail, 'home') ? $.get(homeStoryIndex) : $.get(storiesRailIndex)) + (distance < 0 ? 1 : -1)));

			if ($.strict_equals(rail, 'home')) $.set(homeStoryIndex, next); else $.set(storiesRailIndex, next);
		}

		$.set(storyRailTouchStart, null);
	}

	async function startEdit(item) {
		$.set(editing, item);
		$.set(editAmount, String(item.amount ?? ''));
		$.set(editDate, localInputDate(transactionDate(item)));
		$.set(editCategory, $.strict_equals(category(item), 'Uncategorised') ? '' : category(item));
		$.set(editSubcategory, item.subcategory?.name || item.subcategory || '');
		$.set(editMerchantId, String(item.merchantId ?? item.merchant?.id ?? ''));
		$.set(editAccountId, String(item.accountId ?? item.account?.id ?? item.sourceAccountId ?? ''));
		$.set(actionError, '');
		$.set(optionsError, '');

		if ($.strict_equals($.get(optionsStatus), 'ready')) {
			selectCurrentReferences(item);

			return;
		}

		$.set(optionsStatus, 'loading');

		try {
			const result = (await $.track_reactivity_loss(getExpenseOptions()))();

			$.set(editOptions, {
				categories: result.categories || [],
				merchants: result.merchants || [],
				accounts: result.accounts || []
			});

			$.set(optionsStatus, 'ready');
			selectCurrentReferences(item);
		} catch(cause) {
			$.set(optionsStatus, 'error');
			$.set(optionsError, cause?.message || 'Could not load expense options.');
		}
	}

	function selectCurrentReferences(item) {
		if (!$.get(editMerchantId)) {
			const match = $.get(editOptions).merchants.find((option) => $.strict_equals(option.name?.toLowerCase(), merchant(item).toLowerCase()));

			if (match) $.set(editMerchantId, String(match.id));
		}

		if (!$.get(editAccountId)) {
			const current = String(item.account?.name ?? item.sourceAccount?.name ?? item.accountName ?? '').toLowerCase(),
				match = $.get(editOptions).accounts.find((option) => $.strict_equals(option.name?.toLowerCase(), current));

			if (match) $.set(editAccountId, String(match.id));
		}
	}

	function changeEditCategory(event) {
		$.set(editCategory, event.currentTarget.value);

		if (!$.get(editSubcategories).includes($.get(editSubcategory))) $.set(editSubcategory, '');
	}

	async function saveEdit() {
		const amount = Number($.get(editAmount)),
			merchantId = Number($.get(editMerchantId)),
			accountId = Number($.get(editAccountId));

		if (!$.get(editing) || $.get(saving) || $.strict_equals($.get(optionsStatus), 'ready', false) || !Number.isFinite(amount) || amount <= 0 || !$.get(editDate) || !$.get(editCategory) || !$.get(editSubcategory) || !Number.isFinite(merchantId) || !Number.isFinite(accountId)) return;

		$.set(saving, true);
		$.set(actionError, '');

		try {
			(await $.track_reactivity_loss(updateExpense($.get(editing).id, {
				amount,
				transactionDate: $.get(editDate),
				category: $.get(editCategory),
				subcategory: $.get(editSubcategory),
				merchantId,
				accountId
			})))();

			$.set(editing, null);

			(await $.track_reactivity_loss(Promise.all([
				loadDay(),
				refreshRecent()(),
				refreshCalendar()(),
				refreshStories()()
			])))();
		} catch(cause) {
			$.set(actionError, cause?.message || 'Could not update the transaction.');
		} finally {
			$.set(saving, false);
		}
	}

	async function confirmDelete() {
		if (!$.get(deleting)) return;

		try {
			(await $.track_reactivity_loss(deleteExpense($.get(deleting).id)))();
			$.set(deleting, null);

			(await $.track_reactivity_loss(Promise.all([
				loadDay(),
				refreshRecent()(),
				refreshCalendar()(),
				refreshStories()()
			])))();
		} catch(cause) {
			$.set(actionError, cause?.message || 'Could not delete the transaction.');
			$.set(deleting, null);
		}
	}

	async function addMissingDate() {
		if (!$.get(selected) || $.get(addingContext)) return;

		$.set(addingContext, true);

		try {
			const result = (await $.track_reactivity_loss(createMissingDateContext(isoDate($.get(selected).day), $.get(data).timezone || Intl.DateTimeFormat().resolvedOptions().timeZone)))();

			$.set(handoff, { ...result, date: isoDate($.get(selected).day) });
		} catch(cause) {
			$.set(actionError, cause instanceof ApiError
				? cause.message
				: 'Could not prepare WhatsApp recording.');
		} finally {
			$.set(addingContext, false);
		}
	}

	async function signOut() {
		$.set(loggingOut, true);

		try {
			(await $.track_reactivity_loss(logout()))();

			try {
				localStorage.removeItem(`${MONEY_MODULES_CACHE_KEY}.real`);
				localStorage.removeItem(`${MONEY_MODULES_CACHE_KEY}.demo`);
			} catch {}

			onLogout()();
		} catch {
			$.set(loggingOut, false);
			$.set(signOutError, 'Could not sign out.');
		}
	}

	async function switchDemoMode() {
		if ($.get(demoSwitching)) return;

		$.set(demoSwitching, true);
		$.set(demoError, '');

		try {
			(await $.track_reactivity_loss(onDemoModeChange()(!demoMode())))();
			$.set(loans, []);
			$.set(mutualFunds, []);
			$.set(stocks, []);
			$.set(actions, []);
			$.set(loanStatus, 'idle');
			$.set(mutualFundStatus, 'idle');
			$.set(stockStatus, 'idle');
			actionsStatus = 'idle';
			$.set(fundDetail, null);
			$.set(dayItems, []);
			$.set(selectedDay, null);
			$.set(editOptions, { categories: [], merchants: [], accounts: [] });
			$.set(optionsStatus, 'idle');
			$.set(showMoney, false);
			(await $.track_reactivity_loss(loadActions()))();
		} catch(cause) {
			$.set(demoError, cause?.message || 'Could not switch profiles.');
		} finally {
			$.set(demoSwitching, false);
		}
	}

	onMount(() => {
		try {
			$.set(commitmentStyle, localStorage.getItem('money-stories.commitment-style') || 'playful');
		} catch {}

		loadActions();
	});

	$.legacy_pre_effect(() => ($.deep_read_state(calendarSection())), () => {
		$.set(data, calendarSection().data || {});
	});

	$.legacy_pre_effect(() => ($.get(data)), () => {
		$.set(currency, $.get(data).currency || 'INR');
	});

	$.legacy_pre_effect(() => ($.deep_read_state(selectedMonth()), $.get(data)), () => {
		$.set(calendar, buildCalendar(selectedMonth(), $.get(data).days || []));
	});

	$.legacy_pre_effect(() => ($.deep_read_state(recentSection())), () => {
		$.set(recentData, recentSection().data || {});
	});

	$.legacy_pre_effect(() => ($.get(recentData)), () => {
		$.set(recentItems, ($.get(recentData).items || $.get(recentData).expenses || []).slice(0, 5));
	});

	$.legacy_pre_effect(() => ($.deep_read_state(storiesSection())), () => {
		$.set(storyData, storiesSection().data || {});
	});

	$.legacy_pre_effect(() => ($.get(storyData)), () => {
		$.set(stories, $.get(storyData).stories || $.get(storyData).moneyStories || $.get(storyData).storyCards || []);
	});

	$.legacy_pre_effect(() => ($.get(storyFilter), $.get(stories)), () => {
		$.set(filteredStories, $.strict_equals($.get(storyFilter), 'All')
			? $.get(stories)
			: $.get(stories).filter((story) => $.strict_equals(storySource(story).toLowerCase(), $.get(storyFilter).toLowerCase())));
	});

	$.legacy_pre_effect(() => ($.get(stories)), () => {
		$.set(homeStories, $.get(stories).slice(0, 3));
	});

	$.legacy_pre_effect(() => ($.get(homeStoryIndex), $.get(homeStories)), () => {
		if ($.get(homeStoryIndex) >= $.get(homeStories).length) $.set(homeStoryIndex, 0);
	});

	$.legacy_pre_effect(() => ($.get(storiesRailIndex), $.get(filteredStories)), () => {
		if ($.get(storiesRailIndex) >= $.get(filteredStories).length) $.set(storiesRailIndex, 0);
	});

	$.legacy_pre_effect(() => ($.get(selectedDay), $.get(calendar)), () => {
		$.set(selected, $.equals($.get(selectedDay), null)
			? null
			: $.get(calendar).days.find((day) => $.strict_equals(day.day, $.get(selectedDay))));
	});

	$.legacy_pre_effect(() => ($.get(activityTab), $.get(recentItems), $.get(dayItems)), () => {
		$.set(activeItems, $.strict_equals($.get(activityTab), 'recent') ? $.get(recentItems) : $.get(dayItems));
	});

	$.legacy_pre_effect(() => ($.get(showAll), $.get(activeItems)), () => {
		$.set(visibleItems, $.get(showAll) ? $.get(activeItems) : $.get(activeItems).slice(0, 5));
	});

	$.legacy_pre_effect(() => ($.get(editOptions), $.get(editCategory)), () => {
		$.set(editSubcategories, $.get(editOptions).categories.find((option) => $.strict_equals(option.name, $.get(editCategory)))?.subcategories || []);
	});

	$.legacy_pre_effect(() => ($.get(loans)), () => {
		$.set(activeLoans, $.get(loans).filter((loan) => $.strict_equals(loan.status, 'ACTIVE')));
	});

	$.legacy_pre_effect(() => ($.get(loans)), () => {
		$.set(closedLoans, $.get(loans).filter((loan) => $.strict_equals(loan.status, 'CLOSED')));
	});

	$.legacy_pre_effect(() => ($.get(activeLoans)), () => {
		$.set(totalMonthlyEmi, $.get(activeLoans).reduce((total, loan) => total + Number(loan.monthlyEmiAmount || 0), 0));
	});

	$.legacy_pre_effect(() => ($.get(mutualFunds)), () => {
		$.set(mutualPortfolio, {
			invested: $.get(mutualFunds).reduce((total, fund) => total + Number(fund.invested || 0), 0),

			current: $.get(mutualFunds).some((fund) => $.strict_equals(fund.currentValue, null, false))
				? $.get(mutualFunds).reduce((total, fund) => total + Number(fund.currentValue || 0), 0)
				: null,

			pnl: $.get(mutualFunds).some((fund) => $.strict_equals(fund.profitOrLoss, null, false))
				? $.get(mutualFunds).reduce((total, fund) => total + Number(fund.profitOrLoss || 0), 0)
				: null
		});
	});

	$.legacy_pre_effect(() => ($.get(stocks)), () => {
		$.set(stockPortfolio, {
			invested: $.get(stocks).reduce((total, stock) => total + Number(stock.invested || 0), 0),

			current: $.get(stocks).some((stock) => $.strict_equals(stock.currentValue, null, false))
				? $.get(stocks).reduce((total, stock) => total + Number(stock.currentValue || 0), 0)
				: null,

			pnl: $.get(stocks).some((stock) => $.strict_equals(stock.profitOrLoss, null, false))
				? $.get(stocks).reduce((total, stock) => total + Number(stock.profitOrLoss || 0), 0)
				: null
		});
	});

	$.legacy_pre_effect(() => ($.get(actions)), () => {
		$.set(visibleActions, $.get(actions).map((action) => ({ action, presentation: actionPresentation(action) })).filter((item) => item.presentation));
	});

	$.legacy_pre_effect(() => ($.get(actions), $.get(highlightedLoanId)), () => {
		$.set(highlightedLoanAction, $.get(actions).find((action) => $.strict_equals(String(action.referenceId), String($.get(highlightedLoanId))) && $.strict_equals(action.actionType, 'LOAN_CLOSURE_CONFIRMATION')));
	});

	$.legacy_pre_effect(() => ($.deep_read_state(connectionStatus())), () => {
		$.set(connectionLabel, $.strict_equals(connectionStatus(), 'online')
			? 'Online'
			: $.strict_equals(connectionStatus(), 'offline') ? 'Offline' : 'Checking');
	});

	$.legacy_pre_effect(() => ($.get(commitments), $.get(openedStory), $.get(storySlide)), () => {
		$.set(evidenceItems, (
			$.get(commitments),
			evidenceFor($.get(openedStory), $.get(storySlide))
		));
	});

	$.legacy_pre_effect_reset();

	var $$exports = { ...$.legacy_api() };

	$.init();

	var fragment = root();
	var node = $.first_child(fragment);

	{
		var consequent_4 = ($$anchor) => {
			var div = root_1();
			var section = $.child(div);
			var button = $.child(section);
			var h2 = $.sibling(button, 2);
			var text_1 = $.child(h2, true);

			$.reset(h2);

			var node_1 = $.sibling(h2);

			{
				var consequent = ($$anchor) => {
					var p = root_2();

					$.append($$anchor, p);
				};

				var alternate_2 = ($$anchor) => {
					var fragment_1 = $.comment();
					var node_2 = $.first_child(fragment_1);

					{
						var consequent_1 = ($$anchor) => {
							var p_1 = root_4();
							var text_2 = $.child(p_1, true);

							$.reset(p_1);
							$.template_effect(() => $.set_text(text_2, $.get(loanHistoryError)));
							$.append($$anchor, p_1);
						};

						var alternate_1 = ($$anchor) => {
							var section_1 = root_5();
							var node_3 = $.sibling($.child(section_1));

							{
								var consequent_3 = ($$anchor) => {
									var fragment_2 = $.comment();
									var node_4 = $.first_child(fragment_2);

									$.add_svelte_meta(
										() => $.each(
											node_4,
											1,
											() => (
												$.get(loanHistory),
												$.untrack(() => $.get(loanHistory).history)
											),
											$.index,
											($$anchor, entry) => {
												var div_1 = root_7();
												let classes;
												var span = $.child(div_1);
												var text_3 = $.child(span, true);

												$.reset(span);

												var strong = $.sibling(span);
												var text_4 = $.child(strong);

												$.reset(strong);

												var span_1 = $.sibling(strong);
												var b_1 = $.child(span_1);
												var text_5 = $.child(b_1, true);

												$.reset(b_1);
												$.reset(span_1);

												var small = $.sibling(span_1);
												var text_6 = $.child(small, true);

												$.reset(small);

												var node_5 = $.sibling(small);

												{
													var consequent_2 = ($$anchor) => {
														var div_2 = root_8();
														var node_6 = $.child(div_2);

														{
															let $0 = $.derived_safe_equal(() => (
																$.get(entry),
																$.untrack(() => `Due now · ${money($.get(entry).plannedAmount)}`)
															));

															let $1 = $.derived_safe_equal(() => (
																$.get(entry),
																$.untrack(() => `Mark ${monthLabel($.get(entry).month)} EMI paid`)
															));

															$.add_svelte_meta(
																() => DueReminder(node_6, {
																	get detail() {
																		return $.get($0);
																	},

																	get actionLabel() {
																		return $.get($1);
																	},

																	onAction: () => payLoanHistoryEmi($.get(entry))
																}),
																'component',
																Home,
																165,
																962,
																{ componentTag: 'DueReminder' }
															);
														}

														$.reset(div_2);
														$.append($$anchor, div_2);
													};

													$.add_svelte_meta(
														() => $.if(node_5, ($$render) => {
															if ((
																$.get(entry),
																$.untrack(() => $.strict_equals($.get(entry).status, 'DUE'))
															)) $$render(consequent_2);
														}),
														'if',
														Home,
														165,
														903
													);
												}

												$.reset(div_1);

												$.template_effect(
													($0, $1, $2, $3) => {
														classes = $.set_class(div_1, 1, 'investment-history-row', null, classes, { due: $.strict_equals($.get(entry).status, 'DUE') });
														$.set_text(text_3, $0);
														$.set_text(text_4, `${$1 ?? ''} EMI`);
														$.set_text(text_5, $2);
														$.set_text(text_6, $3);
													},
													[
														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).dueDate))
														),

														() => (
															$.get(entry),
															$.untrack(() => monthLabel($.get(entry).month))
														),

														() => (
															$.get(entry),
															$.untrack(() => money($.get(entry).paidAmount || $.get(entry).plannedAmount))
														),

														() => (
															$.get(entry),

															$.untrack(() => $.strict_equals($.get(entry).status, 'PAID')
																? `Paid on ${dateLabel($.get(entry).paidAt)}`
																: $.strict_equals($.get(entry).status, 'DUE') ? 'Due now' : $.get(entry).status.toLowerCase())
														)
													]
												);

												$.append($$anchor, div_1);
											}
										),
										'each',
										Home,
										165,
										491
									);

									$.append($$anchor, fragment_2);
								};

								var alternate = ($$anchor) => {
									var p_2 = root_9();

									$.append($$anchor, p_2);
								};

								$.add_svelte_meta(
									() => $.if(node_3, ($$render) => {
										if ((
											$.get(loanHistory),
											$.untrack(() => $.get(loanHistory).history?.length)
										)) $$render(consequent_3); else $$render(alternate, false);
									}),
									'if',
									Home,
									165,
									458
								);
							}

							$.reset(section_1);
							$.append($$anchor, section_1);
						};

						$.add_svelte_meta(
							() => $.if(
								node_2,
								($$render) => {
									if ($.strict_equals($.get(loanHistoryStatus), 'error')) $$render(consequent_1); else $$render(alternate_1, false);
								},
								true
							),
							'if',
							Home,
							165,
							331
						);
					}

					$.append($$anchor, fragment_1);
				};

				$.add_svelte_meta(
					() => $.if(node_1, ($$render) => {
						if ($.strict_equals($.get(loanHistoryStatus), 'loading')) $$render(consequent); else $$render(alternate_2, false);
					}),
					'if',
					Home,
					165,
					265
				);
			}

			$.reset(section);
			$.reset(div);

			$.template_effect(() => $.set_text(text_1, (
				$.get(loanHistory),
				$.untrack(() => $.get(loanHistory).loanName)
			)));

			$.event('click', button, () => $.set(loanHistory, null));
			$.append($$anchor, div);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if ($.get(loanHistory)) $$render(consequent_4);
			}),
			'if',
			Home,
			165,
			0
		);
	}

	var node_7 = $.sibling(node, 2);

	{
		var consequent_8 = ($$anchor) => {
			var div_3 = root_10();
			var section_2 = $.child(div_3);
			var button_1 = $.child(section_2);
			var h2_1 = $.sibling(button_1, 2);
			var text_7 = $.child(h2_1, true);

			$.reset(h2_1);

			var node_8 = $.sibling(h2_1);

			{
				var consequent_5 = ($$anchor) => {
					var p_3 = root_11();

					$.append($$anchor, p_3);
				};

				var alternate_5 = ($$anchor) => {
					var fragment_3 = $.comment();
					var node_9 = $.first_child(fragment_3);

					{
						var consequent_6 = ($$anchor) => {
							var p_4 = root_13();
							var text_8 = $.child(p_4, true);

							$.reset(p_4);
							$.template_effect(() => $.set_text(text_8, $.get(commitmentHistoryError)));
							$.append($$anchor, p_4);
						};

						var alternate_4 = ($$anchor) => {
							var section_3 = root_14();
							var node_10 = $.sibling($.child(section_3));

							{
								var consequent_7 = ($$anchor) => {
									var fragment_4 = $.comment();
									var node_11 = $.first_child(fragment_4);

									$.add_svelte_meta(
										() => $.each(
											node_11,
											1,
											() => (
												$.get(commitmentHistory),
												$.untrack(() => $.get(commitmentHistory).history)
											),
											$.index,
											($$anchor, entry) => {
												var div_4 = root_16();
												var span_2 = $.child(div_4);
												var text_9 = $.child(span_2, true);

												$.reset(span_2);

												var strong_1 = $.sibling(span_2);
												var text_10 = $.child(strong_1);

												$.reset(strong_1);

												var span_3 = $.sibling(strong_1);
												var b_2 = $.child(span_3);
												var text_11 = $.child(b_2, true);

												$.reset(b_2);
												$.reset(span_3);

												var small_1 = $.sibling(span_3);
												var text_12 = $.child(small_1);

												$.reset(small_1);
												$.reset(div_4);

												$.template_effect(
													($0, $1, $2, $3) => {
														$.set_text(text_9, $0);
														$.set_text(text_10, `${$1 ?? ''} payment`);
														$.set_text(text_11, $2);
														$.set_text(text_12, `Done on ${$3 ?? ''}`);
													},
													[
														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).dueDate))
														),

														() => (
															$.get(entry),
															$.untrack(() => monthLabel($.get(entry).month))
														),

														() => (
															$.get(commitmentHistory),
															$.untrack(() => money($.get(commitmentHistory).planningAmount))
														),

														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).completedAt))
														)
													]
												);

												$.append($$anchor, div_4);
											}
										),
										'each',
										Home,
										166,
										539
									);

									$.append($$anchor, fragment_4);
								};

								var alternate_3 = ($$anchor) => {
									var p_5 = root_17();

									$.append($$anchor, p_5);
								};

								$.add_svelte_meta(
									() => $.if(node_10, ($$render) => {
										if ((
											$.get(commitmentHistory),
											$.untrack(() => $.get(commitmentHistory).history?.length)
										)) $$render(consequent_7); else $$render(alternate_3, false);
									}),
									'if',
									Home,
									166,
									500
								);
							}

							$.reset(section_3);
							$.append($$anchor, section_3);
						};

						$.add_svelte_meta(
							() => $.if(
								node_9,
								($$render) => {
									if ($.strict_equals($.get(commitmentHistoryStatus), 'error')) $$render(consequent_6); else $$render(alternate_4, false);
								},
								true
							),
							'if',
							Home,
							166,
							358
						);
					}

					$.append($$anchor, fragment_3);
				};

				$.add_svelte_meta(
					() => $.if(node_8, ($$render) => {
						if ($.strict_equals($.get(commitmentHistoryStatus), 'loading')) $$render(consequent_5); else $$render(alternate_5, false);
					}),
					'if',
					Home,
					166,
					286
				);
			}

			$.reset(section_2);
			$.reset(div_3);

			$.template_effect(() => $.set_text(text_7, (
				$.get(commitmentHistory),
				$.untrack(() => $.get(commitmentHistory).label)
			)));

			$.event('click', button_1, () => $.set(commitmentHistory, null));
			$.append($$anchor, div_3);
		};

		$.add_svelte_meta(
			() => $.if(node_7, ($$render) => {
				if ($.get(commitmentHistory)) $$render(consequent_8);
			}),
			'if',
			Home,
			166,
			0
		);
	}

	var node_12 = $.sibling(node_7, 2);

	$.add_svelte_meta(
		() => AppHeader(node_12, {
			get connectionStatus() {
				return connectionStatus();
			},

			get connectionLabel() {
				return $.get(connectionLabel);
			},

			get onRetry() {
				return onRetryConnection();
			},

			onHome: () => navigate('home'),
			onProfile: () => navigate('you')
		}),
		'component',
		Home,
		168,
		0,
		{ componentTag: 'AppHeader' }
	);

	var main = $.sibling(node_12, 2);
	var node_13 = $.child(main);

	{
		var consequent_9 = ($$anchor) => {
			var section_4 = root_18();
			var div_5 = $.sibling($.child(section_4));
			var strong_2 = $.child(div_5);
			var text_13 = $.child(strong_2, true);

			$.reset(strong_2);

			var p_6 = $.sibling(strong_2);
			var text_14 = $.child(p_6, true);

			$.reset(p_6);
			$.reset(div_5);

			var button_2 = $.sibling(div_5);

			$.reset(section_4);

			$.template_effect(() => {
				$.set_text(text_13, cacheUpdatedAt() ? 'Showing your last saved view' : 'You’re offline');

				$.set_text(text_14, cacheUpdatedAt()
					? 'We’ll refresh automatically when the service is back.'
					: 'Your layout is ready. Connect once to load your expenses and stories.');
			});

			$.event('click', button_2, function (...$$args) {
				$.apply(onRetryConnection, this, $$args, Home, [170, 341]);
			});

			$.append($$anchor, section_4);
		};

		$.add_svelte_meta(
			() => $.if(node_13, ($$render) => {
				if ($.strict_equals(connectionStatus(), 'offline')) $$render(consequent_9);
			}),
			'if',
			Home,
			170,
			0
		);
	}

	var node_14 = $.sibling(node_13, 2);

	{
		var consequent_11 = ($$anchor) => {
			var fragment_5 = root_19();
			var section_5 = $.first_child(fragment_5);
			var div_6 = $.child(section_5);
			var p_7 = $.child(div_6);
			var text_15 = $.child(p_7, true);

			$.reset(p_7);

			var h1 = $.sibling(p_7);
			var text_16 = $.child(h1, true);

			$.reset(h1);
			$.next();
			$.reset(div_6);
			$.reset(section_5);

			var node_15 = $.sibling(section_5, 2);

			$.add_svelte_meta(
				() => SectionState(node_15, {
					get section() {
						return calendarSection();
					},

					title: 'Spending overview',

					get retry() {
						return refreshCalendar();
					},

					children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
						var button_3 = root_20();
						var strong_3 = $.sibling($.child(button_3));
						var text_17 = $.child(strong_3);

						$.next();
						$.reset(strong_3);

						var b_3 = $.sibling(strong_3);
						var text_18 = $.child(b_3);

						$.reset(b_3);
						$.reset(button_3);

						$.template_effect(
							($0) => {
								$.set_text(text_17, `${$0 ?? ''} `);

								$.set_text(text_18, `${(
									$.get(data),
									$.untrack(() => $.get(data).transactionCount || 0)
								) ?? ''} transactions · View transactions →`);
							},
							[
								() => ($.get(data), $.untrack(() => money($.get(data).totalSpend)))
							]
						);

						$.event('click', button_3, () => navigate('transactions'));
						$.append($$anchor, button_3);
					}),

					$$slots: { default: true }
				}),
				'component',
				Home,
				173,
				2,
				{ componentTag: 'SectionState' }
			);

			var section_6 = $.sibling(node_15, 2);
			var div_7 = $.child(section_6);
			var button_4 = $.sibling($.child(div_7));

			$.reset(div_7);

			var node_16 = $.sibling(div_7);

			$.add_svelte_meta(
				() => SectionState(node_16, {
					get section() {
						return storiesSection();
					},

					title: 'Your stories',

					get retry() {
						return refreshStories();
					},

					children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
						var fragment_6 = $.comment();
						var node_17 = $.first_child(fragment_6);

						{
							var consequent_10 = ($$anchor) => {
								var div_8 = root_22();
								var div_9 = $.child(div_8);
								var node_18 = $.child(div_9);

								$.add_svelte_meta(
									() => $.each(node_18, 1, () => $.get(homeStories), $.index, ($$anchor, story, index) => {
										var button_5 = root_23();
										let classes_1;

										$.template_effect(
											($0) => {
												$.set_attribute(button_5, 'aria-label', $0);
												$.set_attribute(button_5, 'aria-current', $.strict_equals(index, $.get(homeStoryIndex)) ? 'true' : undefined);
												classes_1 = $.set_class(button_5, 1, '', null, classes_1, { active: $.strict_equals(index, $.get(homeStoryIndex)) });
											},
											[
												() => (
													index,
													$.get(homeStories),
													$.get(story),
													$.untrack(() => `Show story ${index + 1} of ${$.get(homeStories).length}: ${storyCardFace($.get(story)).heading}`)
												)
											]
										);

										$.event('click', button_5, () => $.set(homeStoryIndex, index));
										$.append($$anchor, button_5);
									}),
									'each',
									Home,
									174,
									441
								);

								var span_4 = $.sibling(node_18);
								var text_19 = $.child(span_4);

								$.reset(span_4);
								$.reset(div_9);

								var div_10 = $.sibling(div_9);
								var div_11 = $.child(div_10);

								$.add_svelte_meta(
									() => $.each(div_11, 5, () => $.get(homeStories), $.index, ($$anchor, story, index) => {
										var button_6 = root_24();
										let classes_2;
										var span_5 = $.child(button_6);
										var text_20 = $.child(span_5, true);

										$.reset(span_5);

										var strong_4 = $.sibling(span_5);
										var text_21 = $.child(strong_4, true);

										$.reset(strong_4);

										var b_4 = $.sibling(strong_4);
										var text_22 = $.child(b_4, true);

										$.reset(b_4);
										$.next();
										$.reset(button_6);

										$.template_effect(
											($0, $1, $2, $3) => {
												classes_2 = $.set_class(button_6, 1, $0, null, classes_2, { current: $.strict_equals(index, $.get(homeStoryIndex)) });
												$.set_text(text_20, $1);
												$.set_text(text_21, $2);
												$.set_text(text_22, $3);
											},
											[
												() => (
													$.get(story),
													$.untrack(() => `story-carousel-card ${storyTone($.get(story))}`)
												),

												() => ($.get(story), $.untrack(() => storySource($.get(story)))),

												() => (
													$.get(story),
													$.untrack(() => storyCardFace($.get(story)).heading)
												),

												() => (
													$.get(story),
													$.untrack(() => storyCardFace($.get(story)).displayValue)
												)
											]
										);

										$.event('click', button_6, () => openStory($.get(story)));
										$.append($$anchor, button_6);
									}),
									'each',
									Home,
									174,
									1054
								);

								$.reset(div_11);
								$.reset(div_10);
								$.reset(div_8);

								$.template_effect(() => {
									$.set_text(text_19, `${$.get(homeStoryIndex) + 1} / ${(
										$.get(homeStories),
										$.untrack(() => $.get(homeStories).length)
									) ?? ''}`);

									$.set_style(div_11, `transform:translateX(calc(${$.get(homeStoryIndex)} * -92%))`);
								});

								$.event('touchstart', div_10, (event) => $.set(storyRailTouchStart, event.touches[0].clientX));
								$.event('touchend', div_10, (event) => endRailSwipe(event, $.get(homeStories).length, 'home'));
								$.append($$anchor, div_8);
							};

							var alternate_6 = ($$anchor) => {
								var div_12 = root_25();

								$.append($$anchor, div_12);
							};

							$.add_svelte_meta(
								() => $.if(node_17, ($$render) => {
									if ((
										$.get(homeStories),
										$.untrack(() => $.get(homeStories).length)
									)) $$render(consequent_10); else $$render(alternate_6, false);
								}),
								'if',
								Home,
								174,
								311
							);
						}

						$.append($$anchor, fragment_6);
					}),

					$$slots: { default: true }
				}),
				'component',
				Home,
				174,
				228,
				{ componentTag: 'SectionState' }
			);

			$.reset(section_6);

			var section_7 = $.sibling(section_6, 2);
			var div_13 = $.child(section_7);
			var button_7 = $.sibling($.child(div_13));

			$.reset(div_13);

			var div_14 = $.sibling(div_13);

			$.add_svelte_meta(
				() => $.each(
					div_14,
					5,
					() => (
						$.get(recentItems),
						$.untrack(() => $.get(recentItems).slice(0, 3))
					),
					$.index,
					($$anchor, item) => {
						var button_8 = root_26();
						var div_15 = $.child(button_8);
						var strong_5 = $.child(div_15);
						var text_23 = $.child(strong_5, true);

						$.reset(strong_5);

						var span_6 = $.sibling(strong_5);
						var text_24 = $.child(span_6);

						$.reset(span_6);
						$.reset(div_15);

						var b_5 = $.sibling(div_15);
						var text_25 = $.child(b_5);

						$.reset(b_5);
						$.reset(button_8);

						$.template_effect(
							($0, $1, $2, $3) => {
								$.set_text(text_23, $0);
								$.set_text(text_24, `${$1 ?? ''} · ${$2 ?? ''}`);
								$.set_text(text_25, `− ${$3 ?? ''}`);
							},
							[
								() => ($.get(item), $.untrack(() => merchant($.get(item)))),
								() => ($.get(item), $.untrack(() => category($.get(item)))),

								() => (
									$.get(item),
									$.untrack(() => dateLabel(transactionDate($.get(item))))
								),

								() => ($.get(item), $.untrack(() => money($.get(item).amount)))
							]
						);

						$.event('click', button_8, () => {
							navigate('transactions');
							startEdit($.get(item));
						});

						$.append($$anchor, button_8);
					},
					($$anchor) => {
						var p_8 = root_27();

						$.append($$anchor, p_8);
					}
				),
				'each',
				Home,
				175,
				255
			);

			$.reset(div_14);
			$.reset(section_7);

			var button_9 = $.sibling(section_7, 2);

			$.template_effect(
				($0, $1) => {
					$.set_text(text_15, $0);
					$.set_text(text_16, $1);
				},
				[
					() => (
						$.deep_read_state(selectedMonth()),
						$.untrack(() => monthLabel(selectedMonth()).toUpperCase())
					),

					() => ($.untrack(greeting))
				]
			);

			$.event('click', button_4, () => navigate('stories'));
			$.event('click', button_7, () => navigate('transactions'));
			$.event('click', button_9, openMoney);
			$.append($$anchor, fragment_5);
		};

		var alternate_12 = ($$anchor) => {
			var fragment_7 = $.comment();
			var node_19 = $.first_child(fragment_7);

			{
				var consequent_16 = ($$anchor) => {
					var fragment_8 = root_29();
					var section_8 = $.first_child(fragment_8);
					var label = $.sibling($.child(section_8));
					var button_10 = $.child(label);
					var input = $.sibling(button_10);

					$.remove_input_defaults(input);

					var button_11 = $.sibling(input);

					$.reset(label);
					$.reset(section_8);

					var node_20 = $.sibling(section_8, 2);

					$.add_svelte_meta(
						() => SectionState(node_20, {
							get section() {
								return calendarSection();
							},

							title: 'Spending calendar',

							get retry() {
								return refreshCalendar();
							},

							children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
								var section_9 = root_30();
								var div_16 = $.child(section_9);
								var div_17 = $.child(div_16);
								var strong_6 = $.sibling($.child(div_17));
								var text_26 = $.child(strong_6, true);

								$.reset(strong_6);
								$.reset(div_17);

								var div_18 = $.sibling(div_17);
								var strong_7 = $.sibling($.child(div_18));
								var text_27 = $.child(strong_7, true);

								$.reset(strong_7);
								$.reset(div_18);

								var div_19 = $.sibling(div_18);
								var strong_8 = $.sibling($.child(div_19));
								var text_28 = $.child(strong_8, true);

								$.reset(strong_8);
								$.reset(div_19);
								$.reset(div_16);

								var div_20 = $.sibling(div_16);

								$.add_svelte_meta(
									() => $.each(div_20, 4, () => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], $.index, ($$anchor, d) => {
										var span_7 = root_31();
										var text_29 = $.child(span_7, true);

										$.reset(span_7);
										$.template_effect(() => $.set_text(text_29, d));
										$.append($$anchor, span_7);
									}),
									'each',
									Home,
									179,
									411
								);

								$.reset(div_20);

								var div_21 = $.sibling(div_20);
								var node_21 = $.child(div_21);

								$.add_svelte_meta(
									() => $.each(
										node_21,
										1,
										() => (
											$.get(calendar),
											$.untrack(() => Array($.get(calendar).leading))
										),
										$.index,
										($$anchor, _) => {
											var span_8 = root_32();

											$.append($$anchor, span_8);
										}
									),
									'each',
									Home,
									179,
									518
								);

								var node_22 = $.sibling(node_21);

								$.add_svelte_meta(
									() => $.each(node_22, 1, () => ($.get(calendar), $.untrack(() => $.get(calendar).days)), $.index, ($$anchor, d) => {
										var button_12 = root_33();
										let classes_3;
										var text_30 = $.child(button_12, true);

										$.reset(button_12);

										$.template_effect(() => {
											classes_3 = $.set_class(button_12, 1, ($.get(d), $.untrack(() => `level-${$.get(d).intensity}`)), null, classes_3, {
												future: $.get(d).future,
												selected: $.strict_equals($.get(selectedDay), $.get(d).day)
											});

											button_12.disabled = ($.get(d), $.untrack(() => $.get(d).future));
											$.set_text(text_30, ($.get(d), $.untrack(() => $.get(d).day)));
										});

										$.event('click', button_12, () => selectDate($.get(d)));
										$.append($$anchor, button_12);
									}),
									'each',
									Home,
									179,
									574
								);

								$.reset(div_21);

								var div_22 = $.sibling(div_21);
								var div_23 = $.sibling($.child(div_22));

								$.add_svelte_meta(
									() => $.each(div_23, 4, () => [0, 1, 2, 3, 4], $.index, ($$anchor, l) => {
										var i_1 = root_34();

										$.template_effect(() => $.set_class(i_1, 1, `level-${l}`));
										$.append($$anchor, i_1);
									}),
									'each',
									Home,
									179,
									827
								);

								$.reset(div_23);
								$.next();
								$.reset(div_22);
								$.reset(section_9);

								$.template_effect(
									($0, $1) => {
										$.set_text(text_26, $0);

										$.set_text(text_27, (
											$.get(data),
											$.untrack(() => $.get(data).transactionCount || 0)
										));

										$.set_text(text_28, $1);
									},
									[
										() => ($.get(data), $.untrack(() => money($.get(data).totalSpend))),

										() => (
											$.get(data),
											$.untrack(() => money($.get(data).highestSpend))
										)
									]
								);

								$.append($$anchor, section_9);
							}),

							$$slots: { default: true }
						}),
						'component',
						Home,
						179,
						2,
						{ componentTag: 'SectionState' }
					);

					var section_10 = $.sibling(node_20, 2);
					var div_24 = $.child(section_10);
					var button_13 = $.child(div_24);
					let classes_4;
					var button_14 = $.sibling(button_13);
					let classes_5;
					var text_31 = $.child(button_14, true);

					$.reset(button_14);
					$.reset(div_24);

					var node_23 = $.sibling(div_24);

					{
						var consequent_12 = ($$anchor) => {
							var div_25 = root_35();

							$.append($$anchor, div_25);
						};

						var alternate_8 = ($$anchor) => {
							var fragment_9 = $.comment();
							var node_24 = $.first_child(fragment_9);

							{
								var consequent_13 = ($$anchor) => {
									var div_26 = root_37();
									var button_15 = $.sibling($.child(div_26));

									$.reset(div_26);
									$.event('click', button_15, loadDay);
									$.append($$anchor, div_26);
								};

								var alternate_7 = ($$anchor) => {
									var fragment_10 = root_38();
									var div_27 = $.first_child(fragment_10);
									var p_9 = $.child(div_27);
									var text_32 = $.child(p_9, true);

									$.reset(p_9);

									var h2_2 = $.sibling(p_9);
									var text_33 = $.child(h2_2, true);

									$.reset(h2_2);
									$.reset(div_27);

									var div_28 = $.sibling(div_27);

									$.add_svelte_meta(
										() => $.each(
											div_28,
											5,
											() => $.get(visibleItems),
											$.index,
											($$anchor, item) => {
												var article = root_39();
												let classes_6;
												var button_16 = $.child(article);
												var div_29 = $.child(button_16);
												var strong_9 = $.child(div_29);
												var text_34 = $.child(strong_9, true);

												$.reset(strong_9);

												var span_9 = $.sibling(strong_9);
												var text_35 = $.child(span_9);

												$.reset(span_9);
												$.reset(div_29);

												var div_30 = $.sibling(div_29);
												var b_6 = $.child(div_30);
												var text_36 = $.child(b_6);

												$.reset(b_6);

												var span_10 = $.sibling(b_6);
												let classes_7;

												$.reset(div_30);
												$.reset(button_16);

												var node_25 = $.sibling(button_16);

												{
													var consequent_14 = ($$anchor) => {
														var div_31 = root_40();
														var button_17 = $.child(div_31);
														var button_18 = $.sibling(button_17);

														$.reset(div_31);
														$.event('click', button_17, () => startEdit($.get(item)));
														$.event('click', button_18, () => $.set(deleting, $.get(item)));
														$.append($$anchor, div_31);
													};

													$.add_svelte_meta(
														() => $.if(node_25, ($$render) => {
															if ((
																$.get(expandedId),
																$.get(item),
																$.untrack(() => $.strict_equals($.get(expandedId), $.get(item).id))
															)) $$render(consequent_14);
														}),
														'if',
														Home,
														180,
														1415
													);
												}

												$.reset(article);

												$.template_effect(
													($0, $1, $2, $3) => {
														classes_6 = $.set_class(article, 1, 'compact-row', null, classes_6, { expanded: $.strict_equals($.get(expandedId), $.get(item).id) });
														$.set_text(text_34, $0);
														$.set_text(text_35, `${$1 ?? ''} · ${$2 ?? ''}`);
														$.set_text(text_36, `− ${$3 ?? ''}`);
														classes_7 = $.set_class(span_10, 1, 'row-chevron', null, classes_7, { open: $.strict_equals($.get(expandedId), $.get(item).id) });
													},
													[
														() => ($.get(item), $.untrack(() => merchant($.get(item)))),
														() => ($.get(item), $.untrack(() => category($.get(item)))),

														() => (
															$.get(item),
															$.untrack(() => dateLabel(transactionDate($.get(item))))
														),

														() => ($.get(item), $.untrack(() => money($.get(item).amount)))
													]
												);

												$.event('click', button_16, () => $.set(expandedId, $.strict_equals($.get(expandedId), $.get(item).id) ? null : $.get(item).id));
												$.append($$anchor, article);
											},
											($$anchor) => {
												var p_10 = root_41();

												$.append($$anchor, p_10);
											}
										),
										'each',
										Home,
										180,
										990
									);

									$.reset(div_28);

									var node_26 = $.sibling(div_28);

									{
										var consequent_15 = ($$anchor) => {
											var button_19 = root_42();
											var text_37 = $.child(button_19, true);

											$.reset(button_19);

											$.template_effect(() => $.set_text(text_37, (
												$.get(showAll),
												$.get(activeItems),

												$.untrack(() => $.get(showAll)
													? 'Show fewer ↑'
													: `View all ${$.get(activeItems).length} transactions ↓`)
											)));

											$.event('click', button_19, () => $.set(showAll, !$.get(showAll)));
											$.append($$anchor, button_19);
										};

										$.add_svelte_meta(
											() => $.if(node_26, ($$render) => {
												if ((
													$.get(activeItems),
													$.untrack(() => $.get(activeItems).length > 5)
												)) $$render(consequent_15);
											}),
											'if',
											Home,
											180,
											1694
										);
									}

									$.template_effect(
										($0, $1) => {
											$.set_text(text_32, $0);
											$.set_text(text_33, $1);
										},
										[
											() => (
												$.get(activityTab),
												$.get(selected),
												$.deep_read_state(selectedMonth()),

												$.untrack(() => $.strict_equals($.get(activityTab), 'recent')
													? 'RECENT EXPENSES'
													: $.get(selected)
														? `${$.get(selected).day} ${monthLabel(selectedMonth())}`
														: 'SELECT A DATE')
											),

											() => (
												$.get(activityTab),
												$.get(recentItems),
												$.get(selected),

												$.untrack(() => $.strict_equals($.get(activityTab), 'recent')
													? `${$.get(recentItems).length} recent transactions`
													: $.get(selected)
														? `${$.get(selected).transactionCount} transactions · ${money($.get(selected).totalSpend)}`
														: 'Choose a date in the calendar')
											)
										]
									);

									$.append($$anchor, fragment_10);
								};

								$.add_svelte_meta(
									() => $.if(
										node_24,
										($$render) => {
											if ($.strict_equals($.get(activityTab), 'day') && $.strict_equals($.get(dayStatus), 'error')) $$render(consequent_13); else $$render(alternate_7, false);
										},
										true
									),
									'if',
									Home,
									180,
									425
								);
							}

							$.append($$anchor, fragment_9);
						};

						$.add_svelte_meta(
							() => $.if(node_23, ($$render) => {
								if ($.strict_equals($.get(activityTab), 'day') && $.strict_equals($.get(dayStatus), 'loading')) $$render(consequent_12); else $$render(alternate_8, false);
							}),
							'if',
							Home,
							180,
							320
						);
					}

					$.reset(section_10);

					var button_20 = $.sibling(section_10, 2);
					var text_38 = $.child(button_20, true);

					$.reset(button_20);

					var button_21 = $.sibling(button_20);

					$.template_effect(
						($0) => {
							$.set_value(input, selectedMonth());
							$.set_attribute(input, 'max', $0);
							classes_4 = $.set_class(button_13, 1, '', null, classes_4, { active: $.strict_equals($.get(activityTab), 'recent') });
							classes_5 = $.set_class(button_14, 1, '', null, classes_5, { active: $.strict_equals($.get(activityTab), 'day') });

							$.set_text(text_31, (
								$.get(selected),
								$.untrack(() => $.get(selected) ? `${$.get(selected).day} selected` : 'Select a date')
							));

							button_20.disabled = !$.get(selected) || $.get(addingContext);

							$.set_text(text_38, $.get(addingContext)
								? 'Preparing WhatsApp…'
								: $.get(selected)
									? '+ Add missing expense'
									: 'Select a date to add an expense');
						},
						[() => ($.untrack(currentLocalMonth))]
					);

					$.event('click', button_10, () => changeMonth(-1));
					$.event('change', input, (e) => onMonthChange()(e.currentTarget.value));
					$.event('click', button_11, () => changeMonth(1));
					$.event('click', button_13, () => $.set(activityTab, 'recent'));
					$.event('click', button_14, () => $.set(activityTab, 'day'));
					$.event('click', button_20, addMissingDate);
					$.event('click', button_21, () => $.set(showNormalization, true));
					$.append($$anchor, fragment_8);
				};

				var alternate_11 = ($$anchor) => {
					var fragment_11 = $.comment();
					var node_27 = $.first_child(fragment_11);

					{
						var consequent_19 = ($$anchor) => {
							var fragment_12 = root_44();
							var div_32 = $.sibling($.first_child(fragment_12));

							$.add_svelte_meta(
								() => $.each(div_32, 4, () => ['All', 'Spending', 'Investing', 'Planning'], $.index, ($$anchor, filter) => {
									var button_22 = root_45();
									let classes_8;
									var text_39 = $.child(button_22, true);

									$.reset(button_22);

									$.template_effect(() => {
										classes_8 = $.set_class(button_22, 1, '', null, classes_8, { active: $.strict_equals($.get(storyFilter), filter) });
										$.set_text(text_39, filter);
									});

									$.event('click', button_22, () => {
										$.set(storyFilter, filter);
										$.set(storiesRailIndex, 0);
									});

									$.append($$anchor, button_22);
								}),
								'each',
								Home,
								183,
								208
							);

							$.reset(div_32);

							var div_33 = $.sibling(div_32);
							var button_23 = $.sibling($.child(div_33));
							let classes_9;
							var button_24 = $.sibling(button_23);
							let classes_10;

							$.reset(div_33);

							var node_28 = $.sibling(div_33);

							$.add_svelte_meta(
								() => SectionState(node_28, {
									get section() {
										return storiesSection();
									},

									title: 'Stories',

									get retry() {
										return refreshStories();
									},

									children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
										var fragment_13 = $.comment();
										var node_29 = $.first_child(fragment_13);

										{
											var consequent_18 = ($$anchor) => {
												var div_34 = root_47();
												var div_35 = $.child(div_34);
												var node_30 = $.child(div_35);

												$.add_svelte_meta(
													() => $.each(node_30, 1, () => $.get(filteredStories), $.index, ($$anchor, story, index) => {
														var button_25 = root_48();
														let classes_11;

														$.template_effect(
															($0) => {
																$.set_attribute(button_25, 'aria-label', $0);
																$.set_attribute(button_25, 'aria-current', $.strict_equals(index, $.get(storiesRailIndex)) ? 'true' : undefined);
																classes_11 = $.set_class(button_25, 1, '', null, classes_11, { active: $.strict_equals(index, $.get(storiesRailIndex)) });
															},
															[
																() => (
																	index,
																	$.get(filteredStories),
																	$.get(story),
																	$.untrack(() => `Show story ${index + 1} of ${$.get(filteredStories).length}: ${storyCardFace($.get(story)).heading}`)
																)
															]
														);

														$.event('click', button_25, () => $.set(storiesRailIndex, index));
														$.append($$anchor, button_25);
													}),
													'each',
													Home,
													183,
													931
												);

												var span_11 = $.sibling(node_30);
												var text_40 = $.child(span_11);

												$.reset(span_11);
												$.reset(div_35);

												var div_36 = $.sibling(div_35);
												var div_37 = $.child(div_36);

												$.add_svelte_meta(
													() => $.each(div_37, 5, () => $.get(filteredStories), $.index, ($$anchor, story, index) => {
														var button_26 = root_49();
														let classes_12;
														var span_12 = $.child(button_26);
														var text_41 = $.child(span_12, true);

														$.reset(span_12);

														var node_31 = $.sibling(span_12);

														{
															var consequent_17 = ($$anchor) => {
																var span_13 = root_50();
																var text_42 = $.child(span_13, true);

																$.reset(span_13);

																$.template_effect(($0) => $.set_text(text_42, $0), [
																	() => ($.get(story), $.untrack(() => storyIcon($.get(story))))
																]);

																$.append($$anchor, span_13);
															};

															$.add_svelte_meta(
																() => $.if(node_31, ($$render) => {
																	if (($.get(story), $.untrack(() => storyIcon($.get(story))))) $$render(consequent_17);
																}),
																'if',
																Home,
																183,
																1902
															);
														}

														var strong_10 = $.sibling(node_31);
														var text_43 = $.child(strong_10, true);

														$.reset(strong_10);

														var b_7 = $.sibling(strong_10);
														var text_44 = $.child(b_7, true);

														$.reset(b_7);
														$.next();
														$.reset(button_26);

														$.template_effect(
															($0, $1, $2, $3, $4) => {
																classes_12 = $.set_class(button_26, 1, $0, null, classes_12, $1);
																$.set_text(text_41, $2);
																$.set_text(text_43, $3);
																$.set_text(text_44, $4);
															},
															[
																() => (
																	$.get(story),
																	$.untrack(() => `story-carousel-card ${storyTone($.get(story))}`)
																),

																() => ({
																	'commitment-card': isCommitment($.get(story)),
																	playful: isCommitment($.get(story)) && $.strict_equals($.get(commitmentStyle), 'playful'),
																	current: $.strict_equals(index, $.get(storiesRailIndex))
																}),

																() => ($.get(story), $.untrack(() => storySource($.get(story)))),
																() => ($.get(story), $.untrack(() => storyHeading($.get(story)))),

																() => (
																	$.get(story),
																	$.untrack(() => storyCardFace($.get(story)).displayValue)
																)
															]
														);

														$.event('click', button_26, () => openStory($.get(story)));
														$.append($$anchor, button_26);
													}),
													'each',
													Home,
													183,
													1570
												);

												$.reset(div_37);
												$.reset(div_36);
												$.reset(div_34);

												$.template_effect(() => {
													$.set_attribute(div_34, 'aria-label', `${$.get(storyFilter)} stories`);

													$.set_text(text_40, `${$.get(storiesRailIndex) + 1} / ${(
														$.get(filteredStories),
														$.untrack(() => $.get(filteredStories).length)
													) ?? ''}`);

													$.set_style(div_37, `transform:translateX(calc(${$.get(storiesRailIndex)} * -92%))`);
												});

												$.event('touchstart', div_36, (event) => $.set(storyRailTouchStart, event.touches[0].clientX));
												$.event('touchend', div_36, (event) => endRailSwipe(event, $.get(filteredStories).length, 'full'));
												$.append($$anchor, div_34);
											};

											var alternate_9 = ($$anchor) => {
												var div_38 = root_51();
												var h2_3 = $.sibling($.child(div_38));
												var text_45 = $.child(h2_3);

												$.reset(h2_3);
												$.next();
												$.reset(div_38);

												$.template_effect(($0) => $.set_text(text_45, `No ${$0 ?? ''} stories yet`), [
													() => (
														$.get(storyFilter),
														$.untrack(() => $.get(storyFilter).toLowerCase())
													)
												]);

												$.append($$anchor, div_38);
											};

											$.add_svelte_meta(
												() => $.if(node_29, ($$render) => {
													if ((
														$.get(filteredStories),
														$.untrack(() => $.get(filteredStories).length)
													)) $$render(consequent_18); else $$render(alternate_9, false);
												}),
												'if',
												Home,
												183,
												765
											);
										}

										$.append($$anchor, fragment_13);
									}),

									$$slots: { default: true }
								}),
								'component',
								Home,
								183,
								687,
								{ componentTag: 'SectionState' }
							);

							$.template_effect(() => {
								classes_9 = $.set_class(button_23, 1, '', null, classes_9, { active: $.strict_equals($.get(commitmentStyle), 'calm') });
								classes_10 = $.set_class(button_24, 1, '', null, classes_10, { active: $.strict_equals($.get(commitmentStyle), 'playful') });
							});

							$.event('click', button_23, () => setCommitmentStyle('calm'));
							$.event('click', button_24, () => setCommitmentStyle('playful'));
							$.append($$anchor, fragment_12);
						};

						var alternate_10 = ($$anchor) => {
							var fragment_14 = $.comment();
							var node_32 = $.first_child(fragment_14);

							$.add_svelte_meta(
								() => ProfileSettings(node_32, {
									get demoMode() {
										return demoMode();
									},

									get demoSwitching() {
										return $.get(demoSwitching);
									},

									get demoError() {
										return $.get(demoError);
									},

									get loggingOut() {
										return $.get(loggingOut);
									},

									get signOutError() {
										return $.get(signOutError);
									},

									get storyControls() {
										return storyControls;
									},

									onNavigate: navigate,
									onOpenMoney: openMoney,
									onDemoModeChange: switchDemoMode,
									onSignOut: signOut
								}),
								'component',
								Home,
								185,
								2,
								{ componentTag: 'ProfileSettings' }
							);

							$.append($$anchor, fragment_14);
						};

						$.add_svelte_meta(
							() => $.if(
								node_27,
								($$render) => {
									if ($.strict_equals($.get(view), 'stories')) $$render(consequent_19); else $$render(alternate_10, false);
								},
								true
							),
							'if',
							Home,
							182,
							0
						);
					}

					$.append($$anchor, fragment_11);
				};

				$.add_svelte_meta(
					() => $.if(
						node_19,
						($$render) => {
							if ($.strict_equals($.get(view), 'transactions')) $$render(consequent_16); else $$render(alternate_11, false);
						},
						true
					),
					'if',
					Home,
					177,
					0
				);
			}

			$.append($$anchor, fragment_7);
		};

		$.add_svelte_meta(
			() => $.if(node_14, ($$render) => {
				if ($.strict_equals($.get(view), 'home')) $$render(consequent_11); else $$render(alternate_12, false);
			}),
			'if',
			Home,
			171,
			0
		);
	}

	$.reset(main);

	var node_33 = $.sibling(main, 2);

	$.add_svelte_meta(
		() => BottomNav(node_33, {
			get view() {
				return $.get(view);
			},

			onNavigate: navigate
		}),
		'component',
		Home,
		188,
		0,
		{ componentTag: 'BottomNav' }
	);

	var node_34 = $.sibling(node_33, 2);

	{
		var consequent_52 = ($$anchor) => {
			var div_39 = root_53();
			var section_11 = $.child(div_39);
			var button_27 = $.child(section_11);
			var section_12 = $.sibling(button_27, 7);
			var node_35 = $.sibling($.child(section_12));

			{
				var consequent_20 = ($$anchor) => {
					var p_11 = root_54();

					$.append($$anchor, p_11);
				};

				var alternate_15 = ($$anchor) => {
					var fragment_15 = $.comment();
					var node_36 = $.first_child(fragment_15);

					{
						var consequent_21 = ($$anchor) => {
							var div_40 = root_56();
							var span_14 = $.child(div_40);
							var text_46 = $.child(span_14, true);

							$.reset(span_14);

							var button_28 = $.sibling(span_14);

							$.reset(div_40);
							$.template_effect(() => $.set_text(text_46, $.get(incomeError)));
							$.event('click', button_28, loadIncomeOutlook);
							$.append($$anchor, div_40);
						};

						var alternate_14 = ($$anchor) => {
							var fragment_16 = $.comment();
							var node_37 = $.first_child(fragment_16);

							{
								var consequent_22 = ($$anchor) => {
									var div_41 = root_58();
									var strong_11 = $.sibling($.child(div_41));
									var text_47 = $.child(strong_11, true);

									$.reset(strong_11);

									var button_29 = $.sibling(strong_11);

									$.next();
									$.reset(div_41);

									$.template_effect(() => $.set_text(text_47, (
										$.get(incomeOutlook),
										$.untrack(() => $.get(incomeOutlook).salary.maskedValue)
									)));

									$.event('click', button_29, openIncomeFlow);
									$.append($$anchor, div_41);
								};

								var alternate_13 = ($$anchor) => {
									var fragment_17 = root_59();
									var button_30 = $.sibling($.first_child(fragment_17));

									$.event('click', button_30, openIncomeFlow);
									$.append($$anchor, fragment_17);
								};

								$.add_svelte_meta(
									() => $.if(
										node_37,
										($$render) => {
											if ((
												$.get(incomeOutlook),
												$.untrack(() => $.get(incomeOutlook).salary)
											)) $$render(consequent_22); else $$render(alternate_13, false);
										},
										true
									),
									'if',
									Home,
									197,
									442
								);
							}

							$.append($$anchor, fragment_16);
						};

						$.add_svelte_meta(
							() => $.if(
								node_36,
								($$render) => {
									if ($.strict_equals($.get(incomeStatus), 'error')) $$render(consequent_21); else $$render(alternate_14, false);
								},
								true
							),
							'if',
							Home,
							197,
							292
						);
					}

					$.append($$anchor, fragment_15);
				};

				$.add_svelte_meta(
					() => $.if(node_35, ($$render) => {
						if ($.strict_equals($.get(incomeStatus), 'loading')) $$render(consequent_20); else $$render(alternate_15, false);
					}),
					'if',
					Home,
					197,
					226
				);
			}

			$.reset(section_12);

			var section_13 = $.sibling(section_12, 2);
			var node_38 = $.sibling($.child(section_13));

			{
				var consequent_23 = ($$anchor) => {
					var p_12 = root_60();

					$.append($$anchor, p_12);
				};

				var alternate_19 = ($$anchor) => {
					var fragment_18 = $.comment();
					var node_39 = $.first_child(fragment_18);

					{
						var consequent_24 = ($$anchor) => {
							var div_42 = root_62();
							var span_15 = $.child(div_42);
							var text_48 = $.child(span_15, true);

							$.reset(span_15);

							var button_31 = $.sibling(span_15);

							$.reset(div_42);
							$.template_effect(() => $.set_text(text_48, $.get(commitmentError)));
							$.event('click', button_31, loadCommitments);
							$.append($$anchor, div_42);
						};

						var alternate_18 = ($$anchor) => {
							var fragment_19 = $.comment();
							var node_40 = $.first_child(fragment_19);

							{
								var consequent_27 = ($$anchor) => {
									var fragment_20 = $.comment();
									var node_41 = $.first_child(fragment_20);

									$.add_svelte_meta(
										() => $.each(node_41, 1, () => $.get(commitments), $.index, ($$anchor, commitment) => {
											var article_1 = root_65();
											let classes_13;
											var div_43 = $.sibling($.child(article_1));
											var strong_12 = $.child(div_43);
											var text_49 = $.child(strong_12, true);
											var button_32 = $.sibling(text_49);
											var button_33 = $.sibling(button_32);
											var text_50 = $.child(button_33, true);

											$.reset(button_33);
											$.reset(strong_12);

											var small_2 = $.sibling(strong_12);
											var text_51 = $.child(small_2);

											$.reset(small_2);
											$.reset(div_43);

											var div_44 = $.sibling(div_43);
											var b_8 = $.child(div_44);
											var text_52 = $.child(b_8);

											$.reset(b_8);

											var small_3 = $.sibling(b_8);
											var text_53 = $.child(small_3, true);

											$.reset(small_3);
											$.reset(div_44);

											var node_42 = $.sibling(div_44);

											$.add_svelte_meta(() => ViewDetailsLink(node_42, { onAction: () => openCommitmentHistory($.get(commitment)) }), 'component', Home, 198, 1487, { componentTag: 'ViewDetailsLink' });

											var node_43 = $.sibling(node_42);

											{
												var consequent_25 = ($$anchor) => {
													var div_45 = root_66();
													var node_44 = $.child(div_45);

													{
														let $0 = $.derived_safe_equal(() => (
															$.get(commitment),
															$.untrack(() => `Due now · ${money($.get(commitment).planningAmount)}`)
														));

														$.add_svelte_meta(
															() => DueReminder(node_44, {
																get detail() {
																	return $.get($0);
																},

																actionLabel: 'Mark commitment done',
																onAction: () => markCommitmentDone($.get(commitment))
															}),
															'component',
															Home,
															198,
															1633,
															{ componentTag: 'DueReminder' }
														);
													}

													$.reset(div_45);
													$.append($$anchor, div_45);
												};

												var alternate_16 = ($$anchor) => {
													var fragment_21 = $.comment();
													var node_45 = $.first_child(fragment_21);

													{
														var consequent_26 = ($$anchor) => {
															var div_46 = root_68();
															var small_4 = $.child(div_46);
															var text_54 = $.child(small_4);

															$.reset(small_4);
															$.reset(div_46);

															$.template_effect(($0) => $.set_text(text_54, `Done on ${$0 ?? ''}`), [
																() => (
																	$.get(commitment),
																	$.untrack(() => dateLabel(`${$.get(commitment).currentOccurrence.completedAt}T12:00:00`))
																)
															]);

															$.append($$anchor, div_46);
														};

														$.add_svelte_meta(
															() => $.if(
																node_45,
																($$render) => {
																	if ((
																		$.get(commitment),
																		$.untrack(() => $.strict_equals($.get(commitment).currentOccurrence?.status, 'COMPLETED'))
																	)) $$render(consequent_26);
																},
																true
															),
															'if',
															Home,
															198,
															1791
														);
													}

													$.append($$anchor, fragment_21);
												};

												$.add_svelte_meta(
													() => $.if(node_43, ($$render) => {
														if ((
															$.get(commitment),
															$.untrack(() => $.strict_equals($.get(commitment).currentOccurrence?.status, 'DUE'))
														)) $$render(consequent_25); else $$render(alternate_16, false);
													}),
													'if',
													Home,
													198,
													1554
												);
											}

											$.reset(article_1);

											$.template_effect(
												($0, $1) => {
													classes_13 = $.set_class(article_1, 1, 'loan-row', null, classes_13, {
														'due-recurring': $.strict_equals($.get(commitment).currentOccurrence?.status, 'DUE')
													});

													$.set_attribute(article_1, 'data-testid', (
														$.get(commitment),
														$.untrack(() => `monthly-commitment-${$.get(commitment).id}`)
													));

													$.set_text(text_49, ($.get(commitment), $.untrack(() => $.get(commitment).label)));

													$.set_attribute(button_32, 'aria-label', (
														$.get(commitment),
														$.untrack(() => `Edit ${$.get(commitment).label}`)
													));

													$.set_attribute(button_33, 'aria-label', (
														$.get(commitment),
														$.untrack(() => `Delete ${$.get(commitment).label}`)
													));

													button_33.disabled = $.strict_equals($.get(commitmentDeletingId), null, false);

													$.set_text(text_50, (
														$.get(commitmentDeletingId),
														$.get(commitment),
														$.untrack(() => $.strict_equals($.get(commitmentDeletingId), $.get(commitment).id) ? '…' : '🗑')
													));

													$.set_text(text_51, `${(
														$.get(commitment),
														$.untrack(() => $.strict_equals($.get(commitment).amountMode, 'RECENT_BILL_ESTIMATE') ? 'Recent-bill estimate' : 'Monthly planning amount')
													) ?? ''}${(
														$.get(commitment),
														$.untrack(() => $.get(commitment).dueDay ? ` · due around the ${$.get(commitment).dueDay}` : '')
													) ?? ''}`);

													$.set_text(text_52, `${$0 ?? ''}/mo`);
													$.set_text(text_53, $1);
												},
												[
													() => (
														$.get(commitment),
														$.untrack(() => money($.get(commitment).planningAmount))
													),

													() => (
														$.get(commitment),
														$.untrack(() => $.strict_equals($.get(commitment).currentOccurrence?.status, 'COMPLETED') ? 'done' : $.get(commitment).status.toLowerCase())
													)
												]
											);

											$.event('click', button_32, () => openCommitmentForm($.get(commitment)));
											$.event('click', button_33, () => removeCommitment($.get(commitment)));
											$.append($$anchor, article_1);
										}),
										'each',
										Home,
										198,
										497
									);

									$.append($$anchor, fragment_20);
								};

								var alternate_17 = ($$anchor) => {
									var p_13 = root_69();

									$.append($$anchor, p_13);
								};

								$.add_svelte_meta(
									() => $.if(
										node_40,
										($$render) => {
											if ((
												$.get(commitments),
												$.untrack(() => $.get(commitments).length)
											)) $$render(consequent_27); else $$render(alternate_17, false);
										},
										true
									),
									'if',
									Home,
									198,
									468
								);
							}

							$.append($$anchor, fragment_19);
						};

						$.add_svelte_meta(
							() => $.if(
								node_39,
								($$render) => {
									if ($.strict_equals($.get(commitmentStatus), 'error')) $$render(consequent_24); else $$render(alternate_18, false);
								},
								true
							),
							'if',
							Home,
							198,
							312
						);
					}

					$.append($$anchor, fragment_18);
				};

				$.add_svelte_meta(
					() => $.if(node_38, ($$render) => {
						if ($.strict_equals($.get(commitmentStatus), 'loading')) $$render(consequent_23); else $$render(alternate_19, false);
					}),
					'if',
					Home,
					198,
					232
				);
			}

			var button_34 = $.sibling(node_38);

			$.reset(section_13);

			var section_14 = $.sibling(section_13, 2);
			var node_46 = $.sibling($.child(section_14));

			{
				var consequent_28 = ($$anchor) => {
					var p_14 = root_70();

					$.append($$anchor, p_14);
				};

				var alternate_22 = ($$anchor) => {
					var fragment_22 = $.comment();
					var node_47 = $.first_child(fragment_22);

					{
						var consequent_29 = ($$anchor) => {
							var div_47 = root_72();
							var span_16 = $.child(div_47);
							var text_55 = $.child(span_16, true);

							$.reset(span_16);

							var button_35 = $.sibling(span_16);

							$.reset(div_47);
							$.template_effect(() => $.set_text(text_55, $.get(creditCardError)));
							$.event('click', button_35, loadCreditCards);
							$.append($$anchor, div_47);
						};

						var alternate_21 = ($$anchor) => {
							var fragment_23 = $.comment();
							var node_48 = $.first_child(fragment_23);

							{
								var consequent_30 = ($$anchor) => {
									var fragment_24 = $.comment();
									var node_49 = $.first_child(fragment_24);

									$.add_svelte_meta(
										() => $.each(node_49, 1, () => $.get(creditCards), $.index, ($$anchor, card) => {
											var article_2 = root_75();
											var div_48 = $.sibling($.child(article_2));
											var strong_13 = $.child(div_48);
											var text_56 = $.child(strong_13, true);
											var button_36 = $.sibling(text_56);

											$.reset(strong_13);

											var small_5 = $.sibling(strong_13);
											var text_57 = $.child(small_5);

											$.reset(small_5);
											$.reset(div_48);

											var div_49 = $.sibling(div_48);
											var b_9 = $.child(div_49);
											var text_58 = $.child(b_9);

											$.reset(b_9);

											var small_6 = $.sibling(b_9);
											var text_59 = $.child(small_6);

											$.reset(small_6);
											$.reset(div_49);
											$.reset(article_2);

											$.template_effect(() => {
												$.set_text(text_56, ($.get(card), $.untrack(() => $.get(card).cardName)));
												$.set_attribute(button_36, 'aria-label', ($.get(card), $.untrack(() => `Edit ${$.get(card).cardName}`)));
												$.set_text(text_57, `${($.get(card), $.untrack(() => $.get(card).issuerName)) ?? ''} · captured as ${($.get(card), $.untrack(() => $.get(card).accountName)) ?? ''}`);
												$.set_text(text_58, `Due ${($.get(card), $.untrack(() => $.get(card).dueDay)) ?? ''}`);
												$.set_text(text_59, `Statement ${($.get(card), $.untrack(() => $.get(card).statementDay)) ?? ''}`);
											});

											$.event('click', button_36, () => openCreditCardForm($.get(card)));
											$.append($$anchor, article_2);
										}),
										'each',
										Home,
										199,
										446
									);

									$.append($$anchor, fragment_24);
								};

								var alternate_20 = ($$anchor) => {
									var p_15 = root_76();

									$.append($$anchor, p_15);
								};

								$.add_svelte_meta(
									() => $.if(
										node_48,
										($$render) => {
											if ((
												$.get(creditCards),
												$.untrack(() => $.get(creditCards).length)
											)) $$render(consequent_30); else $$render(alternate_20, false);
										},
										true
									),
									'if',
									Home,
									199,
									417
								);
							}

							$.append($$anchor, fragment_23);
						};

						$.add_svelte_meta(
							() => $.if(
								node_47,
								($$render) => {
									if ($.strict_equals($.get(creditCardStatus), 'error')) $$render(consequent_29); else $$render(alternate_21, false);
								},
								true
							),
							'if',
							Home,
							199,
							261
						);
					}

					$.append($$anchor, fragment_22);
				};

				$.add_svelte_meta(
					() => $.if(node_46, ($$render) => {
						if ($.strict_equals($.get(creditCardStatus), 'loading')) $$render(consequent_28); else $$render(alternate_22, false);
					}),
					'if',
					Home,
					199,
					180
				);
			}

			var button_37 = $.sibling(node_46);

			$.reset(section_14);

			var node_50 = $.sibling(section_14, 2);

			$.add_svelte_meta(
				() => $.each(
					node_50,
					0,
					() => [
						['◒', 'Emergency fund', 'Track your safety cushion'],
						['◎', 'Goals', 'Plan for what matters'],
						['▤', 'Budgets', 'Set gentle spending limits']
					],
					$.index,
					($$anchor, module) => {
						var button_38 = root_77();
						var span_17 = $.child(button_38);
						var text_60 = $.child(span_17, true);

						$.reset(span_17);

						var div_50 = $.sibling(span_17);
						var strong_14 = $.child(div_50);
						var text_61 = $.child(strong_14, true);

						$.reset(strong_14);

						var small_7 = $.sibling(strong_14);
						var text_62 = $.child(small_7, true);

						$.reset(small_7);
						$.reset(div_50);
						$.next();
						$.reset(button_38);

						$.template_effect(() => {
							$.set_text(text_60, (module, $.untrack(() => module[0])));
							$.set_text(text_61, (module, $.untrack(() => module[1])));
							$.set_text(text_62, (module, $.untrack(() => module[2])));
						});

						$.event('click', button_38, closeMoney);
						$.append($$anchor, button_38);
					}
				),
				'each',
				Home,
				200,
				6
			);

			var section_15 = $.sibling(node_50, 2);
			var node_51 = $.sibling($.child(section_15));

			{
				var consequent_31 = ($$anchor) => {
					var p_16 = root_78();

					$.append($$anchor, p_16);
				};

				var alternate_27 = ($$anchor) => {
					var fragment_25 = $.comment();
					var node_52 = $.first_child(fragment_25);

					{
						var consequent_32 = ($$anchor) => {
							var div_51 = root_80();
							var span_18 = $.child(div_51);
							var text_63 = $.child(span_18, true);

							$.reset(span_18);

							var button_39 = $.sibling(span_18);

							$.reset(div_51);
							$.template_effect(() => $.set_text(text_63, $.get(mutualFundError)));
							$.event('click', button_39, loadMutualFunds);
							$.append($$anchor, div_51);
						};

						var alternate_26 = ($$anchor) => {
							var fragment_26 = $.comment();
							var node_53 = $.first_child(fragment_26);

							{
								var consequent_37 = ($$anchor) => {
									var fragment_27 = root_82();
									var section_16 = $.first_child(fragment_27);
									var node_54 = $.sibling($.child(section_16));

									{
										var consequent_33 = ($$anchor) => {
											var fragment_28 = root_83();
											var strong_15 = $.first_child(fragment_28);
											var text_64 = $.child(strong_15, true);

											$.reset(strong_15);

											var small_8 = $.sibling(strong_15);
											let classes_14;
											var text_65 = $.child(small_8);

											$.reset(small_8);

											$.template_effect(
												($0, $1, $2) => {
													$.set_text(text_64, $0);
													classes_14 = $.set_class(small_8, 1, '', null, classes_14, $1);

													$.set_text(text_65, `${(
														$.get(mutualPortfolio),
														$.untrack(() => $.get(mutualPortfolio).pnl >= 0 ? '+' : '')
													) ?? ''}${$2 ?? ''} overall P&L`);
												},
												[
													() => (
														$.get(mutualPortfolio),
														$.untrack(() => money($.get(mutualPortfolio).current))
													),

													() => ({
														positive: Number($.get(mutualPortfolio).pnl) >= 0,
														negative: Number($.get(mutualPortfolio).pnl) < 0
													}),

													() => (
														$.get(mutualPortfolio),
														$.untrack(() => money($.get(mutualPortfolio).pnl))
													)
												]
											);

											$.append($$anchor, fragment_28);
										};

										var alternate_23 = ($$anchor) => {
											var fragment_29 = root_84();
											var strong_16 = $.first_child(fragment_29);
											var text_66 = $.child(strong_16, true);

											$.reset(strong_16);
											$.next();

											$.template_effect(($0) => $.set_text(text_66, $0), [
												() => (
													$.get(mutualPortfolio),
													$.untrack(() => money($.get(mutualPortfolio).invested))
												)
											]);

											$.append($$anchor, fragment_29);
										};

										$.add_svelte_meta(
											() => $.if(node_54, ($$render) => {
												if ((
													$.get(mutualPortfolio),
													$.untrack(() => $.strict_equals($.get(mutualPortfolio).current, null, false))
												)) $$render(consequent_33); else $$render(alternate_23, false);
											}),
											'if',
											Home,
											203,
											533
										);
									}

									$.reset(section_16);

									var div_52 = $.sibling(section_16);

									$.add_svelte_meta(
										() => $.each(div_52, 5, () => $.get(mutualFunds), $.index, ($$anchor, fund) => {
											var button_40 = root_85();
											var div_53 = $.sibling($.child(button_40));
											var strong_17 = $.child(div_53);
											var text_67 = $.child(strong_17, true);

											$.reset(strong_17);

											var span_19 = $.sibling(strong_17);
											var text_68 = $.child(span_19, true);

											$.reset(span_19);

											var small_9 = $.sibling(span_19);
											var text_69 = $.child(small_9, true);

											$.reset(small_9);
											$.reset(div_53);

											var node_55 = $.sibling(div_53);

											{
												var consequent_35 = ($$anchor) => {
													var fragment_30 = root_86();
													var div_54 = $.first_child(fragment_30);
													var div_55 = $.child(div_54);
													let classes_15;
													var b_10 = $.sibling($.child(div_55));
													var text_70 = $.child(b_10);

													$.reset(b_10);

													var small_10 = $.sibling(b_10);
													var text_71 = $.child(small_10);

													$.reset(small_10);
													$.reset(div_55);

													var div_56 = $.sibling(div_55);
													var b_11 = $.sibling($.child(div_56));
													var text_72 = $.child(b_11, true);

													$.reset(b_11);
													$.reset(div_56);

													var div_57 = $.sibling(div_56);
													var b_12 = $.sibling($.child(div_57));
													var text_73 = $.child(b_12, true);

													$.reset(b_12);
													$.reset(div_57);
													$.reset(div_54);

													var p_17 = $.sibling(div_54);
													var text_74 = $.child(p_17);
													var node_56 = $.sibling(text_74);

													{
														var consequent_34 = ($$anchor) => {
															var span_20 = root_87();

															$.template_effect(() => $.set_attribute(span_20, 'aria-label', (
																$.get(fund),
																$.untrack(() => `Set SIP for ${$.get(fund).schemeName}`)
															)));

															$.event('click', span_20, $.stopPropagation(() => openFundSipPlan($.get(fund))));

															$.event('keydown', span_20, $.stopPropagation((event) => {
																if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
																	event.preventDefault();
																	openFundSipPlan($.get(fund));
																}
															}));

															$.append($$anchor, span_20);
														};

														$.add_svelte_meta(
															() => $.if(node_56, ($$render) => {
																if (($.get(fund), $.untrack(() => !$.get(fund).activeSip))) $$render(consequent_34);
															}),
															'if',
															Home,
															203,
															2204
														);
													}

													$.reset(p_17);

													$.template_effect(
														($0, $1, $2, $3, $4, $5, $6, $7) => {
															classes_15 = $.set_class(div_55, 1, '', null, classes_15, $0);
															$.set_text(text_70, `${$1 ?? ''}${$2 ?? ''}`);
															$.set_text(text_71, `${$3 ?? ''}${$4 ?? ''}%`);
															$.set_text(text_72, $5);
															$.set_text(text_73, $6);
															$.set_text(text_74, `Latest NAV ${$7 ?? ''} `);
														},
														[
															() => ({
																positive: Number($.get(fund).profitOrLoss) >= 0,
																negative: Number($.get(fund).profitOrLoss) < 0
															}),

															() => (
																$.get(fund),
																$.untrack(() => Number($.get(fund).profitOrLoss) >= 0 ? '+' : '')
															),

															() => (
																$.get(fund),
																$.untrack(() => compactMoney($.get(fund).profitOrLoss))
															),

															() => (
																$.get(fund),
																$.untrack(() => Number($.get(fund).profitOrLossPercent) >= 0 ? '+' : '')
															),

															() => (
																$.get(fund),
																$.untrack(() => Number($.get(fund).profitOrLossPercent).toFixed(2))
															),

															() => (
																$.get(fund),
																$.untrack(() => compactMoney($.get(fund).invested))
															),

															() => (
																$.get(fund),
																$.untrack(() => compactMoney($.get(fund).currentValue))
															),

															() => (
																$.get(fund),
																$.untrack(() => moneyDecimal($.get(fund).latestNav))
															)
														]
													);

													$.append($$anchor, fragment_30);
												};

												var alternate_24 = ($$anchor) => {
													var p_18 = root_88();
													var text_75 = $.child(p_18);

													$.reset(p_18);

													$.template_effect(($0) => $.set_text(text_75, `Current valuation is temporarily unavailable. Your invested amount is ${$0 ?? ''}.`), [
														() => ($.get(fund), $.untrack(() => money($.get(fund).invested)))
													]);

													$.append($$anchor, p_18);
												};

												$.add_svelte_meta(
													() => $.if(node_55, ($$render) => {
														if ((
															$.get(fund),
															$.untrack(() => $.strict_equals($.get(fund).currentValue, null, false))
														)) $$render(consequent_35); else $$render(alternate_24, false);
													}),
													'if',
													Home,
													203,
													1628
												);
											}

											var footer = $.sibling(node_55);
											var span_21 = $.child(footer);
											var text_76 = $.child(span_21, true);

											$.reset(span_21);

											var span_22 = $.sibling(span_21);
											var span_23 = $.sibling($.child(span_22));

											$.reset(span_22);
											$.reset(footer);

											var node_57 = $.sibling(footer);

											{
												var consequent_36 = ($$anchor) => {
													var fragment_31 = $.comment();
													var node_58 = $.first_child(fragment_31);

													{
														let $0 = $.derived_safe_equal(() => (
															$.get(fund),
															$.untrack(() => `mutual-fund-sip-${$.get(fund).id}`)
														));

														let $1 = $.derived_safe_equal(() => (
															$.get(fund),
															$.untrack(() => `Due now · ${money($.get(fund).currentSip.amount)}`)
														));

														$.add_svelte_meta(
															() => DueReminder(node_58, {
																get testId() {
																	return $.get($0);
																},

																get detail() {
																	return $.get($1);
																},

																actionLabel: 'Confirm allocation',
																onAction: () => openSipConfirmation($.get(fund), $.get(fund).currentSip)
															}),
															'component',
															Home,
															203,
															3185,
															{ componentTag: 'DueReminder' }
														);
													}

													$.append($$anchor, fragment_31);
												};

												$.add_svelte_meta(
													() => $.if(node_57, ($$render) => {
														if ((
															$.get(fund),
															$.untrack(() => $.strict_equals($.get(fund).currentSip?.status, "DUE"))
														)) $$render(consequent_36);
													}),
													'if',
													Home,
													203,
													3148
												);
											}

											$.reset(button_40);

											$.template_effect(
												($0, $1, $2) => {
													$.set_class(button_40, 1, $0);

													$.set_attribute(button_40, 'aria-label', (
														$.get(fund),
														$.untrack(() => `Open ${$.get(fund).schemeName} details`)
													));

													$.set_text(text_67, ($.get(fund), $.untrack(() => $.get(fund).schemeName)));

													$.set_attribute(span_19, 'aria-label', (
														$.get(fund),
														$.untrack(() => `Delete ${$.get(fund).schemeName}`)
													));

													$.set_text(text_68, (
														$.get(mutualFundDeletingId),
														$.get(fund),
														$.untrack(() => $.strict_equals($.get(mutualFundDeletingId), $.get(fund).id) ? '…' : '🗑')
													));

													$.set_text(text_69, $1);
													$.set_text(text_76, $2);
												},
												[
													() => (
														$.get(fund),
														$.untrack(() => `fund-card ${fundAccent($.get(fund).id)}`)
													),

													() => (
														$.get(fund),
														$.untrack(() => fundSubtitle($.get(fund).schemeName))
													),

													() => (
														$.get(fund),

														$.untrack(() => $.get(fund).activeSip
															? `1 SIP · ${compactMoney($.get(fund).activeSip.amount)} on the ${$.get(fund).activeSip.day}${$.strict_equals($.get(fund).activeSip.day, 1)
																? 'st'
																: $.strict_equals($.get(fund).activeSip.day, 2)
																	? 'nd'
																	: $.strict_equals($.get(fund).activeSip.day, 3) ? 'rd' : 'th'} of every month`
															: 'No active SIP')
													)
												]
											);

											$.event('click', span_19, $.stopPropagation(() => removeMutualFund($.get(fund))));

											$.event('keydown', span_19, $.stopPropagation((event) => {
												if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
													event.preventDefault();
													removeMutualFund($.get(fund));
												}
											}));

											$.event('click', span_23, $.stopPropagation(() => openLumpSum($.get(fund))));
											$.event('click', button_40, () => openFundDetail($.get(fund).id));
											$.append($$anchor, button_40);
										}),
										'each',
										Home,
										203,
										962
									);

									$.reset(div_52);
									$.append($$anchor, fragment_27);
								};

								var alternate_25 = ($$anchor) => {
									var p_19 = root_90();

									$.append($$anchor, p_19);
								};

								$.add_svelte_meta(
									() => $.if(
										node_53,
										($$render) => {
											if ((
												$.get(mutualFunds),
												$.untrack(() => $.get(mutualFunds).length)
											)) $$render(consequent_37); else $$render(alternate_25, false);
										},
										true
									),
									'if',
									Home,
									203,
									437
								);
							}

							$.append($$anchor, fragment_26);
						};

						$.add_svelte_meta(
							() => $.if(
								node_52,
								($$render) => {
									if ($.strict_equals($.get(mutualFundStatus), 'error')) $$render(consequent_32); else $$render(alternate_26, false);
								},
								true
							),
							'if',
							Home,
							203,
							281
						);
					}

					$.append($$anchor, fragment_25);
				};

				$.add_svelte_meta(
					() => $.if(node_51, ($$render) => {
						if ($.strict_equals($.get(mutualFundStatus), 'loading')) $$render(consequent_31); else $$render(alternate_27, false);
					}),
					'if',
					Home,
					203,
					221
				);
			}

			var button_41 = $.sibling(node_51);

			$.reset(section_15);

			var section_17 = $.sibling(section_15, 2);
			var node_59 = $.sibling($.child(section_17), 2);

			{
				var consequent_38 = ($$anchor) => {
					var p_20 = root_91();

					$.append($$anchor, p_20);
				};

				var alternate_32 = ($$anchor) => {
					var fragment_32 = $.comment();
					var node_60 = $.first_child(fragment_32);

					{
						var consequent_39 = ($$anchor) => {
							var div_58 = root_93();
							var span_24 = $.child(div_58);
							var text_77 = $.child(span_24, true);

							$.reset(span_24);

							var button_42 = $.sibling(span_24);

							$.reset(div_58);
							$.template_effect(() => $.set_text(text_77, $.get(stockError)));
							$.event('click', button_42, loadStocks);
							$.append($$anchor, div_58);
						};

						var alternate_31 = ($$anchor) => {
							var fragment_33 = $.comment();
							var node_61 = $.first_child(fragment_33);

							{
								var consequent_43 = ($$anchor) => {
									var fragment_34 = root_95();
									var section_18 = $.first_child(fragment_34);
									var node_62 = $.sibling($.child(section_18));

									{
										var consequent_40 = ($$anchor) => {
											var fragment_35 = root_96();
											var strong_18 = $.first_child(fragment_35);
											var text_78 = $.child(strong_18, true);

											$.reset(strong_18);

											var small_11 = $.sibling(strong_18);
											let classes_16;
											var text_79 = $.child(small_11);

											$.reset(small_11);

											$.template_effect(
												($0, $1) => {
													$.set_text(text_78, $0);

													classes_16 = $.set_class(small_11, 1, '', null, classes_16, {
														positive: $.get(stockPortfolio).pnl >= 0,
														negative: $.get(stockPortfolio).pnl < 0
													});

													$.set_text(text_79, `${(
														$.get(stockPortfolio),
														$.untrack(() => $.get(stockPortfolio).pnl >= 0 ? '+' : '')
													) ?? ''}${$1 ?? ''} overall P&L`);
												},
												[
													() => (
														$.get(stockPortfolio),
														$.untrack(() => money($.get(stockPortfolio).current))
													),

													() => (
														$.get(stockPortfolio),
														$.untrack(() => money($.get(stockPortfolio).pnl))
													)
												]
											);

											$.append($$anchor, fragment_35);
										};

										var alternate_28 = ($$anchor) => {
											var fragment_36 = root_97();
											var strong_19 = $.first_child(fragment_36);
											var text_80 = $.child(strong_19, true);

											$.reset(strong_19);
											$.next();

											$.template_effect(($0) => $.set_text(text_80, $0), [
												() => (
													$.get(stockPortfolio),
													$.untrack(() => money($.get(stockPortfolio).invested))
												)
											]);

											$.append($$anchor, fragment_36);
										};

										$.add_svelte_meta(
											() => $.if(node_62, ($$render) => {
												if ((
													$.get(stockPortfolio),
													$.untrack(() => $.strict_equals($.get(stockPortfolio).current, null, false))
												)) $$render(consequent_40); else $$render(alternate_28, false);
											}),
											'if',
											Home,
											209,
											73
										);
									}

									$.reset(section_18);

									var div_59 = $.sibling(section_18, 2);

									$.add_svelte_meta(
										() => $.each(div_59, 5, () => $.get(stocks), $.index, ($$anchor, stock) => {
											var article_3 = root_98();
											let classes_17;
											var div_60 = $.sibling($.child(article_3));
											var strong_20 = $.child(div_60);
											var text_81 = $.child(strong_20, true);

											$.reset(strong_20);

											var span_25 = $.sibling(strong_20);
											var text_82 = $.child(span_25, true);

											$.reset(span_25);

											var small_12 = $.sibling(span_25);
											var text_83 = $.child(small_12);

											$.reset(small_12);
											$.reset(div_60);

											var node_63 = $.sibling(div_60, 2);

											{
												var consequent_41 = ($$anchor) => {
													var fragment_37 = root_99();
													var div_61 = $.first_child(fragment_37);
													var div_62 = $.child(div_61);
													let classes_18;
													var b_13 = $.sibling($.child(div_62));
													var text_84 = $.child(b_13);

													$.reset(b_13);

													var small_13 = $.sibling(b_13);
													var text_85 = $.child(small_13);

													$.reset(small_13);
													$.reset(div_62);

													var div_63 = $.sibling(div_62);
													var b_14 = $.sibling($.child(div_63));
													var text_86 = $.child(b_14, true);

													$.reset(b_14);
													$.reset(div_63);

													var div_64 = $.sibling(div_63);
													var b_15 = $.sibling($.child(div_64));
													var text_87 = $.child(b_15, true);

													$.reset(b_15);
													$.reset(div_64);
													$.reset(div_61);

													var p_21 = $.sibling(div_61);
													var text_88 = $.child(p_21);
													var button_43 = $.sibling(text_88);

													$.reset(p_21);

													$.template_effect(
														($0, $1, $2, $3, $4, $5, $6, $7, $8) => {
															classes_18 = $.set_class(div_62, 1, '', null, classes_18, $0);
															$.set_text(text_84, `${$1 ?? ''}${$2 ?? ''}`);
															$.set_text(text_85, `${$3 ?? ''}${$4 ?? ''}%`);
															$.set_text(text_86, $5);
															$.set_text(text_87, $6);
															$.set_text(text_88, `Latest price ${$7 ?? ''} · ${$8 ?? ''} shares `);

															$.set_attribute(button_43, 'aria-label', (
																$.get(stock),
																$.untrack(() => `Set monthly recurring plan for ${$.get(stock).name}`)
															));
														},
														[
															() => ({
																positive: Number($.get(stock).profitOrLoss) >= 0,
																negative: Number($.get(stock).profitOrLoss) < 0
															}),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).profitOrLoss) >= 0 ? '+' : '')
															),

															() => (
																$.get(stock),
																$.untrack(() => compactMoney($.get(stock).profitOrLoss))
															),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).profitOrLossPercent) >= 0 ? '+' : '')
															),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).profitOrLossPercent).toFixed(2))
															),

															() => (
																$.get(stock),
																$.untrack(() => compactMoney($.get(stock).invested))
															),

															() => (
																$.get(stock),
																$.untrack(() => compactMoney($.get(stock).currentValue))
															),

															() => (
																$.get(stock),
																$.untrack(() => moneyDecimal($.get(stock).latestPrice))
															),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).quantity).toFixed(3))
															)
														]
													);

													$.event('click', button_43, () => openStockPlan($.get(stock)));
													$.append($$anchor, fragment_37);
												};

												var alternate_29 = ($$anchor) => {
													var p_22 = root_100();
													var text_89 = $.child(p_22);

													$.reset(p_22);

													$.template_effect(($0) => $.set_text(text_89, `Current price is temporarily unavailable. Your invested amount is ${$0 ?? ''}.`), [
														() => ($.get(stock), $.untrack(() => money($.get(stock).invested)))
													]);

													$.append($$anchor, p_22);
												};

												$.add_svelte_meta(
													() => $.if(node_63, ($$render) => {
														if ((
															$.get(stock),
															$.untrack(() => $.strict_equals($.get(stock).currentValue, null, false))
														)) $$render(consequent_41); else $$render(alternate_29, false);
													}),
													'if',
													Home,
													212,
													12
												);
											}

											var footer_1 = $.sibling(node_63, 2);
											var span_26 = $.child(footer_1);
											var text_90 = $.child(span_26, true);

											$.reset(span_26);

											var node_64 = $.sibling(span_26);

											$.add_svelte_meta(() => ViewDetailsLink(node_64, { onAction: () => openStockDetail($.get(stock).id) }), 'component', Home, 213, 322, { componentTag: 'ViewDetailsLink' });
											$.reset(footer_1);

											var node_65 = $.sibling(footer_1, 2);

											{
												var consequent_42 = ($$anchor) => {
													var fragment_38 = $.comment();
													var node_66 = $.first_child(fragment_38);

													{
														let $0 = $.derived_safe_equal(() => (
															$.get(stock),
															$.untrack(() => `stock-monthly-plan-${$.get(stock).id}`)
														));

														let $1 = $.derived_safe_equal(() => (
															$.get(stock),
															$.untrack(() => `Due now · ${money($.get(stock).currentMonthlyPlan.amount)}`)
														));

														$.add_svelte_meta(
															() => DueReminder(node_66, {
																get testId() {
																	return $.get($0);
																},

																get detail() {
																	return $.get($1);
																},

																actionLabel: 'Confirm allocation',

																onAction: () => {
																	$.set(stockPlanConfirmationTarget, $.get(stock));

																	$.set(stockPlanConfirmation, {
																		amount: String($.get(stock).currentMonthlyPlan.amount),
																		price: String($.get(stock).latestPrice || '')
																	});
																}
															}),
															'component',
															Home,
															214,
															58,
															{ componentTag: 'DueReminder' }
														);
													}

													$.append($$anchor, fragment_38);
												};

												$.add_svelte_meta(
													() => $.if(node_65, ($$render) => {
														if ((
															$.get(stock),
															$.untrack(() => $.strict_equals($.get(stock).currentMonthlyPlan?.status, 'DUE'))
														)) $$render(consequent_42);
													}),
													'if',
													Home,
													214,
													12
												);
											}

											$.reset(article_3);

											$.template_effect(
												($0, $1, $2) => {
													classes_17 = $.set_class(article_3, 1, $0, null, classes_17, $1);

													$.set_attribute(article_3, 'data-testid', (
														$.get(stock),
														$.untrack(() => `stock-card-${$.get(stock).id}`)
													));

													$.set_text(text_81, ($.get(stock), $.untrack(() => $.get(stock).name)));
													$.set_attribute(span_25, 'aria-label', ($.get(stock), $.untrack(() => `Delete ${$.get(stock).name}`)));

													$.set_text(text_82, (
														$.get(stockDeletingId),
														$.get(stock),
														$.untrack(() => $.strict_equals($.get(stockDeletingId), $.get(stock).id) ? '…' : '🗑')
													));

													$.set_text(text_83, `${($.get(stock), $.untrack(() => $.get(stock).symbol)) ?? ''}${(
														$.get(stock),
														$.untrack(() => $.get(stock).exchange ? ` · ${$.get(stock).exchange}` : '')
													) ?? ''}`);

													$.set_text(text_90, $2);
												},
												[
													() => (
														$.get(stock),
														$.untrack(() => `fund-card ${fundAccent($.get(stock).id)}`)
													),

													() => ({
														'due-stock': $.strict_equals(String($.get(stock).id), String($.get(highlightedStockId)))
													}),

													() => (
														$.get(stock),

														$.untrack(() => $.get(stock).activeMonthlyPlan
															? `Monthly plan · ${compactMoney($.get(stock).activeMonthlyPlan.amount)} on the ${$.get(stock).activeMonthlyPlan.day}${$.strict_equals($.get(stock).activeMonthlyPlan.day, 1)
																? 'st'
																: $.strict_equals($.get(stock).activeMonthlyPlan.day, 2)
																	? 'nd'
																	: $.strict_equals($.get(stock).activeMonthlyPlan.day, 3) ? 'rd' : 'th'}`
															: 'No monthly plan')
													)
												]
											);

											$.event('click', span_25, () => removeStock($.get(stock)));

											$.event('keydown', span_25, (event) => {
												if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
													event.preventDefault();
													removeStock($.get(stock));
												}
											});

											$.append($$anchor, article_3);
										}),
										'each',
										Home,
										210,
										38
									);

									$.reset(div_59);
									$.append($$anchor, fragment_34);
								};

								var alternate_30 = ($$anchor) => {
									var p_23 = root_102();

									$.append($$anchor, p_23);
								};

								$.add_svelte_meta(
									() => $.if(
										node_61,
										($$render) => {
											if (($.get(stocks), $.untrack(() => $.get(stocks).length))) $$render(consequent_43); else $$render(alternate_30, false);
										},
										true
									),
									'if',
									Home,
									208,
									8
								);
							}

							$.append($$anchor, fragment_33);
						};

						$.add_svelte_meta(
							() => $.if(
								node_60,
								($$render) => {
									if ($.strict_equals($.get(stockStatus), 'error')) $$render(consequent_39); else $$render(alternate_31, false);
								},
								true
							),
							'if',
							Home,
							207,
							8
						);
					}

					$.append($$anchor, fragment_32);
				};

				$.add_svelte_meta(
					() => $.if(node_59, ($$render) => {
						if ($.strict_equals($.get(stockStatus), 'loading')) $$render(consequent_38); else $$render(alternate_32, false);
					}),
					'if',
					Home,
					206,
					8
				);
			}

			var button_44 = $.sibling(node_59, 2);

			$.reset(section_17);

			var section_19 = $.sibling(section_17, 2);
			var div_65 = $.child(section_19);
			var node_67 = $.sibling($.child(div_65));

			{
				var consequent_44 = ($$anchor) => {
					var div_66 = root_103();
					var b_16 = $.sibling($.child(div_66));
					var text_91 = $.child(b_16);

					$.reset(b_16);
					$.reset(div_66);

					$.template_effect(($0) => $.set_text(text_91, `${$0 ?? ''}/mo`), [
						() => (
							$.get(totalMonthlyEmi),
							$.untrack(() => money($.get(totalMonthlyEmi)))
						)
					]);

					$.append($$anchor, div_66);
				};

				$.add_svelte_meta(
					() => $.if(node_67, ($$render) => {
						if ((
							$.get(activeLoans),
							$.untrack(() => $.get(activeLoans).length)
						)) $$render(consequent_44);
					}),
					'if',
					Home,
					219,
					179
				);
			}

			$.reset(div_65);

			var node_68 = $.sibling(div_65, 2);

			{
				var consequent_45 = ($$anchor) => {
					var p_24 = root_104();

					$.append($$anchor, p_24);
				};

				var alternate_35 = ($$anchor) => {
					var fragment_39 = $.comment();
					var node_69 = $.first_child(fragment_39);

					{
						var consequent_46 = ($$anchor) => {
							var div_67 = root_106();
							var span_27 = $.child(div_67);
							var text_92 = $.child(span_27, true);

							$.reset(span_27);

							var button_45 = $.sibling(span_27);

							$.reset(div_67);
							$.template_effect(() => $.set_text(text_92, $.get(loanError)));
							$.event('click', button_45, loadLoans);
							$.append($$anchor, div_67);
						};

						var alternate_34 = ($$anchor) => {
							var fragment_40 = $.comment();
							var node_70 = $.first_child(fragment_40);

							{
								var consequent_49 = ($$anchor) => {
									var fragment_41 = $.comment();
									var node_71 = $.first_child(fragment_41);

									$.add_svelte_meta(
										() => $.each(node_71, 1, () => $.get(activeLoans), $.index, ($$anchor, loan) => {
											const schedule = $.tag($.derived_safe_equal(() => ($.get(loan), $.untrack(() => loanSchedule($.get(loan))))), 'schedule');

											$.get(schedule);

											var article_4 = root_109();
											let classes_19;
											var div_68 = $.sibling($.child(article_4));
											var strong_21 = $.child(div_68);
											var text_93 = $.child(strong_21, true);
											var button_46 = $.sibling(text_93);
											var button_47 = $.sibling(button_46);
											var text_94 = $.child(button_47, true);

											$.reset(button_47);
											$.reset(strong_21);

											var small_14 = $.sibling(strong_21);
											var text_95 = $.child(small_14);

											$.reset(small_14);
											$.reset(div_68);

											var div_69 = $.sibling(div_68);
											var b_17 = $.child(div_69);
											var text_96 = $.child(b_17);

											$.reset(b_17);

											var small_15 = $.sibling(b_17);
											var text_97 = $.child(small_15);

											$.reset(small_15);
											$.reset(div_69);

											var node_72 = $.sibling(div_69);

											$.add_svelte_meta(() => ViewDetailsLink(node_72, { onAction: () => openLoanHistory($.get(loan)) }), 'component', Home, 220, 1006, { componentTag: 'ViewDetailsLink' });

											var node_73 = $.sibling(node_72);

											{
												var consequent_47 = ($$anchor) => {
													var div_70 = root_110();
													var div_71 = $.child(div_70);
													var span_28 = $.child(div_71);
													var text_98 = $.child(span_28);

													$.reset(span_28);
													$.reset(div_71);

													var i_2 = $.sibling(div_71);

													$.reset(div_70);

													$.template_effect(() => {
														$.set_text(text_98, `${(
															$.deep_read_state($.get(schedule)),
															$.untrack(() => $.get(schedule).due)
														) ?? ''} of ${(
															$.deep_read_state($.get(schedule)),
															$.untrack(() => $.get(schedule).tenure)
														) ?? ''} historical EMI months completed`);

														$.set_style(i_2, (
															$.deep_read_state($.get(schedule)),
															$.untrack(() => `--loan-progress:${$.get(schedule).percent}%`)
														));
													});

													$.append($$anchor, div_70);
												};

												$.add_svelte_meta(
													() => $.if(node_73, ($$render) => {
														if ($.get(schedule)) $$render(consequent_47);
													}),
													'if',
													Home,
													220,
													1061
												);
											}

											var node_74 = $.sibling(node_73);

											{
												var consequent_48 = ($$anchor) => {
													var div_72 = root_111();
													var button_48 = $.sibling($.child(div_72), 2);
													var text_99 = $.child(button_48, true);

													$.reset(button_48);
													$.reset(div_72);

													$.template_effect(() => {
														button_48.disabled = $.strict_equals($.get(completingActionId), null, false);

														$.set_text(text_99, (
															$.get(completingActionId),
															$.get(highlightedLoanAction),
															$.untrack(() => $.strict_equals($.get(completingActionId), $.get(highlightedLoanAction).id) ? 'Marking loan closed…' : 'Mark final EMI paid')
														));
													});

													$.event('click', button_48, () => completeOpenAction($.get(highlightedLoanAction)));
													$.append($$anchor, div_72);
												};

												$.add_svelte_meta(
													() => $.if(node_74, ($$render) => {
														if ((
															$.get(loan),
															$.get(highlightedLoanId),
															$.get(highlightedLoanAction),
															$.untrack(() => $.strict_equals(String($.get(loan).id), String($.get(highlightedLoanId))) && $.get(highlightedLoanAction))
														)) $$render(consequent_48);
													}),
													'if',
													Home,
													220,
													1258
												);
											}

											$.reset(article_4);

											$.template_effect(
												($0, $1, $2, $3) => {
													classes_19 = $.set_class(article_4, 1, 'loan-row', null, classes_19, $0);
													$.set_text(text_93, ($.get(loan), $.untrack(() => $.get(loan).loanName)));
													$.set_attribute(button_46, 'aria-label', ($.get(loan), $.untrack(() => `Edit ${$.get(loan).loanName}`)));

													$.set_attribute(button_47, 'aria-label', (
														$.get(loan),
														$.untrack(() => `Delete ${$.get(loan).loanName}`)
													));

													button_47.disabled = $.strict_equals($.get(loanDeletingId), null, false);

													$.set_text(text_94, (
														$.get(loanDeletingId),
														$.get(loan),
														$.untrack(() => $.strict_equals($.get(loanDeletingId), $.get(loan).id) ? '…' : '🗑')
													));

													$.set_text(text_95, `${($.get(loan), $.untrack(() => $.get(loan).lenderName)) ?? ''} · ${$1 ?? ''} · ${($.get(loan), $.untrack(() => $.get(loan).totalTenureMonths)) ?? ''} months`);
													$.set_text(text_96, `${$2 ?? ''}/mo`);
													$.set_text(text_97, `${$3 ?? ''} principal`);
												},
												[
													() => ({
														'due-loan': $.strict_equals(String($.get(loan).id), String($.get(highlightedLoanId)))
													}),

													() => (
														$.get(loan),
														$.untrack(() => $.get(loan).loanType.replaceAll('_', ' '))
													),

													() => (
														$.get(loan),
														$.untrack(() => money($.get(loan).monthlyEmiAmount))
													),

													() => (
														$.get(loan),
														$.untrack(() => money($.get(loan).originalPrincipal))
													)
												]
											);

											$.event('click', button_46, () => openLoanForm($.get(loan)));
											$.event('click', button_47, () => removeLoan($.get(loan)));
											$.append($$anchor, article_4);
										}),
										'each',
										Home,
										220,
										248
									);

									$.append($$anchor, fragment_41);
								};

								var alternate_33 = ($$anchor) => {
									var p_25 = root_112();

									$.append($$anchor, p_25);
								};

								$.add_svelte_meta(
									() => $.if(
										node_70,
										($$render) => {
											if ((
												$.get(activeLoans),
												$.untrack(() => $.get(activeLoans).length)
											)) $$render(consequent_49); else $$render(alternate_33, false);
										},
										true
									),
									'if',
									Home,
									220,
									219
								);
							}

							$.append($$anchor, fragment_40);
						};

						$.add_svelte_meta(
							() => $.if(
								node_69,
								($$render) => {
									if ($.strict_equals($.get(loanStatus), 'error')) $$render(consequent_46); else $$render(alternate_34, false);
								},
								true
							),
							'if',
							Home,
							220,
							81
						);
					}

					$.append($$anchor, fragment_39);
				};

				$.add_svelte_meta(
					() => $.if(node_68, ($$render) => {
						if ($.strict_equals($.get(loanStatus), 'loading')) $$render(consequent_45); else $$render(alternate_35, false);
					}),
					'if',
					Home,
					220,
					8
				);
			}

			var node_75 = $.sibling(node_68, 2);

			{
				var consequent_51 = ($$anchor) => {
					var fragment_42 = root_113();
					var button_49 = $.first_child(fragment_42);
					var text_100 = $.child(button_49);
					var span_29 = $.sibling(text_100);
					var text_101 = $.child(span_29, true);

					$.reset(span_29);
					$.reset(button_49);

					var node_76 = $.sibling(button_49);

					{
						var consequent_50 = ($$anchor) => {
							var div_73 = root_114();

							$.add_svelte_meta(
								() => $.each(div_73, 5, () => $.get(closedLoans), $.index, ($$anchor, loan) => {
									var fragment_43 = $.comment();
									var node_77 = $.first_child(fragment_43);

									$.add_svelte_meta(
										() => ClosedLoanRow(node_77, {
											get loan() {
												return $.get(loan);
											},

											money
										}),
										'component',
										Home,
										221,
										343,
										{ componentTag: 'ClosedLoanRow' }
									);

									$.append($$anchor, fragment_43);
								}),
								'each',
								Home,
								221,
								316
							);

							$.reset(div_73);
							$.append($$anchor, div_73);
						};

						$.add_svelte_meta(
							() => $.if(node_76, ($$render) => {
								if ($.get(showClosedLoans)) $$render(consequent_50);
							}),
							'if',
							Home,
							221,
							264
						);
					}

					$.template_effect(() => {
						$.set_attribute(button_49, 'aria-expanded', $.get(showClosedLoans));

						$.set_text(text_100, `Closed loans · ${(
							$.get(closedLoans),
							$.untrack(() => $.get(closedLoans).length)
						) ?? ''}`);

						$.set_text(text_101, $.get(showClosedLoans) ? '⌃' : '⌄');
					});

					$.event('click', button_49, () => $.set(showClosedLoans, !$.get(showClosedLoans)));
					$.append($$anchor, fragment_42);
				};

				$.add_svelte_meta(
					() => $.if(node_75, ($$render) => {
						if ((
							$.get(closedLoans),
							$.untrack(() => $.get(closedLoans).length)
						)) $$render(consequent_51);
					}),
					'if',
					Home,
					221,
					8
				);
			}

			var button_50 = $.sibling(node_75, 2);

			$.reset(section_19);
			$.next(2);
			$.reset(section_11);
			$.reset(div_39);
			$.event('click', button_27, closeMoney);
			$.event('click', button_34, () => openCommitmentForm());
			$.event('click', button_37, () => openCreditCardForm());
			$.event('click', button_41, openMutualFundForm);
			$.event('click', button_44, openStockForm);
			$.event('click', button_50, () => openLoanForm());

			$.event('click', section_11, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_39, closeMoney);
			$.event('keydown', div_39, (event) => $.strict_equals(event.key, 'Escape') && closeMoney());
			$.append($$anchor, div_39);
		};

		$.add_svelte_meta(
			() => $.if(node_34, ($$render) => {
				if ($.get(showMoney)) $$render(consequent_52);
			}),
			'if',
			Home,
			191,
			0
		);
	}

	var node_78 = $.sibling(node_34, 2);

	{
		var consequent_54 = ($$anchor) => {
			var div_74 = root_116();
			var section_20 = $.child(div_74);
			var button_51 = $.child(section_20);
			var h2_4 = $.sibling(button_51, 2);
			var text_102 = $.child(h2_4, true);

			$.reset(h2_4);

			var label_1 = $.sibling(h2_4, 2);
			var input_1 = $.sibling($.child(label_1));

			$.remove_input_defaults(input_1);
			$.reset(label_1);

			var label_2 = $.sibling(label_1);
			var input_2 = $.sibling($.child(label_2));

			$.remove_input_defaults(input_2);
			$.reset(label_2);

			var label_3 = $.sibling(label_2);
			var input_3 = $.sibling($.child(label_3), 2);

			$.remove_input_defaults(input_3);
			$.reset(label_3);

			var label_4 = $.sibling(label_3);
			var select = $.sibling($.child(label_4));

			$.template_effect(() => {
				$.get(commitmentForm);
				$.invalidate_inner_signals(() => {});
			});

			var option_1 = $.child(select);

			option_1.value = option_1.__value = 'FIXED';

			var option_2 = $.sibling(option_1);

			option_2.value = option_2.__value = 'USER_ESTIMATE';
			$.reset(select);
			$.reset(label_4);

			var node_79 = $.sibling(label_4);

			{
				var consequent_53 = ($$anchor) => {
					var p_26 = root_117();
					var text_103 = $.child(p_26, true);

					$.reset(p_26);
					$.template_effect(() => $.set_text(text_103, $.get(commitmentError)));
					$.append($$anchor, p_26);
				};

				$.add_svelte_meta(
					() => $.if(node_79, ($$render) => {
						if ($.get(commitmentError)) $$render(consequent_53);
					}),
					'if',
					Home,
					228,
					977
				);
			}

			var div_75 = $.sibling(node_79);
			var button_52 = $.child(div_75);
			var button_53 = $.sibling(button_52);
			var text_104 = $.child(button_53, true);

			$.reset(button_53);
			$.reset(div_75);
			$.reset(section_20);
			$.reset(div_74);

			$.template_effect(() => {
				$.set_text(text_102, $.strict_equals($.get(commitmentEditingId), null)
					? 'Add a repeatable obligation'
					: 'Edit monthly commitment');

				button_53.disabled = $.get(commitmentSaving);

				$.set_text(text_104, $.get(commitmentSaving)
					? 'Saving…'
					: $.strict_equals($.get(commitmentEditingId), null) ? 'Add commitment' : 'Save changes');
			});

			$.event('click', button_51, () => $.set(showCommitmentForm, false));

			$.bind_value(
				input_1,
				function get() {
					return $.get(commitmentForm).label;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).label = $$value);
				}
			);

			$.bind_value(
				input_2,
				function get() {
					return $.get(commitmentForm).planningAmount;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).planningAmount = $$value);
				}
			);

			$.bind_value(
				input_3,
				function get() {
					return $.get(commitmentForm).dueDay;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).dueDay = $$value);
				}
			);

			$.bind_select_value(
				select,
				function get() {
					return $.get(commitmentForm).amountMode;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).amountMode = $$value);
				}
			);

			$.event('click', button_52, () => $.set(showCommitmentForm, false));
			$.event('click', button_53, saveCommitment);
			$.append($$anchor, div_74);
		};

		$.add_svelte_meta(
			() => $.if(node_78, ($$render) => {
				if ($.get(showCommitmentForm)) $$render(consequent_54);
			}),
			'if',
			Home,
			228,
			0
		);
	}

	var node_80 = $.sibling(node_78, 2);

	{
		var consequent_56 = ($$anchor) => {
			var div_76 = root_118();
			var section_21 = $.child(div_76);
			var button_54 = $.child(section_21);
			var h2_5 = $.sibling(button_54, 2);
			var text_105 = $.child(h2_5, true);

			$.reset(h2_5);

			var label_5 = $.sibling(h2_5, 2);
			var select_1 = $.sibling($.child(label_5));

			$.template_effect(() => {
				$.get(creditCardForm);

				$.invalidate_inner_signals(() => {
					$.get(editOptions);
					String;
				});
			});

			var option_3 = $.child(select_1);

			option_3.value = option_3.__value = '';

			var node_81 = $.sibling(option_3);

			$.add_svelte_meta(
				() => $.each(
					node_81,
					1,
					() => (
						$.get(editOptions),
						$.untrack(() => $.get(editOptions).accounts)
					),
					$.index,
					($$anchor, account) => {
						var option_4 = root_119();
						var text_106 = $.child(option_4, true);

						$.reset(option_4);

						var option_4_value = {};

						$.template_effect(
							($0) => {
								$.set_text(text_106, ($.get(account), $.untrack(() => $.get(account).name)));

								if (option_4_value !== (option_4_value = $0)) {
									option_4.value = (option_4.__value = $0) ?? '';
								}
							},
							[
								() => ($.get(account), $.untrack(() => String($.get(account).id)))
							]
						);

						$.append($$anchor, option_4);
					}
				),
				'each',
				Home,
				229,
				586
			);

			$.reset(select_1);
			$.reset(label_5);

			var label_6 = $.sibling(label_5);
			var input_4 = $.sibling($.child(label_6));

			$.remove_input_defaults(input_4);
			$.reset(label_6);

			var label_7 = $.sibling(label_6);
			var input_5 = $.sibling($.child(label_7));

			$.remove_input_defaults(input_5);
			$.reset(label_7);

			var label_8 = $.sibling(label_7);
			var input_6 = $.sibling($.child(label_8));

			$.remove_input_defaults(input_6);
			$.reset(label_8);

			var label_9 = $.sibling(label_8);
			var input_7 = $.sibling($.child(label_9));

			$.remove_input_defaults(input_7);
			$.reset(label_9);

			var node_82 = $.sibling(label_9);

			{
				var consequent_55 = ($$anchor) => {
					var p_27 = root_120();
					var text_107 = $.child(p_27, true);

					$.reset(p_27);
					$.template_effect(() => $.set_text(text_107, $.get(creditCardError)));
					$.append($$anchor, p_27);
				};

				$.add_svelte_meta(
					() => $.if(node_82, ($$render) => {
						if ($.get(creditCardError)) $$render(consequent_55);
					}),
					'if',
					Home,
					229,
					1161
				);
			}

			var div_77 = $.sibling(node_82);
			var button_55 = $.child(div_77);
			var button_56 = $.sibling(button_55);
			var text_108 = $.child(button_56, true);

			$.reset(button_56);
			$.reset(div_77);
			$.reset(section_21);
			$.reset(div_76);

			$.template_effect(() => {
				$.set_text(text_105, $.strict_equals($.get(creditCardEditingId), null) ? 'Add a credit card' : 'Edit credit card');
				button_56.disabled = $.get(creditCardSaving) || $.strict_equals($.get(optionsStatus), 'ready', false);

				$.set_text(text_108, $.get(creditCardSaving)
					? 'Saving…'
					: $.strict_equals($.get(creditCardEditingId), null) ? 'Add credit card' : 'Save changes');
			});

			$.event('click', button_54, () => $.set(showCreditCardForm, false));

			$.bind_select_value(
				select_1,
				function get() {
					return $.get(creditCardForm).accountReferenceId;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).accountReferenceId = $$value);
				}
			);

			$.bind_value(
				input_4,
				function get() {
					return $.get(creditCardForm).cardName;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).cardName = $$value);
				}
			);

			$.bind_value(
				input_5,
				function get() {
					return $.get(creditCardForm).issuerName;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).issuerName = $$value);
				}
			);

			$.bind_value(
				input_6,
				function get() {
					return $.get(creditCardForm).statementDay;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).statementDay = $$value);
				}
			);

			$.bind_value(
				input_7,
				function get() {
					return $.get(creditCardForm).dueDay;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).dueDay = $$value);
				}
			);

			$.event('click', button_55, () => $.set(showCreditCardForm, false));
			$.event('click', button_56, saveCreditCard);
			$.append($$anchor, div_76);
		};

		$.add_svelte_meta(
			() => $.if(node_80, ($$render) => {
				if ($.get(showCreditCardForm)) $$render(consequent_56);
			}),
			'if',
			Home,
			229,
			0
		);
	}

	var node_83 = $.sibling(node_80, 2);

	{
		var consequent_59 = ($$anchor) => {
			var div_78 = root_121();
			var section_22 = $.child(div_78);
			var button_57 = $.child(section_22);
			var div_79 = $.sibling(button_57, 4);

			$.add_svelte_meta(
				() => $.each(
					div_79,
					4,
					() => [
						'UNDER_25000',
						'FROM_25000_TO_50000',
						'FROM_50000_TO_100000',
						'FROM_100000_TO_200000',
						'OVER_200000'
					],
					$.index,
					($$anchor, range) => {
						var button_58 = root_122();
						let classes_20;
						var text_109 = $.child(button_58, true);

						$.reset(button_58);

						$.template_effect(
							($0) => {
								classes_20 = $.set_class(button_58, 1, '', null, classes_20, {
									active: $.strict_equals($.get(salaryForm).salaryRange, range) && $.strict_equals($.get(salaryForm).salaryVisibility, 'RANGE')
								});

								$.set_text(text_109, $0);
							},
							[() => (range, $.untrack(() => incomeRangeLabel(range)))]
						);

						$.event('click', button_58, () => {
							$.mutate(salaryForm, $.get(salaryForm).salaryVisibility = 'RANGE');
							$.mutate(salaryForm, $.get(salaryForm).salaryRange = range);
						});

						$.append($$anchor, button_58);
					}
				),
				'each',
				Home,
				230,
				451
			);

			$.reset(div_79);

			var button_59 = $.sibling(div_79);
			var text_110 = $.child(button_59, true);

			$.reset(button_59);

			var node_84 = $.sibling(button_59);

			{
				var consequent_57 = ($$anchor) => {
					var label_10 = root_123();
					var input_8 = $.sibling($.child(label_10));

					$.remove_input_defaults(input_8);
					$.reset(label_10);

					$.bind_value(
						input_8,
						function get() {
							return $.get(salaryForm).exactMonthlySalary;
						},
						function set($$value) {
							$.mutate(salaryForm, $.get(salaryForm).exactMonthlySalary = $$value);
						}
					);

					$.append($$anchor, label_10);
				};

				$.add_svelte_meta(
					() => $.if(node_84, ($$render) => {
						if ((
							$.get(salaryForm),
							$.untrack(() => $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT'))
						)) $$render(consequent_57);
					}),
					'if',
					Home,
					230,
					1045
				);
			}

			var label_11 = $.sibling(node_84);
			var select_2 = $.sibling($.child(label_11));

			$.template_effect(() => {
				$.get(salaryForm);
				$.invalidate_inner_signals(() => {});
			});

			$.add_svelte_meta(
				() => $.each(select_2, 4, () => ['MONTHLY', 'TWICE_MONTHLY', 'WEEKLY', 'IRREGULAR'], $.index, ($$anchor, frequency) => {
					var option_5 = root_124();
					var text_111 = $.child(option_5, true);

					$.reset(option_5);

					var option_5_value = {};

					$.template_effect(
						($0) => {
							$.set_text(text_111, $0);

							if (option_5_value !== (option_5_value = frequency)) {
								option_5.value = (option_5.__value = frequency) ?? '';
							}
						},
						[
							() => (
								frequency,
								$.untrack(() => frequency.replaceAll('_', ' ').toLowerCase())
							)
						]
					);

					$.append($$anchor, option_5);
				}),
				'each',
				Home,
				230,
				1341
			);

			$.reset(select_2);
			$.reset(label_11);

			var node_85 = $.sibling(label_11);

			{
				var consequent_58 = ($$anchor) => {
					var p_28 = root_125();
					var text_112 = $.child(p_28, true);

					$.reset(p_28);
					$.template_effect(() => $.set_text(text_112, $.get(incomeError)));
					$.append($$anchor, p_28);
				};

				$.add_svelte_meta(
					() => $.if(node_85, ($$render) => {
						if ($.get(incomeError)) $$render(consequent_58);
					}),
					'if',
					Home,
					230,
					1514
				);
			}

			var div_80 = $.sibling(node_85);
			var button_60 = $.child(div_80);
			var button_61 = $.sibling(button_60);
			var text_113 = $.child(button_61, true);

			$.reset(button_61);
			$.reset(div_80);
			$.reset(section_22);
			$.reset(div_78);

			$.template_effect(() => {
				$.set_text(text_110, (
					$.get(salaryForm),

					$.untrack(() => $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT')
						? 'Use a range instead'
						: 'I’m comfortable sharing the exact amount')
				));

				button_60.disabled = $.get(incomeSaving);
				button_61.disabled = $.get(incomeSaving);
				$.set_text(text_113, $.get(incomeSaving) ? 'Saving…' : 'Save salary outlook');
			});

			$.event('click', button_57, () => $.set(showIncomeFlow, false));
			$.event('click', button_59, () => $.mutate(salaryForm, $.get(salaryForm).salaryVisibility = $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT') ? 'RANGE' : 'EXACT'));

			$.bind_select_value(
				select_2,
				function get() {
					return $.get(salaryForm).salaryFrequency;
				},
				function set($$value) {
					$.mutate(salaryForm, $.get(salaryForm).salaryFrequency = $$value);
				}
			);

			$.event('click', button_60, () => {
				$.mutate(salaryForm, $.get(salaryForm).salaryVisibility = 'SKIPPED');
				saveSalary();
			});

			$.event('click', button_61, saveSalary);
			$.append($$anchor, div_78);
		};

		$.add_svelte_meta(
			() => $.if(node_83, ($$render) => {
				if ($.get(showIncomeFlow)) $$render(consequent_59);
			}),
			'if',
			Home,
			230,
			0
		);
	}

	var node_86 = $.sibling(node_83, 2);

	{
		var consequent_61 = ($$anchor) => {
			var div_81 = root_126();
			var section_23 = $.child(div_81);
			var button_62 = $.child(section_23);
			var h2_6 = $.sibling(button_62, 2);
			var text_114 = $.child(h2_6, true);

			$.reset(h2_6);

			var label_12 = $.sibling(h2_6, 2);
			var input_9 = $.sibling($.child(label_12));

			$.remove_input_defaults(input_9);
			$.reset(label_12);

			var label_13 = $.sibling(label_12);
			var select_3 = $.sibling($.child(label_13));

			$.template_effect(() => {
				$.get(loanForm);
				$.invalidate_inner_signals(() => {});
			});

			$.add_svelte_meta(
				() => $.each(
					select_3,
					4,
					() => [
						'HOME',
						'VEHICLE',
						'PERSONAL',
						'EDUCATION',
						'CREDIT_CARD_EMI',
						'OTHER'
					],
					$.index,
					($$anchor, type) => {
						var option_6 = root_127();
						var text_115 = $.child(option_6, true);

						$.reset(option_6);

						var option_6_value = {};

						$.template_effect(
							($0) => {
								$.set_text(text_115, $0);

								if (option_6_value !== (option_6_value = type)) {
									option_6.value = (option_6.__value = type) ?? '';
								}
							},
							[() => (type, $.untrack(() => type.replaceAll('_', ' ')))]
						);

						$.append($$anchor, option_6);
					}
				),
				'each',
				Home,
				232,
				568
			);

			$.reset(select_3);
			$.reset(label_13);

			var label_14 = $.sibling(label_13);
			var input_10 = $.sibling($.child(label_14));

			$.remove_input_defaults(input_10);
			$.reset(label_14);

			var label_15 = $.sibling(label_14);
			var input_11 = $.sibling($.child(label_15));

			$.remove_input_defaults(input_11);
			$.reset(label_15);

			var label_16 = $.sibling(label_15);
			var input_12 = $.sibling($.child(label_16));

			$.remove_input_defaults(input_12);
			$.reset(label_16);

			var label_17 = $.sibling(label_16);
			var input_13 = $.sibling($.child(label_17));

			$.remove_input_defaults(input_13);
			$.reset(label_17);

			var label_18 = $.sibling(label_17);
			var input_14 = $.sibling($.child(label_18));

			$.remove_input_defaults(input_14);
			$.reset(label_18);

			var label_19 = $.sibling(label_18);
			var input_15 = $.sibling($.child(label_19), 2);

			$.remove_input_defaults(input_15);
			$.reset(label_19);

			var node_87 = $.sibling(label_19);

			{
				var consequent_60 = ($$anchor) => {
					var p_29 = root_128();
					var text_116 = $.child(p_29, true);

					$.reset(p_29);
					$.template_effect(() => $.set_text(text_116, $.get(loanError)));
					$.append($$anchor, p_29);
				};

				$.add_svelte_meta(
					() => $.if(node_87, ($$render) => {
						if ($.get(loanError)) $$render(consequent_60);
					}),
					'if',
					Home,
					232,
					1526
				);
			}

			var div_82 = $.sibling(node_87);
			var button_63 = $.child(div_82);
			var button_64 = $.sibling(button_63);
			var text_117 = $.child(button_64, true);

			$.reset(button_64);
			$.reset(div_82);
			$.reset(section_23);
			$.reset(div_81);

			$.template_effect(() => {
				$.set_text(text_114, $.equals($.get(loanEditingId), null) ? 'Add a loan' : 'Edit loan');
				button_64.disabled = $.get(loanSaving);

				$.set_text(text_117, $.get(loanSaving)
					? 'Saving…'
					: $.equals($.get(loanEditingId), null) ? 'Add loan' : 'Save changes');
			});

			$.event('click', button_62, () => $.set(showLoanForm, false));

			$.bind_value(
				input_9,
				function get() {
					return $.get(loanForm).loanName;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).loanName = $$value);
				}
			);

			$.bind_select_value(
				select_3,
				function get() {
					return $.get(loanForm).loanType;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).loanType = $$value);
				}
			);

			$.bind_value(
				input_10,
				function get() {
					return $.get(loanForm).originalPrincipal;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).originalPrincipal = $$value);
				}
			);

			$.bind_value(
				input_11,
				function get() {
					return $.get(loanForm).monthlyEmiAmount;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).monthlyEmiAmount = $$value);
				}
			);

			$.bind_value(
				input_12,
				function get() {
					return $.get(loanForm).totalTenureMonths;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).totalTenureMonths = $$value);
				}
			);

			$.bind_value(
				input_13,
				function get() {
					return $.get(loanForm).firstEmiDueDate;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).firstEmiDueDate = $$value);
				}
			);

			$.bind_value(
				input_14,
				function get() {
					return $.get(loanForm).lenderName;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).lenderName = $$value);
				}
			);

			$.bind_value(
				input_15,
				function get() {
					return $.get(loanForm).notes;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).notes = $$value);
				}
			);

			$.event('click', button_63, () => $.set(showLoanForm, false));
			$.event('click', button_64, saveLoan);
			$.append($$anchor, div_81);
		};

		$.add_svelte_meta(
			() => $.if(node_86, ($$render) => {
				if ($.get(showLoanForm)) $$render(consequent_61);
			}),
			'if',
			Home,
			231,
			0
		);
	}

	var node_88 = $.sibling(node_86, 2);

	{
		var consequent_70 = ($$anchor) => {
			var div_83 = root_129();
			var section_24 = $.child(div_83);
			var button_65 = $.child(section_24);
			var node_89 = $.sibling(button_65, 2);

			{
				var consequent_62 = ($$anchor) => {
					var div_84 = root_130();
					var p_30 = $.sibling($.child(div_84));
					var text_118 = $.child(p_30, true);

					$.reset(p_30);

					var h2_7 = $.sibling(p_30);
					var text_119 = $.child(h2_7, true);

					$.reset(h2_7);

					var p_31 = $.sibling(h2_7);
					var text_120 = $.child(p_31, true);

					$.reset(p_31);

					var button_66 = $.sibling(p_31);

					$.reset(div_84);

					$.template_effect(
						($0) => {
							$.set_text(text_118, (
								$.get(fundForm),
								$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES') ? 'SIP READY' : 'FUND ADDED')
							));

							$.set_text(text_119, (
								$.get(fundForm),
								$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES') ? 'Your SIP is set up' : 'Your fund is ready')
							));

							$.set_text(text_120, $0);
						},
						[
							() => (
								$.get(fundForm),
								$.get(selectedScheme),

								$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES')
									? `${money($.get(fundForm).sipAmount)} will be tracked monthly for ${$.get(selectedScheme).schemeName}. The first occurrence will be due in ${monthLabel($.get(fundForm).startMonth)}.`
									: `${$.get(selectedScheme).schemeName} is ready for occasional lump sums. You can set up a SIP later from its bell button.`)
							)
						]
					);

					$.event('click', button_66, () => $.set(showMutualFundForm, false));
					$.append($$anchor, div_84);
				};

				var alternate_38 = ($$anchor) => {
					var fragment_44 = root_131();
					var div_85 = $.sibling($.first_child(fragment_44), 4);
					var label_20 = $.sibling($.child(div_85));
					var input_16 = $.sibling($.child(label_20));

					$.remove_input_defaults(input_16);

					var node_90 = $.sibling(input_16);

					{
						var consequent_65 = ($$anchor) => {
							var div_86 = root_132();
							var node_91 = $.child(div_86);

							{
								var consequent_63 = ($$anchor) => {
									var p_32 = root_133();

									$.append($$anchor, p_32);
								};

								var alternate_37 = ($$anchor) => {
									var fragment_45 = $.comment();
									var node_92 = $.first_child(fragment_45);

									{
										var consequent_64 = ($$anchor) => {
											var p_33 = root_135();

											$.append($$anchor, p_33);
										};

										var alternate_36 = ($$anchor) => {
											var fragment_46 = $.comment();
											var node_93 = $.first_child(fragment_46);

											$.add_svelte_meta(
												() => $.each(
													node_93,
													1,
													() => $.get(schemeResults),
													$.index,
													($$anchor, scheme) => {
														var button_67 = root_137();
														var strong_22 = $.child(button_67);
														var text_121 = $.child(strong_22, true);

														$.reset(strong_22);

														var small_16 = $.sibling(strong_22);
														var text_122 = $.child(small_16);

														$.reset(small_16);
														$.reset(button_67);

														$.template_effect(
															($0) => {
																$.set_text(text_121, ($.get(scheme), $.untrack(() => $.get(scheme).schemeName)));
																$.set_text(text_122, `Scheme code ${($.get(scheme), $.untrack(() => $.get(scheme).schemeCode)) ?? ''} · ${$0 ?? ''}`);
															},
															[
																() => (
																	$.get(scheme),

																	$.untrack(() => $.equals($.get(scheme).latestNav, null)
																		? 'Latest NAV unavailable'
																		: `Latest NAV ${moneyDecimal($.get(scheme).latestNav)}`)
																)
															]
														);

														$.event('mousedown', button_67, $.preventDefault(() => selectScheme($.get(scheme))));
														$.append($$anchor, button_67);
													},
													($$anchor) => {
														var p_34 = root_138();

														$.append($$anchor, p_34);
													}
												),
												'each',
												Home,
												238,
												503
											);

											$.append($$anchor, fragment_46);
										};

										$.add_svelte_meta(
											() => $.if(
												node_92,
												($$render) => {
													if ((
														$.get(schemeQuery),
														$.untrack(() => $.get(schemeQuery).trim().length < 2)
													)) $$render(consequent_64); else $$render(alternate_36, false);
												},
												true
											),
											'if',
											Home,
											238,
											414
										);
									}

									$.append($$anchor, fragment_45);
								};

								$.add_svelte_meta(
									() => $.if(node_91, ($$render) => {
										if ($.strict_equals($.get(schemeSearchStatus), 'loading')) $$render(consequent_63); else $$render(alternate_37, false);
									}),
									'if',
									Home,
									238,
									353
								);
							}

							$.reset(div_86);
							$.append($$anchor, div_86);
						};

						$.add_svelte_meta(
							() => $.if(node_90, ($$render) => {
								if ($.get(showSchemeMenu)) $$render(consequent_65);
							}),
							'if',
							Home,
							238,
							308
						);
					}

					$.reset(label_20);

					var node_94 = $.sibling(label_20);

					{
						var consequent_66 = ($$anchor) => {
							var div_87 = root_139();
							var div_88 = $.sibling($.child(div_87));
							var small_17 = $.sibling($.child(div_88));
							var text_123 = $.child(small_17);

							$.reset(small_17);
							$.reset(div_88);
							$.reset(div_87);

							$.template_effect(
								($0) => $.set_text(text_123, `Code ${(
									$.get(selectedScheme),
									$.untrack(() => $.get(selectedScheme).schemeCode)
								) ?? ''} · ${$0 ?? ''}`),
								[
									() => (
										$.get(selectedScheme),

										$.untrack(() => $.equals($.get(selectedScheme).latestNav, null)
											? 'Latest NAV unavailable'
											: `Latest NAV ${moneyDecimal($.get(selectedScheme).latestNav)}`)
									)
								]
							);

							$.append($$anchor, div_87);
						};

						$.add_svelte_meta(
							() => $.if(node_94, ($$render) => {
								if ($.get(selectedScheme)) $$render(consequent_66);
							}),
							'if',
							Home,
							238,
							871
						);
					}

					$.reset(div_85);

					var div_89 = $.sibling(div_85, 2);
					var fieldset = $.sibling($.child(div_89));
					var label_21 = $.sibling($.child(fieldset));
					var input_17 = $.child(label_21);

					$.remove_input_defaults(input_17);
					input_17.value = input_17.__value = 'YES';
					$.next();
					$.reset(label_21);

					var label_22 = $.sibling(label_21);
					var input_18 = $.child(label_22);

					$.remove_input_defaults(input_18);
					input_18.value = input_18.__value = 'NO';
					$.next();
					$.reset(label_22);
					$.reset(fieldset);

					var node_95 = $.sibling(fieldset);

					{
						var consequent_67 = ($$anchor) => {
							var fragment_47 = root_140();
							var label_23 = $.first_child(fragment_47);
							var input_19 = $.sibling($.child(label_23));

							$.remove_input_defaults(input_19);
							$.reset(label_23);

							var div_90 = $.sibling(label_23);
							var label_24 = $.child(div_90);
							var select_4 = $.sibling($.child(label_24));

							$.template_effect(() => {
								$.get(fundForm);

								$.invalidate_inner_signals(() => {
									Array;
								});
							});

							$.add_svelte_meta(
								() => $.each(select_4, 4, () => Array(28), $.index, ($$anchor, _, index) => {
									var option_7 = root_141();

									option_7.textContent = `${index + 1}${$.strict_equals(index, 0)
										? 'st'
										: $.strict_equals(index, 1) ? 'nd' : $.strict_equals(index, 2) ? 'rd' : 'th'} of every month`;

									option_7.value = option_7.__value = index + 1;
									$.append($$anchor, option_7);
								}),
								'each',
								Home,
								239,
								594
							);

							$.reset(select_4);
							$.reset(label_24);

							var label_25 = $.sibling(label_24);
							var input_20 = $.sibling($.child(label_25));

							$.remove_input_defaults(input_20);
							$.reset(label_25);
							$.reset(div_90);

							$.bind_value(
								input_19,
								function get() {
									return $.get(fundForm).sipAmount;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).sipAmount = $$value);
								}
							);

							$.bind_select_value(
								select_4,
								function get() {
									return $.get(fundForm).sipDate;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).sipDate = $$value);
								}
							);

							$.bind_value(
								input_20,
								function get() {
									return $.get(fundForm).startMonth;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).startMonth = $$value);
								}
							);

							$.append($$anchor, fragment_47);
						};

						$.add_svelte_meta(
							() => $.if(node_95, ($$render) => {
								if ((
									$.get(fundForm),
									$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES'))
								)) $$render(consequent_67);
							}),
							'if',
							Home,
							239,
							367
						);
					}

					$.reset(div_89);

					var div_91 = $.sibling(div_89, 2);
					var fieldset_1 = $.sibling($.child(div_91));
					var label_26 = $.sibling($.child(fieldset_1));
					var input_21 = $.child(label_26);

					$.remove_input_defaults(input_21);
					input_21.value = input_21.__value = 'NO';
					$.next();
					$.reset(label_26);

					var label_27 = $.sibling(label_26);
					var input_22 = $.child(label_27);

					$.remove_input_defaults(input_22);
					input_22.value = input_22.__value = 'YES';
					$.next();
					$.reset(label_27);
					$.reset(fieldset_1);

					var node_96 = $.sibling(fieldset_1);

					{
						var consequent_68 = ($$anchor) => {
							var fragment_48 = root_142();
							var div_92 = $.first_child(fragment_48);
							var label_28 = $.child(div_92);
							var input_23 = $.sibling($.child(label_28));

							$.remove_input_defaults(input_23);
							$.reset(label_28);

							var label_29 = $.sibling(label_28);
							var input_24 = $.sibling($.child(label_29));

							$.remove_input_defaults(input_24);
							$.reset(label_29);
							$.reset(div_92);
							$.next();

							$.bind_value(
								input_23,
								function get() {
									return $.get(fundForm).currentUnits;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).currentUnits = $$value);
								}
							);

							$.bind_value(
								input_24,
								function get() {
									return $.get(fundForm).totalInvested;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).totalInvested = $$value);
								}
							);

							$.append($$anchor, fragment_48);
						};

						$.add_svelte_meta(
							() => $.if(node_96, ($$render) => {
								if ((
									$.get(fundForm),
									$.untrack(() => $.strict_equals($.get(fundForm).hasHolding, 'YES'))
								)) $$render(consequent_68);
							}),
							'if',
							Home,
							240,
							378
						);
					}

					$.reset(div_91);

					var node_97 = $.sibling(div_91, 2);

					{
						var consequent_69 = ($$anchor) => {
							var p_35 = root_143();
							var text_124 = $.child(p_35, true);

							$.reset(p_35);
							$.template_effect(() => $.set_text(text_124, $.get(fundError)));
							$.append($$anchor, p_35);
						};

						$.add_svelte_meta(
							() => $.if(node_97, ($$render) => {
								if ($.get(fundError)) $$render(consequent_69);
							}),
							'if',
							Home,
							241,
							6
						);
					}

					var div_93 = $.sibling(node_97);
					var button_68 = $.child(div_93);
					var button_69 = $.sibling(button_68);
					var text_125 = $.child(button_69, true);

					$.reset(button_69);
					$.reset(div_93);

					$.template_effect(() => {
						$.set_value(input_16, $.get(schemeQuery));
						button_69.disabled = $.get(fundSaving);
						$.set_text(text_125, $.get(fundSaving) ? 'Creating…' : 'Add mutual fund');
					});

					$.event('focus', input_16, () => $.set(showSchemeMenu, true));
					$.event('input', input_16, (e) => searchSchemes(e.currentTarget.value));

					$.bind_group(
						binding_group,
						[],
						input_17,
						function get() {
							return $.get(fundForm).hasSip;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasSip = $$value);
						}
					);

					$.bind_group(
						binding_group,
						[],
						input_18,
						function get() {
							return $.get(fundForm).hasSip;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasSip = $$value);
						}
					);

					$.bind_group(
						binding_group_1,
						[],
						input_21,
						function get() {
							return $.get(fundForm).hasHolding;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasHolding = $$value);
						}
					);

					$.bind_group(
						binding_group_1,
						[],
						input_22,
						function get() {
							return $.get(fundForm).hasHolding;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasHolding = $$value);
						}
					);

					$.event('click', button_68, () => $.set(showMutualFundForm, false));
					$.event('click', button_69, saveMutualFund);
					$.append($$anchor, fragment_44);
				};

				$.add_svelte_meta(
					() => $.if(node_89, ($$render) => {
						if ($.get(fundSaved)) $$render(consequent_62); else $$render(alternate_38, false);
					}),
					'if',
					Home,
					236,
					4
				);
			}

			$.reset(section_24);
			$.reset(div_83);
			$.event('click', button_65, () => $.set(showMutualFundForm, false));
			$.append($$anchor, div_83);
		};

		$.add_svelte_meta(
			() => $.if(node_88, ($$render) => {
				if ($.get(showMutualFundForm)) $$render(consequent_70);
			}),
			'if',
			Home,
			234,
			0
		);
	}

	var node_98 = $.sibling(node_88, 2);

	{
		var consequent_76 = ($$anchor) => {
			var div_94 = root_144();
			var section_25 = $.child(div_94);
			var button_70 = $.child(section_25);
			var div_95 = $.sibling(button_70, 4);
			var label_30 = $.sibling($.child(div_95));
			var input_25 = $.sibling($.child(label_30));

			$.remove_input_defaults(input_25);

			var node_99 = $.sibling(input_25);

			{
				var consequent_73 = ($$anchor) => {
					var div_96 = root_145();
					var node_100 = $.child(div_96);

					{
						var consequent_71 = ($$anchor) => {
							var p_36 = root_146();

							$.append($$anchor, p_36);
						};

						var alternate_40 = ($$anchor) => {
							var fragment_49 = $.comment();
							var node_101 = $.first_child(fragment_49);

							{
								var consequent_72 = ($$anchor) => {
									var p_37 = root_148();

									$.append($$anchor, p_37);
								};

								var alternate_39 = ($$anchor) => {
									var fragment_50 = $.comment();
									var node_102 = $.first_child(fragment_50);

									$.add_svelte_meta(
										() => $.each(
											node_102,
											1,
											() => $.get(stockResults),
											$.index,
											($$anchor, stock) => {
												var button_71 = root_150();
												var strong_23 = $.child(button_71);
												var text_126 = $.child(strong_23, true);

												$.reset(strong_23);

												var small_18 = $.sibling(strong_23);
												var text_127 = $.child(small_18);

												$.reset(small_18);
												$.reset(button_71);

												$.template_effect(
													($0) => {
														$.set_text(text_126, (
															$.get(stock),
															$.untrack(() => $.get(stock).name || $.get(stock).symbol)
														));

														$.set_text(text_127, `${($.get(stock), $.untrack(() => $.get(stock).symbol)) ?? ''}${(
															$.get(stock),
															$.untrack(() => $.get(stock).exchange ? ` · ${$.get(stock).exchange}` : '')
														) ?? ''} · ${$0 ?? ''}`);
													},
													[
														() => (
															$.get(stock),

															$.untrack(() => $.equals($.get(stock).latestPrice, null)
																? 'Latest price unavailable'
																: `Latest price ${moneyDecimal($.get(stock).latestPrice)}`)
														)
													]
												);

												$.event('mousedown', button_71, $.preventDefault(() => selectStock($.get(stock))));
												$.append($$anchor, button_71);
											},
											($$anchor) => {
												var p_38 = root_151();

												$.append($$anchor, p_38);
											}
										),
										'each',
										Home,
										245,
										923
									);

									$.append($$anchor, fragment_50);
								};

								$.add_svelte_meta(
									() => $.if(
										node_101,
										($$render) => {
											if ($.strict_equals($.get(stockSearchStatus), 'error')) $$render(consequent_72); else $$render(alternate_39, false);
										},
										true
									),
									'if',
									Home,
									245,
									847
								);
							}

							$.append($$anchor, fragment_49);
						};

						$.add_svelte_meta(
							() => $.if(node_100, ($$render) => {
								if ($.strict_equals($.get(stockSearchStatus), 'loading')) $$render(consequent_71); else $$render(alternate_40, false);
							}),
							'if',
							Home,
							245,
							781
						);
					}

					$.reset(div_96);
					$.append($$anchor, div_96);
				};

				$.add_svelte_meta(
					() => $.if(node_99, ($$render) => {
						if ((
							$.get(stockQuery),
							$.get(selectedStock),
							$.untrack(() => $.get(stockQuery).trim().length >= 2 && !$.get(selectedStock))
						)) $$render(consequent_73);
					}),
					'if',
					Home,
					245,
					707
				);
			}

			$.reset(label_30);

			var node_103 = $.sibling(label_30);

			{
				var consequent_74 = ($$anchor) => {
					var div_97 = root_152();
					var div_98 = $.sibling($.child(div_97));
					var small_19 = $.sibling($.child(div_98));
					var text_128 = $.child(small_19);

					$.reset(small_19);
					$.reset(div_98);
					$.reset(div_97);

					$.template_effect(
						($0) => $.set_text(text_128, `${(
							$.get(selectedStock),
							$.untrack(() => $.get(selectedStock).symbol)
						) ?? ''}${(
							$.get(selectedStock),
							$.untrack(() => $.get(selectedStock).exchange ? ` · ${$.get(selectedStock).exchange}` : '')
						) ?? ''} · ${$0 ?? ''}`),
						[
							() => (
								$.get(selectedStock),

								$.untrack(() => $.equals($.get(selectedStock).latestPrice, null)
									? 'Latest price unavailable'
									: `Latest price ${moneyDecimal($.get(selectedStock).latestPrice)}`)
							)
						]
					);

					$.append($$anchor, div_97);
				};

				$.add_svelte_meta(
					() => $.if(node_103, ($$render) => {
						if ($.get(selectedStock)) $$render(consequent_74);
					}),
					'if',
					Home,
					245,
					1331
				);
			}

			$.reset(div_95);

			var div_99 = $.sibling(div_95);
			var div_100 = $.sibling($.child(div_99));
			var label_31 = $.child(div_100);
			var input_26 = $.sibling($.child(label_31));

			$.remove_input_defaults(input_26);
			$.reset(label_31);

			var label_32 = $.sibling(label_31);
			var input_27 = $.sibling($.child(label_32));

			$.remove_input_defaults(input_27);
			$.reset(label_32);
			$.reset(div_100);
			$.reset(div_99);

			var node_104 = $.sibling(div_99);

			{
				var consequent_75 = ($$anchor) => {
					var p_39 = root_153();
					var text_129 = $.child(p_39, true);

					$.reset(p_39);
					$.template_effect(() => $.set_text(text_129, $.get(stockError)));
					$.append($$anchor, p_39);
				};

				$.add_svelte_meta(
					() => $.if(node_104, ($$render) => {
						if ($.get(stockError)) $$render(consequent_75);
					}),
					'if',
					Home,
					245,
					2048
				);
			}

			var div_101 = $.sibling(node_104);
			var button_72 = $.child(div_101);
			var button_73 = $.sibling(button_72);
			var text_130 = $.child(button_73, true);

			$.reset(button_73);
			$.reset(div_101);
			$.reset(section_25);
			$.reset(div_94);

			$.template_effect(() => {
				$.set_value(input_25, $.get(stockQuery));
				button_73.disabled = $.get(stockSaving);
				$.set_text(text_130, $.get(stockSaving) ? 'Adding…' : 'Add stock');
			});

			$.event('click', button_70, () => $.set(showStockForm, false));
			$.event('input', input_25, (e) => findStocks(e.currentTarget.value));

			$.bind_value(
				input_26,
				function get() {
					return $.get(stockForm).quantity;
				},
				function set($$value) {
					$.mutate(stockForm, $.get(stockForm).quantity = $$value);
				}
			);

			$.bind_value(
				input_27,
				function get() {
					return $.get(stockForm).totalInvested;
				},
				function set($$value) {
					$.mutate(stockForm, $.get(stockForm).totalInvested = $$value);
				}
			);

			$.event('click', button_72, () => $.set(showStockForm, false));
			$.event('click', button_73, saveStock);
			$.append($$anchor, div_94);
		};

		$.add_svelte_meta(
			() => $.if(node_98, ($$render) => {
				if ($.get(showStockForm)) $$render(consequent_76);
			}),
			'if',
			Home,
			244,
			0
		);
	}

	var node_105 = $.sibling(node_98, 2);

	{
		var consequent_78 = ($$anchor) => {
			var div_102 = root_154();
			var section_26 = $.child(div_102);
			var button_74 = $.child(section_26);
			var h2_8 = $.sibling(button_74, 2);
			var text_131 = $.child(h2_8);

			$.reset(h2_8);

			var label_33 = $.sibling(h2_8, 2);
			var input_28 = $.sibling($.child(label_33));

			$.remove_input_defaults(input_28);
			$.reset(label_33);

			var label_34 = $.sibling(label_33);
			var input_29 = $.sibling($.child(label_34));

			$.remove_input_defaults(input_29);
			$.reset(label_34);

			var label_35 = $.sibling(label_34);
			var input_30 = $.sibling($.child(label_35));

			$.remove_input_defaults(input_30);
			$.reset(label_35);

			var node_106 = $.sibling(label_35);

			{
				var consequent_77 = ($$anchor) => {
					var p_40 = root_155();
					var text_132 = $.child(p_40, true);

					$.reset(p_40);
					$.template_effect(() => $.set_text(text_132, $.get(fundError)));
					$.append($$anchor, p_40);
				};

				$.add_svelte_meta(
					() => $.if(node_106, ($$render) => {
						if ($.get(fundError)) $$render(consequent_77);
					}),
					'if',
					Home,
					247,
					653
				);
			}

			var div_103 = $.sibling(node_106);
			var button_75 = $.child(div_103);
			var button_76 = $.sibling(button_75);
			var text_133 = $.child(button_76, true);

			$.reset(button_76);
			$.reset(div_103);
			$.reset(section_26);
			$.reset(div_102);

			$.template_effect(() => {
				$.set_text(text_131, `Set up SIP for ${(
					$.get(fundSipTarget),
					$.untrack(() => $.get(fundSipTarget).schemeName)
				) ?? ''}`);

				button_76.disabled = $.get(fundSipSaving);
				$.set_text(text_133, $.get(fundSipSaving) ? 'Saving…' : 'Save SIP');
			});

			$.event('click', button_74, () => $.set(fundSipTarget, null));

			$.bind_value(
				input_28,
				function get() {
					return $.get(fundSipForm).amount;
				},
				function set($$value) {
					$.mutate(fundSipForm, $.get(fundSipForm).amount = $$value);
				}
			);

			$.bind_value(
				input_29,
				function get() {
					return $.get(fundSipForm).day;
				},
				function set($$value) {
					$.mutate(fundSipForm, $.get(fundSipForm).day = $$value);
				}
			);

			$.bind_value(
				input_30,
				function get() {
					return $.get(fundSipForm).startMonth;
				},
				function set($$value) {
					$.mutate(fundSipForm, $.get(fundSipForm).startMonth = $$value);
				}
			);

			$.event('click', button_75, () => $.set(fundSipTarget, null));
			$.event('click', button_76, saveFundSipPlan);
			$.append($$anchor, div_102);
		};

		$.add_svelte_meta(
			() => $.if(node_105, ($$render) => {
				if ($.get(fundSipTarget)) $$render(consequent_78);
			}),
			'if',
			Home,
			247,
			0
		);
	}

	var node_107 = $.sibling(node_105, 2);

	{
		var consequent_79 = ($$anchor) => {
			var div_104 = root_156();
			var section_27 = $.child(div_104);
			var button_77 = $.child(section_27);
			var h2_9 = $.sibling(button_77, 2);
			var text_134 = $.child(h2_9);

			$.reset(h2_9);

			var label_36 = $.sibling(h2_9);
			var input_31 = $.sibling($.child(label_36));

			$.remove_input_defaults(input_31);
			$.reset(label_36);

			var label_37 = $.sibling(label_36);
			var input_32 = $.sibling($.child(label_37));

			$.remove_input_defaults(input_32);
			$.reset(label_37);

			var label_38 = $.sibling(label_37);
			var input_33 = $.sibling($.child(label_38));

			$.remove_input_defaults(input_33);
			$.reset(label_38);

			var div_105 = $.sibling(label_38);
			var button_78 = $.child(div_105);
			var button_79 = $.sibling(button_78);
			var text_135 = $.child(button_79, true);

			$.reset(button_79);
			$.reset(div_105);
			$.reset(section_27);
			$.reset(div_104);

			$.template_effect(() => {
				$.set_text(text_134, `Plan ${(
					$.get(stockPlanTarget),
					$.untrack(() => $.get(stockPlanTarget).name)
				) ?? ''}`);

				button_79.disabled = $.get(stockPlanSaving);
				$.set_text(text_135, $.get(stockPlanSaving) ? 'Saving…' : 'Save monthly plan');
			});

			$.event('click', button_77, () => $.set(stockPlanTarget, null));

			$.bind_value(
				input_31,
				function get() {
					return $.get(stockPlanForm).amount;
				},
				function set($$value) {
					$.mutate(stockPlanForm, $.get(stockPlanForm).amount = $$value);
				}
			);

			$.bind_value(
				input_32,
				function get() {
					return $.get(stockPlanForm).day;
				},
				function set($$value) {
					$.mutate(stockPlanForm, $.get(stockPlanForm).day = $$value);
				}
			);

			$.bind_value(
				input_33,
				function get() {
					return $.get(stockPlanForm).startMonth;
				},
				function set($$value) {
					$.mutate(stockPlanForm, $.get(stockPlanForm).startMonth = $$value);
				}
			);

			$.event('click', button_78, () => $.set(stockPlanTarget, null));
			$.event('click', button_79, saveStockPlan);
			$.append($$anchor, div_104);
		};

		$.add_svelte_meta(
			() => $.if(node_107, ($$render) => {
				if ($.get(stockPlanTarget)) $$render(consequent_79);
			}),
			'if',
			Home,
			248,
			0
		);
	}

	var node_108 = $.sibling(node_107, 2);

	{
		var consequent_80 = ($$anchor) => {
			var div_106 = root_157();
			var section_28 = $.child(div_106);
			var button_80 = $.child(section_28);
			var label_39 = $.sibling(button_80, 3);
			var input_34 = $.sibling($.child(label_39));

			$.remove_input_defaults(input_34);
			$.reset(label_39);

			var label_40 = $.sibling(label_39);
			var input_35 = $.sibling($.child(label_40));

			$.remove_input_defaults(input_35);
			$.reset(label_40);

			var div_107 = $.sibling(label_40);
			var button_81 = $.child(div_107);
			var button_82 = $.sibling(button_81);

			$.reset(div_107);
			$.reset(section_28);
			$.reset(div_106);
			$.event('click', button_80, () => $.set(stockPlanConfirmationTarget, null));

			$.bind_value(
				input_34,
				function get() {
					return $.get(stockPlanConfirmation).amount;
				},
				function set($$value) {
					$.mutate(stockPlanConfirmation, $.get(stockPlanConfirmation).amount = $$value);
				}
			);

			$.bind_value(
				input_35,
				function get() {
					return $.get(stockPlanConfirmation).price;
				},
				function set($$value) {
					$.mutate(stockPlanConfirmation, $.get(stockPlanConfirmation).price = $$value);
				}
			);

			$.event('click', button_81, () => $.set(stockPlanConfirmationTarget, null));
			$.event('click', button_82, confirmStockPlan);
			$.append($$anchor, div_106);
		};

		$.add_svelte_meta(
			() => $.if(node_108, ($$render) => {
				if ($.get(stockPlanConfirmationTarget)) $$render(consequent_80);
			}),
			'if',
			Home,
			249,
			0
		);
	}

	var node_109 = $.sibling(node_108, 2);

	{
		var consequent_83 = ($$anchor) => {
			var div_108 = root_158();
			var section_29 = $.child(div_108);
			var button_83 = $.child(section_29);
			var node_110 = $.sibling(button_83);

			{
				var consequent_81 = ($$anchor) => {
					var h2_10 = root_159();

					$.append($$anchor, h2_10);
				};

				var alternate_42 = ($$anchor) => {
					var fragment_51 = $.comment();
					var node_111 = $.first_child(fragment_51);

					{
						var consequent_82 = ($$anchor) => {
							var h2_11 = root_161();

							$.append($$anchor, h2_11);
						};

						var alternate_41 = ($$anchor) => {
							var fragment_52 = root_162();
							var h2_12 = $.sibling($.first_child(fragment_52));
							var text_136 = $.child(h2_12, true);

							$.reset(h2_12);

							var div_109 = $.sibling(h2_12);
							var div_110 = $.child(div_109);
							var b_18 = $.sibling($.child(div_110));
							var text_137 = $.child(b_18, true);

							$.reset(b_18);
							$.reset(div_110);

							var div_111 = $.sibling(div_110);
							var b_19 = $.sibling($.child(div_111));
							var text_138 = $.child(b_19, true);

							$.reset(b_19);
							$.reset(div_111);
							$.reset(div_109);

							var section_30 = $.sibling(div_109);
							var node_112 = $.sibling($.child(section_30));

							$.add_svelte_meta(
								() => $.each(
									node_112,
									1,
									() => (
										$.get(stockDetail),
										$.untrack(() => $.get(stockDetail).history)
									),
									$.index,
									($$anchor, entry) => {
										var div_112 = root_163();
										var span_30 = $.child(div_112);
										var text_139 = $.child(span_30, true);

										$.reset(span_30);

										var strong_24 = $.sibling(span_30);
										var text_140 = $.child(strong_24, true);

										$.reset(strong_24);

										var span_31 = $.sibling(strong_24);
										var b_20 = $.child(span_31);
										var text_141 = $.child(b_20, true);

										$.reset(b_20);
										$.reset(span_31);

										var small_20 = $.sibling(span_31);
										var text_142 = $.child(small_20);

										$.reset(small_20);
										$.reset(div_112);

										$.template_effect(
											($0, $1, $2, $3) => {
												$.set_text(text_139, $0);

												$.set_text(text_140, (
													$.get(entry),
													$.untrack(() => $.strict_equals($.get(entry).kind, 'SIP') ? 'Monthly ETF purchase' : 'Opening holding')
												));

												$.set_text(text_141, $1);
												$.set_text(text_142, `Price ${$2 ?? ''} · ${$3 ?? ''} shares`);
											},
											[
												() => (
													$.get(entry),
													$.untrack(() => dateLabel($.get(entry).transactionDate))
												),

												() => ($.get(entry), $.untrack(() => money($.get(entry).amount))),

												() => (
													$.get(entry),
													$.untrack(() => moneyDecimal($.get(entry).executionPrice))
												),

												() => (
													$.get(entry),
													$.untrack(() => Number($.get(entry).units).toFixed(3))
												)
											]
										);

										$.append($$anchor, div_112);
									}
								),
								'each',
								Home,
								250,
								664
							);

							$.reset(section_30);

							$.template_effect(
								($0, $1) => {
									$.set_text(text_136, (
										$.get(stockDetail),
										$.untrack(() => $.get(stockDetail).stock.name)
									));

									$.set_text(text_137, $0);
									$.set_text(text_138, $1);
								},
								[
									() => (
										$.get(stockDetail),
										$.untrack(() => money($.get(stockDetail).stock.invested))
									),

									() => (
										$.get(stockDetail),
										$.untrack(() => Number($.get(stockDetail).stock.quantity).toFixed(3))
									)
								]
							);

							$.append($$anchor, fragment_52);
						};

						$.add_svelte_meta(
							() => $.if(
								node_111,
								($$render) => {
									if ($.strict_equals($.get(stockDetailStatus), 'error')) $$render(consequent_82); else $$render(alternate_41, false);
								},
								true
							),
							'if',
							Home,
							250,
							261
						);
					}

					$.append($$anchor, fragment_51);
				};

				$.add_svelte_meta(
					() => $.if(node_110, ($$render) => {
						if ($.strict_equals($.get(stockDetailStatus), 'loading')) $$render(consequent_81); else $$render(alternate_42, false);
					}),
					'if',
					Home,
					250,
					195
				);
			}

			$.reset(section_29);
			$.reset(div_108);
			$.event('click', button_83, () => $.set(stockDetail, null));
			$.append($$anchor, div_108);
		};

		$.add_svelte_meta(
			() => $.if(node_109, ($$render) => {
				if ($.get(stockDetail)) $$render(consequent_83);
			}),
			'if',
			Home,
			250,
			0
		);
	}

	var node_113 = $.sibling(node_109, 2);

	{
		var consequent_87 = ($$anchor) => {
			var div_113 = root_164();
			var section_31 = $.child(div_113);
			var button_84 = $.child(section_31);
			var node_114 = $.sibling(button_84);

			{
				var consequent_84 = ($$anchor) => {
					var fragment_53 = root_165();

					$.next();
					$.append($$anchor, fragment_53);
				};

				var alternate_44 = ($$anchor) => {
					var fragment_54 = $.comment();
					var node_115 = $.first_child(fragment_54);

					{
						var consequent_85 = ($$anchor) => {
							var fragment_55 = root_167();
							var p_41 = $.sibling($.first_child(fragment_55), 2);
							var text_143 = $.child(p_41, true);

							$.reset(p_41);

							var button_85 = $.sibling(p_41);

							$.template_effect(() => $.set_text(text_143, $.get(fundDetailError)));
							$.event('click', button_85, () => openFundDetail($.get(fundDetail).id));
							$.append($$anchor, fragment_55);
						};

						var alternate_43 = ($$anchor) => {
							const detailSummary = $.tag(
								$.derived_safe_equal(() => (
									$.get(fundDetail),
									$.untrack(() => fundSummary($.get(fundDetail).id))
								)),
								'detailSummary'
							);

							$.get(detailSummary);

							var fragment_56 = root_168();
							var h2_13 = $.sibling($.first_child(fragment_56));
							var text_144 = $.child(h2_13, true);

							$.reset(h2_13);

							var div_114 = $.sibling(h2_13);
							var strong_25 = $.sibling($.child(div_114));
							var text_145 = $.child(strong_25, true);

							$.reset(strong_25);
							$.reset(div_114);

							var div_115 = $.sibling(div_114);
							let classes_21;
							var strong_26 = $.sibling($.child(div_115));
							var text_146 = $.child(strong_26);

							$.reset(strong_26);

							var b_21 = $.sibling(strong_26);
							var text_147 = $.child(b_21);

							$.reset(b_21);
							$.reset(div_115);

							var div_116 = $.sibling(div_115);
							var div_117 = $.child(div_116);
							var b_22 = $.sibling($.child(div_117));
							var text_148 = $.child(b_22, true);

							$.reset(b_22);
							$.reset(div_117);

							var div_118 = $.sibling(div_117);
							var b_23 = $.sibling($.child(div_118));
							var text_149 = $.child(b_23, true);

							$.reset(b_23);
							$.reset(div_118);

							var div_119 = $.sibling(div_118);
							var b_24 = $.sibling($.child(div_119));
							var text_150 = $.child(b_24, true);

							$.reset(b_24);
							$.reset(div_119);

							var div_120 = $.sibling(div_119);
							var b_25 = $.sibling($.child(div_120));
							var text_151 = $.child(b_25, true);

							$.reset(b_25);
							$.reset(div_120);
							$.reset(div_116);

							var node_116 = $.sibling(div_116);

							{
								var consequent_86 = ($$anchor) => {
									var section_32 = root_169();
									var node_117 = $.sibling($.child(section_32));

									$.add_svelte_meta(
										() => $.each(
											node_117,
											1,
											() => (
												$.get(fundDetail),
												$.untrack(() => $.get(fundDetail).history)
											),
											$.index,
											($$anchor, entry) => {
												var div_121 = root_170();
												var span_32 = $.child(div_121);
												var text_152 = $.child(span_32, true);

												$.reset(span_32);

												var strong_27 = $.sibling(span_32);
												var text_153 = $.child(strong_27, true);

												$.reset(strong_27);

												var span_33 = $.sibling(strong_27);
												var b_26 = $.child(span_33);
												var text_154 = $.child(b_26, true);

												$.reset(b_26);

												var button_86 = $.sibling(b_26);

												$.reset(span_33);

												var small_21 = $.sibling(span_33);
												var text_155 = $.child(small_21);

												$.reset(small_21);
												$.reset(div_121);

												$.template_effect(
													($0, $1, $2, $3) => {
														$.set_text(text_152, $0);

														$.set_text(text_153, (
															$.get(entry),

															$.untrack(() => $.strict_equals($.get(entry).kind, "SIP")
																? "SIP"
																: $.strict_equals($.get(entry).kind, "LUMPSUM") ? "Lump sum" : "Opening holding")
														));

														$.set_text(text_154, $1);
														$.set_text(text_155, `NAV ${$2 ?? ''} · ${$3 ?? ''} units`);
													},
													[
														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).transactionDate))
														),

														() => ($.get(entry), $.untrack(() => money($.get(entry).amount))),

														() => (
															$.get(entry),
															$.untrack(() => moneyDecimal($.get(entry).nav))
														),

														() => (
															$.get(entry),
															$.untrack(() => Number($.get(entry).units).toFixed(3))
														)
													]
												);

												$.event('click', button_86, () => openHistoryEdit($.get(detailSummary), $.get(entry)));
												$.append($$anchor, div_121);
											}
										),
										'each',
										Home,
										252,
										1533
									);

									$.reset(section_32);
									$.append($$anchor, section_32);
								};

								$.add_svelte_meta(
									() => $.if(node_116, ($$render) => {
										if ((
											$.get(fundDetail),
											$.untrack(() => $.get(fundDetail).history?.length)
										)) $$render(consequent_86);
									}),
									'if',
									Home,
									252,
									1438
								);
							}

							$.next();

							$.template_effect(
								($0, $1, $2, $3, $4, $5, $6, $7, $8, $9) => {
									$.set_text(text_144, (
										$.get(fundDetail),
										$.untrack(() => $.get(fundDetail).schemeName)
									));

									$.set_text(text_145, $0);
									classes_21 = $.set_class(div_115, 1, 'detail-pnl', null, classes_21, $1);
									$.set_text(text_146, `${$2 ?? ''}${$3 ?? ''}`);
									$.set_text(text_147, `${$4 ?? ''}${$5 ?? ''}%`);
									$.set_text(text_148, $6);
									$.set_text(text_149, $7);
									$.set_text(text_150, $8);
									$.set_text(text_151, $9);
								},
								[
									() => (
										$.get(fundDetail),
										$.untrack(() => money($.get(fundDetail).currentValue))
									),

									() => ({
										positive: Number($.get(fundDetail).profitOrLoss) >= 0,
										negative: Number($.get(fundDetail).profitOrLoss) < 0
									}),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).profitOrLoss) >= 0 ? '+' : '')
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => money($.get(fundDetail).profitOrLoss))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).profitOrLossPercent) >= 0 ? '+' : '')
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).profitOrLossPercent).toFixed(2))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => money($.get(fundDetail).invested))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).units).toFixed(3))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => moneyDecimal($.get(fundDetail).averageNav))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => moneyDecimal($.get(fundDetail).currentNav))
									)
								]
							);

							$.append($$anchor, fragment_56);
						};

						$.add_svelte_meta(
							() => $.if(
								node_115,
								($$render) => {
									if ($.strict_equals($.get(fundDetailStatus), 'error')) $$render(consequent_85); else $$render(alternate_43, false);
								},
								true
							),
							'if',
							Home,
							252,
							296
						);
					}

					$.append($$anchor, fragment_54);
				};

				$.add_svelte_meta(
					() => $.if(node_114, ($$render) => {
						if ($.strict_equals($.get(fundDetailStatus), 'loading')) $$render(consequent_84); else $$render(alternate_44, false);
					}),
					'if',
					Home,
					252,
					193
				);
			}

			$.reset(section_31);
			$.reset(div_113);
			$.event('click', button_84, () => $.set(fundDetail, null));
			$.append($$anchor, div_113);
		};

		$.add_svelte_meta(
			() => $.if(node_113, ($$render) => {
				if ($.get(fundDetail)) $$render(consequent_87);
			}),
			'if',
			Home,
			252,
			0
		);
	}

	var node_118 = $.sibling(node_113, 2);

	{
		var consequent_89 = ($$anchor) => {
			var div_122 = root_171();
			var section_33 = $.child(div_122);
			var button_87 = $.child(section_33);
			var h2_14 = $.sibling(button_87, 2);
			var text_156 = $.child(h2_14);

			$.reset(h2_14);

			var label_41 = $.sibling(h2_14, 2);
			var input_36 = $.sibling($.child(label_41));

			$.remove_input_defaults(input_36);
			$.reset(label_41);

			var label_42 = $.sibling(label_41);
			var input_37 = $.sibling($.child(label_42));

			$.remove_input_defaults(input_37);
			$.reset(label_42);

			var label_43 = $.sibling(label_42);
			var input_38 = $.sibling($.child(label_43));

			$.remove_input_defaults(input_38);
			$.reset(label_43);

			var node_119 = $.sibling(label_43);

			{
				var consequent_88 = ($$anchor) => {
					var p_42 = root_172();
					var text_157 = $.child(p_42, true);

					$.reset(p_42);
					$.template_effect(() => $.set_text(text_157, $.get(lumpSumError)));
					$.append($$anchor, p_42);
				};

				$.add_svelte_meta(
					() => $.if(node_119, ($$render) => {
						if ($.get(lumpSumError)) $$render(consequent_88);
					}),
					'if',
					Home,
					253,
					718
				);
			}

			var div_123 = $.sibling(node_119);
			var button_88 = $.child(div_123);
			var button_89 = $.sibling(button_88);
			var text_158 = $.child(button_89, true);

			$.reset(button_89);
			$.reset(div_123);
			$.reset(section_33);
			$.reset(div_122);

			$.template_effect(() => {
				$.set_text(text_156, `Add to ${(
					$.get(lumpSumFund),
					$.untrack(() => $.get(lumpSumFund).schemeName)
				) ?? ''}`);

				button_89.disabled = $.get(lumpSumSaving);
				$.set_text(text_158, $.get(lumpSumSaving) ? 'Adding…' : 'Add lump sum');
			});

			$.event('click', button_87, () => $.set(lumpSumFund, null));

			$.bind_value(
				input_36,
				function get() {
					return $.get(lumpSumForm).amount;
				},
				function set($$value) {
					$.mutate(lumpSumForm, $.get(lumpSumForm).amount = $$value);
				}
			);

			$.bind_value(
				input_37,
				function get() {
					return $.get(lumpSumForm).transactionDate;
				},
				function set($$value) {
					$.mutate(lumpSumForm, $.get(lumpSumForm).transactionDate = $$value);
				}
			);

			$.bind_value(
				input_38,
				function get() {
					return $.get(lumpSumForm).nav;
				},
				function set($$value) {
					$.mutate(lumpSumForm, $.get(lumpSumForm).nav = $$value);
				}
			);

			$.event('click', button_88, () => $.set(lumpSumFund, null));
			$.event('click', button_89, saveLumpSum);
			$.append($$anchor, div_122);
		};

		$.add_svelte_meta(
			() => $.if(node_118, ($$render) => {
				if ($.get(lumpSumFund)) $$render(consequent_89);
			}),
			'if',
			Home,
			253,
			0
		);
	}

	var node_120 = $.sibling(node_118, 2);

	{
		var consequent_91 = ($$anchor) => {
			var div_124 = root_173();
			var section_34 = $.child(div_124);
			var button_90 = $.child(section_34);
			var div_125 = $.sibling(button_90, 4);
			var strong_28 = $.child(div_125);
			var text_159 = $.child(strong_28, true);

			$.reset(strong_28);

			var span_34 = $.sibling(strong_28);
			var text_160 = $.child(span_34);

			$.reset(span_34);
			$.reset(div_125);

			var label_44 = $.sibling(div_125);
			var input_39 = $.sibling($.child(label_44));

			$.remove_input_defaults(input_39);
			$.reset(label_44);

			var label_45 = $.sibling(label_44);
			var input_40 = $.sibling($.child(label_45));

			$.remove_input_defaults(input_40);
			$.reset(label_45);

			var label_46 = $.sibling(label_45);
			var input_41 = $.sibling($.child(label_46), 2);

			$.remove_input_defaults(input_41);
			$.reset(label_46);

			var node_121 = $.sibling(label_46);

			{
				var consequent_90 = ($$anchor) => {
					var p_43 = root_174();
					var text_161 = $.child(p_43, true);

					$.reset(p_43);
					$.template_effect(() => $.set_text(text_161, $.get(sipConfirmError)));
					$.append($$anchor, p_43);
				};

				$.add_svelte_meta(
					() => $.if(node_121, ($$render) => {
						if ($.get(sipConfirmError)) $$render(consequent_90);
					}),
					'if',
					Home,
					254,
					931
				);
			}

			var div_126 = $.sibling(node_121);
			var button_91 = $.child(div_126);
			var button_92 = $.sibling(button_91);
			var text_162 = $.child(button_92, true);

			$.reset(button_92);
			$.reset(div_126);
			$.reset(section_34);
			$.reset(div_124);

			$.template_effect(() => {
				$.set_text(text_159, (
					$.get(confirmingSip),
					$.untrack(() => $.get(confirmingSip).fund.schemeName)
				));

				$.set_text(text_160, `${(
					$.get(confirmingSip),
					$.untrack(() => $.get(confirmingSip).occurrence.scheduledMonth)
				) ?? ''} occurrence`);

				button_92.disabled = $.get(sipConfirmSaving);
				$.set_text(text_162, $.get(sipConfirmSaving) ? 'Confirming…' : 'Confirm estimate');
			});

			$.event('click', button_90, () => $.set(confirmingSip, null));

			$.bind_value(
				input_39,
				function get() {
					return $.get(sipConfirmForm).amount;
				},
				function set($$value) {
					$.mutate(sipConfirmForm, $.get(sipConfirmForm).amount = $$value);
				}
			);

			$.bind_value(
				input_40,
				function get() {
					return $.get(sipConfirmForm).transactionDate;
				},
				function set($$value) {
					$.mutate(sipConfirmForm, $.get(sipConfirmForm).transactionDate = $$value);
				}
			);

			$.bind_value(
				input_41,
				function get() {
					return $.get(sipConfirmForm).nav;
				},
				function set($$value) {
					$.mutate(sipConfirmForm, $.get(sipConfirmForm).nav = $$value);
				}
			);

			$.event('click', button_91, () => $.set(confirmingSip, null));
			$.event('click', button_92, saveSipConfirmation);
			$.append($$anchor, div_124);
		};

		$.add_svelte_meta(
			() => $.if(node_120, ($$render) => {
				if ($.get(confirmingSip)) $$render(consequent_91);
			}),
			'if',
			Home,
			254,
			0
		);
	}

	var node_122 = $.sibling(node_120, 2);

	{
		var consequent_93 = ($$anchor) => {
			var div_127 = root_175();
			var section_35 = $.child(div_127);
			var button_93 = $.child(section_35);
			var h2_15 = $.sibling(button_93, 2);
			var text_163 = $.child(h2_15, true);

			$.reset(h2_15);

			var label_47 = $.sibling(h2_15, 2);
			var input_42 = $.sibling($.child(label_47));

			$.remove_input_defaults(input_42);
			$.reset(label_47);

			var label_48 = $.sibling(label_47);
			var input_43 = $.sibling($.child(label_48));

			$.remove_input_defaults(input_43);
			$.reset(label_48);

			var label_49 = $.sibling(label_48);
			var input_44 = $.sibling($.child(label_49));

			$.remove_input_defaults(input_44);
			$.reset(label_49);

			var node_123 = $.sibling(label_49);

			{
				var consequent_92 = ($$anchor) => {
					var p_44 = root_176();
					var text_164 = $.child(p_44, true);

					$.reset(p_44);
					$.template_effect(() => $.set_text(text_164, $.get(fundTransactionError)));
					$.append($$anchor, p_44);
				};

				$.add_svelte_meta(
					() => $.if(node_123, ($$render) => {
						if ($.get(fundTransactionError)) $$render(consequent_92);
					}),
					'if',
					Home,
					255,
					850
				);
			}

			var div_128 = $.sibling(node_123);
			var button_94 = $.child(div_128);
			var button_95 = $.sibling(button_94);
			var text_165 = $.child(button_95, true);

			$.reset(button_95);
			$.reset(div_128);
			$.reset(section_35);
			$.reset(div_127);

			$.template_effect(() => {
				$.set_text(text_163, (
					$.get(editingFundTransaction),

					$.untrack(() => $.strict_equals($.get(editingFundTransaction).entry.kind, "SIP")
						? "Edit SIP allocation"
						: $.strict_equals($.get(editingFundTransaction).entry.kind, "LUMPSUM") ? "Edit lump sum" : "Edit opening holding")
				));

				button_95.disabled = $.get(fundTransactionSaving);
				$.set_text(text_165, $.get(fundTransactionSaving) ? "Saving…" : "Save changes");
			});

			$.event('click', button_93, () => $.set(editingFundTransaction, null));

			$.bind_value(
				input_42,
				function get() {
					return $.get(fundTransactionForm).amount;
				},
				function set($$value) {
					$.mutate(fundTransactionForm, $.get(fundTransactionForm).amount = $$value);
				}
			);

			$.bind_value(
				input_43,
				function get() {
					return $.get(fundTransactionForm).transactionDate;
				},
				function set($$value) {
					$.mutate(fundTransactionForm, $.get(fundTransactionForm).transactionDate = $$value);
				}
			);

			$.bind_value(
				input_44,
				function get() {
					return $.get(fundTransactionForm).nav;
				},
				function set($$value) {
					$.mutate(fundTransactionForm, $.get(fundTransactionForm).nav = $$value);
				}
			);

			$.event('click', button_94, () => $.set(editingFundTransaction, null));
			$.event('click', button_95, saveFundTransaction);
			$.append($$anchor, div_127);
		};

		$.add_svelte_meta(
			() => $.if(node_122, ($$render) => {
				if ($.get(editingFundTransaction)) $$render(consequent_93);
			}),
			'if',
			Home,
			255,
			0
		);
	}

	var node_124 = $.sibling(node_122, 2);

	{
		var consequent_94 = ($$anchor) => {
			var div_129 = root_177();
			var section_36 = $.child(div_129);
			var header = $.child(section_36);
			var button_96 = $.sibling($.child(header));

			$.reset(header);

			var div_130 = $.sibling(header);
			var node_125 = $.child(div_130);

			$.add_svelte_meta(() => Normalization(node_125, {}), 'component', Home, 257, 552, { componentTag: 'Normalization' });
			$.reset(div_130);
			$.reset(section_36);
			$.reset(div_129);
			$.event('click', button_96, () => $.set(showNormalization, false));

			$.event('click', section_36, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_129, () => $.set(showNormalization, false));
			$.event('keydown', div_129, (event) => $.strict_equals(event.key, 'Escape') && $.set(showNormalization, false));
			$.append($$anchor, div_129);
		};

		$.add_svelte_meta(
			() => $.if(node_124, ($$render) => {
				if ($.get(showNormalization)) $$render(consequent_94);
			}),
			'if',
			Home,
			257,
			0
		);
	}

	var node_126 = $.sibling(node_124, 2);

	{
		var consequent_104 = ($$anchor) => {
			var div_131 = root_178();
			var section_37 = $.child(div_131);
			var button_97 = $.child(section_37);
			var p_45 = $.sibling(button_97);
			var text_166 = $.child(p_45);

			$.reset(p_45);

			var node_127 = $.sibling(p_45);

			{
				var consequent_103 = ($$anchor) => {
					const cards = $.tag(
						$.derived_safe_equal(() => (
							$.get(openedStory),
							$.untrack(() => $.get(openedStory).cards.slice().sort((a, b) => (a.sequence || 0) - (b.sequence || 0)))
						)),
						'cards'
					);

					$.get(cards);

					const currentCard = $.tag(
						$.derived_safe_equal(() => (
							$.deep_read_state($.get(cards)),
							$.get(storySlide),
							$.untrack(() => $.get(cards)[$.get(storySlide)])
						)),
						'currentCard'
					);

					$.get(currentCard);

					var div_132 = root_179();
					var node_128 = $.child(div_132);

					{
						var consequent_95 = ($$anchor) => {
							var div_133 = root_180();

							$.add_svelte_meta(
								() => $.each(div_133, 5, () => $.get(cards), $.index, ($$anchor, _, index) => {
									var i_3 = root_181();
									let classes_22;

									$.template_effect(() => classes_22 = $.set_class(i_3, 1, '', null, classes_22, { active: $.strict_equals(index, $.get(storySlide)) }));
									$.append($$anchor, i_3);
								}),
								'each',
								Home,
								259,
								656
							);

							$.reset(div_133);
							$.append($$anchor, div_133);
						};

						$.add_svelte_meta(
							() => $.if(node_128, ($$render) => {
								if ((
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.get(cards).length > 1)
								)) $$render(consequent_95);
							}),
							'if',
							Home,
							259,
							608
						);
					}

					var article_5 = $.sibling(node_128);
					var node_129 = $.child(article_5);

					{
						var consequent_96 = ($$anchor) => {
							var p_46 = root_182();
							var text_167 = $.child(p_46, true);

							$.reset(p_46);

							$.template_effect(() => $.set_text(text_167, (
								$.deep_read_state($.get(currentCard)),
								$.untrack(() => $.get(currentCard).eyebrow)
							)));

							$.append($$anchor, p_46);
						};

						$.add_svelte_meta(
							() => $.if(node_129, ($$render) => {
								if ((
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).eyebrow)
								)) $$render(consequent_96);
							}),
							'if',
							Home,
							259,
							939
						);
					}

					var node_130 = $.sibling(node_129);

					{
						var consequent_97 = ($$anchor) => {
							var div_134 = root_183();
							var span_35 = $.child(div_134);
							var text_168 = $.child(span_35, true);

							$.reset(span_35);

							var strong_29 = $.sibling(span_35);
							var text_169 = $.child(strong_29, true);

							$.reset(strong_29);
							$.reset(div_134);

							$.template_effect(() => {
								$.set_text(text_168, (
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).components[0].label)
								));

								$.set_text(text_169, (
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).components[0].displayValue)
								));
							});

							$.append($$anchor, div_134);
						};

						$.add_svelte_meta(
							() => $.if(node_130, ($$render) => {
								if ((
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.strict_equals($.get(currentCard).layout, 'HERO_STAT') && $.get(currentCard).components?.[0])
								)) $$render(consequent_97);
							}),
							'if',
							Home,
							259,
							1019
						);
					}

					var h1_1 = $.sibling(node_130);
					var text_170 = $.child(h1_1, true);

					$.reset(h1_1);

					var p_47 = $.sibling(h1_1);
					var text_171 = $.child(p_47, true);

					$.reset(p_47);

					var node_131 = $.sibling(p_47);

					{
						var consequent_98 = ($$anchor) => {
							var div_135 = root_184();

							$.add_svelte_meta(
								() => $.each(
									div_135,
									5,
									() => (
										$.deep_read_state($.get(currentCard)),
										$.untrack(() => $.get(currentCard).components)
									),
									$.index,
									($$anchor, component) => {
										var div_136 = root_185();
										var span_36 = $.child(div_136);
										var text_172 = $.child(span_36, true);

										$.reset(span_36);

										var strong_30 = $.sibling(span_36);
										var text_173 = $.child(strong_30, true);

										$.reset(strong_30);
										$.reset(div_136);

										$.template_effect(() => {
											$.set_text(text_172, ($.get(component), $.untrack(() => $.get(component).label)));

											$.set_text(text_173, (
												$.get(component),
												$.untrack(() => $.get(component).displayValue)
											));
										});

										$.append($$anchor, div_136);
									}
								),
								'each',
								Home,
								259,
								1351
							);

							$.reset(div_135);
							$.append($$anchor, div_135);
						};

						$.add_svelte_meta(
							() => $.if(node_131, ($$render) => {
								if ((
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).components?.length)
								)) $$render(consequent_98);
							}),
							'if',
							Home,
							259,
							1279
						);
					}

					var node_132 = $.sibling(node_131);

					$.add_svelte_meta(
						() => $.each(
							node_132,
							1,
							() => (
								$.deep_read_state($.get(currentCard)),
								$.untrack(() => $.get(currentCard).actions || [])
							),
							$.index,
							($$anchor, action) => {
								var fragment_57 = $.comment();
								var node_133 = $.first_child(fragment_57);

								{
									var consequent_99 = ($$anchor) => {
										var button_98 = root_187();
										var text_174 = $.child(button_98, true);

										$.reset(button_98);
										$.template_effect(() => $.set_text(text_174, ($.get(action), $.untrack(() => $.get(action).label))));
										$.event('click', button_98, openCommitmentSources);
										$.append($$anchor, button_98);
									};

									var alternate_46 = ($$anchor) => {
										var fragment_58 = $.comment();
										var node_134 = $.first_child(fragment_58);

										{
											var consequent_100 = ($$anchor) => {
												var button_99 = root_189();
												var text_175 = $.child(button_99, true);

												$.reset(button_99);
												$.template_effect(() => $.set_text(text_175, ($.get(action), $.untrack(() => $.get(action).label))));

												$.event('click', button_99, () => {
													$.set(openedStory, null);
													openMoney();
												});

												$.append($$anchor, button_99);
											};

											var alternate_45 = ($$anchor) => {
												var fragment_59 = $.comment();
												var node_135 = $.first_child(fragment_59);

												{
													var consequent_101 = ($$anchor) => {
														var button_100 = root_191();
														var text_176 = $.child(button_100, true);

														$.reset(button_100);
														$.template_effect(() => $.set_text(text_176, ($.get(action), $.untrack(() => $.get(action).label))));

														$.event('click', button_100, function (...$$args) {
															$.apply(() => openDueLoanFromStory, this, $$args, Home, [259, 1950]);
														});

														$.append($$anchor, button_100);
													};

													$.add_svelte_meta(
														() => $.if(
															node_135,
															($$render) => {
																if ((
																	$.get(action),
																	$.untrack(() => $.strict_equals($.get(action).type, 'OPEN_DUE_LOAN'))
																)) $$render(consequent_101);
															},
															true
														),
														'if',
														Home,
														259,
														1840
													);
												}

												$.append($$anchor, fragment_59);
											};

											$.add_svelte_meta(
												() => $.if(
													node_134,
													($$render) => {
														if ((
															$.get(action),
															$.untrack(() => $.strict_equals($.get(action).type, 'OPEN_SALARY_OUTLOOK'))
														)) $$render(consequent_100); else $$render(alternate_45, false);
													},
													true
												),
												'if',
												Home,
												259,
												1695
											);
										}

										$.append($$anchor, fragment_58);
									};

									$.add_svelte_meta(
										() => $.if(node_133, ($$render) => {
											if ((
												$.get(action),
												$.untrack(() => $.strict_equals($.get(action).type, 'OPEN_EVIDENCE'))
											)) $$render(consequent_99); else $$render(alternate_46, false);
										}),
										'if',
										Home,
										259,
										1535
									);
								}

								$.append($$anchor, fragment_57);
							}
						),
						'each',
						Home,
						259,
						1494
					);

					$.reset(article_5);

					var node_136 = $.sibling(article_5);

					{
						var consequent_102 = ($$anchor) => {
							var div_137 = root_192();
							var button_101 = $.child(div_137);
							var span_37 = $.sibling(button_101);
							var text_177 = $.child(span_37);

							$.reset(span_37);

							var button_102 = $.sibling(span_37);

							$.reset(div_137);

							$.template_effect(() => {
								button_101.disabled = $.strict_equals($.get(storySlide), 0);

								$.set_text(text_177, `${$.get(storySlide) + 1} of ${(
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.get(cards).length)
								) ?? ''}`);

								button_102.disabled = (
									$.get(storySlide),
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.strict_equals($.get(storySlide), $.get(cards).length - 1))
								);
							});

							$.event('click', button_101, () => $.set(storySlide, $.get(storySlide) - 1));
							$.event('click', button_102, () => $.set(storySlide, $.get(storySlide) + 1));
							$.append($$anchor, div_137);
						};

						$.add_svelte_meta(
							() => $.if(node_136, ($$render) => {
								if ((
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.get(cards).length > 1)
								)) $$render(consequent_102);
							}),
							'if',
							Home,
							259,
							2017
						);
					}

					$.reset(div_132);

					$.template_effect(() => {
						$.set_class(article_5, 1, (
							$.deep_read_state($.get(currentCard)),
							$.untrack(() => `story-slide deck-theme-${$.get(currentCard).theme || 'CALM_CONTEXT'}`)
						));

						$.set_text(text_170, (
							$.deep_read_state($.get(currentCard)),
							$.untrack(() => $.get(currentCard).title)
						));

						$.set_text(text_171, (
							$.deep_read_state($.get(currentCard)),
							$.untrack(() => $.get(currentCard).body)
						));
					});

					$.event('touchstart', article_5, (event) => $.set(storyTouchStart, event.touches[0].clientX));
					$.event('touchend', article_5, (event) => endStorySwipe(event, $.get(cards).length));
					$.append($$anchor, div_132);
				};

				$.add_svelte_meta(
					() => $.if(node_127, ($$render) => {
						if (hasDeck) $$render(consequent_103);
					}),
					'if',
					Home,
					259,
					448
				);
			}

			$.reset(section_37);
			$.reset(div_131);

			$.template_effect(($0, $1) => $.set_text(text_166, `${$0 ?? ''} · ${$1 ?? ''}`), [
				() => (
					$.get(openedStory),
					$.untrack(() => storySource($.get(openedStory)).toUpperCase())
				),

				() => (
					$.get(openedStory),
					$.untrack(() => storyName($.get(openedStory)))
				)
			]);

			$.event('click', button_97, () => $.set(openedStory, null));

			$.event('click', section_37, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_131, () => $.set(openedStory, null));
			$.event('keydown', div_131, (event) => $.strict_equals(event.key, 'Escape') && $.set(openedStory, null));
			$.append($$anchor, div_131);
		};

		$.add_svelte_meta(
			() => $.if(node_126, ($$render) => {
				if ($.get(openedStory)) $$render(consequent_104);
			}),
			'if',
			Home,
			259,
			0
		);
	}

	var node_137 = $.sibling(node_126, 2);

	{
		var consequent_108 = ($$anchor) => {
			var div_138 = root_193();
			var section_38 = $.child(div_138);
			var button_103 = $.child(section_38);
			var node_138 = $.sibling(button_103, 4);

			{
				var consequent_105 = ($$anchor) => {
					var p_48 = root_194();

					$.append($$anchor, p_48);
				};

				var alternate_48 = ($$anchor) => {
					var fragment_60 = $.comment();
					var node_139 = $.first_child(fragment_60);

					{
						var consequent_106 = ($$anchor) => {
							var p_49 = root_196();
							var text_178 = $.child(p_49, true);

							$.reset(p_49);
							$.template_effect(() => $.set_text(text_178, $.get(commitmentError)));
							$.append($$anchor, p_49);
						};

						var alternate_47 = ($$anchor) => {
							var fragment_61 = root_197();
							var node_140 = $.first_child(fragment_61);

							$.add_svelte_meta(
								() => $.each(node_140, 1, () => $.get(commitmentReview), $.index, ($$anchor, candidate) => {
									var fragment_62 = root_198();
									var div_139 = $.first_child(fragment_62);
									var strong_31 = $.child(div_139);
									var text_179 = $.child(strong_31);

									$.reset(strong_31);

									var span_38 = $.sibling(strong_31);
									var text_180 = $.child(span_38, true);

									$.reset(span_38);
									$.reset(div_139);

									var node_141 = $.sibling(div_139, 2);

									$.add_svelte_meta(
										() => $.each(node_141, 1, () => ($.get(candidate), $.untrack(() => $.get(candidate).choices)), $.index, ($$anchor, choice) => {
											var button_104 = root_199();
											var text_181 = $.child(button_104, true);

											$.reset(button_104);

											$.template_effect(() => {
												button_104.disabled = (
													$.get(resolvingCandidate),
													$.get(candidate),
													$.untrack(() => $.strict_equals($.get(resolvingCandidate), $.get(candidate).transactionId))
												);

												$.set_text(text_181, ($.get(choice), $.untrack(() => $.get(choice).label)));
											});

											$.event('click', button_104, () => resolveCandidate($.get(candidate).transactionId, $.get(choice).id));
											$.append($$anchor, button_104);
										}),
										'each',
										Home,
										261,
										791
									);

									var button_105 = $.sibling(node_141);

									$.template_effect(
										($0, $1) => {
											$.set_text(text_179, `${$0 ?? ''} · ${($.get(candidate), $.untrack(() => $.get(candidate).category)) ?? ''} / ${(
												$.get(candidate),
												$.untrack(() => $.get(candidate).subcategory)
											) ?? ''}`);

											$.set_text(text_180, $1);

											button_105.disabled = (
												$.get(resolvingCandidate),
												$.get(candidate),
												$.untrack(() => $.strict_equals($.get(resolvingCandidate), $.get(candidate).transactionId))
											);
										},
										[
											() => (
												$.get(candidate),
												$.untrack(() => money($.get(candidate).amount))
											),

											() => (
												$.get(candidate),
												$.untrack(() => dateLabel($.get(candidate).transactionDate))
											)
										]
									);

									$.event('click', button_105, () => resolveCandidate($.get(candidate).transactionId, null));
									$.append($$anchor, fragment_62);
								}),
								'each',
								Home,
								261,
								545
							);

							var node_142 = $.sibling(node_140);

							{
								var consequent_107 = ($$anchor) => {
									var p_50 = root_200();

									$.append($$anchor, p_50);
								};

								$.add_svelte_meta(
									() => $.if(node_142, ($$render) => {
										if ((
											$.get(commitmentReview),
											$.untrack(() => !$.get(commitmentReview).length)
										)) $$render(consequent_107);
									}),
									'if',
									Home,
									261,
									1192
								);
							}

							$.append($$anchor, fragment_61);
						};

						$.add_svelte_meta(
							() => $.if(
								node_139,
								($$render) => {
									if ($.strict_equals($.get(commitmentReviewStatus), 'error')) $$render(consequent_106); else $$render(alternate_47, false);
								},
								true
							),
							'if',
							Home,
							261,
							452
						);
					}

					$.append($$anchor, fragment_60);
				};

				$.add_svelte_meta(
					() => $.if(node_138, ($$render) => {
						if ($.strict_equals($.get(commitmentReviewStatus), 'loading')) $$render(consequent_105); else $$render(alternate_48, false);
					}),
					'if',
					Home,
					261,
					381
				);
			}

			$.reset(section_38);
			$.reset(div_138);
			$.event('click', button_103, () => $.set(showCommitmentReview, false));
			$.append($$anchor, div_138);
		};

		$.add_svelte_meta(
			() => $.if(node_137, ($$render) => {
				if ($.get(showCommitmentReview)) $$render(consequent_108);
			}),
			'if',
			Home,
			261,
			0
		);
	}

	var node_143 = $.sibling(node_137, 2);

	{
		var consequent_114 = ($$anchor) => {
			var div_140 = root_201();
			var section_39 = $.child(div_140);
			var button_106 = $.child(section_39);
			var h2_16 = $.sibling(button_106, 2);
			var text_182 = $.child(h2_16, true);

			$.reset(h2_16);

			var node_144 = $.sibling(h2_16);

			{
				var consequent_113 = ($$anchor) => {
					var fragment_63 = root_202();
					var p_51 = $.first_child(fragment_63);
					var text_183 = $.child(p_51);

					$.reset(p_51);

					var div_141 = $.sibling(p_51);

					$.add_svelte_meta(
						() => $.each(div_141, 5, () => $.get(evidenceItems), $.index, ($$anchor, item) => {
							const loanItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => (/loan/i).test($.get(item).category))
								)),
								'loanItem'
							);

							$.get(loanItem);

							const fundItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => $.strict_equals($.get(item).sourceType, 'mutual_fund_sip'))
								)),
								'fundItem'
							);

							$.get(fundItem);

							const stockItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => $.strict_equals($.get(item).sourceType, 'stock_monthly_plan'))
								)),
								'stockItem'
							);

							$.get(stockItem);

							const recurringItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => $.strict_equals($.get(item).sourceType, 'recurring_commitment'))
								)),
								'recurringItem'
							);

							$.get(recurringItem);

							const recurringStatus = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => recurringOccurrence($.get(item).sourceId)?.status)
								)),
								'recurringStatus'
							);

							$.get(recurringStatus);

							var div_142 = root_203();
							let classes_23;
							var div_143 = $.child(div_142);
							var strong_32 = $.child(div_143);
							var text_184 = $.child(strong_32, true);

							$.reset(strong_32);

							var span_39 = $.sibling(strong_32);
							var text_185 = $.child(span_39);

							$.reset(span_39);
							$.reset(div_143);

							var b_27 = $.sibling(div_143);
							var text_186 = $.child(b_27, true);

							$.reset(b_27);

							var node_145 = $.sibling(b_27);

							{
								var consequent_109 = ($$anchor) => {
									var button_107 = root_204();

									$.event('click', button_107, openIncludedLoan);
									$.append($$anchor, button_107);
								};

								var alternate_51 = ($$anchor) => {
									var fragment_64 = $.comment();
									var node_146 = $.first_child(fragment_64);

									{
										var consequent_110 = ($$anchor) => {
											var button_108 = root_206();

											$.template_effect(() => $.set_attribute(button_108, 'data-testid', (
												$.get(item),
												$.untrack(() => `included-mutual-fund-commitment-${$.get(item).sourceId}`)
											)));

											$.event('click', button_108, () => openIncludedMutualFund($.get(item)));
											$.append($$anchor, button_108);
										};

										var alternate_50 = ($$anchor) => {
											var fragment_65 = $.comment();
											var node_147 = $.first_child(fragment_65);

											{
												var consequent_111 = ($$anchor) => {
													var button_109 = root_208();

													$.template_effect(() => $.set_attribute(button_109, 'data-testid', (
														$.get(item),
														$.untrack(() => `included-stock-commitment-${$.get(item).sourceId}`)
													)));

													$.event('click', button_109, () => openIncludedStock($.get(item)));
													$.append($$anchor, button_109);
												};

												var alternate_49 = ($$anchor) => {
													var fragment_66 = $.comment();
													var node_148 = $.first_child(fragment_66);

													{
														var consequent_112 = ($$anchor) => {
															var button_110 = root_210();

															$.template_effect(() => $.set_attribute(button_110, 'data-testid', (
																$.get(item),
																$.untrack(() => `included-recurring-commitment-${$.get(item).sourceId}`)
															)));

															$.event('click', button_110, () => openIncludedCommitment($.get(item)));
															$.append($$anchor, button_110);
														};

														$.add_svelte_meta(
															() => $.if(
																node_148,
																($$render) => {
																	if ($.get(recurringItem)) $$render(consequent_112);
																},
																true
															),
															'if',
															Home,
															262,
															1923
														);
													}

													$.append($$anchor, fragment_66);
												};

												$.add_svelte_meta(
													() => $.if(
														node_147,
														($$render) => {
															if ($.get(stockItem)) $$render(consequent_111); else $$render(alternate_49, false);
														},
														true
													),
													'if',
													Home,
													262,
													1764
												);
											}

											$.append($$anchor, fragment_65);
										};

										$.add_svelte_meta(
											() => $.if(
												node_146,
												($$render) => {
													if ($.get(fundItem)) $$render(consequent_110); else $$render(alternate_50, false);
												},
												true
											),
											'if',
											Home,
											262,
											1595
										);
									}

									$.append($$anchor, fragment_64);
								};

								$.add_svelte_meta(
									() => $.if(node_145, ($$render) => {
										if ($.get(loanItem)) $$render(consequent_109); else $$render(alternate_51, false);
									}),
									'if',
									Home,
									262,
									1473
								);
							}

							$.reset(div_142);

							$.template_effect(
								($0) => {
									classes_23 = $.set_class(div_142, 1, 'evidence-row', null, classes_23, $0);
									$.set_text(text_184, ($.get(item), $.untrack(() => $.get(item).merchant)));

									$.set_text(text_185, `${($.get(item), $.untrack(() => $.get(item).date)) ?? ''}${(
										$.get(item),
										$.untrack(() => $.get(item).date && $.get(item).category ? ' · ' : '')
									) ?? ''}${($.get(item), $.untrack(() => $.get(item).category)) ?? ''}`);

									$.set_text(text_186, ($.get(item), $.untrack(() => $.get(item).amount)));
								},
								[
									() => ({
										'due-commitment': $.get(loanItem) && currentCommitmentIsDue() || $.get(fundItem) && sipIsDue($.get(item)) || $.get(stockItem) && $.strict_equals($.get(stocks).find((stock) => $.strict_equals(String(stock.id), String($.get(item).sourceId)))?.currentMonthlyPlan?.status, 'DUE') || $.get(recurringItem) && $.strict_equals($.get(recurringStatus), 'DUE'),
										'confirmed-commitment': $.get(fundItem) && sipIsConfirmed($.get(item)) || $.get(recurringItem) && $.strict_equals($.get(recurringStatus), 'COMPLETED')
									})
								]
							);

							$.append($$anchor, div_142);
						}),
						'each',
						Home,
						262,
						645
					);

					$.reset(div_141);

					$.template_effect(() => $.set_text(text_183, `${(
						$.get(evidenceItems),
						$.untrack(() => $.get(evidenceItems).length)
					) ?? ''} included ${(
						$.get(evidenceItems),
						$.untrack(() => $.strict_equals($.get(evidenceItems).length, 1) ? 'commitment' : 'commitments')
					) ?? ''}`));

					$.append($$anchor, fragment_63);
				};

				var alternate_52 = ($$anchor) => {
					var div_144 = root_211();

					$.append($$anchor, div_144);
				};

				$.add_svelte_meta(
					() => $.if(node_144, ($$render) => {
						if ((
							$.get(evidenceItems),
							$.untrack(() => $.get(evidenceItems).length)
						)) $$render(consequent_113); else $$render(alternate_52, false);
					}),
					'if',
					Home,
					262,
					477
				);
			}

			$.reset(section_39);
			$.reset(div_140);

			$.template_effect(($0) => $.set_text(text_182, $0), [
				() => (
					$.get(openedStory),
					$.untrack(() => isCommitment($.get(openedStory)) ? 'What makes up this month' : 'Supporting evidence')
				)
			]);

			$.event('click', button_106, () => $.set(showStoryEvidence, false));

			$.event('click', section_39, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_140, () => $.set(showStoryEvidence, false));
			$.event('keydown', div_140, (event) => $.strict_equals(event.key, 'Escape') && $.set(showStoryEvidence, false));
			$.append($$anchor, div_140);
		};

		$.add_svelte_meta(
			() => $.if(node_143, ($$render) => {
				if ($.get(showStoryEvidence)) $$render(consequent_114);
			}),
			'if',
			Home,
			262,
			0
		);
	}

	var node_149 = $.sibling(node_143, 2);

	{
		var consequent_118 = ($$anchor) => {
			var div_145 = root_212();
			var section_40 = $.child(div_145);
			var button_111 = $.child(section_40);
			var label_50 = $.sibling(button_111, 4);
			var input_45 = $.sibling($.child(label_50));

			$.remove_input_defaults(input_45);
			$.reset(label_50);

			var label_51 = $.sibling(label_50);
			var input_46 = $.sibling($.child(label_51));

			$.remove_input_defaults(input_46);
			$.reset(label_51);

			var node_150 = $.sibling(label_51);

			{
				var consequent_115 = ($$anchor) => {
					var p_52 = root_213();

					$.append($$anchor, p_52);
				};

				var alternate_54 = ($$anchor) => {
					var fragment_67 = $.comment();
					var node_151 = $.first_child(fragment_67);

					{
						var consequent_116 = ($$anchor) => {
							var p_53 = root_215();
							var text_187 = $.child(p_53, true);

							$.reset(p_53);
							$.template_effect(() => $.set_text(text_187, $.get(optionsError)));
							$.append($$anchor, p_53);
						};

						var alternate_53 = ($$anchor) => {
							var fragment_68 = root_216();
							var label_52 = $.first_child(fragment_68);
							var select_5 = $.sibling($.child(label_52));
							var option_8 = $.child(select_5);

							option_8.value = option_8.__value = '';

							var node_152 = $.sibling(option_8);

							$.add_svelte_meta(
								() => $.each(
									node_152,
									1,
									() => (
										$.get(editOptions),
										$.untrack(() => $.get(editOptions).categories)
									),
									$.index,
									($$anchor, option) => {
										var option_9 = root_217();
										var text_188 = $.child(option_9, true);

										$.reset(option_9);

										var option_9_value = {};

										$.template_effect(() => {
											$.set_text(text_188, ($.get(option), $.untrack(() => $.get(option).name)));

											if (option_9_value !== (option_9_value = ($.get(option), $.untrack(() => $.get(option).name)))) {
												option_9.value = (option_9.__value = ($.get(option), $.untrack(() => $.get(option).name))) ?? '';
											}
										});

										$.append($$anchor, option_9);
									}
								),
								'each',
								Home,
								263,
								911
							);

							$.reset(select_5);

							var select_5_value;

							$.init_select(select_5);
							$.reset(label_52);

							var label_53 = $.sibling(label_52);
							var select_6 = $.sibling($.child(label_53));

							$.template_effect(() => {
								$.get(editSubcategory);

								$.invalidate_inner_signals(() => {
									$.get(editCategory);
									$.get(editSubcategories);
								});
							});

							var option_10 = $.child(select_6);

							option_10.value = option_10.__value = '';

							var node_153 = $.sibling(option_10);

							$.add_svelte_meta(
								() => $.each(node_153, 1, () => $.get(editSubcategories), $.index, ($$anchor, option) => {
									var option_11 = root_218();
									var text_189 = $.child(option_11, true);

									$.reset(option_11);

									var option_11_value = {};

									$.template_effect(() => {
										$.set_text(text_189, $.get(option));

										if (option_11_value !== (option_11_value = $.get(option))) {
											option_11.value = (option_11.__value = $.get(option)) ?? '';
										}
									});

									$.append($$anchor, option_11);
								}),
								'each',
								Home,
								263,
								1160
							);

							$.reset(select_6);
							$.reset(label_53);

							var label_54 = $.sibling(label_53);
							var select_7 = $.sibling($.child(label_54));

							$.template_effect(() => {
								$.get(editMerchantId);

								$.invalidate_inner_signals(() => {
									$.get(editOptions);
									String;
								});
							});

							var option_12 = $.child(select_7);

							option_12.value = option_12.__value = '';

							var node_154 = $.sibling(option_12);

							$.add_svelte_meta(
								() => $.each(
									node_154,
									1,
									() => (
										$.get(editOptions),
										$.untrack(() => $.get(editOptions).merchants)
									),
									$.index,
									($$anchor, option) => {
										var option_13 = root_219();
										var text_190 = $.child(option_13, true);

										$.reset(option_13);

										var option_13_value = {};

										$.template_effect(
											($0) => {
												$.set_text(text_190, ($.get(option), $.untrack(() => $.get(option).name)));

												if (option_13_value !== (option_13_value = $0)) {
													option_13.value = (option_13.__value = $0) ?? '';
												}
											},
											[
												() => ($.get(option), $.untrack(() => String($.get(option).id)))
											]
										);

										$.append($$anchor, option_13);
									}
								),
								'each',
								Home,
								263,
								1362
							);

							$.reset(select_7);
							$.reset(label_54);

							var label_55 = $.sibling(label_54);
							var select_8 = $.sibling($.child(label_55));

							$.template_effect(() => {
								$.get(editAccountId);

								$.invalidate_inner_signals(() => {
									$.get(editOptions);
									String;
								});
							});

							var option_14 = $.child(select_8);

							option_14.value = option_14.__value = '';

							var node_155 = $.sibling(option_14);

							$.add_svelte_meta(
								() => $.each(
									node_155,
									1,
									() => (
										$.get(editOptions),
										$.untrack(() => $.get(editOptions).accounts)
									),
									$.index,
									($$anchor, option) => {
										var option_15 = root_220();
										var text_191 = $.child(option_15, true);

										$.reset(option_15);

										var option_15_value = {};

										$.template_effect(
											($0) => {
												$.set_text(text_191, ($.get(option), $.untrack(() => $.get(option).name)));

												if (option_15_value !== (option_15_value = $0)) {
													option_15.value = (option_15.__value = $0) ?? '';
												}
											},
											[
												() => ($.get(option), $.untrack(() => String($.get(option).id)))
											]
										);

										$.append($$anchor, option_15);
									}
								),
								'each',
								Home,
								263,
								1589
							);

							$.reset(select_8);
							$.reset(label_55);

							$.template_effect(() => {
								if (select_5_value !== (select_5_value = $.get(editCategory))) {
									(
										select_5.value = (select_5.__value = $.get(editCategory)) ?? '',
										$.select_option(select_5, $.get(editCategory))
									);
								}

								select_6.disabled = !$.get(editCategory);
							});

							$.event('change', select_5, changeEditCategory);

							$.bind_select_value(
								select_6,
								function get() {
									return $.get(editSubcategory);
								},
								function set($$value) {
									$.set(editSubcategory, $$value);
								}
							);

							$.bind_select_value(
								select_7,
								function get() {
									return $.get(editMerchantId);
								},
								function set($$value) {
									$.set(editMerchantId, $$value);
								}
							);

							$.bind_select_value(
								select_8,
								function get() {
									return $.get(editAccountId);
								},
								function set($$value) {
									$.set(editAccountId, $$value);
								}
							);

							$.append($$anchor, fragment_68);
						};

						$.add_svelte_meta(
							() => $.if(
								node_151,
								($$render) => {
									if ($.strict_equals($.get(optionsStatus), 'error')) $$render(consequent_116); else $$render(alternate_53, false);
								},
								true
							),
							'if',
							Home,
							263,
							703
						);
					}

					$.append($$anchor, fragment_67);
				};

				$.add_svelte_meta(
					() => $.if(node_150, ($$render) => {
						if ($.strict_equals($.get(optionsStatus), 'loading')) $$render(consequent_115); else $$render(alternate_54, false);
					}),
					'if',
					Home,
					263,
					593
				);
			}

			var node_156 = $.sibling(node_150);

			{
				var consequent_117 = ($$anchor) => {
					var p_54 = root_221();
					var text_192 = $.child(p_54, true);

					$.reset(p_54);
					$.template_effect(() => $.set_text(text_192, $.get(actionError)));
					$.append($$anchor, p_54);
				};

				$.add_svelte_meta(
					() => $.if(node_156, ($$render) => {
						if ($.get(actionError)) $$render(consequent_117);
					}),
					'if',
					Home,
					263,
					1712
				);
			}

			var div_146 = $.sibling(node_156);
			var button_112 = $.child(div_146);
			var button_113 = $.sibling(button_112);
			var text_193 = $.child(button_113, true);

			$.reset(button_113);
			$.reset(div_146);
			$.reset(section_40);
			$.reset(div_145);

			$.template_effect(
				($0) => {
					$.set_attribute(input_46, 'max', $0);
					button_113.disabled = $.get(saving) || $.strict_equals($.get(optionsStatus), 'ready', false);
					$.set_text(text_193, $.get(saving) ? 'Saving…' : 'Save changes');
				},
				[
					() => ($.untrack(() => new Date().toISOString().slice(0, 10)))
				]
			);

			$.event('click', button_111, () => $.set(editing, null));

			$.bind_value(
				input_45,
				function get() {
					return $.get(editAmount);
				},
				function set($$value) {
					$.set(editAmount, $$value);
				}
			);

			$.bind_value(
				input_46,
				function get() {
					return $.get(editDate);
				},
				function set($$value) {
					$.set(editDate, $$value);
				}
			);

			$.event('click', button_112, () => $.set(editing, null));
			$.event('click', button_113, saveEdit);
			$.append($$anchor, div_145);
		};

		$.add_svelte_meta(
			() => $.if(node_149, ($$render) => {
				if ($.get(editing)) $$render(consequent_118);
			}),
			'if',
			Home,
			263,
			0
		);
	}

	var node_157 = $.sibling(node_149, 2);

	{
		var consequent_119 = ($$anchor) => {
			var div_147 = root_222();
			var section_41 = $.child(div_147);
			var h2_17 = $.sibling($.child(section_41));
			var text_194 = $.child(h2_17);

			$.reset(h2_17);

			var div_148 = $.sibling(h2_17, 2);
			var button_114 = $.child(div_148);
			var button_115 = $.sibling(button_114);

			$.reset(div_148);
			$.reset(section_41);
			$.reset(div_147);

			$.template_effect(($0) => $.set_text(text_194, `Delete ${$0 ?? ''}?`), [
				() => ($.get(deleting), $.untrack(() => merchant($.get(deleting))))
			]);

			$.event('click', button_114, () => $.set(deleting, null));
			$.event('click', button_115, confirmDelete);
			$.append($$anchor, div_147);
		};

		$.add_svelte_meta(
			() => $.if(node_157, ($$render) => {
				if ($.get(deleting)) $$render(consequent_119);
			}),
			'if',
			Home,
			264,
			0
		);
	}

	var node_158 = $.sibling(node_157, 2);

	{
		var consequent_121 = ($$anchor) => {
			var div_149 = root_223();
			var section_42 = $.child(div_149);
			var button_116 = $.child(section_42);
			var p_55 = $.sibling(button_116, 3);
			var text_195 = $.child(p_55);

			$.reset(p_55);

			var node_159 = $.sibling(p_55);

			{
				var consequent_120 = ($$anchor) => {
					var a_1 = root_224();

					$.template_effect(() => $.set_attribute(a_1, 'href', ($.get(handoff), $.untrack(() => $.get(handoff).whatsappUrl))));
					$.append($$anchor, a_1);
				};

				$.add_svelte_meta(
					() => $.if(node_159, ($$render) => {
						if (($.get(handoff), $.untrack(() => $.get(handoff).whatsappUrl))) $$render(consequent_120);
					}),
					'if',
					Home,
					265,
					337
				);
			}

			var button_117 = $.sibling(node_159);

			$.reset(section_42);
			$.reset(div_149);

			$.template_effect(($0) => $.set_text(text_195, `Send the missing transaction for ${$0 ?? ''}.`), [
				() => (
					$.get(handoff),
					$.untrack(() => dateLabel(`${$.get(handoff).date}T12:00:00`))
				)
			]);

			$.event('click', button_116, () => $.set(handoff, null));
			$.event('click', button_117, () => $.set(handoff, null));
			$.append($$anchor, div_149);
		};

		$.add_svelte_meta(
			() => $.if(node_158, ($$render) => {
				if ($.get(handoff)) $$render(consequent_121);
			}),
			'if',
			Home,
			265,
			0
		);
	}

	$.append($$anchor, fragment);

	return $.pop($$exports);
}

if (import.meta.hot) {
	Home = $.hmr(Home, () => Home[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = Home[$.HMR].source;
		$.set(Home[$.HMR].source, module.default[$.HMR].original);
	});
}

export default Home;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7O09BRVMsa0JBQWtCO09BQ2xCLCtCQUErQjtTQUM3QixPQUFPLEVBQUUsSUFBSSxRQUFRLFFBQVE7OztDQUM3QixRQUFRO0NBQUUsY0FBYztDQUFFLDJCQUEyQjtDQUFFLG9CQUFvQjtDQUFFLHVCQUF1QjtDQUFFLGdCQUFnQjtDQUFFLFVBQVU7Q0FBRSx3QkFBd0I7Q0FBRSxnQkFBZ0I7Q0FBRSx1QkFBdUI7Q0FBRSxtQkFBbUI7Q0FBRSxXQUFXO0NBQUUsc0JBQXNCO0NBQUUseUJBQXlCO0NBQUUsYUFBYTtDQUFFLFVBQVU7Q0FBRSxnQkFBZ0I7Q0FBRSx5QkFBeUI7Q0FBRSxXQUFXO0NBQUUsVUFBVTtDQUFFLG1CQUFtQjtDQUFFLGNBQWM7Q0FBRSxpQkFBaUI7Q0FBRSxrQkFBa0I7Q0FBRSxnQkFBZ0I7Q0FBRSxjQUFjO0NBQUUsUUFBUTtDQUFFLGFBQWE7Q0FBRSxjQUFjO0NBQUUsNkJBQTZCO0NBQUUsdUJBQXVCO0NBQUUsUUFBUTtDQUFFLFNBQVM7Q0FBRSxNQUFNO0NBQUUsZUFBZTtDQUFFLHVCQUF1QjtDQUFFLGlCQUFpQjtDQUFFLGlCQUFpQjtDQUFFLFlBQVk7Q0FBRSxnQkFBZ0I7Q0FBRSxhQUFhO0NBQUUsVUFBVTtDQUFFLHlCQUF5QjtDQUFFLG1CQUFtQjtDQUFFLDJCQUEyQjtPQUFRLGNBQWM7O09BQ3oxQixZQUFZLE1BQU0sdUJBQXVCO09BQ3pDLGFBQWEsTUFBTSx3QkFBd0I7T0FDM0MsU0FBUyxNQUFNLCtCQUErQjtPQUM5QyxTQUFTLE1BQU0sK0JBQStCO09BQzlDLFdBQVcsTUFBTSxpQ0FBaUM7T0FDbEQsZUFBZSxNQUFNLHFDQUFxQztPQUMxRCxhQUFhLE1BQU0sbUNBQW1DO09BQ3RELGVBQWUsTUFBTSwyQ0FBMkM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQWJ6RSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBY1ksZUFBZTtLQUFhLGFBQWE7S0FBYSxjQUFjO0tBQWEsYUFBYTtLQUFhLGdCQUFnQjtLQUFhLGNBQWM7S0FBYSxRQUFRO0tBQWEsZ0JBQWdCO0tBQWEsYUFBYTtLQUFhLGVBQWU7S0FBYSxhQUFhO0tBQWEsY0FBYztLQUFhLGlCQUFpQjtLQUFhLFFBQVE7S0FFN1csSUFBSSxvQkFBQyxNQUFNO0tBQUUsU0FBUyxvQkFBQyxLQUFLO0tBQUUsaUJBQWlCLG9CQUFDLEtBQUs7S0FBRSxXQUFXLG9CQUFDLElBQUk7S0FBRSxXQUFXLG9CQUFDLFFBQVE7S0FBRSxRQUFRO0tBQUssU0FBUyxvQkFBQyxNQUFNO0tBQUUsT0FBTyxvQkFBQyxLQUFLO0tBQUUsVUFBVSxvQkFBQyxJQUFJO0tBQzVKLFdBQVcsb0JBQUMsSUFBSTtLQUFFLE9BQU8sb0JBQUMsSUFBSTtLQUFFLGFBQWEsb0JBQUMsS0FBSztLQUFFLFdBQVcsb0JBQUMsRUFBRTtLQUFFLFVBQVUsb0JBQUMsS0FBSztLQUFFLFlBQVksb0JBQUMsRUFBRTtLQUFFLGFBQWEsb0JBQUMsS0FBSztLQUFFLFNBQVMsb0JBQUMsRUFBRTtLQUFFLFVBQVUsb0JBQUMsQ0FBQztLQUFFLGVBQWUsb0JBQUMsSUFBSTtLQUFFLGlCQUFpQixvQkFBQyxLQUFLO0tBQUUsV0FBVyxvQkFBQyxLQUFLO0tBQUUsY0FBYyxvQkFBQyxDQUFDO0tBQUUsZ0JBQWdCLG9CQUFDLENBQUM7S0FBRSxtQkFBbUIsb0JBQUMsSUFBSTtLQUN6UixlQUFlLG9CQUFDLFNBQVM7S0FDekIsT0FBTyxvQkFBQyxJQUFJO0tBQUUsVUFBVSxvQkFBQyxFQUFFO0tBQUUsUUFBUSxvQkFBQyxFQUFFO0tBQUUsWUFBWSxvQkFBQyxFQUFFO0tBQUUsZUFBZSxvQkFBQyxFQUFFO0tBQUUsY0FBYyxvQkFBQyxFQUFFO0tBQUUsYUFBYSxvQkFBQyxFQUFFO0tBQUUsTUFBTSxvQkFBQyxLQUFLO0tBQUUsUUFBUSxvQkFBQyxJQUFJO0tBQy9JLFdBQVcsc0JBQUUsVUFBVSxNQUFJLFNBQVMsTUFBSSxRQUFRO0tBQU0sYUFBYSxvQkFBQyxNQUFNO0tBQUUsWUFBWSxvQkFBQyxFQUFFO0tBQzNGLGFBQWEsS0FBRSxRQUFRLEVBQUMsSUFBSSxFQUFDLFdBQVcsRUFBQyxJQUFJLEVBQUMsUUFBUSxFQUFDLElBQUk7S0FDM0QsWUFBWSxvQkFBQyxLQUFLO0tBQUUsU0FBUyxvQkFBQyxFQUFFO0tBQUUsVUFBVSxvQkFBQyxNQUFNO0tBQUUsYUFBYSxvQkFBQyxJQUFJO0tBQUUsVUFBVSxvQkFBQyxLQUFLO0tBQUUsY0FBYyxvQkFBQyxJQUFJO0tBQUUsZUFBZSxvQkFBQyxLQUFLOztLQUNySSxRQUFRO0VBQUUsUUFBUSxFQUFDLEVBQUU7RUFBQyxRQUFRLEVBQUMsTUFBTTtFQUFDLFVBQVUsRUFBQyxFQUFFO0VBQUMsaUJBQWlCLEVBQUMsRUFBRTtFQUFDLGdCQUFnQixFQUFDLEVBQUU7RUFBQyxpQkFBaUIsRUFBQyxFQUFFO0VBQUMsZUFBZSxFQUFDLEVBQUU7RUFBQyxLQUFLLEVBQUMsRUFBRTs7O0tBQzdJLEtBQUs7S0FDTCxXQUFXLG9CQUFDLElBQUk7S0FBRSxpQkFBaUIsb0JBQUMsTUFBTTtLQUFFLGdCQUFnQixvQkFBQyxFQUFFO0tBQy9ELFdBQVc7S0FBSyxnQkFBZ0Isb0JBQUMsTUFBTTtLQUFFLGVBQWUsb0JBQUMsRUFBRTtLQUFFLGtCQUFrQixvQkFBQyxLQUFLO0tBQUUsZ0JBQWdCLG9CQUFDLEtBQUs7S0FBRSxtQkFBbUIsb0JBQUMsSUFBSTtLQUFFLG9CQUFvQixvQkFBQyxJQUFJO0tBQUUsc0JBQXNCLEdBQUMsSUFBSTtLQUMvTCxpQkFBaUIsb0JBQUMsSUFBSTtLQUFFLHVCQUF1QixvQkFBQyxNQUFNO0tBQUUsc0JBQXNCLG9CQUFDLEVBQUU7O0tBQ2pGLGNBQWM7RUFBRSxLQUFLLEVBQUMsRUFBRTtFQUFDLGNBQWMsRUFBQyxFQUFFO0VBQUMsTUFBTSxFQUFDLEVBQUU7RUFBQyxVQUFVLEVBQUMsT0FBTzs7O0tBQ3ZFLFdBQVc7S0FBSyxnQkFBZ0Isb0JBQUMsTUFBTTtLQUFFLGVBQWUsb0JBQUMsRUFBRTtLQUFFLGtCQUFrQixvQkFBQyxLQUFLO0tBQUUsZ0JBQWdCLG9CQUFDLEtBQUs7S0FBRSxtQkFBbUIsb0JBQUMsSUFBSTs7S0FDdkksY0FBYztFQUFFLGtCQUFrQixFQUFDLEVBQUU7RUFBQyxRQUFRLEVBQUMsRUFBRTtFQUFDLFVBQVUsRUFBQyxFQUFFO0VBQUMsWUFBWSxFQUFDLEVBQUU7RUFBQyxNQUFNLEVBQUMsRUFBRTs7O0tBQ3pGLG9CQUFvQixvQkFBQyxLQUFLO0tBQUUsZ0JBQWdCO0tBQUssc0JBQXNCLG9CQUFDLE1BQU07S0FBRSxrQkFBa0Isb0JBQUMsSUFBSTtLQUN2RyxhQUFhLHNCQUFFLE1BQU0sRUFBQyxJQUFJO0tBQUcsWUFBWSxvQkFBQyxNQUFNO0tBQUUsV0FBVyxvQkFBQyxFQUFFO0tBQUUsWUFBWSxvQkFBQyxLQUFLO0tBQUUsY0FBYyxvQkFBQyxLQUFLOztLQUMxRyxVQUFVO0VBQUUsZ0JBQWdCLEVBQUMsT0FBTztFQUFDLFdBQVcsRUFBQyxzQkFBc0I7RUFBQyxrQkFBa0IsRUFBQyxFQUFFO0VBQUMsZUFBZSxFQUFDLFNBQVM7OztLQUN2SCxrQkFBa0Isb0JBQUMsS0FBSztLQUFFLFdBQVcsb0JBQUMsRUFBRTtLQUFFLGNBQWMsb0JBQUMsS0FBSztLQUFFLGNBQWMsb0JBQUMsSUFBSTtLQUFFLFNBQVMsb0JBQUMsRUFBRTtLQUFFLFNBQVMsb0JBQUMsS0FBSztLQUFFLFVBQVUsb0JBQUMsS0FBSztLQUFFLGtCQUFrQixvQkFBQyxNQUFNO0tBQUUsYUFBYTtLQUFLLG1CQUFtQixHQUFDLENBQUM7S0FDeE0sV0FBVztLQUFLLGdCQUFnQixvQkFBQyxNQUFNO0tBQUUsZUFBZSxvQkFBQyxFQUFFO0tBQUUsb0JBQW9CLG9CQUFDLElBQUk7S0FDdEYsTUFBTTtLQUFLLFdBQVcsb0JBQUMsTUFBTTtLQUFFLFVBQVUsb0JBQUMsRUFBRTtLQUFFLGFBQWEsb0JBQUMsS0FBSztLQUFFLFVBQVUsb0JBQUMsRUFBRTtLQUFFLGFBQWEsb0JBQUMsSUFBSTtLQUFFLFlBQVk7S0FBSyxpQkFBaUIsb0JBQUMsTUFBTTtLQUFFLGtCQUFrQixHQUFDLENBQUM7S0FBRSxXQUFXLG9CQUFDLEtBQUs7S0FBRSxlQUFlLG9CQUFDLElBQUk7S0FDOU0sZUFBZSxvQkFBQyxJQUFJO0tBQUMsYUFBYSxzQkFBRSxNQUFNLEVBQUMsRUFBRSxFQUFDLEdBQUcsRUFBQyxFQUFFLEVBQUMsVUFBVSxFQUFDLEVBQUU7S0FBRSxlQUFlLG9CQUFDLEtBQUs7S0FBQywyQkFBMkIsb0JBQUMsSUFBSTtLQUFDLHFCQUFxQixzQkFBRSxNQUFNLEVBQUMsRUFBRSxFQUFDLEtBQUssRUFBQyxFQUFFO0tBQUUsV0FBVyxvQkFBQyxJQUFJO0tBQUMsaUJBQWlCLG9CQUFDLE1BQU07S0FBQyxrQkFBa0Isb0JBQUMsSUFBSTtLQUN2TyxTQUFTLHNCQUFFLFFBQVEsRUFBQyxFQUFFLEVBQUMsYUFBYSxFQUFDLEVBQUU7S0FDdkMsT0FBTztLQUFLLGFBQWEsR0FBQyxNQUFNO0tBQUUsWUFBWSxHQUFDLEVBQUU7S0FBRSxrQkFBa0Isb0JBQUMsSUFBSTtLQUFFLGlCQUFpQixvQkFBQyxJQUFJO0tBQUUsaUJBQWlCLEdBQUMsSUFBSTtLQUMxSCxhQUFhLG9CQUFDLElBQUk7S0FBRSxlQUFlLG9CQUFDLEVBQUU7S0FBRSxnQkFBZ0Isb0JBQUMsS0FBSzs7S0FBRSxjQUFjO0VBQUUsTUFBTSxFQUFDLEVBQUU7RUFBQyxlQUFlLE1BQUssSUFBSSxHQUFHLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFDLEVBQUU7RUFBRSxHQUFHLEVBQUMsRUFBRTs7O0tBQ3JKLFVBQVUsb0JBQUMsSUFBSTtLQUFFLGdCQUFnQixvQkFBQyxNQUFNO0tBQUUsZUFBZSxvQkFBQyxFQUFFO0tBQUUsV0FBVyxvQkFBQyxJQUFJO0tBQUUsYUFBYSxvQkFBQyxLQUFLO0tBQUUsWUFBWSxvQkFBQyxFQUFFO0tBQUUsV0FBVyxzQkFBRSxNQUFNLEVBQUMsRUFBRSxFQUFDLGVBQWUsRUFBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEVBQUU7S0FDdEssc0JBQXNCLG9CQUFDLElBQUk7S0FBRSxxQkFBcUIsb0JBQUMsS0FBSztLQUFFLG9CQUFvQixvQkFBQyxFQUFFO0tBQUUsbUJBQW1CLHNCQUFFLE1BQU0sRUFBQyxFQUFFLEVBQUMsZUFBZSxFQUFDLEVBQUUsRUFBQyxHQUFHLEVBQUMsRUFBRTtPQUN6SSx1QkFBdUIsR0FBQyxzQ0FBc0M7O0tBQ2hFLFFBQVE7RUFBRSxNQUFNLEVBQUMsS0FBSztFQUFDLFNBQVMsRUFBQyxPQUFPO0VBQUMsT0FBTyxFQUFDLEdBQUc7RUFBQyxVQUFVLEVBQUMsU0FBUztFQUFDLFVBQVUsRUFBQyxLQUFLO0VBQUMsWUFBWSxFQUFDLFNBQVM7RUFBQyxhQUFhLEVBQUMsT0FBTzs7O0tBQ3ZJLGFBQWEsb0JBQUMsSUFBSTtLQUFFLFdBQVcsc0JBQUUsTUFBTSxFQUFDLEVBQUUsRUFBQyxHQUFHLEVBQUMsRUFBRSxFQUFDLFVBQVUsRUFBQyxFQUFFO0tBQUcsYUFBYSxvQkFBQyxLQUFLOztPQWVuRixLQUFLLElBQUMsS0FBSyxTQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTztFQUFFLEtBQUssRUFBQyxVQUFVO0VBQUMsUUFBUSxRQUFSLFFBQVE7RUFBQyxxQkFBcUIsRUFBQyxDQUFDO0lBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUUsQ0FBQzs7T0FDdEgsWUFBWSxJQUFDLEtBQUssU0FBTSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU87RUFBRSxLQUFLLEVBQUMsVUFBVTtFQUFDLFFBQVEsUUFBUixRQUFRO0VBQUMscUJBQXFCLEVBQUMsQ0FBQztFQUFDLHFCQUFxQixFQUFDLENBQUM7SUFBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBRSxDQUFDOztPQUNySixZQUFZLElBQUMsS0FBSyxTQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTztFQUFFLEtBQUssRUFBQyxVQUFVO0VBQUMsUUFBUSxRQUFSLFFBQVE7RUFBQyxRQUFRLEVBQUMsU0FBUztFQUFDLHFCQUFxQixFQUFDLENBQUM7SUFBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBRSxDQUFDOztPQUNoSixZQUFZLElBQUMsSUFBSSxNQUFFLFNBQVMsRUFBQyxJQUFJLENBQUMsSUFBSSxJQUFFLHNCQUFzQixHQUFDLGlCQUFpQjtPQUFRLFVBQVUsSUFBQyxFQUFFLE1BQUcsT0FBTyxFQUFDLE1BQU0sRUFBQyxRQUFRLEVBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFFLElBQUUsQ0FBQyxJQUFFLENBQUM7T0FDdkosUUFBUSxJQUFDLElBQUksS0FBRSxJQUFJLENBQUMsUUFBUSxJQUFFLElBQUksQ0FBQyxZQUFZLElBQUUsSUFBSSxDQUFDLFdBQVcsSUFBRSxJQUFJLENBQUMsZUFBZSxJQUFFLFNBQVM7T0FBUSxRQUFRLElBQUMsSUFBSSxLQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxJQUFFLElBQUksQ0FBQyxRQUFRLElBQUUsZUFBZTtPQUFRLGVBQWUsSUFBQyxJQUFJLEtBQUUsSUFBSSxDQUFDLGVBQWUsSUFBRSxJQUFJLENBQUMsZUFBZSxJQUFFLElBQUksQ0FBQyxJQUFJOztPQUMvUCxTQUFTLElBQUMsS0FBSyxLQUFFLEtBQUs7UUFBSyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsSUFBRSxHQUFHLEVBQUMsU0FBUyxFQUFDLEtBQUssRUFBQyxPQUFPLElBQUcsTUFBTSxLQUFLLElBQUksQ0FBQyxLQUFLO0lBQUcsRUFBRTs7T0FDbEgsVUFBVSxJQUFDLEtBQUssS0FBRSxDQUFDO1NBQU0sQ0FBQyxFQUFDLENBQUMsSUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsTUFBTTs7YUFBYSxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsSUFBRSxLQUFLLEVBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxTQUFTLElBQUcsTUFBTSxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUM7Q0FBRyxDQUFDOztPQUM1SixRQUFRLGFBQVMsSUFBSSxHQUFHLFFBQVEsS0FBRyxFQUFFO0lBQUMsY0FBYztRQUFLLElBQUksR0FBRyxRQUFRLEtBQUcsRUFBRSxHQUFDLGdCQUFnQixHQUFDLGNBQWM7O09BQVEsT0FBTyxJQUFDLEdBQUcsUUFBSyxhQUFhLE1BQUksTUFBTSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFDLEdBQUc7T0FDaEwsT0FBTyxJQUFDLEtBQUssS0FBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUMsQ0FBQztPQUFRLFNBQVMsSUFBQyxLQUFLLEtBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUUsS0FBSyxDQUFDLElBQUksSUFBRSxhQUFhLEVBQUUsVUFBVSxDQUFDLEdBQUcsRUFBQyxHQUFHO09BQVMsU0FBUyxJQUFDLEtBQUssS0FBRSxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBRSxNQUFNO09BQVEsYUFBYSxJQUFDLEtBQUssS0FBRSxLQUFLLENBQUMsUUFBUSxNQUFHLE9BQU8sRUFBQyxhQUFhLEVBQUMsWUFBWSxFQUFDLE1BQU0sRUFBQyxLQUFLLEVBQUMsTUFBTTtPQUFTLFdBQVcsSUFBQyxLQUFLLEtBQUUsS0FBSyxDQUFDLE1BQU0sSUFBRSxLQUFLLENBQUMsTUFBTSxxQkFBRyxLQUFLLENBQUMsU0FBUyxFQUFHLG9CQUFvQixJQUFDLFVBQVUsR0FBQyxVQUFVO09BQzdhLFlBQVksSUFBQyxLQUFLLHFCQUFFLEtBQUssRUFBRSxTQUFTLEVBQUcsb0JBQW9CO09BQVEsU0FBUyxJQUFDLEtBQUssS0FBRSxZQUFZLENBQUMsS0FBSyxJQUFFLElBQUksR0FBQyxFQUFFO09BQVEsWUFBWSxJQUFDLEtBQUssS0FBRSxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU87O1VBQ3BLLGtCQUFrQixDQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsZUFBZSxFQUFDLEtBQUs7O01BQUksQ0FBQztHQUFBLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0NBQWdDLEVBQUMsS0FBSztFQUFFLENBQUMsT0FBSyxDQUFDLENBQUM7Q0FBQTs7VUFHekgsY0FBYyxDQUFDLEtBQUssRUFBQyxDQUFDO09BQUksS0FBSyxTQUFRLEVBQUU7O1FBQU8sSUFBSSxHQUFDLE1BQU0sQ0FBQyxLQUFLOztPQUFLLHFCQUFxQixFQUFDLElBQUksQ0FBQyxJQUFJLFVBQVMsSUFBSTs7UUFBTyxJQUFJLE9BQUssSUFBSSxDQUFDLElBQUk7O1NBQVMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTztLQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLEVBQUU7UUFBSyxJQUFJLENBQUMsV0FBVyxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxLQUFHLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFDLEdBQUcsS0FBSyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxRQUFRLENBQUMsQ0FBQyxFQUFDLEdBQUc7Q0FBSTs7VUFDalQsV0FBVyxDQUFDLEtBQUssRUFBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLENBQUM7UUFBTSxJQUFJLEdBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFFLENBQUMsRUFBQyxDQUFDLE1BQUksQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLEdBQUcsS0FBSztRQUFRLFFBQVEsR0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sR0FBRyxJQUFJLEVBQUUsTUFBTSxLQUFHLEtBQUssRUFBRSxRQUFROztRQUFPLEdBQUcsR0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVE7S0FBRSxRQUFRO0tBQUMsUUFBUSxFQUFFLFlBQVksSUFBRSxRQUFRLEVBQUUsS0FBSyxJQUFFLEtBQUssRUFBRSxZQUFZOztTQUFZLEdBQUcsQ0FBQyxHQUFHLEVBQUMsSUFBSSxLQUFFLENBQUM7VUFBTSxNQUFNLEVBQUMsRUFBRSxJQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFFLElBQUksQ0FBQyxFQUFFLElBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxHQUFHOzs7SUFBUyxVQUFVLEVBQUMsTUFBTTtJQUFDLFFBQVEsRUFBQyxFQUFFO0lBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxhQUFhLElBQUUsSUFBSSxDQUFDLFFBQVEsSUFBRSxJQUFJLENBQUMsWUFBWSxJQUFFLElBQUksQ0FBQyxXQUFXLElBQUUsU0FBUztJQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsYUFBYSxJQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxJQUFFLElBQUksQ0FBQyxRQUFRLElBQUUsZUFBZTtJQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsZ0JBQWdCLElBQUUsSUFBSSxDQUFDLE1BQU0sSUFBRSxFQUFFO0lBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxlQUFlLElBQUUsSUFBSSxDQUFDLGVBQWUsSUFBRSxJQUFJLENBQUMsSUFBSTtJQUFFLE1BQU0sRUFBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksSUFBRSxJQUFJLENBQUMsYUFBYSxJQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTTs7RUFBRSxDQUFDO0NBQUU7O1VBQy94QixZQUFZLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBTSxLQUFLLE9BQUssSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlOztNQUFnQixNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLFlBQVcsSUFBSTs7UUFBTyxNQUFNLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsS0FBRyxDQUFDO0dBQUMsR0FBRyxHQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLElBQUksQ0FBQyxpQkFBaUIsR0FBQyxDQUFDO0dBQUMsU0FBUyxHQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLElBQUksQ0FBQyxpQkFBaUIsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxNQUFNLEdBQUMsR0FBRztHQUFFLFFBQVEsT0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsSUFBRyxLQUFLLENBQUMsUUFBUSxLQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLE1BQU0sR0FBQyxDQUFDLEdBQUUsS0FBSyxDQUFDLE9BQU87OztHQUFXLEdBQUc7R0FBQyxTQUFTO0dBQUMsTUFBTTtHQUFDLE9BQU8sRUFBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUMsTUFBTSxHQUFDLEdBQUcsSUFBRSxDQUFDO0dBQUMsUUFBUSxNQUFLLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxJQUFFLEtBQUssRUFBQyxPQUFPLEVBQUMsSUFBSSxFQUFDLFNBQVMsSUFBRyxNQUFNLENBQUMsUUFBUTs7Q0FBRzs7VUFDamxCLGtCQUFrQixDQUFDLE1BQU0sRUFBQyxDQUFDO3NCQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUcsMkJBQTJCLEdBQUMsQ0FBQztTQUFNLFNBQVMsR0FBQyxNQUFNLENBQUMsdUJBQXVCO1VBQUssSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLElBQUUsR0FBRyxFQUFDLFNBQVMsRUFBQyxLQUFLLEVBQUMsT0FBTyxFQUFDLElBQUksRUFBQyxTQUFTLElBQUcsTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLENBQUMsdUJBQXVCO01BQWMsRUFBRTs7U0FBTyxXQUFXLElBQUUsTUFBTSxDQUFDLFdBQVcsc0NBQW9DLFNBQVMsS0FBSyxPQUFPLENBQUMsTUFBTSxDQUFDLHVCQUF1QixJQUFFLEVBQUUsRUFBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLHFEQUFxRCxFQUFDLEVBQUU7OztJQUFTLEtBQUssRUFBQywyQkFBMkI7SUFBQyxXQUFXO0lBQUMsR0FBRyxFQUFDLGFBQWE7O0VBQUUsQ0FBQzs7U0FBTyxJQUFJO0NBQUM7O09BQ3ZqQixvQkFBb0IsWUFBUSx1QkFBdUIsSUFBSSxRQUFRLEtBQUMsTUFBTSxHQUFDLE1BQU07O1VBQzFFLHFCQUFxQixHQUFFLENBQUM7TUFBRyxDQUFDO1NBQU0sTUFBTSxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsT0FBSyxNQUFNOztRQUFNLE1BQU0sU0FBUSxLQUFLOztPQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRSxDQUFDO1VBQUEsS0FBSyxFQUFDLE1BQU0sQ0FBQyxLQUFLO1VBQUMsVUFBVSxFQUFDLE9BQU87R0FBQyxDQUFDOztPQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFdBQVcsR0FBRSxDQUFDO1VBQUEsV0FBVyxFQUFDLE1BQU0sQ0FBQyxXQUFXO1VBQUMsZ0JBQWdCLEVBQUMsT0FBTztHQUFDLENBQUM7O09BQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFFLENBQUM7VUFBQSxNQUFNLEVBQUMsTUFBTSxDQUFDLE1BQU07VUFBQyxXQUFXLEVBQUMsT0FBTztHQUFDLENBQUM7O1VBQU8sSUFBSTtFQUFDLENBQUMsT0FBSyxDQUFDO1VBQU8sS0FBSztFQUFDLENBQUM7Q0FBQTs7VUFDcFoscUJBQXFCLEdBQUUsQ0FBQztNQUFHLENBQUM7R0FBQSxZQUFZLENBQUMsT0FBTyxDQUFDLG9CQUFvQixJQUFHLElBQUksQ0FBQyxTQUFTO0lBQUUsU0FBUyxNQUFLLElBQUksR0FBRyxXQUFXO0lBQUcsS0FBSyxRQUFMLEtBQUs7SUFBQyxXQUFXLFFBQVgsV0FBVztJQUFDLE1BQU0sUUFBTixNQUFNOztFQUFJLENBQUMsT0FBSyxDQUFDOztFQUE0RCxDQUFDO0NBQUE7O2dCQUNyTixTQUFTLEdBQUUsQ0FBQztRQUFBLFVBQVUsUUFBQyxLQUFLLEVBQUMsTUFBTSxHQUFDLFlBQVksR0FBQyxTQUFTOztNQUFJLENBQUM7U0FBTSxNQUFNLGtDQUFPLFFBQVE7O1NBQUcsS0FBSyxFQUFDLE1BQU0sQ0FBQyxLQUFLO1NBQUssVUFBVSxFQUFDLE9BQU87R0FBQyxxQkFBcUI7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7YUFBRyxLQUFLLEVBQUMsTUFBTSxFQUFDLENBQUM7VUFBQSxVQUFVLEVBQUMsT0FBTzs7O0dBQVEsQ0FBQzs7U0FBQSxVQUFVLEVBQUMsT0FBTztTQUFDLFNBQVMsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLHVCQUF1QjtFQUFDLENBQUM7Q0FBQTs7Z0JBQy9SLGVBQWUsR0FBRSxDQUFDO1FBQUEsZ0JBQWdCLEVBQUMsU0FBUztRQUFDLGVBQWUsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBTSxNQUFNLGtDQUFPLHVCQUF1Qjs7U0FBRyxXQUFXLEVBQUMsTUFBTSxDQUFDLEtBQUs7U0FBSyxnQkFBZ0IsRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsT0FBTztTQUFDLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDZCQUE2QjtFQUFDLENBQUM7Q0FBQTs7VUFDblIsa0JBQWtCLENBQUMsSUFBSSxHQUFDLElBQUksRUFBQyxDQUFDO1FBQU0sZUFBZSxHQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUUsZ0JBQWdCLElBQUksSUFBSTs7UUFBRSxlQUFlLEVBQUMsRUFBRTtRQUFDLG1CQUFtQixFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsRUFBRSxHQUFDLElBQUk7O1FBQUMsY0FBYyxFQUFDLElBQUk7O0lBQUUsS0FBSyxFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLFFBQVEsQ0FBQyxJQUFJO0lBQUUsY0FBYyxFQUFDLE1BQU0sQ0FBQyxlQUFlLEdBQUMsSUFBSSxDQUFDLGNBQWMsR0FBQyxJQUFJLENBQUMsTUFBTSxJQUFFLEVBQUU7O0lBQUUsTUFBTSxFQUFDLE1BQU0sQ0FBQyxlQUFlO09BQUMsSUFBSSxDQUFDLE1BQU0sSUFBRSxFQUFFO1dBQUssSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEdBQUcsT0FBTyxNQUFJLEVBQUU7O0lBQUUsVUFBVSxFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLE9BQU8sR0FBQyxPQUFPO09BQUssZUFBZSxVQUFLLG1CQUFtQixFQUFDLElBQUksQ0FBQyxFQUFFOzs7SUFBSyxLQUFLLEVBQUMsRUFBRTtJQUFDLGNBQWMsRUFBQyxFQUFFO0lBQUMsTUFBTSxFQUFDLEVBQUU7SUFBQyxVQUFVLEVBQUMsT0FBTzs7O1FBQUUsa0JBQWtCLEVBQUMsSUFBSTtDQUFDOztnQkFDNWtCLGNBQWMsR0FBRSxDQUFDO1FBQU0sY0FBYyxHQUFDLE1BQU0sT0FBQyxjQUFjLEVBQUMsY0FBYztHQUFFLE1BQU0sU0FBQyxjQUFjLEVBQUMsTUFBTSxHQUFDLE1BQU0sT0FBQyxjQUFjLEVBQUMsTUFBTSxJQUFFLElBQUk7O2FBQUssY0FBYyxFQUFDLEtBQUssQ0FBQyxJQUFJLFFBQU0sY0FBYyxHQUFDLENBQUMscUJBQUcsTUFBTSxFQUFHLElBQUksYUFBRyxNQUFNLEdBQUMsQ0FBQyxJQUFFLE1BQU0sR0FBQyxFQUFFLEdBQUUsQ0FBQztTQUFBLGVBQWUsRUFBQywrRUFBK0U7OztFQUFRLENBQUM7O1FBQUEsZ0JBQWdCLEVBQUMsSUFBSTs7TUFBSSxDQUFDO1NBQU0sT0FBTzthQUFLLGNBQWM7SUFBQyxLQUFLLFFBQUMsY0FBYyxFQUFDLEtBQUssQ0FBQyxJQUFJO0lBQUcsY0FBYztJQUFDLE1BQU07SUFBQyxjQUFjLEVBQUMsYUFBYTs7OzZCQUFLLG1CQUFtQixHQUFHLElBQUksaUJBQVEsT0FBTyxDQUFDLG1CQUFtQjs7d0RBQVEsbUJBQW1CLEdBQUcsSUFBSTtNQUFDLHlCQUF5QixDQUFDLE9BQU87TUFBRSx5QkFBeUIsT0FBQyxtQkFBbUIsR0FBQyxPQUFPOztTQUFHLGtCQUFrQixFQUFDLEtBQUs7a0NBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxlQUFlLElBQUcsY0FBYztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGlDQUFpQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Z0JBQ2oyQixnQkFBZ0IsQ0FBQyxVQUFVLEVBQUMsQ0FBQzs0QkFBRyxvQkFBb0IsR0FBRyxJQUFJOztRQUFRLG9CQUFvQixFQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQUMsZUFBZSxFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsRUFBRTtTQUFFLFdBQVcsUUFBQyxXQUFXLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRyxVQUFVLENBQUMsRUFBRTtrQ0FBUSxjQUFjO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsbUNBQW1DO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxvQkFBb0IsRUFBQyxJQUFJO0VBQUMsQ0FBQztDQUFBOztnQkFDdlgsZUFBZSxHQUFFLENBQUM7UUFBQSxnQkFBZ0IsUUFBQyxXQUFXLEVBQUMsTUFBTSxHQUFDLFlBQVksR0FBQyxTQUFTO1FBQUMsZUFBZSxFQUFDLEVBQUU7O01BQUksQ0FBQztTQUFNLE1BQU0sa0NBQU8sY0FBYzs7U0FBRyxXQUFXLEVBQUMsTUFBTSxDQUFDLFdBQVc7U0FBSyxnQkFBZ0IsRUFBQyxPQUFPO0dBQUMscUJBQXFCO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO2FBQUcsV0FBVyxFQUFDLE1BQU0sRUFBQyxDQUFDO1VBQUEsZ0JBQWdCLEVBQUMsT0FBTzs7O0dBQVEsQ0FBQzs7U0FBQSxnQkFBZ0IsRUFBQyxPQUFPO1NBQUMsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsOEJBQThCO0VBQUMsQ0FBQztDQUFBOztnQkFDM1gsVUFBVSxHQUFFLENBQUM7UUFBQSxXQUFXLFFBQUMsTUFBTSxFQUFDLE1BQU0sR0FBQyxZQUFZLEdBQUMsU0FBUztRQUFDLFVBQVUsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBTSxNQUFNLGtDQUFPLFNBQVM7O1NBQUcsTUFBTSxFQUFDLE1BQU0sQ0FBQyxNQUFNO1NBQUssV0FBVyxFQUFDLE9BQU87R0FBQyxxQkFBcUI7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7YUFBRyxNQUFNLEVBQUMsTUFBTSxFQUFDLENBQUM7VUFBQSxXQUFXLEVBQUMsT0FBTzs7O0dBQVEsQ0FBQzs7U0FBQSxXQUFXLEVBQUMsT0FBTztTQUFDLFVBQVUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLHdCQUF3QjtFQUFDLENBQUM7Q0FBQTs7Z0JBQ3pULFdBQVcsR0FBRSxDQUFDO0VBQUEsYUFBYSxTQUFDLE9BQU8sRUFBQyxNQUFNLEdBQUMsWUFBWSxHQUFDLFNBQVM7RUFBQyxZQUFZLEdBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxVQUFVOztTQUFHLE9BQU8sRUFBQyxNQUFNLENBQUMsT0FBTztHQUFLLGFBQWEsR0FBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO0dBQUEsYUFBYSxHQUFDLE9BQU87R0FBQyxZQUFZLEdBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx5QkFBeUI7RUFBQyxDQUFDO0NBQUE7O2dCQUNuUSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUMsQ0FBQzs0QkFBRyxrQkFBa0IsR0FBRyxJQUFJOztRQUFRLGtCQUFrQixFQUFDLE1BQU0sQ0FBQyxFQUFFO0VBQUMsWUFBWSxHQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUU7U0FBRSxPQUFPLFFBQUMsT0FBTyxFQUFDLE1BQU0sRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxFQUFFLEVBQUcsTUFBTSxDQUFDLEVBQUU7a0NBQVEsT0FBTyxDQUFDLEdBQUcsRUFBRSxTQUFTLElBQUcsV0FBVztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztHQUFBLFlBQVksR0FBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGlDQUFpQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsa0JBQWtCLEVBQUMsSUFBSTtFQUFDLENBQUM7Q0FBQTs7VUFDdFcsaUJBQWlCLENBQUMsSUFBSSxFQUFDLEVBQUUsRUFBQyxDQUFDO3NCQUFHLElBQUksRUFBRyxNQUFNLEdBQUMsQ0FBQztTQUFNLElBQUksU0FBQyxLQUFLLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLEVBQUU7O1VBQVUsSUFBSTtPQUFNLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyx5Q0FBeUM7S0FBRyxJQUFJLEVBQUMsR0FBRyxLQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLFdBQVcsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRO0VBQUcsQ0FBQzs7c0JBQUcsSUFBSSxFQUFHLFlBQVksVUFBUSxRQUFRLENBQUMsYUFBYSxxQ0FBcUMsRUFBRTtzQkFBUyxJQUFJLEVBQUcsT0FBTyxVQUFRLFFBQVEsQ0FBQyxhQUFhLDZCQUE2QixFQUFFOztRQUFZLElBQUksR0FBQyxXQUFXLENBQUMsRUFBRTs7U0FBUyxJQUFJO01BQU0sUUFBUSxDQUFDLGdCQUFnQixDQUFDLHFEQUFxRDtJQUFHLElBQUksRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxXQUFZLElBQUksQ0FBQyxVQUFVO0NBQVk7O2dCQUNycEIsZ0JBQWdCLENBQUMsSUFBSSxFQUFDLEVBQUUsRUFBQyxDQUFDO2lDQUFNLElBQUk7cUNBQWEsT0FBTyxFQUFDLE9BQU8sS0FBRSxxQkFBcUIsQ0FBQyxPQUFPOztRQUFTLE1BQU0sR0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUMsRUFBRTs7T0FBTSxNQUFNOztFQUFRLE1BQU0sQ0FBQyxRQUFRLElBQUUsQ0FBQztFQUFDLE1BQU0sQ0FBQyxjQUFjLEdBQUUsUUFBUSxFQUFDLFFBQVEsRUFBQyxLQUFLLEVBQUMsUUFBUTtFQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUUsYUFBYSxFQUFDLElBQUk7Q0FBRzs7Z0JBQzVRLGlCQUFpQixDQUFDLE1BQU0sRUFBQyxDQUFDO1FBQUEsaUJBQWlCLEVBQUMsTUFBTSxDQUFDLFdBQVc7UUFBQyxTQUFTLEVBQUMsSUFBSTtpQ0FBTyxPQUFPLENBQUMsR0FBRyxFQUFFLFNBQVMsSUFBRyxXQUFXO2lDQUFXLGdCQUFnQixDQUFDLE1BQU0sRUFBQyxNQUFNLENBQUMsV0FBVztDQUFFOztnQkFDL0sscUJBQXFCLEdBQUUsQ0FBQztRQUFBLGlCQUFpQixFQUFDLElBQUk7aUNBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxlQUFlLElBQUcsZUFBZTtDQUFLOztnQkFDeEcsZ0JBQWdCLENBQUMsS0FBSyxFQUFDLENBQUM7UUFBTSxTQUFTLFNBQUMsYUFBYSxFQUFDLE1BQU0sRUFBQyxJQUFJLE1BQUUsT0FBTyxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUTs7UUFBUyxPQUFPO01BQUssUUFBUSxDQUFDLGdCQUFnQixDQUFDLDBDQUEwQzs7O1FBQVMsSUFBSSxHQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhOztPQUFPLElBQUk7O1FBQVEsaUJBQWlCLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxJQUFJO2lDQUFPLFNBQVM7aUNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxRQUFRO0NBQUU7O2dCQUM1VyxzQkFBc0IsQ0FBQyxJQUFJLEVBQUMsQ0FBQztFQUFBLGlCQUFpQixHQUFDLElBQUksQ0FBQyxRQUFRO1FBQUMsaUJBQWlCLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxJQUFJO2lDQUFPLFNBQVM7aUNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxRQUFRO0NBQUU7O2dCQUNySyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLGtCQUFrQixFQUFDLElBQUksQ0FBQyxRQUFRO1FBQUMsaUJBQWlCLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxJQUFJO2lDQUFPLFNBQVM7aUNBQVMsZ0JBQWdCLENBQUMsT0FBTyxFQUFDLElBQUksQ0FBQyxRQUFRO0NBQUU7O2dCQUNsSyxzQkFBc0IsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLGlCQUFpQixFQUFDLEtBQUs7UUFBQyxXQUFXLEVBQUMsSUFBSTtpQ0FBTyxTQUFTO2lDQUFTLGdCQUFnQixDQUFDLFlBQVksRUFBQyxJQUFJLENBQUMsUUFBUTtDQUFFOztPQUNwSixtQkFBbUIsSUFBQyxJQUFJLEtBQUUsQ0FBQztRQUFNLEVBQUUsMEJBQVEsSUFBSSxFQUFHLFFBQVEsSUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLElBQUk7UUFBTyxLQUFLLFNBQUMsV0FBVyxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFJLE1BQU0sQ0FBQyxFQUFFLGFBQUksV0FBVyxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUcsSUFBSSxFQUFFLFFBQVE7O1VBQVUsS0FBSywwQkFBRSxXQUFXLEVBQUMsTUFBTSxFQUFHLENBQUMsV0FBRSxXQUFXLEVBQUMsQ0FBQyxJQUFJLGlCQUFpQjtDQUFDLENBQUM7O2dCQUMxUSxrQkFBa0IsQ0FBQyxVQUFVLEVBQUMsQ0FBQztzQkFBRyxzQkFBc0IsRUFBRyxJQUFJOztRQUFjLFVBQVUsR0FBQyxVQUFVLENBQUMsaUJBQWlCOztPQUFLLFVBQVUsRUFBRSxLQUFLOztFQUFRLHNCQUFzQixHQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQUMsZUFBZSxFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSwyQkFBMkIsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFDLFVBQVUsQ0FBQyxLQUFLO2tDQUFRLE9BQU8sQ0FBQyxHQUFHLEVBQUUsZUFBZSxJQUFHLGNBQWM7RUFBSyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxzQ0FBc0M7RUFBQyxDQUFDLFNBQU8sQ0FBQztHQUFBLHNCQUFzQixHQUFDLElBQUk7RUFBQyxDQUFDO0NBQUE7O1VBQ3pjLFFBQVEsQ0FBQyxJQUFJLEVBQUMsQ0FBQzsrQkFBTyxXQUFXLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUksVUFBVSxFQUFFLE1BQU0sRUFBRyxLQUFLO0NBQUM7O1VBQ2xILGNBQWMsQ0FBQyxJQUFJLEVBQUMsQ0FBQzsrQkFBTyxXQUFXLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUksVUFBVSxFQUFFLE1BQU0sRUFBRyxXQUFXO0NBQUM7O1VBQzlILHNCQUFzQixHQUFFLENBQUM7UUFBTSxJQUFJLFNBQUMsV0FBVyxHQUFFLEtBQUssRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFFLENBQUMsRUFBQyxDQUFDLE1BQUksQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLFNBQUcsVUFBVTs7U0FBUyxJQUFJLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBQyxTQUFTLHFCQUFFLFNBQVMsQ0FBQyxLQUFLLEVBQUcsWUFBWSxLQUFFLFNBQVMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLEtBQUs7Q0FBRzs7T0FDaFAsZ0JBQWdCLElBQUMsS0FBSztFQUFJLFdBQVcsRUFBQyxZQUFZO0VBQUMsbUJBQW1CLEVBQUMsV0FBVztFQUFDLG9CQUFvQixFQUFDLFVBQVU7RUFBQyxxQkFBcUIsRUFBQyxTQUFTO0VBQUMsV0FBVyxFQUFDLFVBQVU7SUFBRyxLQUFLLEtBQUcsWUFBWTs7Z0JBQ3ZMLGlCQUFpQixHQUFFLENBQUM7UUFBQSxZQUFZLEVBQUMsU0FBUztRQUFDLFdBQVcsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBQSxhQUFhLGlDQUFPLGdCQUFnQjtTQUFHLFlBQVksRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsWUFBWSxFQUFDLE9BQU87U0FBQyxXQUFXLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxxQ0FBcUM7RUFBQyxDQUFDO0NBQUE7O2dCQUNoTyxTQUFTLEdBQUUsQ0FBQztRQUFBLFNBQVMsRUFBQyxJQUFJO0VBQUMscUJBQXFCOztpQ0FBUyxPQUFPLENBQUMsR0FBRztHQUFFLFNBQVM7R0FBRyxlQUFlO0dBQUcsVUFBVTtHQUFHLGlCQUFpQjtHQUFHLGVBQWU7R0FBRyxlQUFlO0dBQUcsa0JBQWtCOztDQUFLOztVQUN0TSxVQUFVLEdBQUUsQ0FBQztRQUFBLFNBQVMsRUFBQyxLQUFLO1FBQUMsaUJBQWlCLEVBQUMsSUFBSTtFQUFDLGlCQUFpQixHQUFDLElBQUk7Q0FBQzs7T0FDOUUsV0FBVyxJQUFDLEVBQUUsV0FBRSxXQUFXLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLEVBQUU7O2dCQUN6RCxlQUFlLEdBQUUsQ0FBQztRQUFBLGdCQUFnQixFQUFDLFNBQVM7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxjQUFjOztTQUFHLFdBQVcsRUFBQyxNQUFNLENBQUMsS0FBSztTQUFLLGdCQUFnQixFQUFDLE9BQU87RUFBQyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxnQkFBZ0IsRUFBQyxPQUFPO1NBQUMsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsOEJBQThCO0VBQUMsQ0FBQztDQUFBOztnQkFDclEsa0JBQWtCLEdBQUUsQ0FBQzs0QkFBRyxhQUFhLEdBQUcsU0FBUzs7TUFBVyxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxpQkFBaUI7O1NBQUcsV0FBVztJQUFFLFVBQVUsRUFBQyxNQUFNLENBQUMsVUFBVTtJQUFLLFNBQVMsRUFBQyxNQUFNLENBQUMsU0FBUztJQUFLLFFBQVEsRUFBQyxNQUFNLENBQUMsUUFBUTs7O1NBQU0sYUFBYSxFQUFDLE9BQU87RUFBQyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxhQUFhLEVBQUMsT0FBTztTQUFDLFlBQVksRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDBCQUEwQjtFQUFDLENBQUM7Q0FBQTs7VUFDeFUsa0JBQWtCLENBQUMsSUFBSSxHQUFDLElBQUksRUFBQyxDQUFDO1FBQUEsZUFBZSxFQUFDLEVBQUU7UUFBQyxtQkFBbUIsRUFBQyxJQUFJLEVBQUUsRUFBRSxJQUFFLElBQUk7O1FBQUMsY0FBYyxFQUFDLElBQUk7O0lBQUUsa0JBQWtCLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0I7SUFBRSxRQUFRLEVBQUMsSUFBSSxDQUFDLFFBQVE7SUFBQyxVQUFVLEVBQUMsSUFBSSxDQUFDLFVBQVU7SUFBQyxZQUFZLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZO0lBQUUsTUFBTSxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTTs7O0lBQUksa0JBQWtCLEVBQUMsRUFBRTtJQUFDLFFBQVEsRUFBQyxFQUFFO0lBQUMsVUFBVSxFQUFDLEVBQUU7SUFBQyxZQUFZLEVBQUMsRUFBRTtJQUFDLE1BQU0sRUFBQyxFQUFFOzs7UUFBRSxrQkFBa0IsRUFBQyxJQUFJO0NBQUM7O2dCQUMvVyxjQUFjLEdBQUUsQ0FBQztRQUFNLFlBQVksR0FBQyxNQUFNLE9BQUMsY0FBYyxFQUFDLFlBQVk7R0FBRSxNQUFNLEdBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxNQUFNOzthQUFNLGNBQWMsRUFBQyxrQkFBa0IsV0FBRyxjQUFjLEVBQUMsUUFBUSxDQUFDLElBQUksYUFBSyxjQUFjLEVBQUMsVUFBVSxDQUFDLElBQUksTUFBSSxZQUFZLEdBQUMsQ0FBQyxJQUFFLFlBQVksR0FBQyxFQUFFLElBQUUsTUFBTSxHQUFDLENBQUMsSUFBRSxNQUFNLEdBQUMsRUFBRSxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsK0RBQStEOzs7RUFBUSxDQUFDOztRQUFBLGdCQUFnQixFQUFDLElBQUk7UUFBQyxlQUFlLEVBQUMsRUFBRTs7UUFBTyxPQUFPO0dBQUUsa0JBQWtCLEVBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxrQkFBa0I7R0FBRSxRQUFRLFFBQUMsY0FBYyxFQUFDLFFBQVEsQ0FBQyxJQUFJO0dBQUcsVUFBVSxRQUFDLGNBQWMsRUFBQyxVQUFVLENBQUMsSUFBSTtHQUFHLFlBQVk7R0FBQyxNQUFNOzs7TUFBSyxDQUFDO1NBQU0sS0FBSyx5QkFBQyxtQkFBbUIsR0FBRyxJQUFJO3FDQUFPLGdCQUFnQixDQUFDLE9BQU87cUNBQVEsZ0JBQWdCLE9BQUMsbUJBQW1CLEdBQUMsT0FBTzs7U0FBRSxXQUFXLHdCQUFDLG1CQUFtQixHQUFHLElBQUk7T0FBRSxLQUFLLFdBQUksV0FBVztZQUFFLFdBQVcsRUFBQyxHQUFHLEVBQUMsSUFBSSxxQkFBRSxJQUFJLENBQUMsRUFBRSxFQUFHLEtBQUssQ0FBQyxFQUFFLElBQUMsS0FBSyxHQUFDLElBQUk7O1NBQUUsZ0JBQWdCLEVBQUMsT0FBTztTQUFDLGtCQUFrQixFQUFDLEtBQUs7a0NBQU8sY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGtDQUFrQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7VUFDdi9CLGNBQWMsR0FBRSxDQUFDO1FBQUEsV0FBVyxFQUFDLEVBQUU7O1FBQUMsVUFBVTtHQUFFLGdCQUFnQixFQUFDLE9BQU87R0FBQyxXQUFXLEVBQUMsc0JBQXNCO0dBQUMsa0JBQWtCLEVBQUMsRUFBRTtHQUFDLGVBQWUsRUFBQyxTQUFTOzs7UUFBRSxjQUFjLEVBQUMsSUFBSTtDQUFDOztnQkFDdkssVUFBVSxHQUFFLENBQUM7UUFBQSxZQUFZLEVBQUMsSUFBSTtRQUFDLFdBQVcsRUFBQyxFQUFFOztNQUFJLENBQUM7a0NBQU0saUJBQWlCO2FBQUssVUFBVTtJQUFDLGtCQUFrQix3QkFBQyxVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTyxJQUFDLE1BQU0sT0FBQyxVQUFVLEVBQUMsa0JBQWtCLElBQUUsSUFBSTs7O2tDQUFTLGlCQUFpQjtTQUFHLGNBQWMsRUFBQyxLQUFLO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsaUNBQWlDO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxZQUFZLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7VUFDN1YsWUFBWSxDQUFDLElBQUksR0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLFNBQVMsRUFBQyxFQUFFO1FBQUMsYUFBYSxFQUFDLElBQUksRUFBRSxFQUFFLElBQUUsSUFBSTs7UUFBQyxRQUFRLEVBQUMsSUFBSTs7SUFBRSxRQUFRLEVBQUMsSUFBSSxDQUFDLFFBQVEsSUFBRSxFQUFFO0lBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxRQUFRLElBQUUsTUFBTTtJQUFDLFVBQVUsRUFBQyxJQUFJLENBQUMsVUFBVSxJQUFFLEVBQUU7SUFBQyxpQkFBaUIsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLEVBQUU7SUFBRSxnQkFBZ0IsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFFLEVBQUU7SUFBRSxpQkFBaUIsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLEVBQUU7SUFBRSxlQUFlLEVBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxlQUFlO0lBQUUsS0FBSyxFQUFDLElBQUksQ0FBQyxLQUFLLElBQUUsRUFBRTs7O0lBQUcsUUFBUSxFQUFDLEVBQUU7SUFBQyxRQUFRLEVBQUMsTUFBTTtJQUFDLFVBQVUsRUFBQyxFQUFFO0lBQUMsaUJBQWlCLEVBQUMsRUFBRTtJQUFDLGdCQUFnQixFQUFDLEVBQUU7SUFBQyxpQkFBaUIsRUFBQyxFQUFFO0lBQUMsZUFBZSxFQUFDLEVBQUU7SUFBQyxLQUFLLEVBQUMsRUFBRTs7O1FBQUUsWUFBWSxFQUFDLElBQUk7Q0FBQzs7Z0JBQ3BpQixRQUFRLEdBQUUsQ0FBQztRQUFNLGlCQUFpQixHQUFDLE1BQU0sT0FBQyxRQUFRLEVBQUMsaUJBQWlCO0dBQUUsZ0JBQWdCLEdBQUMsTUFBTSxPQUFDLFFBQVEsRUFBQyxnQkFBZ0I7R0FBRSxpQkFBaUIsR0FBQyxNQUFNLE9BQUMsUUFBUSxFQUFDLGlCQUFpQjs7YUFBTSxRQUFRLEVBQUMsUUFBUSxDQUFDLElBQUksYUFBSyxRQUFRLEVBQUMsVUFBVSxDQUFDLElBQUksYUFBSyxRQUFRLEVBQUMsZUFBZSxJQUFFLGlCQUFpQixJQUFFLENBQUMsSUFBRSxnQkFBZ0IsSUFBRSxDQUFDLEtBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsS0FBRyxpQkFBaUIsSUFBRSxDQUFDLEVBQUMsQ0FBQztTQUFBLFNBQVMsRUFBQyxrRUFBa0U7OztFQUFRLENBQUM7O1FBQU0sT0FBTztHQUFFLFFBQVEsUUFBQyxRQUFRLEVBQUMsUUFBUSxDQUFDLElBQUk7R0FBRyxRQUFRLFFBQUMsUUFBUSxFQUFDLFFBQVE7R0FBQyxVQUFVLFFBQUMsUUFBUSxFQUFDLFVBQVUsQ0FBQyxJQUFJO0dBQUcsaUJBQWlCO0dBQUMsZ0JBQWdCO0dBQUMsaUJBQWlCO0dBQUMsZUFBZSxRQUFDLFFBQVEsRUFBQyxlQUFlO0dBQUMsS0FBSyxRQUFDLFFBQVEsRUFBQyxLQUFLOzs7UUFBRSxVQUFVLEVBQUMsSUFBSTtRQUFDLFNBQVMsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBTSxLQUFLLGtCQUFDLGFBQWEsR0FBRSxJQUFJO3FDQUFPLFVBQVUsQ0FBQyxPQUFPO3FDQUFRLFVBQVUsT0FBQyxhQUFhLEdBQUMsT0FBTzs7U0FBRSxLQUFLLGlCQUFDLGFBQWEsR0FBRSxJQUFJO2dCQUFLLEtBQUssR0FBQyxLQUFLO1lBQUUsS0FBSyxFQUFDLEdBQUcsRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxFQUFFLEVBQUcsS0FBSyxDQUFDLEVBQUUsSUFBQyxLQUFLLEdBQUMsSUFBSTs7U0FBRSxZQUFZLEVBQUMsS0FBSztTQUFDLFVBQVUsRUFBQyxPQUFPO2tDQUFPLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwyQkFBMkI7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDL2hDLFVBQVUsQ0FBQyxJQUFJLEVBQUMsQ0FBQzs0QkFBRyxjQUFjLEdBQUcsSUFBSTs7UUFBUSxjQUFjLEVBQUMsSUFBSSxDQUFDLEVBQUU7UUFBQyxTQUFTLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtTQUFFLEtBQUssUUFBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRyxJQUFJLENBQUMsRUFBRTtHQUFFLHFCQUFxQjtrQ0FBUyxjQUFjO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsU0FBUyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsNkJBQTZCO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxjQUFjLEVBQUMsSUFBSTtFQUFDLENBQUM7Q0FBQTs7Z0JBQ2xULFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFDLENBQUM7TUFBRyxDQUFDO2tDQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFDLFVBQVUsQ0FBQyxLQUFLO2tDQUFRLE9BQU8sQ0FBQyxHQUFHLEVBQUUsU0FBUyxJQUFHLGNBQWM7RUFBSyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwrQkFBK0I7RUFBQyxDQUFDO0NBQUE7O2dCQUM1TSxlQUFlLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBQSxXQUFXLElBQUUsUUFBUSxFQUFDLElBQUksQ0FBQyxRQUFRO1FBQUUsaUJBQWlCLEVBQUMsU0FBUztRQUFDLGdCQUFnQixFQUFDLEVBQUU7O01BQUksQ0FBQztTQUFBLFdBQVcsaUNBQU8sY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1NBQUUsaUJBQWlCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGlCQUFpQixFQUFDLE9BQU87U0FBQyxnQkFBZ0IsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGlDQUFpQztFQUFDLENBQUM7Q0FBQTs7Z0JBQy9SLGlCQUFpQixDQUFDLFVBQVUsRUFBQyxDQUFDO2FBQUksV0FBVzs7TUFBVyxDQUFDO2tDQUFNLGVBQWUsT0FBQyxXQUFXLEVBQUMsRUFBRSxFQUFDLFVBQVUsQ0FBQyxLQUFLOztrQ0FBUSxPQUFPLENBQUMsR0FBRztJQUFFLFNBQVM7SUFBRyxlQUFlLE9BQUMsV0FBVztJQUFFLGNBQWM7O0VBQUssQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwrQkFBK0I7RUFBQyxDQUFDO0NBQUE7O2dCQUMvUSxxQkFBcUIsQ0FBQyxVQUFVLEVBQUMsQ0FBQztRQUFBLGlCQUFpQixJQUFFLEtBQUssRUFBQyxVQUFVLENBQUMsS0FBSztRQUFFLHVCQUF1QixFQUFDLFNBQVM7UUFBQyxzQkFBc0IsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBQSxpQkFBaUIsaUNBQU8sNkJBQTZCLENBQUMsVUFBVSxDQUFDLEVBQUU7U0FBRSx1QkFBdUIsRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsdUJBQXVCLEVBQUMsT0FBTztTQUFDLHNCQUFzQixFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsaUNBQWlDO0VBQUMsQ0FBQztDQUFBOztVQUNoWCxrQkFBa0IsR0FBRSxDQUFDO1FBQUEsU0FBUyxFQUFDLEVBQUU7UUFBQyxTQUFTLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxFQUFFO1FBQUMsY0FBYyxFQUFDLElBQUk7UUFBQyxjQUFjLEVBQUMsS0FBSzs7UUFBQyxRQUFRO0dBQUUsTUFBTSxFQUFDLEtBQUs7R0FBQyxTQUFTLEVBQUMsT0FBTztHQUFDLE9BQU8sRUFBQyxHQUFHO0dBQUMsVUFBVSxFQUFDLFNBQVM7R0FBQyxVQUFVLEVBQUMsS0FBSztHQUFDLFlBQVksRUFBQyxTQUFTO0dBQUMsYUFBYSxFQUFDLE9BQU87OztRQUFFLGtCQUFrQixFQUFDLElBQUk7Q0FBQzs7Z0JBQ3JRLGFBQWEsQ0FBQyxLQUFLLEVBQUMsQ0FBQztRQUFBLFdBQVcsRUFBQyxLQUFLO1FBQUMsY0FBYyxFQUFDLElBQUk7UUFBQyxjQUFjLEVBQUMsSUFBSTtRQUFDLFNBQVMsRUFBQyxFQUFFOztNQUFJLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDO1NBQUEsYUFBYTtTQUFJLGtCQUFrQixFQUFDLE1BQU07OztFQUFRLENBQUM7O1FBQU0sU0FBUyxLQUFHLG1CQUFtQjs7UUFBQyxrQkFBa0IsRUFBQyxTQUFTOztNQUFJLENBQUM7U0FBTSxNQUFNLGtDQUFPLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxJQUFJOzt1QkFBTyxTQUFTLEVBQUcsbUJBQW1COztTQUFRLGFBQWEsRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBRSxNQUFNLEdBQUMsTUFBTSxDQUFDLE9BQU87U0FBSyxrQkFBa0IsRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO3VCQUFHLFNBQVMsRUFBRyxtQkFBbUI7O1NBQVEsYUFBYTtTQUFJLGtCQUFrQixFQUFDLE9BQU87U0FBQyxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxxQ0FBcUM7RUFBQyxDQUFDO0NBQUE7O1VBQ2psQixZQUFZLENBQUMsTUFBTSxFQUFDLENBQUM7UUFBQSxjQUFjLEVBQUMsTUFBTTtRQUFDLFdBQVcsRUFBQyxNQUFNLENBQUMsVUFBVTtRQUFDLGNBQWMsRUFBQyxLQUFLO1FBQUMsU0FBUyxFQUFDLEVBQUU7Q0FBQzs7Z0JBQ3JHLGNBQWMsR0FBRSxDQUFDO1FBQU0sU0FBUyxHQUFDLE1BQU0sT0FBQyxRQUFRLEVBQUMsU0FBUztHQUFFLEtBQUssR0FBQyxNQUFNLE9BQUMsUUFBUSxFQUFDLFlBQVk7R0FBRSxRQUFRLEdBQUMsTUFBTSxPQUFDLFFBQVEsRUFBQyxhQUFhOzthQUFNLGNBQWMsR0FBQyxDQUFDO1NBQUEsU0FBUyxFQUFDLGtEQUFrRDs7O0VBQVEsQ0FBQzs7NEJBQUcsUUFBUSxFQUFDLE1BQU0sRUFBRyxLQUFLLE1BQUcsU0FBUyxJQUFFLENBQUMsV0FBRyxRQUFRLEVBQUMsT0FBTyxXQUFHLFFBQVEsRUFBQyxVQUFVLEdBQUUsQ0FBQztTQUFBLFNBQVMsRUFBQyx3REFBd0Q7OztFQUFRLENBQUM7OzRCQUFHLFFBQVEsRUFBQyxVQUFVLEVBQUcsS0FBSyxRQUFLLEtBQUssR0FBQyxDQUFDLE9BQUssUUFBUSxHQUFDLENBQUMsSUFBRyxDQUFDO1NBQUEsU0FBUyxFQUFDLDREQUE0RDs7O0VBQVEsQ0FBQzs7UUFBTSxPQUFPO0dBQUUsVUFBVSxRQUFDLGNBQWMsRUFBQyxVQUFVO0dBQUMsVUFBVSxRQUFDLGNBQWMsRUFBQyxVQUFVOzs0QkFBSyxRQUFRLEVBQUMsTUFBTSxFQUFHLEtBQUs7O0tBQUUsZ0JBQWdCLEVBQUMsU0FBUztLQUFDLE1BQU0sRUFBQyxNQUFNLE9BQUMsUUFBUSxFQUFDLE9BQU87S0FBRSxVQUFVLFFBQUMsUUFBUSxFQUFDLFVBQVU7Ozs7WUFBVSxjQUFjLEVBQUMsSUFBSSxLQUFFLElBQUksUUFBQyxjQUFjLEVBQUMsSUFBSTs7NEJBQVUsUUFBUSxFQUFDLFVBQVUsRUFBRyxLQUFLOztLQUFFLGVBQWUsSUFBRSxZQUFZLEVBQUMsS0FBSyxFQUFDLG1CQUFtQixFQUFDLFFBQVE7Ozs7O1FBQVEsVUFBVSxFQUFDLElBQUk7UUFBQyxTQUFTLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLGdCQUFnQixDQUFDLE9BQU87U0FBRSxTQUFTLEVBQUMsSUFBSTtrQ0FBTyxlQUFlO2tDQUFTLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxvQ0FBb0M7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDem1DLGdCQUFnQixDQUFDLElBQUksRUFBQyxDQUFDOzRCQUFHLG9CQUFvQixHQUFHLElBQUk7O1FBQVEsb0JBQW9CLEVBQUMsSUFBSSxDQUFDLEVBQUU7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFO1NBQUUsV0FBVyxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUMsSUFBSSxxQkFBRSxJQUFJLENBQUMsRUFBRSxFQUFHLElBQUksQ0FBQyxFQUFFO0dBQUUscUJBQXFCO2tDQUFTLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxvQ0FBb0M7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLG9CQUFvQixFQUFDLElBQUk7RUFBQyxDQUFDO0NBQUE7O1VBQ3JYLGVBQWUsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLGFBQWEsRUFBQyxJQUFJOztRQUFDLFdBQVc7R0FBRSxNQUFNLEVBQUMsRUFBRTtHQUFDLEdBQUcsRUFBQyxFQUFFO0dBQUMsVUFBVSxNQUFLLElBQUksR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7UUFBRyxTQUFTLEVBQUMsRUFBRTtDQUFDOztnQkFDOUgsZUFBZSxHQUFFLENBQUM7UUFBTSxNQUFNLEdBQUMsTUFBTSxPQUFDLFdBQVcsRUFBQyxNQUFNO0dBQUUsR0FBRyxHQUFDLE1BQU0sT0FBQyxXQUFXLEVBQUMsR0FBRzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxPQUFLLEdBQUcsSUFBRSxDQUFDLElBQUUsR0FBRyxJQUFFLEVBQUUsWUFBSSxXQUFXLEVBQUMsVUFBVSxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMseUVBQXlFOzs7RUFBUSxDQUFDOztRQUFBLGFBQWEsRUFBQyxJQUFJOztNQUFJLENBQUM7a0NBQU0sbUJBQW1CLE9BQUMsYUFBYSxFQUFDLEVBQUUsSUFBRSxNQUFNLEVBQUMsR0FBRyxFQUFDLFVBQVUsUUFBQyxXQUFXLEVBQUMsVUFBVTtTQUFHLGFBQWEsRUFBQyxJQUFJO2tDQUFPLGVBQWU7a0NBQVMsY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFNBQVMsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDBCQUEwQjtFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsYUFBYSxFQUFDLEtBQUs7RUFBQyxDQUFDO0NBQUE7O1VBQzFnQixhQUFhLEdBQUUsQ0FBQztRQUFBLFVBQVUsRUFBQyxFQUFFO1FBQUMsVUFBVSxFQUFDLEVBQUU7UUFBQyxhQUFhLEVBQUMsSUFBSTtRQUFDLFlBQVk7UUFBSSxTQUFTLElBQUUsUUFBUSxFQUFDLEVBQUUsRUFBQyxhQUFhLEVBQUMsRUFBRTtRQUFFLGFBQWEsRUFBQyxJQUFJO0NBQUM7O2dCQUNySSxVQUFVLENBQUMsS0FBSyxFQUFDLENBQUM7UUFBQSxVQUFVLEVBQUMsS0FBSztRQUFDLGFBQWEsRUFBQyxJQUFJO1FBQUMsVUFBVSxFQUFDLEVBQUU7O01BQUksS0FBSyxDQUFDLElBQUksR0FBRyxNQUFNLEdBQUMsQ0FBQyxFQUFDLENBQUM7U0FBQSxZQUFZO1NBQUksaUJBQWlCLEVBQUMsTUFBTTs7O0VBQVEsQ0FBQzs7UUFBTSxTQUFTLEtBQUcsa0JBQWtCOztRQUFDLGlCQUFpQixFQUFDLFNBQVM7O01BQUksQ0FBQztTQUFNLE1BQU0sa0NBQU8sWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJOzt1QkFBTyxTQUFTLEVBQUcsa0JBQWtCOztTQUFRLFlBQVksRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBRSxNQUFNO1NBQUksaUJBQWlCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQzt1QkFBRyxTQUFTLEVBQUcsa0JBQWtCOztTQUFRLFlBQVk7U0FBSSxpQkFBaUIsRUFBQyxPQUFPO1NBQUMsVUFBVSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsaUNBQWlDO0VBQUMsQ0FBQztDQUFBOztVQUN2aEIsV0FBVyxDQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsYUFBYSxFQUFDLEtBQUs7UUFBQyxVQUFVLEtBQUksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsTUFBTTtRQUFJLFlBQVk7UUFBSSxVQUFVLEVBQUMsRUFBRTtDQUFDOztnQkFDNUcsU0FBUyxHQUFFLENBQUM7UUFBTSxRQUFRLEdBQUMsTUFBTSxPQUFDLFNBQVMsRUFBQyxRQUFRO0dBQUUsbUJBQW1CLEdBQUMsTUFBTSxPQUFDLFNBQVMsRUFBQyxhQUFhOzthQUFNLGFBQWEsR0FBQyxDQUFDO1NBQUEsVUFBVSxFQUFDLHlDQUF5Qzs7O0VBQVEsQ0FBQzs7UUFBSyxRQUFRLEdBQUMsQ0FBQyxPQUFLLG1CQUFtQixHQUFDLENBQUMsR0FBRSxDQUFDO1NBQUEsVUFBVSxFQUFDLDBEQUEwRDs7O0VBQVEsQ0FBQzs7UUFBQSxXQUFXLEVBQUMsSUFBSTtRQUFDLFVBQVUsRUFBQyxFQUFFOztNQUFJLENBQUM7a0NBQU0sV0FBVztJQUFFLE1BQU0sUUFBQyxhQUFhLEVBQUMsTUFBTTtJQUFDLElBQUksUUFBQyxhQUFhLEVBQUMsSUFBSTtJQUFDLFFBQVEsUUFBQyxhQUFhLEVBQUMsUUFBUTtJQUFDLFFBQVE7SUFBQyxtQkFBbUI7OztTQUFHLGFBQWEsRUFBQyxLQUFLO2tDQUFPLFVBQVU7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwyQkFBMkI7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLFdBQVcsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDcm1CLFdBQVcsQ0FBQyxLQUFLLEVBQUMsQ0FBQzs0QkFBRyxlQUFlLEdBQUcsSUFBSTs7UUFBUSxlQUFlLEVBQUMsS0FBSyxDQUFDLEVBQUU7UUFBQyxVQUFVLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtTQUFFLE1BQU0sUUFBQyxNQUFNLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRyxLQUFLLENBQUMsRUFBRTtHQUFFLHFCQUFxQjtFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDhCQUE4QjtFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZUFBZSxFQUFDLElBQUk7RUFBQyxDQUFDO0NBQUE7O1VBQy9TLGFBQWEsQ0FBQyxLQUFLLEVBQUMsQ0FBQztRQUFBLGVBQWUsRUFBQyxLQUFLOztRQUFDLGFBQWE7R0FBRSxNQUFNLEVBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sSUFBRSxFQUFFO0dBQUMsR0FBRyxFQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLElBQUUsRUFBRTtHQUFDLFVBQVUsRUFBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsVUFBVSxRQUFNLElBQUksR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7UUFBRyxVQUFVLEVBQUMsRUFBRTtDQUFDOztnQkFDdk8sYUFBYSxHQUFFLENBQUM7UUFBTSxNQUFNLEdBQUMsTUFBTSxPQUFDLGFBQWEsRUFBQyxNQUFNO0dBQUUsR0FBRyxHQUFDLE1BQU0sT0FBQyxhQUFhLEVBQUMsR0FBRzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxPQUFLLEdBQUcsSUFBRSxDQUFDLElBQUUsR0FBRyxJQUFFLEVBQUUsWUFBSSxhQUFhLEVBQUMsVUFBVSxFQUFDLENBQUM7U0FBQSxVQUFVLEVBQUMsaUVBQWlFOzs7RUFBUSxDQUFDOztRQUFBLGVBQWUsRUFBQyxJQUFJOztNQUFJLENBQUM7a0NBQU0sc0JBQXNCLE9BQUMsZUFBZSxFQUFDLEVBQUUsSUFBRSxNQUFNLEVBQUMsR0FBRyxFQUFDLFVBQVUsUUFBQyxhQUFhLEVBQUMsVUFBVTtTQUFHLGVBQWUsRUFBQyxJQUFJO2tDQUFPLFVBQVU7a0NBQVMsY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLG1DQUFtQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZUFBZSxFQUFDLEtBQUs7RUFBQyxDQUFDO0NBQUE7O2dCQUNuaEIsZ0JBQWdCLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMscUJBQXFCLEVBQUMsTUFBTTtHQUFFLGNBQWMsR0FBQyxNQUFNLE9BQUMscUJBQXFCLEVBQUMsS0FBSzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxPQUFLLGNBQWMsR0FBQyxDQUFDOztNQUFZLENBQUM7a0NBQU0sdUJBQXVCLE9BQUMsMkJBQTJCLEVBQUMsRUFBRSxRQUFDLDJCQUEyQixFQUFDLGtCQUFrQixDQUFDLEtBQUs7SUFBRSxNQUFNO0lBQUMsY0FBYztJQUFDLGVBQWUsTUFBSyxJQUFJLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTs7O1NBQUksMkJBQTJCLEVBQUMsSUFBSTtrQ0FBTyxVQUFVO2tDQUFTLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx3Q0FBd0M7RUFBQyxDQUFDO0NBQUE7O2dCQUNyZ0IsZUFBZSxDQUFDLEVBQUUsRUFBQyxDQUFDO1FBQUEsV0FBVyxJQUFFLEVBQUU7UUFBRSxpQkFBaUIsRUFBQyxTQUFTOztNQUFJLENBQUM7U0FBQSxXQUFXLGlDQUFPLFFBQVEsQ0FBQyxFQUFFO1NBQUUsaUJBQWlCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGlCQUFpQixFQUFDLE9BQU87U0FBQyxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSw0QkFBNEI7RUFBQyxDQUFDO0NBQUE7O1VBQ3JPLG1CQUFtQixDQUFDLElBQUksRUFBQyxVQUFVLEVBQUMsQ0FBQztRQUFBLGFBQWEsSUFBRSxJQUFJLEVBQUMsVUFBVTtRQUFFLGVBQWUsRUFBQyxFQUFFOztRQUFDLGNBQWM7R0FBRSxNQUFNLEVBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLGdCQUFnQixJQUFFLEVBQUU7R0FBRSxlQUFlLEVBQUMsVUFBVSxDQUFDLGVBQWUsUUFBTSxJQUFJLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTtHQUFFLEdBQUcsV0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLElBQUksSUFBQyxFQUFFLEdBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHOztDQUFHOztnQkFDblMsbUJBQW1CLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMsY0FBYyxFQUFDLE1BQU07R0FBRSxHQUFHLEdBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxHQUFHOztRQUFPLE1BQU0sR0FBQyxDQUFDLFlBQUksY0FBYyxFQUFDLGVBQWUsTUFBSSxHQUFHLEdBQUMsQ0FBQyxHQUFFLENBQUM7U0FBQSxlQUFlLEVBQUMsa0RBQWtEOzs7RUFBUSxDQUFDOztRQUFBLGdCQUFnQixFQUFDLElBQUk7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sT0FBTztJQUFFLE1BQU07SUFBQyxlQUFlLFFBQUMsY0FBYyxFQUFDLGVBQWU7SUFBQyxHQUFHO0lBQUMsaUJBQWlCLEVBQUMsZUFBZTs7OzZCQUFLLGFBQWEsRUFBQyxVQUFVLENBQUMsTUFBTSxFQUFHLFdBQVcsa0NBQU8sbUJBQW1CLE9BQUMsYUFBYSxFQUFDLElBQUksQ0FBQyxFQUFFLFFBQUMsYUFBYSxFQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUMsT0FBTywyQ0FBYSxvQkFBb0IsT0FBQyxhQUFhLEVBQUMsSUFBSSxDQUFDLEVBQUUsUUFBQyxhQUFhLEVBQUMsVUFBVSxDQUFDLGNBQWMsRUFBQyxPQUFPOztTQUFFLGFBQWEsRUFBQyxJQUFJO2tDQUFPLGVBQWU7a0NBQVMsY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLHFDQUFxQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Z0JBQy95QixjQUFjLENBQUMsRUFBRSxFQUFDLENBQUM7UUFBQSxVQUFVLElBQUUsRUFBRTtRQUFFLGdCQUFnQixFQUFDLFNBQVM7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQUEsVUFBVSxpQ0FBTyxhQUFhLENBQUMsRUFBRTtTQUFFLGdCQUFnQixFQUFDLE9BQU87RUFBQyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxnQkFBZ0IsRUFBQyxPQUFPO1NBQUMsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsMkJBQTJCO0VBQUMsQ0FBQztDQUFBOztVQUMzUCxXQUFXLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBQSxXQUFXLEVBQUMsSUFBSTtRQUFDLFlBQVksRUFBQyxFQUFFOztRQUFDLFdBQVc7R0FBRSxNQUFNLEVBQUMsRUFBRTtHQUFDLGVBQWUsTUFBSyxJQUFJLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTtHQUFFLEdBQUcsRUFBQyxFQUFFOztDQUFFOztVQUN2SSxlQUFlLENBQUMsSUFBSSxFQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsc0JBQXNCLElBQUUsSUFBSSxFQUFDLEtBQUs7UUFBRSxvQkFBb0IsRUFBQyxFQUFFOztRQUFDLG1CQUFtQjtHQUFFLE1BQU0sRUFBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBRSxFQUFFO0dBQUUsZUFBZSxFQUFDLEtBQUssQ0FBQyxlQUFlLElBQUUsRUFBRTtHQUFDLEdBQUcsV0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksSUFBQyxFQUFFLEdBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHOztDQUFHOztnQkFDM04sbUJBQW1CLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMsbUJBQW1CLEVBQUMsTUFBTTtHQUFFLEdBQUcsR0FBQyxNQUFNLE9BQUMsbUJBQW1CLEVBQUMsR0FBRzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxZQUFJLG1CQUFtQixFQUFDLGVBQWUsTUFBSSxHQUFHLEdBQUMsQ0FBQyxHQUFFLENBQUM7U0FBQSxvQkFBb0IsRUFBQyxrREFBa0Q7OztFQUFRLENBQUM7O1FBQUEscUJBQXFCLEVBQUMsSUFBSTtRQUFDLG9CQUFvQixFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSwyQkFBMkIsT0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsRUFBRSxRQUFDLHNCQUFzQixFQUFDLEtBQUssQ0FBQyxFQUFFO0lBQUUsTUFBTTtJQUFDLGVBQWUsUUFBQyxtQkFBbUIsRUFBQyxlQUFlO0lBQUMsR0FBRztJQUFDLGlCQUFpQixFQUFDLGNBQWM7OztTQUFTLEVBQUUsU0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsRUFBRTs7U0FBQyxzQkFBc0IsRUFBQyxJQUFJO2tDQUFPLE9BQU8sQ0FBQyxHQUFHLEVBQUUsZUFBZSxJQUFHLGNBQWMsQ0FBQyxFQUFFLEdBQUUsY0FBYztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLG9CQUFvQixFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsbUNBQW1DO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxxQkFBcUIsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDandCLFdBQVcsR0FBRSxDQUFDO1FBQU0sTUFBTSxHQUFDLE1BQU0sT0FBQyxXQUFXLEVBQUMsTUFBTTtHQUFFLEdBQUcsR0FBQyxNQUFNLE9BQUMsV0FBVyxFQUFDLEdBQUc7O1FBQU8sTUFBTSxHQUFDLENBQUMsWUFBSSxXQUFXLEVBQUMsZUFBZSxNQUFJLEdBQUcsR0FBQyxDQUFDLEdBQUUsQ0FBQztTQUFBLFlBQVksRUFBQyxxREFBcUQ7OztFQUFRLENBQUM7O1FBQUEsYUFBYSxFQUFDLElBQUk7O01BQUksQ0FBQztrQ0FBTSx1QkFBdUIsT0FBQyxXQUFXLEVBQUMsRUFBRTtJQUFFLE1BQU07SUFBQyxlQUFlLFFBQUMsV0FBVyxFQUFDLGVBQWU7SUFBQyxHQUFHO0lBQUMsaUJBQWlCLEVBQUMsZUFBZTs7O1NBQUcsV0FBVyxFQUFDLElBQUk7a0NBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxlQUFlLElBQUcsY0FBYztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFlBQVksRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDhCQUE4QjtFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsYUFBYSxFQUFDLEtBQUs7RUFBQyxDQUFDO0NBQUE7O1VBQzVpQixRQUFRLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBQSxJQUFJLEVBQUMsSUFBSTs7c0JBQUksSUFBSSxFQUFHLGNBQWMsVUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLElBQUk7U0FBQyxXQUFXLEVBQUMsUUFBUTtFQUFDLENBQUM7O0VBQUEsTUFBTSxDQUFDLFFBQVEsR0FBRSxHQUFHLEVBQUMsQ0FBQyxFQUFDLFFBQVEsRUFBQyxRQUFRO0NBQUc7O1VBQ3JJLGlCQUFpQixHQUFFLENBQUM7UUFBTSxHQUFHLE9BQUssSUFBSTs7WUFBYSxHQUFHLENBQUMsV0FBVyxNQUFNLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxLQUFHLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFDLEdBQUc7Q0FBSTs7VUFDbkgsV0FBVyxDQUFDLE1BQU0sRUFBQyxDQUFDO1NBQU0sQ0FBQyxFQUFDLENBQUMsSUFBRSxhQUFhLEdBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsTUFBTTtHQUFFLElBQUksT0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxNQUFNLEVBQUMsQ0FBQyxHQUFHLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUM7O01BQUssSUFBSSxJQUFFLGlCQUFpQixJQUFHLENBQUM7U0FBQSxXQUFXLEVBQUMsSUFBSTtTQUFDLFFBQVE7U0FBSSxXQUFXLEVBQUMsUUFBUTtHQUFDLGFBQWEsR0FBQyxJQUFJO0VBQUUsQ0FBQztDQUFBOztVQUMxTyxhQUFhLENBQUMsVUFBVSxFQUFDLE9BQU8sRUFBQyxDQUFDO1NBQU0sQ0FBQyxFQUFDLENBQUMsSUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsTUFBTTtHQUFFLEtBQUssT0FBSyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsT0FBTztHQUFHLE9BQU8sUUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLE1BQU0sS0FBRyxDQUFDLElBQUUsQ0FBQztHQUFDLE1BQU0sT0FBSyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBQyxDQUFDLE1BQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLElBQUcsQ0FBQztHQUFJLEtBQUssT0FBSyxJQUFJO0dBQUcsT0FBTyxtQkFBQyxLQUFLLENBQUMsV0FBVyxJQUFLLENBQUMscUJBQUUsS0FBSyxDQUFDLFFBQVEsS0FBRyxDQUFDLEVBQUcsQ0FBQzs7O0dBQVEsT0FBTzs7R0FBQyxJQUFJLEVBQUMsS0FBSyxDQUFDLElBQUksR0FBRSxNQUFNLEVBQUMsS0FBSyxLQUFHLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQztVQUFNLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUc7OztLQUFhLEdBQUc7S0FBQyxVQUFVLEVBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQztLQUFFLGdCQUFnQixFQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLElBQUUsQ0FBQztLQUFFLFNBQVMsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDO0tBQUksTUFBTSxFQUFDLE9BQU8sSUFBRSxHQUFHLEdBQUMsS0FBSyxDQUFDLE9BQU87O0dBQUksQ0FBQzs7Q0FBRzs7Z0JBQ3pqQixVQUFVLENBQUMsR0FBRyxFQUFDLENBQUM7T0FBSSxHQUFHLElBQUUsR0FBRyxDQUFDLE1BQU07O1FBQVEsV0FBVyxFQUFDLEdBQUcsQ0FBQyxHQUFHO1FBQUMsV0FBVyxFQUFDLEtBQUs7UUFBQyxPQUFPLEVBQUMsS0FBSztRQUFDLFVBQVUsRUFBQyxJQUFJO2lDQUFPLE9BQU87Q0FBRzs7Z0JBQy9ILE9BQU8sR0FBRSxDQUFDO3FCQUFHLFdBQVcsR0FBRSxJQUFJOztRQUFRLFNBQVMsRUFBQyxTQUFTOztNQUFJLENBQUM7U0FBTSxJQUFJLGtDQUFPLGtCQUFrQixDQUFDLGFBQWEsSUFBQyxPQUFPLE9BQUMsV0FBVyxJQUFFLEVBQUU7O1NBQUUsUUFBUSxFQUFDLElBQUksQ0FBQyxLQUFLLElBQUUsSUFBSSxDQUFDLFFBQVE7U0FBSyxTQUFTLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBSyxDQUFDO1NBQUEsU0FBUyxFQUFDLE9BQU87RUFBQyxDQUFDO0NBQUE7O2dCQUM1TixTQUFTLENBQUMsS0FBSyxFQUFDLENBQUM7UUFBQSxXQUFXLEVBQUMsS0FBSztRQUFDLFVBQVUsRUFBQyxDQUFDO1FBQUMsaUJBQWlCLEVBQUMsS0FBSzs7UUFBTyxTQUFTLElBQUUsS0FBSyxDQUFDLEtBQUssUUFBTSxJQUFJLEVBQUMsSUFBSSxNQUFHLElBQUksQ0FBQyxPQUFPLFFBQU0sSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLElBQUksRUFBRyx3QkFBd0I7O01BQU0sU0FBUyxFQUFDLENBQUM7U0FBQSxzQkFBc0IsRUFBQyxTQUFTO1NBQUMsb0JBQW9CLEVBQUMsSUFBSTs7T0FBSSxDQUFDO1VBQU0sTUFBTSxrQ0FBTyxtQkFBbUIsQ0FBQyxhQUFhOztVQUFFLGdCQUFnQixFQUFDLE1BQU0sQ0FBQyxLQUFLO1VBQUssc0JBQXNCLEVBQUMsT0FBTztHQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztVQUFBLHNCQUFzQixFQUFDLE9BQU87VUFBQyxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx5Q0FBeUM7R0FBQyxDQUFDO0VBQUEsQ0FBQztDQUFBOztVQUNqZ0IsWUFBWSxDQUFDLEtBQUssRUFBQyxDQUFDO1NBQU8sWUFBWSxDQUFDLEtBQUssS0FBRyxXQUFXLENBQUMsS0FBSyxRQUFDLFVBQVUsR0FBRSxJQUFJLEVBQUMsSUFBSSxNQUFFLE9BQU8sRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7Q0FBRzs7Z0JBQ2hILGdCQUFnQixDQUFDLGFBQWEsRUFBQyxZQUFZLEVBQUMsQ0FBQztRQUFBLGtCQUFrQixFQUFDLGFBQWE7O01BQUksQ0FBQztrQ0FBTSx1QkFBdUIsQ0FBQyxhQUFhLEVBQUMsWUFBWTtTQUFFLGdCQUFnQixRQUFDLGdCQUFnQixFQUFDLE1BQU0sRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxhQUFhLEVBQUcsYUFBYTtrQ0FBUSxjQUFjOztjQUFPLGdCQUFnQixFQUFDLE1BQU0sUUFBQyxvQkFBb0IsRUFBQyxLQUFLO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsNkJBQTZCO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxrQkFBa0IsRUFBQyxJQUFJO0VBQUMsQ0FBQztDQUFBOztVQUNqYSxhQUFhLENBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxDQUFDOzRCQUFHLGVBQWUsR0FBRyxJQUFJOztRQUFjLFFBQVEsR0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxPQUFPLFNBQUMsZUFBZTs7TUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBRSxFQUFFLFFBQUMsVUFBVSxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFDLENBQUMsUUFBQyxVQUFVLEtBQUUsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQzs7UUFBSSxlQUFlLEVBQUMsSUFBSTtDQUFDOztVQUNqUCxZQUFZLENBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxJQUFJLEVBQUMsQ0FBQzs0QkFBRyxtQkFBbUIsR0FBRyxJQUFJOztRQUFjLFFBQVEsR0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxPQUFPLFNBQUMsbUJBQW1COztNQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxJQUFFLEVBQUUsRUFBQyxDQUFDO1NBQU0sSUFBSSxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFDLENBQUMsbUJBQUUsSUFBSSxFQUFHLE1BQU0sVUFBQyxjQUFjLFVBQUMsZ0JBQWdCLE1BQUcsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQzs7dUJBQU8sSUFBSSxFQUFHLE1BQU0sU0FBQyxjQUFjLEVBQUMsSUFBSSxjQUFNLGdCQUFnQixFQUFDLElBQUk7RUFBQyxDQUFDOztRQUFBLG1CQUFtQixFQUFDLElBQUk7Q0FBQzs7Z0JBQ2xXLFNBQVMsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLE9BQU8sRUFBQyxJQUFJO1FBQUMsVUFBVSxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFFLEVBQUU7UUFBRSxRQUFRLEVBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxJQUFJO1FBQUcsWUFBWSxrQkFBQyxRQUFRLENBQUMsSUFBSSxHQUFJLGVBQWUsSUFBQyxFQUFFLEdBQUMsUUFBUSxDQUFDLElBQUk7UUFBRSxlQUFlLEVBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsSUFBRSxFQUFFO1FBQUMsY0FBYyxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxJQUFFLEVBQUU7UUFBRSxhQUFhLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLElBQUUsSUFBSSxDQUFDLGVBQWUsSUFBRSxFQUFFO1FBQUUsV0FBVyxFQUFDLEVBQUU7UUFBQyxZQUFZLEVBQUMsRUFBRTs7NEJBQUksYUFBYSxHQUFHLE9BQU8sR0FBQyxDQUFDO0dBQUEsdUJBQXVCLENBQUMsSUFBSTs7O0VBQVMsQ0FBQzs7UUFBQSxhQUFhLEVBQUMsU0FBUzs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxpQkFBaUI7O1NBQUcsV0FBVztJQUFFLFVBQVUsRUFBQyxNQUFNLENBQUMsVUFBVTtJQUFLLFNBQVMsRUFBQyxNQUFNLENBQUMsU0FBUztJQUFLLFFBQVEsRUFBQyxNQUFNLENBQUMsUUFBUTs7O1NBQU0sYUFBYSxFQUFDLE9BQU87R0FBQyx1QkFBdUIsQ0FBQyxJQUFJO0VBQUUsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsYUFBYSxFQUFDLE9BQU87U0FBQyxZQUFZLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxpQ0FBaUM7RUFBQyxDQUFDO0NBQUE7O1VBQ3h5Qix1QkFBdUIsQ0FBQyxJQUFJLEVBQUMsQ0FBQzthQUFJLGNBQWMsR0FBQyxDQUFDO1NBQU0sS0FBSyxTQUFDLFdBQVcsRUFBQyxTQUFTLENBQUMsSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLElBQUksRUFBRSxXQUFXLElBQUssUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXOztPQUFPLEtBQUssUUFBQyxjQUFjLEVBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFO0VBQUUsQ0FBQzs7YUFBSSxhQUFhLEdBQUMsQ0FBQztTQUFNLE9BQU8sR0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsSUFBRSxFQUFFLEVBQUUsV0FBVztJQUFHLEtBQUssU0FBQyxXQUFXLEVBQUMsUUFBUSxDQUFDLElBQUksRUFBQyxNQUFNLHFCQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUUsV0FBVyxJQUFLLE9BQU87O09BQUssS0FBSyxRQUFDLGFBQWEsRUFBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUU7RUFBRSxDQUFDO0NBQUE7O1VBQ3ZiLGtCQUFrQixDQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsWUFBWSxFQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSzs7YUFBSyxpQkFBaUIsRUFBQyxRQUFRLE9BQUMsZUFBZSxVQUFFLGVBQWUsRUFBQyxFQUFFO0NBQUM7O2dCQUM5SCxRQUFRLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMsVUFBVTtHQUFFLFVBQVUsR0FBQyxNQUFNLE9BQUMsY0FBYztHQUFFLFNBQVMsR0FBQyxNQUFNLE9BQUMsYUFBYTs7YUFBTSxPQUFPLFdBQUUsTUFBTSwyQkFBRSxhQUFhLEdBQUcsT0FBTyxhQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFHLE1BQU0sSUFBRSxDQUFDLFdBQUcsUUFBUSxZQUFHLFlBQVksWUFBRyxlQUFlLE1BQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLE1BQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTOztRQUFTLE1BQU0sRUFBQyxJQUFJO1FBQUMsV0FBVyxFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSxhQUFhLE9BQUMsT0FBTyxFQUFDLEVBQUU7SUFBRSxNQUFNO0lBQUMsZUFBZSxRQUFDLFFBQVE7SUFBQyxRQUFRLFFBQUMsWUFBWTtJQUFDLFdBQVcsUUFBQyxlQUFlO0lBQUMsVUFBVTtJQUFDLFNBQVM7OztTQUFHLE9BQU8sRUFBQyxJQUFJOztrQ0FBTyxPQUFPLENBQUMsR0FBRztJQUFFLE9BQU87SUFBRyxhQUFhO0lBQUcsZUFBZTtJQUFHLGNBQWM7O0VBQUssQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsbUNBQW1DO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxNQUFNLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Z0JBQ3pwQixhQUFhLEdBQUUsQ0FBQzthQUFJLFFBQVE7O01BQVcsQ0FBQztrQ0FBTSxhQUFhLE9BQUMsUUFBUSxFQUFDLEVBQUU7U0FBRSxRQUFRLEVBQUMsSUFBSTs7a0NBQU8sT0FBTyxDQUFDLEdBQUc7SUFBRSxPQUFPO0lBQUcsYUFBYTtJQUFHLGVBQWU7SUFBRyxjQUFjOztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFdBQVcsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLG1DQUFtQztTQUFDLFFBQVEsRUFBQyxJQUFJO0VBQUMsQ0FBQztDQUFBOztnQkFDdFEsY0FBYyxHQUFFLENBQUM7YUFBSSxRQUFRLFdBQUUsYUFBYTs7UUFBUSxhQUFhLEVBQUMsSUFBSTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyx3QkFBd0IsQ0FBQyxPQUFPLE9BQUMsUUFBUSxFQUFDLEdBQUcsU0FBRSxJQUFJLEVBQUMsUUFBUSxJQUFFLElBQUksQ0FBQyxjQUFjLEdBQUcsZUFBZSxHQUFHLFFBQVE7O1NBQUUsT0FBTyxPQUFLLE1BQU0sRUFBQyxJQUFJLEVBQUMsT0FBTyxPQUFDLFFBQVEsRUFBQyxHQUFHO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLEtBQUssWUFBWSxRQUFRO01BQUMsS0FBSyxDQUFDLE9BQU87TUFBQyx1Q0FBdUM7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLGFBQWEsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDclksT0FBTyxHQUFFLENBQUM7UUFBQSxVQUFVLEVBQUMsSUFBSTs7TUFBSSxDQUFDO2tDQUFNLE1BQU07O09BQU0sQ0FBQztJQUFBLFlBQVksQ0FBQyxVQUFVLElBQUksdUJBQXVCO0lBQVMsWUFBWSxDQUFDLFVBQVUsSUFBSSx1QkFBdUI7R0FBUyxDQUFDLE9BQUssQ0FBQyxDQUFDOztHQUFBLFFBQVE7RUFBRyxDQUFDLE9BQUssQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLO1NBQUMsWUFBWSxFQUFDLHFCQUFxQjtFQUFDLENBQUM7Q0FBQTs7Z0JBQ3RQLGNBQWMsR0FBRSxDQUFDO1lBQUcsYUFBYTs7UUFBUSxhQUFhLEVBQUMsSUFBSTtRQUFDLFNBQVMsRUFBQyxFQUFFOztNQUFJLENBQUM7a0NBQU0sZ0JBQWdCLElBQUUsUUFBUTtTQUFFLEtBQUs7U0FBSSxXQUFXO1NBQUksTUFBTTtTQUFJLE9BQU87U0FBSSxVQUFVLEVBQUMsTUFBTTtTQUFDLGdCQUFnQixFQUFDLE1BQU07U0FBQyxXQUFXLEVBQUMsTUFBTTtHQUFDLGFBQWEsR0FBQyxNQUFNO1NBQUMsVUFBVSxFQUFDLElBQUk7U0FBQyxRQUFRO1NBQUksV0FBVyxFQUFDLElBQUk7U0FBQyxXQUFXLElBQUUsVUFBVSxNQUFJLFNBQVMsTUFBSSxRQUFRO1NBQUssYUFBYSxFQUFDLE1BQU07U0FBQyxTQUFTLEVBQUMsS0FBSztrQ0FBTyxXQUFXO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsU0FBUyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsNEJBQTRCO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxhQUFhLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Q0FDM2YsT0FBTyxPQUFLLENBQUM7TUFBRyxDQUFDO1NBQUEsZUFBZSxFQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0NBQWdDLEtBQUcsU0FBUztFQUFDLENBQUMsT0FBSyxDQUFDLENBQUM7O0VBQUEsV0FBVztDQUFHLENBQUM7OztRQXBIdkgsSUFBSSxFQUFDLGVBQWUsR0FBQyxJQUFJOzs7O1FBQVMsUUFBUSxRQUFDLElBQUksRUFBQyxRQUFRLElBQUUsS0FBSzs7OztRQUFLLFFBQVEsRUFBQyxhQUFhLENBQUMsYUFBYSxVQUFDLElBQUksRUFBQyxJQUFJOzs7O1FBQ2xILFVBQVUsRUFBQyxhQUFhLEdBQUMsSUFBSTs7OztRQUFTLFdBQVcsU0FBRSxVQUFVLEVBQUMsS0FBSyxVQUFFLFVBQVUsRUFBQyxRQUFRLFFBQU0sS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7O1FBQ3ZHLFNBQVMsRUFBQyxjQUFjLEdBQUMsSUFBSTs7OztRQUFTLE9BQU8sUUFBQyxTQUFTLEVBQUMsT0FBTyxVQUFFLFNBQVMsRUFBQyxZQUFZLFVBQUUsU0FBUyxFQUFDLFVBQVU7Ozs7UUFDN0csZUFBZSx3QkFBQyxXQUFXLEdBQUcsS0FBSztXQUFDLE9BQU87V0FBQyxPQUFPLEVBQUMsTUFBTSxFQUFDLEtBQUsscUJBQUUsV0FBVyxDQUFDLEtBQUssRUFBRSxXQUFXLFVBQUssV0FBVyxFQUFDLFdBQVc7Ozs7UUFDNUgsV0FBVyxRQUFDLE9BQU8sRUFBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUM7Ozs7WUFDMUIsY0FBYyxXQUFFLFdBQVcsRUFBQyxNQUFNLFFBQUMsY0FBYyxFQUFDLENBQUM7Ozs7WUFDbkQsZ0JBQWdCLFdBQUUsZUFBZSxFQUFDLE1BQU0sUUFBQyxnQkFBZ0IsRUFBQyxDQUFDOzs7O1FBQzlELFFBQVEsaUJBQUMsV0FBVyxHQUFFLElBQUk7S0FBQyxJQUFJO1dBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsR0FBRyxxQkFBRSxHQUFHLENBQUMsR0FBRyxRQUFHLFdBQVc7Ozs7UUFBTSxXQUFXLHdCQUFDLFdBQVcsR0FBRyxRQUFRLFVBQUMsV0FBVyxVQUFDLFFBQVE7Ozs7UUFBSyxZQUFZLFFBQUMsT0FBTyxVQUFDLFdBQVcsVUFBQyxXQUFXLEVBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7O1FBQ3JNLGlCQUFpQixRQUFDLFdBQVcsRUFBQyxVQUFVLENBQUMsSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLElBQUksUUFBRyxZQUFZLEtBQUcsYUFBYTs7OztRQUNoRyxXQUFXLFFBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxNQUFNLEVBQUcsUUFBUTs7OztRQUFNLFdBQVcsUUFBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRyxRQUFROzs7O1FBQU0sZUFBZSxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLElBQUksS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBRSxDQUFDLEdBQUUsQ0FBQzs7OztRQUMvTSxlQUFlO0dBQUUsUUFBUSxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLElBQUksS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUUsQ0FBQyxHQUFFLENBQUM7O0dBQUUsT0FBTyxRQUFDLFdBQVcsRUFBQyxJQUFJLEVBQUMsSUFBSSxxQkFBRSxJQUFJLENBQUMsWUFBWSxFQUFHLElBQUk7WUFBRSxXQUFXLEVBQUMsTUFBTSxFQUFFLEtBQUssRUFBQyxJQUFJLEtBQUcsS0FBSyxHQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFFLENBQUMsR0FBRSxDQUFDO01BQUUsSUFBSTs7R0FBQyxHQUFHLFFBQUMsV0FBVyxFQUFDLElBQUksRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxZQUFZLEVBQUcsSUFBSTtZQUFFLFdBQVcsRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLElBQUksS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUUsQ0FBQyxHQUFFLENBQUM7TUFBRSxJQUFJOzs7OztRQUNsVyxjQUFjO0dBQUUsUUFBUSxRQUFDLE1BQU0sRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLEtBQUssS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLElBQUUsQ0FBQyxHQUFFLENBQUM7O0dBQUUsT0FBTyxRQUFDLE1BQU0sRUFBQyxJQUFJLEVBQUMsS0FBSyxxQkFBRSxLQUFLLENBQUMsWUFBWSxFQUFHLElBQUk7WUFBRSxNQUFNLEVBQUMsTUFBTSxFQUFFLEtBQUssRUFBQyxLQUFLLEtBQUcsS0FBSyxHQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxJQUFFLENBQUMsR0FBRSxDQUFDO01BQUUsSUFBSTs7R0FBQyxHQUFHLFFBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLEtBQUssQ0FBQyxZQUFZLEVBQUcsSUFBSTtZQUFFLE1BQU0sRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLEtBQUssS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLElBQUUsQ0FBQyxHQUFFLENBQUM7TUFBRSxJQUFJOzs7OztRQUNsVixjQUFjLFFBQUMsT0FBTyxFQUFDLEdBQUcsRUFBQyxNQUFNLFFBQUksTUFBTSxFQUFDLFlBQVksRUFBQyxrQkFBa0IsQ0FBQyxNQUFNLE1BQUssTUFBTSxFQUFDLElBQUksS0FBRSxJQUFJLENBQUMsWUFBWTs7OztRQUNySCxxQkFBcUIsUUFBQyxPQUFPLEVBQUMsSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEdBQUksTUFBTSxPQUFDLGlCQUFpQix1QkFBRyxNQUFNLENBQUMsVUFBVSxFQUFHLDJCQUEyQjs7OztRQVlsSixlQUFlLGtCQUFDLGdCQUFnQixJQUFHLFFBQVE7S0FBQyxRQUFRO3FCQUFDLGdCQUFnQixJQUFHLFNBQVMsSUFBQyxTQUFTLEdBQUMsVUFBVTs7OztRQUN0RyxhQUFhO1NBQUUsV0FBVztHQUFDLFdBQVcsT0FBQyxXQUFXLFNBQUMsVUFBVTs7Ozs7Ozs7Ozs7Ozs7O09BNEZoRCxHQUFHO09BQTRDLE9BQU8sV0FBdEQsR0FBRztPQUErRyxNQUFNLFdBQXpFLE9BQU87T0FBbUssRUFBRSxhQUF6RyxNQUFNO3dCQUFpRyxFQUFFOztXQUFGLEVBQUU7OzBCQUFGLEVBQUU7Ozs7U0FBZ0UsQ0FBQzs7d0JBQUQsQ0FBQzs7Ozs7Ozs7O1dBQW9FLEdBQUM7NEJBQUQsR0FBQzs7ZUFBRCxHQUFDO3dEQUFFLGdCQUFnQjswQkFBbkIsR0FBQzs7OztXQUErQixTQUFPO3NDQUFQLFNBQU87Ozs7Ozs7Ozs7OztrQkEzSW5aLFdBQVc7a0NBMklpZSxXQUFXLEVBQUMsT0FBTzs7O3NCQUFJLEtBQUs7Z0JBQUUsS0FBRzs7Z0JBQWtFLElBQUksV0FBekUsS0FBRztpQ0FBa0UsSUFBSTs7b0JBQUosSUFBSTs7Z0JBQW1DLE1BQU0sYUFBN0MsSUFBSTtpQ0FBbUMsTUFBTTs7b0JBQU4sTUFBTTs7Z0JBQXdDLE1BQUksYUFBbEQsTUFBTTtnQkFBcUUsR0FBQyxXQUE5QixNQUFJO2lDQUF5QixHQUFDOztvQkFBRCxHQUFDO29CQUE5QixNQUFJOztnQkFBcUYsS0FBSyxhQUE5RixNQUFJO2lDQUFxRixLQUFLOztvQkFBTCxLQUFLOzttQ0FBTCxLQUFLOzs7O2tCQUEwSixLQUFHO21DQUFILEtBQUc7Ozs7c0JBQTVaLEtBQUs7NkNBQXNkLEtBQUssT0FBQyxLQUFLLEVBQUMsYUFBYTs7OztzQkFBcGYsS0FBSzt3Q0FBeWdCLFVBQVUsT0FBQyxLQUFLLEVBQUMsS0FBSzs7OztzQkFBMUcsV0FBVzs7Ozs7Ozs7O2lDQUEySCxpQkFBaUIsT0FBQyxLQUFLOzs7Ozs7Ozs7O3NCQUE5TCxLQUFHO2lDQUFILEtBQUc7Ozs7OztzQkFBNVosS0FBSztzREFBOFgsS0FBSyxFQUFDLE1BQU0sRUFBRyxLQUFLOzs7Ozs7Ozs7O29CQUFoWixLQUFHOzs7O29DQUFILEtBQUcsMkVBQTJDLEtBQUssRUFBQyxNQUFNLEVBQUcsS0FBSzs7Ozs7Ozs7cUJBQXpFLEtBQUs7K0JBQTZFLFNBQVMsT0FBQyxLQUFLLEVBQUMsT0FBTzs7OztxQkFBekcsS0FBSzsrQkFBc0gsVUFBVSxPQUFDLEtBQUssRUFBQyxLQUFLOzs7O3FCQUFqSixLQUFLOytCQUE0TCxLQUFLLE9BQUMsS0FBSyxFQUFDLFVBQVUsVUFBRSxLQUFLLEVBQUMsYUFBYTs7OztxQkFBNU8sS0FBSzs7cURBQTRQLEtBQUssRUFBQyxNQUFNLEVBQUcsTUFBTTs2QkFBWSxTQUFTLE9BQUMsS0FBSyxFQUFDLE1BQU07d0NBQUksS0FBSyxFQUFDLE1BQU0sRUFBRyxLQUFLLElBQUMsU0FBUyxTQUFDLEtBQUssRUFBQyxNQUFNLENBQUMsV0FBVzs7Ozs7K0JBQTVXLEtBQUc7Ozs7Ozs7Ozs7Ozs7YUFBaW5CLEdBQUM7OzRCQUFELEdBQUM7Ozs7OztpQkEzSS9uQyxXQUFXO2lDQTJJOGIsV0FBVyxFQUFDLE9BQU8sRUFBRSxNQUFNOzs7Ozs7Ozs7O2VBQXhGLFNBQU87MEJBQVAsU0FBTzs7Ozs7OzttQ0FBcEUsaUJBQWlCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBbEcsaUJBQWlCLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQTFPLE9BQU87V0FBdEQsR0FBRzs7O1VBM0lmLFdBQVc7MEJBMkk4TixXQUFXLEVBQUMsUUFBUTs7O29CQUEvSCxNQUFNLGNBQTZCLFdBQVcsRUFBQyxJQUFJO3NCQUFySyxHQUFHOzs7OztjQUFoQixXQUFXOzs7Ozs7Ozs7Ozs7O09BQ1EsS0FBRztPQUE0QyxTQUFPLFdBQXRELEtBQUc7T0FBK0csUUFBTSxXQUF6RSxTQUFPO09BQStLLElBQUUsYUFBckgsUUFBTTt3QkFBNkcsSUFBRTs7V0FBRixJQUFFOzswQkFBRixJQUFFOzs7O1NBQXlFLEdBQUM7O3dCQUFELEdBQUM7Ozs7Ozs7OztXQUEwRSxHQUFDOzRCQUFELEdBQUM7O2VBQUQsR0FBQzt3REFBRSxzQkFBc0I7MEJBQXpCLEdBQUM7Ozs7V0FBcUMsU0FBTzt1Q0FBUCxTQUFPOzs7Ozs7Ozs7Ozs7a0JBMUkxYixpQkFBaUI7a0NBMEkyZ0IsaUJBQWlCLEVBQUMsT0FBTzs7O3NCQUFJLEtBQUs7Z0JBQUUsS0FBRztnQkFBaUMsTUFBSSxXQUF4QyxLQUFHO2lDQUFpQyxNQUFJOztvQkFBSixNQUFJOztnQkFBbUMsUUFBTSxhQUE3QyxNQUFJO2tDQUFtQyxRQUFNOztvQkFBTixRQUFNOztnQkFBNEMsTUFBSSxhQUF0RCxRQUFNO2dCQUF5RSxHQUFDLFdBQTlCLE1BQUk7a0NBQXlCLEdBQUM7O29CQUFELEdBQUM7b0JBQTlCLE1BQUk7O2dCQUFnRixPQUFLLGFBQXpGLE1BQUk7a0NBQWdGLE9BQUs7O29CQUFMLE9BQUs7b0JBQXROLEtBQUc7Ozs7Ozs7Ozs7O3FCQUFWLEtBQUs7K0JBQTRDLFNBQVMsT0FBQyxLQUFLLEVBQUMsT0FBTzs7OztxQkFBeEUsS0FBSzsrQkFBcUYsVUFBVSxPQUFDLEtBQUssRUFBQyxLQUFLOzs7O3FCQTFJenFCLGlCQUFpQjsrQkEwSTRzQixLQUFLLE9BQUMsaUJBQWlCLEVBQUMsY0FBYzs7OztxQkFBMU0sS0FBSzsrQkFBa08sU0FBUyxPQUFDLEtBQUssRUFBQyxXQUFXOzs7OzsrQkFBM1AsS0FBRzs7Ozs7Ozs7Ozs7OzthQUF1UixHQUFDOzs0QkFBRCxHQUFDOzs7Ozs7aUJBMUkzMUIsaUJBQWlCO2lDQTBJa2UsaUJBQWlCLEVBQUMsT0FBTyxFQUFFLE1BQU07Ozs7Ozs7Ozs7ZUFBakcsU0FBTzswQkFBUCxTQUFPOzs7Ozs7O21DQUFoRix1QkFBdUIsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUE5Ryx1QkFBdUIsR0FBRyxTQUFTOzs7Ozs7Ozs7V0FBL1AsU0FBTztXQUF0RCxLQUFHOzs7VUExSXJCLGlCQUFpQjswQkEwSTBPLGlCQUFpQixFQUFDLEtBQUs7OztvQkFBOUksUUFBTSxjQUE2QixpQkFBaUIsRUFBQyxJQUFJO3NCQUEzSyxLQUFHOzs7OztjQUF0QixpQkFBaUI7Ozs7Ozs7Ozs7OztRQUVyQixTQUFTOztXQUFFLGdCQUFnQjs7OztpQkFBRyxlQUFlOzs7O1dBQVcsaUJBQWlCOzs7aUJBQWdCLFFBQVEsQ0FBQyxNQUFNO29CQUFvQixRQUFRLENBQUMsS0FBSzs7Ozs7Ozs7O0tBQzFJLElBQUk7dUJBQUosSUFBSTs7OztPQUM4QixTQUFPO09BQXVDLEtBQUcscUJBQWpELFNBQU87T0FBNEMsUUFBTSxXQUFYLEtBQUc7eUJBQUUsUUFBTTs7V0FBTixRQUFNOztPQUEyRSxHQUFDLGFBQWxGLFFBQU07eUJBQTJFLEdBQUM7O1dBQUQsR0FBQztXQUF2RixLQUFHOztPQUFnUCxRQUFNLGFBQXpQLEtBQUc7O1dBQWpELFNBQU87Ozt3QkFBb0QsY0FBYyxLQUFDLDhCQUE4QixHQUFDLGdCQUFnQjs7d0JBQWMsY0FBYztPQUFDLHVEQUF1RDtPQUFDLHVFQUF1RTs7O29CQUFZLFFBQU07WUFBVyxpQkFBaUI7OztzQkFBblUsU0FBTzs7Ozs7d0JBQXJDLGdCQUFnQixJQUFHLFNBQVM7Ozs7Ozs7Ozs7Ozs7O09BRTlCLFNBQU87T0FBc0IsS0FBRyxXQUFoQyxTQUFPO09BQTJCLEdBQUMsV0FBTixLQUFHO3lCQUFFLEdBQUM7O1dBQUQsR0FBQzs7T0FBbUUsRUFBRSxhQUF0RSxHQUFDO3lCQUFtRSxFQUFFOztXQUFGLEVBQUU7O1dBQTNFLEtBQUc7V0FBaEMsU0FBTzs7MkJBQVAsU0FBTzs7O1VBQ1AsWUFBWTs7YUFBVSxlQUFlOzs7Ozs7YUFBbUMsZUFBZTs7OztVQUFHLFFBQU07VUFBNkYsUUFBTSxxQkFBekcsUUFBTTs0QkFBNkYsUUFBTTs7O2NBQU4sUUFBTTs7VUFBd0QsR0FBQyxhQUEvRCxRQUFNOzRCQUF3RCxHQUFDOztjQUFELEdBQUM7Y0FBbEssUUFBTTs7Ozs7OztlQTlIOUYsSUFBSTsrQkE4SHdQLElBQUksRUFBQyxnQkFBZ0IsSUFBRSxDQUFDOzs7O3FCQTlIcFIsSUFBSSxtQkE4SCtMLEtBQUssT0FBQyxJQUFJLEVBQUMsVUFBVTs7Ozt1QkFBaEksUUFBTSxRQUFxQyxRQUFRLENBQUMsY0FBYzt5QkFBbEUsUUFBTTs7Ozs7Ozs7Ozs7O09BQ2hHLFNBQU87T0FBdUIsS0FBRyxXQUFqQyxTQUFPO09BQXdJLFFBQU0scUJBQXZILEtBQUc7O1dBQUgsS0FBRzs7MkJBQUgsS0FBRzs7O1VBQWlNLFlBQVk7O2FBQVUsY0FBYzs7Ozs7O2FBQThCLGNBQWM7Ozs7Ozs7OztZQUEyQixLQUFHO1lBQW1ELEtBQUcsV0FBekQsS0FBRzs4QkFBbUQsS0FBRzs7OzhDQUF1RCxXQUFXLHVCQUFJLEtBQUs7Y0FBUSxRQUFNOzs7Ozs0QkFBTixRQUFNOzRCQUFOLFFBQU0sa0NBQW9KLEtBQUssUUFBRyxjQUFjLEtBQUMsTUFBTSxHQUFDLFNBQVM7b0NBQWpNLFFBQU0sb0RBQWUsS0FBSyxRQUFHLGNBQWM7Ozs7O21CQTNIbGdCLFdBQVc7bUJBMkgrYixLQUFLOzJDQUErRSxLQUFLLEdBQUMsQ0FBQyxhQUFPLFdBQVcsRUFBQyxNQUFNLEtBQUssYUFBYSxPQUFDLEtBQUssR0FBRSxPQUFPOzs7OzsyQkFBeEksUUFBTSxjQUEyTSxjQUFjLEVBQUMsS0FBSzs2QkFBck8sUUFBTTs7Ozs7Ozs7WUFBa1AsTUFBSTs4QkFBSixNQUFJOztnQkFBSixNQUFJO2dCQUFsVixLQUFHOztZQUF1WSxNQUFHLGFBQTdZLEtBQUc7WUFBcWpCLE1BQUcsV0FBakwsTUFBRzs7O3NCQUEySyxNQUFHLGlCQUFvRyxXQUFXLHVCQUFJLEtBQUs7Y0FBUSxRQUFNOztjQUEySCxNQUFJLFdBQXJJLFFBQU07Z0NBQTJILE1BQUk7O2tCQUFKLE1BQUk7O2NBQWtELFFBQU0sYUFBNUQsTUFBSTtnQ0FBa0QsUUFBTTs7a0JBQU4sUUFBTTs7Y0FBeUMsR0FBQyxhQUFoRCxRQUFNO2dDQUF5QyxHQUFDOztrQkFBRCxHQUFDOztrQkFBdk8sUUFBTTs7OztvQ0FBTixRQUFNLHFEQUFrRSxLQUFLLFFBQUcsY0FBYzs7Ozs7OzttQkFBM0csS0FBSztvREFBNkMsU0FBUyxPQUFDLEtBQUs7Ozt5QkFBakUsS0FBSyxtQkFBb0ssV0FBVyxPQUFDLEtBQUs7OzttQkFBMUwsS0FBSzs2QkFBdU0sYUFBYSxPQUFDLEtBQUssR0FBRSxPQUFPOzs7O21CQUF4TyxLQUFLOzZCQUFpUCxhQUFhLE9BQUMsS0FBSyxHQUFFLFlBQVk7Ozs7OzJCQUExUSxRQUFNLFFBQXdHLFNBQVMsT0FBQyxLQUFLOzZCQUE3SCxRQUFNOzs7Ozs7OztnQkFBekksTUFBRztnQkFBakwsTUFBRztnQkFBbmMsS0FBRzs7O3NDQUF1WSxjQUFjLElBQUMsQ0FBQztnQkEzSHJ1QixXQUFXO2dDQTJIK3RCLFdBQVcsRUFBQyxNQUFNOzs7cUJBQTZMLE1BQUcscUNBQWtFLGNBQWM7Ozs4QkFBalEsTUFBRyxHQUFnRCxLQUFLLFdBQUcsbUJBQW1CLEVBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTzs0QkFBdkcsTUFBRyxHQUFvSCxLQUFLLEtBQUUsWUFBWSxDQUFDLEtBQUssUUFBQyxXQUFXLEVBQUMsTUFBTSxFQUFDLE1BQU07MkJBQTFtQixLQUFHOzs7O1lBQStpQyxNQUFHOzsyQkFBSCxNQUFHOzs7Ozs7Z0JBM0hoNEMsV0FBVztnQ0EySDRTLFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBQTNVLFNBQU87O09BQ1AsU0FBTyxhQURQLFNBQU87T0FDdUIsTUFBRyxXQUFqQyxTQUFPO09BQW9JLFFBQU0scUJBQW5ILE1BQUc7O1dBQUgsTUFBRzs7T0FBa00sTUFBRyxhQUF4TSxNQUFHOzs7O0tBQWtNLE1BQUc7OztZQS9IOUwsV0FBVzs0QkErSGdOLFdBQVcsRUFBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUM7OztnQkFBSyxJQUFJO1VBQUUsUUFBTTtVQUE4RSxNQUFHLFdBQXZGLFFBQU07VUFBbUYsUUFBTSxXQUFYLE1BQUc7NEJBQUUsUUFBTTs7Y0FBTixRQUFNOztVQUEyQixNQUFJLGFBQXJDLFFBQU07NEJBQTJCLE1BQUk7O2NBQUosTUFBSTtjQUExQyxNQUFHOztVQUEyRyxHQUFDLGFBQS9HLE1BQUc7NEJBQTJHLEdBQUM7O2NBQUQsR0FBQztjQUFuTSxRQUFNOzs7Ozs7Ozs7cUJBQVosSUFBSSxtQkFBbUcsUUFBUSxPQUFDLElBQUk7cUJBQXBILElBQUksbUJBQWtJLFFBQVEsT0FBQyxJQUFJOzs7ZUFBbkosSUFBSTt5QkFBcUosU0FBUyxDQUFDLGVBQWUsT0FBQyxJQUFJOzs7cUJBQXZMLElBQUksbUJBQXlNLEtBQUssT0FBQyxJQUFJLEVBQUMsTUFBTTs7Ozt1QkFBeE4sUUFBTSxRQUFnQyxDQUFDO09BQUEsUUFBUSxDQUFDLGNBQWM7T0FBRSxTQUFTLE9BQUMsSUFBSTtNQUFFLENBQUM7O3lCQUFqRixRQUFNOzs7VUFBeU8sR0FBQzs7eUJBQUQsR0FBQzs7Ozs7Ozs7O1dBQWhULE1BQUc7V0FBdE8sU0FBTzs7T0FDUCxRQUFNLGFBRE4sU0FBTzs7Ozs7Ozs7O3dCQWhLb0YsYUFBYTtzQkE2Si9DLFVBQVUsQ0FBQyxhQUFhLElBQUUsV0FBVzs7O3NCQUFZLFFBQVE7Ozs7b0JBRTZCLFFBQU0sUUFBaUMsUUFBUSxDQUFDLFNBQVM7b0JBQzdELFFBQU0sUUFBaUMsUUFBUSxDQUFDLGNBQWM7b0JBQ3pNLFFBQU0sRUFBbUMsU0FBUzs7Ozs7Ozs7Ozs7U0FFbEQsU0FBTztTQUEySixLQUFLLHFCQUF2SyxTQUFPO1NBQXlMLFNBQU0sV0FBcEMsS0FBSztTQUF3RixLQUFLLGFBQXBFLFNBQU07OzZCQUF5RCxLQUFLOztTQUFvSCxTQUFNLGFBQS9ILEtBQUs7O2FBQWxHLEtBQUs7YUFBdkssU0FBTzs7NkJBQVAsU0FBTzs7O1lBQ1AsWUFBWTs7ZUFBVSxlQUFlOzs7Ozs7ZUFBbUMsZUFBZTs7OztZQUFHLFNBQU87WUFBcUIsTUFBRyxXQUEvQixTQUFPO1lBQWdELE1BQUcsV0FBOUIsTUFBRztZQUF3RCxRQUFNLHFCQUF0QyxNQUFHOzhCQUE2QixRQUFNOztnQkFBTixRQUFNO2dCQUF0QyxNQUFHOztZQUE0RSxNQUFHLGFBQWxGLE1BQUc7WUFBMEcsUUFBTSxxQkFBcEMsTUFBRzs4QkFBMkIsUUFBTTs7Z0JBQU4sUUFBTTtnQkFBcEMsTUFBRzs7WUFBNEUsTUFBRyxhQUFsRixNQUFHO1lBQXlHLFFBQU0scUJBQW5DLE1BQUc7OEJBQTBCLFFBQU07O2dCQUFOLFFBQU07Z0JBQW5DLE1BQUc7Z0JBQTVMLE1BQUc7O1lBQTBRLE1BQUcsYUFBaFIsTUFBRzs7O3NCQUEwUSxNQUFHLFlBQTBCLEtBQUssRUFBQyxLQUFLLEVBQUMsS0FBSyxFQUFDLEtBQUssRUFBQyxLQUFLLEVBQUMsS0FBSyxFQUFDLEtBQUssdUJBQUssQ0FBQztjQUFFLE1BQUk7Z0NBQUosTUFBSTs7a0JBQUosTUFBSTtzREFBRSxDQUFDOzZCQUFQLE1BQUk7Ozs7Ozs7O2dCQUFsRixNQUFHOztZQUF3RyxNQUFHLGFBQTlHLE1BQUc7OEJBQXdHLE1BQUc7Ozs7Ozs7aUJBcEkzYSxRQUFROzJCQW9JNGIsS0FBSyxPQUFDLFFBQVEsRUFBQyxPQUFPOzs7cUJBQUssQ0FBQztlQUFFLE1BQUk7OzhCQUFKLE1BQUk7Ozs7Ozs7Ozs7OzsrQ0FwSXRlLFFBQVEseUJBb0lvZixRQUFRLEVBQUMsSUFBSSx3QkFBSSxDQUFDO2NBQUUsU0FBTTs7Z0NBQU4sU0FBTTs7a0JBQU4sU0FBTTs7O21DQUFOLFNBQU0sWUFBVCxDQUFDLGtDQUFzRixDQUFDLEVBQUMsU0FBUzswQkFBMUUsQ0FBQyxFQUFDLE1BQU07NENBQWtCLFdBQVcsU0FBRyxDQUFDLEVBQUMsR0FBRzs7O1dBQWxFLFNBQU0sbUJBQVQsQ0FBQyx5QkFBK0csQ0FBQyxFQUFDLE1BQU07c0NBQXhILENBQUMseUJBQXVKLENBQUMsRUFBQyxHQUFHOzs7MkJBQTFKLFNBQU0sUUFBK0gsVUFBVSxPQUFDLENBQUM7NkJBQWpKLFNBQU07Ozs7Ozs7O2dCQUE5RyxNQUFHOztZQUF1UixNQUFHLGFBQTdSLE1BQUc7WUFBbVUsTUFBRyxxQkFBL0MsTUFBRzs7O3NCQUF5QyxNQUFHLFlBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsdUJBQUssQ0FBQztjQUFFLEdBQUM7OzhDQUFELEdBQUMsY0FBaUIsQ0FBQzs2QkFBbkIsR0FBQzs7Ozs7Ozs7Z0JBQTlCLE1BQUc7O2dCQUEvQyxNQUFHO2dCQUFqckIsU0FBTzs7Ozs7OztpQkFwSS9GLElBQUk7aUNBb0lnUSxJQUFJLEVBQUMsZ0JBQWdCLElBQUUsQ0FBQzs7Ozs7O3VCQXBJNVIsSUFBSSxtQkFvSW1MLEtBQUssT0FBQyxJQUFJLEVBQUMsVUFBVTs7O2lCQXBJNU0sSUFBSTsyQkFvSThVLEtBQUssT0FBQyxJQUFJLEVBQUMsWUFBWTs7Ozs7MkJBQWpSLFNBQU87Ozs7Ozs7Ozs7OztTQUNqRyxVQUFPO1NBQTJDLE1BQUcsV0FBckQsVUFBTztTQUFzRSxTQUFNLFdBQWpDLE1BQUc7O1NBQXlILFNBQU0sYUFBdkcsU0FBTTs7MkJBQTJGLFNBQU07O2FBQU4sU0FBTTthQUFsSSxNQUFHOzs2QkFBSCxNQUFHOzs7O1dBQXlULE1BQUc7OzBCQUFILE1BQUc7Ozs7Ozs7OzthQUF5RyxNQUFHO2FBQXdELFNBQU0scUJBQWpFLE1BQUc7O2lCQUFILE1BQUc7MEJBQXdELFNBQU0sRUFBVyxPQUFPOzRCQUFuRixNQUFHOzs7OzthQUFrSCxNQUFHO2FBQTJCLEdBQUMsV0FBL0IsTUFBRzsrQkFBMkIsR0FBQzs7aUJBQUQsR0FBQzs7YUFBNEksSUFBRSxhQUEvSSxHQUFDOytCQUE0SSxJQUFFOztpQkFBRixJQUFFO2lCQUE3SyxNQUFHOzthQUFnWCxNQUFHLGFBQXRYLE1BQUc7Ozs7V0FBZ1gsTUFBRzs7dUJBQTZCLFlBQVk7O3NCQUFJLElBQUk7Z0JBQUUsT0FBTzs7Z0JBQTRELFNBQU0sV0FBekUsT0FBTztnQkFBaUosTUFBRyxXQUF4RixTQUFNO2dCQUFvRixRQUFNLFdBQVgsTUFBRztrQ0FBRSxRQUFNOztvQkFBTixRQUFNOztnQkFBMkIsTUFBSSxhQUFyQyxRQUFNO2tDQUEyQixNQUFJOztvQkFBSixNQUFJO29CQUExQyxNQUFHOztnQkFBMkcsTUFBRyxhQUFqSCxNQUFHO2dCQUFrSSxHQUFDLFdBQXhCLE1BQUc7a0NBQW9CLEdBQUM7O29CQUFELEdBQUM7O2dCQUE0QixPQUFJLGFBQWpDLEdBQUM7OztvQkFBeEIsTUFBRztvQkFBdE0sU0FBTTs7b0NBQU4sU0FBTTs7OztrQkFBOFYsTUFBRztrQkFBc0IsU0FBTSxXQUEvQixNQUFHO2tCQUFzRixTQUFNLGFBQXRFLFNBQU07O3NCQUEvQixNQUFHOytCQUFzQixTQUFNLFFBQWUsU0FBUyxPQUFDLElBQUk7K0JBQTZCLFNBQU0sY0FBOEIsUUFBUSxRQUFDLElBQUk7aUNBQTFJLE1BQUc7Ozs7OztzQkFuS2x4QyxVQUFVO3NCQW1LdzFCLElBQUk7c0RBQW1aLFVBQVUsU0FBRyxJQUFJLEVBQUMsRUFBRTs7Ozs7Ozs7OztvQkFBcmEsT0FBTzs7OztzQ0FBUCxPQUFPLHVFQUFpQixVQUFVLFNBQUcsSUFBSSxFQUFDLEVBQUU7Ozs7c0NBQThRLE9BQUksbUVBQWEsVUFBVSxTQUFHLElBQUksRUFBQyxFQUFFOzs7MkJBQXJXLElBQUksbUJBQXVLLFFBQVEsT0FBQyxJQUFJOzJCQUF4TCxJQUFJLG1CQUFzTSxRQUFRLE9BQUMsSUFBSTs7O3FCQUF2TixJQUFJOytCQUF5TixTQUFTLENBQUMsZUFBZSxPQUFDLElBQUk7OzsyQkFBM1AsSUFBSSxtQkFBb1MsS0FBSyxPQUFDLElBQUksRUFBQyxNQUFNOzs7OzZCQUFoUCxTQUFNLGNBQWdDLFVBQVUsd0JBQUMsVUFBVSxTQUFHLElBQUksRUFBQyxFQUFFLElBQUMsSUFBSSxTQUFDLElBQUksRUFBQyxFQUFFOytCQUFySixPQUFPOzs7Z0JBQXdsQixJQUFDOzsrQkFBRCxJQUFDOzs7Ozs7Ozs7aUJBQXRwQixNQUFHOztpQ0FBSCxNQUFHOzs7O2VBQWl2QixTQUFNO2lDQUFOLFNBQU07O21CQUFOLFNBQU07OztrQkFuSzNqRCxPQUFPO2tCQXFDbkQsV0FBVzs7a0NBOEgrb0QsT0FBTztlQUFDLGNBQWM7aUNBQWEsV0FBVyxFQUFDLE1BQU07Ozs0QkFBOUcsU0FBTSxjQUFnQyxPQUFPLFNBQUUsT0FBTzs4QkFBdEQsU0FBTTs7Ozs7O21CQTlIdm1ELFdBQVc7bUNBOEhna0QsV0FBVyxFQUFDLE1BQU0sR0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztrQkFuS3htRCxXQUFXO2tCQXFDckYsUUFBUTs4QkF2Q2lGLGFBQWE7O2tEQXFLNGhCLFdBQVcsR0FBRyxRQUFRO2VBQUMsaUJBQWlCO3FCQUFDLFFBQVE7eUJBQUksUUFBUSxFQUFDLEdBQUcsSUFBSSxVQUFVLENBQUMsYUFBYTtnQkFBSSxlQUFlOzs7O2tCQW5LeHFCLFdBQVc7a0JBK0IvQyxXQUFXO2tCQU1qRCxRQUFROztrREE4SG92QixXQUFXLEdBQUcsUUFBUTt3QkFBSSxXQUFXLEVBQUMsTUFBTTtxQkFBdUIsUUFBUTt5QkFBSSxRQUFRLEVBQUMsZ0JBQWdCLG1CQUFtQixLQUFLLE9BQUMsUUFBUSxFQUFDLFVBQVU7Z0JBQUksK0JBQStCOzs7Ozs7Ozs7Ozs7cUNBQXJnQixXQUFXLEdBQUcsS0FBSywyQkFBRSxTQUFTLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztrQ0FBdEosV0FBVyxHQUFHLEtBQUssMkJBQUUsU0FBUyxHQUFHLFNBQVM7Ozs7Ozs7OzthQUE1VyxVQUFPOztTQUNQLFNBQU0sYUFETixVQUFPOzJCQUNQLFNBQU07O2FBQU4sU0FBTTs7U0FBcU0sU0FBTSxhQUFqTixTQUFNOzs7O21CQUh5UCxLQUFLLEVBQXFCLGFBQWE7dUJBQXZDLEtBQUs7K0JBRXZMLFNBQU0sMERBQWUsV0FBVyxHQUFHLFFBQVE7K0JBQXNELFNBQU0sMERBQWUsV0FBVyxHQUFHLEtBQUs7OztjQTlIcE4sUUFBUTs4QkE4SGdQLFFBQVEsYUFBSSxRQUFRLEVBQUMsR0FBRyxjQUFZLGVBQWU7OztPQUM3UyxTQUFNLG1CQUFnQyxRQUFRLFdBQUUsYUFBYTs7aUNBQTZCLGFBQWE7VUFBQyxxQkFBcUI7Z0JBQUMsUUFBUTtXQUFDLHVCQUF1QjtXQUFDLGlDQUFpQzs7d0JBSDZHLGlCQUFpQjs7O3NCQUE5SCxTQUFNLFFBQTZCLFdBQVcsRUFBRSxDQUFDO3VCQUFjLEtBQUssR0FBeUUsQ0FBQyxLQUFFLGFBQWEsR0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUs7c0JBQUssU0FBTSxRQUE2QixXQUFXLENBQUMsQ0FBQztzQkFFM1YsU0FBTSxjQUFxRCxXQUFXLEVBQUMsUUFBUTtzQkFBa0IsU0FBTSxjQUFrRCxXQUFXLEVBQUMsS0FBSztzQkFDdlAsU0FBTSxFQUFtRSxjQUFjO3NCQUFvSCxTQUFNLGNBQW9DLGlCQUFpQixFQUFDLElBQUk7Ozs7Ozs7Ozs7O1dBRXhGLE1BQUc7OztxQkFBSCxNQUFHLFlBQStCLEtBQUssRUFBQyxVQUFVLEVBQUMsV0FBVyxFQUFDLFVBQVUsdUJBQUssTUFBTTthQUFFLFNBQU07OytCQUFOLFNBQU07O2lCQUFOLFNBQU07OztrQ0FBTixTQUFNLDBEQUFlLFdBQVcsR0FBRyxNQUFNOzhCQUEyRCxNQUFNOzs7MEJBQTFHLFNBQU0sUUFBbUQsQ0FBQztnQkFBQSxXQUFXLEVBQUMsTUFBTTtnQkFBQyxnQkFBZ0IsRUFBQyxDQUFDO1NBQUMsQ0FBQzs7NEJBQWpHLFNBQU07Ozs7Ozs7O2VBQTVGLE1BQUc7O1dBQXFOLE1BQUcsYUFBM04sTUFBRztXQUF3UixTQUFNLHFCQUF6RSxNQUFHOztXQUF1SyxTQUFNLGFBQTdHLFNBQU07OztlQUF6RSxNQUFHOzsrQkFBSCxNQUFHOzs7Y0FBK1IsWUFBWTs7aUJBQVUsY0FBYzs7Ozs7O2lCQUF5QixjQUFjOzs7Ozs7Ozs7Z0JBQStCLE1BQUc7Z0JBQW1GLE1BQUcsV0FBekYsTUFBRztrQ0FBbUYsTUFBRzs7O2tEQUF1RCxlQUFlLHVCQUFJLEtBQUs7a0JBQVEsU0FBTTs7Ozs7Z0NBQU4sU0FBTTtnQ0FBTixTQUFNLGtDQUEwSixLQUFLLFFBQUcsZ0JBQWdCLEtBQUMsTUFBTSxHQUFDLFNBQVM7eUNBQXpNLFNBQU0scURBQWUsS0FBSyxRQUFHLGdCQUFnQjs7Ozs7dUJBcklsL0IsZUFBZTt1QkFxSXk2QixLQUFLOytDQUFpRixLQUFLLEdBQUMsQ0FBQyxhQUFPLGVBQWUsRUFBQyxNQUFNLEtBQUssYUFBYSxPQUFDLEtBQUssR0FBRSxPQUFPOzs7OzsrQkFBOUksU0FBTSxjQUFtTixnQkFBZ0IsRUFBQyxLQUFLO2lDQUEvTyxTQUFNOzs7Ozs7OztnQkFBNFAsT0FBSTtrQ0FBSixPQUFJOztvQkFBSixPQUFJO29CQUFoVyxNQUFHOztnQkFBMlosTUFBRyxhQUFqYSxNQUFHO2dCQUE2a0IsTUFBRyxXQUFyTCxNQUFHOzs7MEJBQStLLE1BQUcsaUJBQXNHLGVBQWUsdUJBQUksS0FBSztrQkFBUSxTQUFNOztrQkFBME8sT0FBSSxXQUFwUCxTQUFNO29DQUEwTyxPQUFJOztzQkFBSixPQUFJOztzQ0FBSixPQUFJOzs7O29CQUF3RSxPQUFJO3NDQUFKLE9BQUk7O3dCQUFKLE9BQUk7Ozs4QkFBN1UsS0FBSyxtQkFBa1csU0FBUyxPQUFDLEtBQUs7OzttQ0FBN0MsT0FBSTs7Ozs7NEJBQTdVLEtBQUssbUJBQWtULFNBQVMsT0FBQyxLQUFLOzs7Ozs7Ozs7a0JBQStELFNBQU07b0NBQU4sU0FBTTs7c0JBQU4sU0FBTTs7a0JBQWdDLEdBQUMsYUFBdkMsU0FBTTtvQ0FBZ0MsR0FBQzs7c0JBQUQsR0FBQzs7c0JBQS9aLFNBQU07Ozs7eUNBQU4sU0FBTTs7Ozs7Ozt1QkFBbkIsS0FBSzt3REFBNkMsU0FBUyxPQUFDLEtBQUs7Ozs7b0NBQTRCLFlBQVksT0FBQyxLQUFLOzBCQUFrQixZQUFZLE9BQUMsS0FBSyw0QkFBRyxlQUFlLEdBQUcsU0FBUzswQ0FBaUIsS0FBSyxRQUFHLGdCQUFnQjs7OzZCQUExTixLQUFLLG1CQUFtUixXQUFXLE9BQUMsS0FBSzs2QkFBelMsS0FBSyxtQkFBd1ksWUFBWSxPQUFDLEtBQUs7Ozt1QkFBL1osS0FBSztpQ0FBeWEsYUFBYSxPQUFDLEtBQUssR0FBRSxZQUFZOzs7OzsrQkFBbGMsU0FBTSxRQUF1TixTQUFTLE9BQUMsS0FBSztpQ0FBNU8sU0FBTTs7Ozs7Ozs7b0JBQS9JLE1BQUc7b0JBQXJMLE1BQUc7b0JBQXZmLE1BQUc7Ozs2QkFBSCxNQUFHLHlCQUEyRCxXQUFXOzswQ0FBK1csZ0JBQWdCLElBQUMsQ0FBQztvQkFySS90QyxlQUFlO29DQXFJcXRDLGVBQWUsRUFBQyxNQUFNOzs7eUJBQWlNLE1BQUcscUNBQWtFLGdCQUFnQjs7O2tDQUF2USxNQUFHLEdBQWdELEtBQUssV0FBRyxtQkFBbUIsRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPO2dDQUF2RyxNQUFHLEdBQW9ILEtBQUssS0FBRSxZQUFZLENBQUMsS0FBSyxRQUFDLGVBQWUsRUFBQyxNQUFNLEVBQUMsTUFBTTsrQkFBbHFCLE1BQUc7Ozs7Z0JBQXF5QyxNQUFHO2dCQUFvQyxJQUFFLHFCQUF6QyxNQUFHO2tDQUFvQyxJQUFFOztvQkFBRixJQUFFOztvQkFBekMsTUFBRzs7OztvQkFyS3YzRCxXQUFXO29DQXFLdTVELFdBQVcsRUFBQyxXQUFXOzs7OytCQUFyRSxNQUFHOzs7Ozs7b0JBckloa0UsZUFBZTtvQ0FxSTh1QixlQUFlLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NBQXZVLFNBQU0sMERBQWUsZUFBZSxHQUFHLE1BQU07aUNBQTBELFNBQU0sMkRBQWUsZUFBZSxHQUFHLFNBQVM7Ozt3QkFBdkosU0FBTSxRQUF1RCxrQkFBa0IsQ0FBQyxNQUFNO3dCQUFpQixTQUFNLFFBQTBELGtCQUFrQixDQUFDLFNBQVM7Ozs7Ozs7OztjQUVqcEIsZUFBZTs7aUJBQUUsUUFBUTs7Ozt1QkFBRyxhQUFhOzs7O3VCQUFHLFNBQVM7Ozs7dUJBQUcsVUFBVTs7Ozt1QkFBRyxZQUFZOzs7O2lCQUFHLGFBQWE7OztxQkFBYyxRQUFRO3NCQUFlLFNBQVM7MkJBQW9CLGNBQWM7b0JBQWEsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OzttQ0FIOUwsSUFBSSxHQUFHLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0FMaEIsSUFBSSxHQUFHLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBTjFCLElBQUksR0FBRyxNQUFNOzs7Ozs7Ozs7U0FGakIsSUFBSTs7eUJBQUosSUFBSTs7O1FBbUJKLFNBQVM7O2lCQUFFLElBQUk7OztlQUFjLFFBQVE7Ozs7Ozs7Ozs7Ozs7T0FJbkMsTUFBRztPQUNELFVBQU8sV0FEVCxNQUFHO09BRUMsU0FBTSxXQURSLFVBQU87T0FJTCxVQUFPLGFBSFAsU0FBTTttQ0FHTixVQUFPOzs7O1NBQW1QLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUFvRSxNQUFHO1dBQTJCLE9BQUksV0FBbEMsTUFBRzs2QkFBMkIsT0FBSTs7ZUFBSixPQUFJOztXQUFzQixTQUFNLGFBQWhDLE9BQUk7O2VBQWxDLE1BQUc7eURBQWlDLFdBQVc7d0JBQVMsU0FBTSxFQUFXLGlCQUFpQjswQkFBMUYsTUFBRzs7Ozs7Ozs7O2FBQWlKLE1BQUc7YUFBeUQsU0FBTSxxQkFBbEUsTUFBRzsrQkFBeUQsU0FBTTs7aUJBQU4sU0FBTTs7YUFBNkMsU0FBTSxhQUF6RCxTQUFNOzs7aUJBQWxFLE1BQUc7OztnQkFwS3ZkLGFBQWE7Z0NBb0syZ0IsYUFBYSxFQUFDLE1BQU0sQ0FBQyxXQUFXOzs7MEJBQVcsU0FBTSxFQUErQixjQUFjOzRCQUFsSyxNQUFHOzs7OzthQUErYixTQUFNOzswQkFBTixTQUFNLEVBQWdDLGNBQWM7Ozs7Ozs7OztrQkFwSzE4QixhQUFhO2tDQW9LaWIsYUFBYSxFQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7bUNBQTFLLFlBQVksR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUE3RixZQUFZLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQXhQLFVBQU87O09BQ1AsVUFBTyxhQURQLFVBQU87bUNBQ1AsVUFBTzs7OztTQUE2UCxJQUFDOzt3QkFBRCxJQUFDOzs7Ozs7Ozs7V0FBa0YsTUFBRztXQUEyQixPQUFJLFdBQWxDLE1BQUc7NkJBQTJCLE9BQUk7O2VBQUosT0FBSTs7V0FBMEIsU0FBTSxhQUFwQyxPQUFJOztlQUFsQyxNQUFHO3lEQUFpQyxlQUFlO3dCQUFTLFNBQU0sRUFBVyxlQUFlOzBCQUE1RixNQUFHOzs7Ozs7Ozs7Ozs7OytDQUF1SixXQUFXLHVCQUFJLFVBQVU7ZUFBRSxTQUFPOztlQUF3SixNQUFHLHFCQUFsSyxTQUFPO2VBQTZKLFNBQU0sV0FBWCxNQUFHO2lDQUFFLFNBQU07ZUFBc0MsU0FBTTtlQUFxSixTQUFNLGFBQWpLLFNBQU07aUNBQXFKLFNBQU07O21CQUFOLFNBQU07bUJBQTdNLFNBQU07O2VBQTZiLE9BQUssYUFBeGMsU0FBTTtpQ0FBNmIsT0FBSzs7bUJBQUwsT0FBSzttQkFBN2MsTUFBRzs7ZUFBMG5CLE1BQUcsYUFBaG9CLE1BQUc7ZUFBK25CLEdBQUMsV0FBTixNQUFHO2lDQUFFLEdBQUM7O21CQUFELEdBQUM7O2VBQTJDLE9BQUssYUFBakQsR0FBQztpQ0FBMkMsT0FBSzs7bUJBQUwsT0FBSzttQkFBdEQsTUFBRzs7bUNBQUgsTUFBRzs7bUNBQThKLGVBQWUsNEJBQWUscUJBQXFCLE9BQUMsVUFBVTs7Ozs7O2lCQUF1RCxNQUFHO21DQUFILE1BQUc7Ozs7cUJBQWprQyxVQUFVOzRDQUFrbkMsS0FBSyxPQUFDLFVBQVUsRUFBQyxjQUFjOzs7O3FCQUFoRSxXQUFXOzs7Ozs7Z0NBQTJHLGtCQUFrQixPQUFDLFVBQVU7Ozs7Ozs7Ozs7cUJBQWhMLE1BQUc7Z0NBQUgsTUFBRzs7Ozs7Ozs7O21CQUFxUCxNQUFHO21CQUEwQixPQUFLLFdBQWxDLE1BQUc7cUNBQTBCLE9BQUs7O3VCQUFMLE9BQUs7dUJBQWxDLE1BQUc7Ozs7dUJBQXp6QyxVQUFVO2lDQUF3MUMsU0FBUyxVQUFJLFVBQVUsRUFBQyxpQkFBaUIsQ0FBQyxXQUFXOzs7O2tDQUFqRyxNQUFHOzs7Ozs7Ozt3QkFBenpDLFVBQVU7d0RBQXd2QyxVQUFVLEVBQUMsaUJBQWlCLEVBQUUsTUFBTSxFQUFHLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFBcHpDLFVBQVU7cURBQXNnQyxVQUFVLEVBQUMsaUJBQWlCLEVBQUUsTUFBTSxFQUFHLEtBQUs7Ozs7Ozs7Ozs7bUJBQWhqQyxTQUFPOzs7O3NDQUFQLFNBQU87cURBQTJGLFVBQVUsRUFBQyxpQkFBaUIsRUFBRSxNQUFNLEVBQUcsS0FBSzs7OzZCQUE5SSxTQUFPO29CQUFuQixVQUFVOzBEQUE4RCxVQUFVLEVBQUMsRUFBRTs7O3dDQUFyRixVQUFVLHlCQUFnTSxVQUFVLEVBQUMsS0FBSzs7NkJBQUUsU0FBTTtvQkFBbE8sVUFBVTs0Q0FBNlMsVUFBVSxFQUFDLEtBQUs7Ozs2QkFBZ0QsU0FBTTtvQkFBN1gsVUFBVTs4Q0FBMGMsVUFBVSxFQUFDLEtBQUs7OzthQUE3RyxTQUFNLGtDQUF1SixvQkFBb0IsR0FBRyxJQUFJOzs7b0JBM0t2NkIsb0JBQW9CO29CQTJLb1csVUFBVTtvREFBd2lCLG9CQUFvQixTQUFHLFVBQVUsRUFBQyxFQUFFLElBQUMsR0FBRyxHQUFDLElBQUk7Ozs7b0JBQS9sQixVQUFVO29EQUFnbkIsVUFBVSxFQUFDLFVBQVUsRUFBRyxzQkFBc0IsSUFBQyxzQkFBc0IsR0FBQyx5QkFBeUI7O29CQUF6dEIsVUFBVTtvQ0FBaXRCLFVBQVUsRUFBQyxNQUFNLDhCQUFzQixVQUFVLEVBQUMsTUFBTSxLQUFHLEVBQUU7Ozs7Ozs7O29CQUF4eEIsVUFBVTs4QkFBc3lCLEtBQUssT0FBQyxVQUFVLEVBQUMsY0FBYzs7OztvQkFBLzBCLFVBQVU7b0RBQXMxQixVQUFVLEVBQUMsaUJBQWlCLEVBQUUsTUFBTSxFQUFHLFdBQVcsSUFBQyxNQUFNLFNBQUMsVUFBVSxFQUFDLE1BQU0sQ0FBQyxXQUFXOzs7Ozs0QkFBM3RCLFNBQU0sUUFBaUMsa0JBQWtCLE9BQUMsVUFBVTs0QkFBdUYsU0FBTSxRQUFtQyxnQkFBZ0IsT0FBQyxVQUFVOzhCQUEvYSxTQUFPOzs7Ozs7Ozs7Ozs7YUFBNjdDLElBQUM7OzRCQUFELElBQUM7Ozs7Ozs7O2tCQTNLbDlELFdBQVc7a0NBMks2YyxXQUFXLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0FBOUssZ0JBQWdCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBL0csZ0JBQWdCLEdBQUcsU0FBUzs7Ozs7Ozs7O09BQTB3RCxTQUFNOztXQUFsaEUsVUFBTzs7T0FDUCxVQUFPLGFBRFAsVUFBTzttQ0FDUCxVQUFPOzs7O1NBQXlNLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUFtRixNQUFHO1dBQTJCLE9BQUksV0FBbEMsTUFBRzs2QkFBMkIsT0FBSTs7ZUFBSixPQUFJOztXQUEwQixTQUFNLGFBQXBDLE9BQUk7O2VBQWxDLE1BQUc7eURBQWlDLGVBQWU7d0JBQVMsU0FBTSxFQUFXLGVBQWU7MEJBQTVGLE1BQUc7Ozs7Ozs7Ozs7Ozs7K0NBQXVKLFdBQVcsdUJBQUksSUFBSTtlQUFFLFNBQU87ZUFBaUMsTUFBRyxxQkFBM0MsU0FBTztlQUFzQyxTQUFNLFdBQVgsTUFBRztpQ0FBRSxTQUFNO2VBQW1DLFNBQU07O21CQUEvQyxTQUFNOztlQUF1TCxPQUFLLGFBQWxNLFNBQU07aUNBQXVMLE9BQUs7O21CQUFMLE9BQUs7bUJBQXZNLE1BQUc7O2VBQXNRLE1BQUcsYUFBNVEsTUFBRztlQUEyUSxHQUFDLFdBQU4sTUFBRztpQ0FBRSxHQUFDOzttQkFBRCxHQUFDOztlQUF1QixPQUFLLGFBQTdCLEdBQUM7aUNBQXVCLE9BQUs7O21CQUFMLE9BQUs7bUJBQWxDLE1BQUc7bUJBQXBULFNBQU87Ozt1Q0FBYixJQUFJLHlCQUF5RSxJQUFJLEVBQUMsUUFBUTs0QkFBRSxTQUFNLHVCQUFsRyxJQUFJLGlDQUE2SyxJQUFJLEVBQUMsUUFBUTswQ0FBOUwsSUFBSSx5QkFBbVAsSUFBSSxFQUFDLFVBQVUsaUNBQXRRLElBQUkseUJBQW1SLElBQUksRUFBQyxXQUFXOzhDQUF2UyxJQUFJLHlCQUErVCxJQUFJLEVBQUMsTUFBTTtvREFBOVUsSUFBSSx5QkFBaVcsSUFBSSxFQUFDLFlBQVk7Ozs0QkFBMVIsU0FBTSxRQUFpQyxrQkFBa0IsT0FBQyxJQUFJOzhCQUFwSixTQUFPOzs7Ozs7Ozs7Ozs7YUFBaVosSUFBQzs7NEJBQUQsSUFBQzs7Ozs7Ozs7a0JBeks3MkIsV0FBVztrQ0F5SzBaLFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUE5SyxnQkFBZ0IsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUFoSCxnQkFBZ0IsR0FBRyxTQUFTOzs7Ozs7Ozs7T0FBK3ZCLFNBQU07O1dBQW45QixVQUFPOzsyQkFBUCxVQUFPOzs7Ozs7O09BQ0MsR0FBRyxFQUFDLGdCQUFnQixFQUFDLDJCQUEyQjtPQUFHLEdBQUcsRUFBQyxPQUFPLEVBQUMsdUJBQXVCO09BQUcsR0FBRyxFQUFDLFNBQVMsRUFBQyw0QkFBNEI7OztnQkFBTSxNQUFNO1VBQ3JKLFNBQU07VUFBMkMsT0FBSSxXQUFyRCxTQUFNOzRCQUEyQyxPQUFJOztjQUFKLE9BQUk7O1VBQW9CLE1BQUcsYUFBM0IsT0FBSTtVQUF5QixTQUFNLFdBQVgsTUFBRzs0QkFBRSxTQUFNOztjQUFOLFNBQU07O1VBQXNCLE9BQUssYUFBakMsU0FBTTs0QkFBc0IsT0FBSzs7Y0FBTCxPQUFLO2NBQXRDLE1BQUc7O2NBQTVFLFNBQU07Ozs0QkFEeUksTUFBTSxrQkFDOUYsTUFBTSxDQUFDLENBQUM7NEJBRGdGLE1BQU0sa0JBQy9ELE1BQU0sQ0FBQyxDQUFDOzRCQURpRCxNQUFNLGtCQUNwQyxNQUFNLENBQUMsQ0FBQzs7O3VCQUF6SCxTQUFNLEVBQThCLFVBQVU7eUJBQTlDLFNBQU07Ozs7Ozs7OztPQUVSLFVBQU87bUNBQVAsVUFBTzs7OztTQUFrUCxJQUFDOzt3QkFBRCxJQUFDOzs7Ozs7Ozs7V0FBOEQsTUFBRztXQUEyQixPQUFJLFdBQWxDLE1BQUc7NkJBQTJCLE9BQUk7O2VBQUosT0FBSTs7V0FBMEIsU0FBTSxhQUFwQyxPQUFJOztlQUFsQyxNQUFHO3lEQUFpQyxlQUFlO3dCQUFTLFNBQU0sRUFBVyxlQUFlOzBCQUE1RixNQUFHOzs7Ozs7Ozs7O2FBQWlKLFVBQU87eUNBQVAsVUFBTzs7Ozs7ZUFBZ0csU0FBTTtpQ0FBTixTQUFNOzttQkFBTixTQUFNOztlQUEyQyxPQUFLLGFBQXRELFNBQU07O2lDQUEyQyxPQUFLOzttQkFBTCxPQUFLOzs7OztzQ0FBTCxPQUFLOzs7b0JBbEozbUIsZUFBZTtvQ0FrSjZyQixlQUFlLEVBQUMsR0FBRyxJQUFFLENBQUMsR0FBQyxHQUFHLEdBQUMsRUFBRTs7Ozs7b0JBbEp6dUIsZUFBZTs4QkFrSjhpQixLQUFLLE9BQUMsZUFBZSxFQUFDLE9BQU87Ozs7d0JBQWtDLE1BQU0sT0FBQyxlQUFlLEVBQUMsR0FBRyxLQUFHLENBQUM7d0JBQWtCLE1BQU0sT0FBQyxlQUFlLEVBQUMsR0FBRyxJQUFFLENBQUM7Ozs7b0JBbEp6c0IsZUFBZTs4QkFrSjR0QixLQUFLLE9BQUMsZUFBZSxFQUFDLEdBQUc7Ozs7Ozs7Ozs7ZUFBa0MsU0FBTTtpQ0FBTixTQUFNOzttQkFBTixTQUFNOzs7OzttQkFsSjV5QixlQUFlOzZCQWtKK3hCLEtBQUssT0FBQyxlQUFlLEVBQUMsUUFBUTs7Ozs7Ozs7OzttQkFsSjUwQixlQUFlO21EQWtKc2dCLGVBQWUsRUFBQyxPQUFPLEVBQUcsSUFBSTs7Ozs7Ozs7OztpQkFBckcsVUFBTzs7YUFBNmMsTUFBRyxhQUF2ZCxVQUFPOzs7dUJBQTZjLE1BQUcsaUJBQStCLFdBQVcsdUJBQUksSUFBSTtlQUFFLFNBQU07ZUFBc0ssTUFBRyxxQkFBL0ssU0FBTTtlQUFtTSxTQUFNLFdBQW5DLE1BQUc7aUNBQTBCLFNBQU07O21CQUFOLFNBQU07O2VBQTRCLE9BQUksYUFBdEMsU0FBTTtpQ0FBNEIsT0FBSTs7bUJBQUosT0FBSTs7ZUFBNFYsT0FBSyxhQUFyVyxPQUFJO2lDQUE0VixPQUFLOzttQkFBTCxPQUFLO21CQUFwYSxNQUFHOzttQ0FBSCxNQUFHOzs7OztpQkFBOGUsTUFBRztpQkFBMkIsTUFBRyxXQUFqQyxNQUFHOztpQkFBK0ksSUFBQyxxQkFBckgsTUFBRzttQ0FBaUgsSUFBQzs7cUJBQUQsSUFBQzs7aUJBQTRFLFFBQUssYUFBbEYsSUFBQzttQ0FBNEUsUUFBSzs7cUJBQUwsUUFBSztxQkFBdE0sTUFBRzs7aUJBQTZTLE1BQUcsYUFBblQsTUFBRztpQkFBdVUsSUFBQyxxQkFBM0IsTUFBRzttQ0FBdUIsSUFBQzs7cUJBQUQsSUFBQztxQkFBM0IsTUFBRzs7aUJBQWlFLE1BQUcsYUFBdkUsTUFBRztpQkFBMEYsSUFBQyxxQkFBMUIsTUFBRzttQ0FBc0IsSUFBQzs7cUJBQUQsSUFBQztxQkFBMUIsTUFBRztxQkFBclosTUFBRzs7aUJBQTRkLElBQUMsYUFBaGUsTUFBRzttQ0FBNGQsSUFBQzs7Ozs7bUJBQXVGLE9BQUk7O3VEQUFKLE9BQUk7c0JBQTl0QyxJQUFJO3FEQUE4eUMsSUFBSSxFQUFDLFVBQVU7OztnQ0FBdkcsT0FBSSwwQkFBcUosZUFBZSxPQUFDLElBQUk7O2tDQUE3SyxPQUFJLHFCQUF5TSxLQUFLLEtBQUcsQ0FBQztvQ0FBRyxLQUFLLENBQUMsR0FBRyxFQUFHLE9BQU8scUJBQUUsS0FBSyxDQUFDLEdBQUcsRUFBRyxHQUFHLEdBQUMsQ0FBQztpQkFBQSxLQUFLLENBQUMsY0FBYztpQkFBRyxlQUFlLE9BQUMsSUFBSTtnQkFBRSxDQUFDO2VBQUEsQ0FBQzs7a0NBQTlTLE9BQUk7Ozs7OzJCQUE5dEMsSUFBSSwwQkFBc3NDLElBQUksRUFBQyxTQUFTOzs7Ozs7Ozs7cUJBQXRGLElBQUM7Ozs7d0NBQWxjLE1BQUc7Ozs7Ozs7OzswQkFBaUIsTUFBTSxPQUFDLElBQUksRUFBQyxZQUFZLEtBQUcsQ0FBQzswQkFBa0IsTUFBTSxPQUFDLElBQUksRUFBQyxZQUFZLElBQUUsQ0FBQzs7OztzQkFBOXhCLElBQUk7Z0NBQW96QixNQUFNLE9BQUMsSUFBSSxFQUFDLFlBQVksS0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEVBQUU7Ozs7c0JBQTMxQixJQUFJO2dDQUF5MUIsWUFBWSxPQUFDLElBQUksRUFBQyxZQUFZOzs7O3NCQUEzM0IsSUFBSTtnQ0FBcTRCLE1BQU0sT0FBQyxJQUFJLEVBQUMsbUJBQW1CLEtBQUcsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFOzs7O3NCQUFuN0IsSUFBSTtnQ0FBaTdCLE1BQU0sT0FBQyxJQUFJLEVBQUMsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7c0JBQS85QixJQUFJO2dDQUEwZ0MsWUFBWSxPQUFDLElBQUksRUFBQyxRQUFROzs7O3NCQUF4aUMsSUFBSTtnQ0FBNmtDLFlBQVksT0FBQyxJQUFJLEVBQUMsWUFBWTs7OztzQkFBL21DLElBQUk7Z0NBQWtxQyxZQUFZLE9BQUMsSUFBSSxFQUFDLFNBQVM7Ozs7Ozs7OztpQkFBbVcsSUFBQzttQ0FBRCxJQUFDOztxQkFBRCxJQUFDOzs7MkJBQXJpRCxJQUFJLG1CQUE0b0QsS0FBSyxPQUFDLElBQUksRUFBQyxRQUFROzs7Z0NBQS9ILElBQUM7Ozs7OztxQkFBcmlELElBQUk7cURBQXFvQixJQUFJLEVBQUMsWUFBWSxFQUFHLElBQUk7Ozs7Ozs7Ozs7ZUFBK2dDLE1BQU07ZUFBRSxPQUFJLFdBQVosTUFBTTtpQ0FBRSxPQUFJOzttQkFBSixPQUFJOztlQUEwUCxPQUFJLGFBQWxRLE9BQUk7ZUFBZ1QsT0FBSSxxQkFBMUQsT0FBSTs7bUJBQUosT0FBSTttQkFBMVEsTUFBTTs7bUNBQU4sTUFBTTs7Ozs7Ozs7O3FCQUF0ckQsSUFBSTt3REFBNnJFLElBQUksRUFBQyxFQUFFOzs7O3FCQUF4c0UsSUFBSTs0Q0FBNnRFLEtBQUssT0FBQyxJQUFJLEVBQUMsVUFBVSxDQUFDLE1BQU07Ozs7cUJBQW5HLFdBQVc7Ozs7Ozs7Ozs7Z0NBQTRJLG1CQUFtQixPQUFDLElBQUksU0FBQyxJQUFJLEVBQUMsVUFBVTs7Ozs7Ozs7Ozs7Ozs7OztxQkFBejFFLElBQUk7cURBQXFuRSxJQUFJLEVBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRyxLQUFLOzs7Ozs7Ozs7O21CQUFscEUsU0FBTTs7Ozt5QkFBTixTQUFNOzs2QkFBTixTQUFNO29CQUFaLElBQUk7NENBQStHLElBQUksRUFBQyxVQUFVOzs7d0NBQWxJLElBQUkseUJBQW1OLElBQUksRUFBQyxVQUFVOzs2QkFBVyxPQUFJO29CQUFyUCxJQUFJOzhDQUF1VCxJQUFJLEVBQUMsVUFBVTs7OztvQkF2Sy90QyxvQkFBb0I7b0JBdUtpNEIsSUFBSTtvREFBNmhCLG9CQUFvQixTQUFHLElBQUksRUFBQyxFQUFFLElBQUMsR0FBRyxHQUFDLElBQUk7Ozs7Ozs7O29CQUF4a0IsSUFBSTsyQ0FBNkIsVUFBVSxPQUFDLElBQUksRUFBQyxFQUFFOzs7O29CQUFuRCxJQUFJOzhCQUFvbEIsWUFBWSxPQUFDLElBQUksRUFBQyxVQUFVOzs7O29CQUFwbkIsSUFBSTs7b0NBQW10RCxJQUFJLEVBQUMsU0FBUzs0QkFBWSxZQUFZLE9BQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxNQUFNLGtCQUFZLElBQUksRUFBQyxTQUFTLENBQUMsR0FBRyx5QkFBRyxJQUFJLEVBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRyxDQUFDO2tCQUFDLElBQUk7d0NBQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUcsQ0FBQzttQkFBQyxJQUFJO3lDQUFDLElBQUksRUFBQyxTQUFTLENBQUMsR0FBRyxFQUFHLENBQUMsSUFBQyxJQUFJLEdBQUMsSUFBSTtpQkFBa0IsZUFBZTs7Ozs7NEJBQTVyRCxPQUFJLDBCQUFrSixnQkFBZ0IsT0FBQyxJQUFJOzs4QkFBM0ssT0FBSSxxQkFBdU0sS0FBSyxLQUFHLENBQUM7Z0NBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRyxPQUFPLHFCQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUcsR0FBRyxHQUFDLENBQUM7YUFBQSxLQUFLLENBQUMsY0FBYzthQUFHLGdCQUFnQixPQUFDLElBQUk7WUFBRSxDQUFDO1dBQUEsQ0FBQzs7NEJBQTg4QyxPQUFJLDBCQUFnRixXQUFXLE9BQUMsSUFBSTs0QkFBMWtFLFNBQU0sUUFBMEQsY0FBYyxPQUFDLElBQUksRUFBQyxFQUFFOzhCQUF0RixTQUFNOzs7Ozs7OztpQkFBN0QsTUFBRzs7Ozs7YUFBODZFLElBQUM7OzRCQUFELElBQUM7Ozs7Ozs7O2tCQXZLbjFHLFdBQVc7a0NBdUs4YSxXQUFXLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0FBOUssZ0JBQWdCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBM0YsZ0JBQWdCLEdBQUcsU0FBUzs7Ozs7Ozs7O09BQW10RyxTQUFNOztXQUFoOUcsVUFBTzs7T0FDUCxVQUFPLGFBRFAsVUFBTzttQ0FDUCxVQUFPOzs7O1NBRXdCLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUNFLE1BQUc7V0FBMkIsT0FBSSxXQUFsQyxNQUFHOzZCQUEyQixPQUFJOztlQUFKLE9BQUk7O1dBQXFCLFNBQU0sYUFBL0IsT0FBSTs7ZUFBbEMsTUFBRzt5REFBaUMsVUFBVTt3QkFBUyxTQUFNLEVBQVcsVUFBVTswQkFBbEYsTUFBRzs7Ozs7Ozs7OzthQUVqQyxVQUFPO3lDQUFQLFVBQU87Ozs7O2VBQTJGLFNBQU07aUNBQU4sU0FBTTs7bUJBQU4sU0FBTTs7ZUFBMEMsUUFBSyxhQUFyRCxTQUFNOztpQ0FBMEMsUUFBSzs7bUJBQUwsUUFBSzs7Ozs7O3NDQUFMLFFBQUs7OEJBQWlCLGNBQWMsRUFBQyxHQUFHLElBQUUsQ0FBQzs4QkFBa0IsY0FBYyxFQUFDLEdBQUcsR0FBQyxDQUFDOzs7O29CQXZKek8sY0FBYztvQ0F1SjhOLGNBQWMsRUFBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFOzs7OztvQkF2SnhRLGNBQWM7OEJBdUprRyxLQUFLLE9BQUMsY0FBYyxFQUFDLE9BQU87Ozs7b0JBdko1SSxjQUFjOzhCQXVKNFAsS0FBSyxPQUFDLGNBQWMsRUFBQyxHQUFHOzs7Ozs7Ozs7O2VBQWtDLFNBQU07aUNBQU4sU0FBTTs7bUJBQU4sU0FBTTs7Ozs7bUJBdkoxVSxjQUFjOzZCQXVKOFQsS0FBSyxPQUFDLGNBQWMsRUFBQyxRQUFROzs7Ozs7Ozs7O21CQXZKelcsY0FBYzttREF1SjJELGNBQWMsRUFBQyxPQUFPLEVBQUcsSUFBSTs7Ozs7Ozs7OztpQkFBaEcsVUFBTzs7YUFDUCxNQUFHLGFBREgsVUFBTzs7O3VCQUNQLE1BQUcsaUJBQStCLE1BQU0sdUJBQUksS0FBSztlQUFFLFNBQU87O2VBQ3JCLE1BQUcscUJBRFcsU0FBTztlQUNRLFNBQU0sV0FBbkMsTUFBRztpQ0FBMEIsU0FBTTs7bUJBQU4sU0FBTTs7ZUFBdUIsT0FBSSxhQUFqQyxTQUFNO2lDQUF1QixPQUFJOzttQkFBSixPQUFJOztlQUFxUyxRQUFLLGFBQTlTLE9BQUk7aUNBQXFTLFFBQUs7O21CQUFMLFFBQUs7bUJBQXhXLE1BQUc7O21DQUFILE1BQUc7Ozs7O2lCQUNQLE1BQUc7aUJBQTJCLE1BQUcsV0FBakMsTUFBRzs7aUJBQWlKLElBQUMscUJBQXZILE1BQUc7bUNBQW1ILElBQUM7O3FCQUFELElBQUM7O2lCQUE4RSxRQUFLLGFBQXBGLElBQUM7bUNBQThFLFFBQUs7O3FCQUFMLFFBQUs7cUJBQTFNLE1BQUc7O2lCQUFtVCxNQUFHLGFBQXpULE1BQUc7aUJBQTZVLElBQUMscUJBQTNCLE1BQUc7bUNBQXVCLElBQUM7O3FCQUFELElBQUM7cUJBQTNCLE1BQUc7O2lCQUFrRSxNQUFHLGFBQXhFLE1BQUc7aUJBQTJGLElBQUMscUJBQTFCLE1BQUc7bUNBQXNCLElBQUM7O3FCQUFELElBQUM7cUJBQTFCLE1BQUc7cUJBQTVaLE1BQUc7O2lCQUFvZSxJQUFDLGFBQXhlLE1BQUc7bUNBQW9lLElBQUM7aUJBQW9ILFNBQU07O3FCQUEzSCxJQUFDOzs7O3dDQUExYyxNQUFHOzs7Ozs7OytCQUEyakIsU0FBTTtzQkFGdmxCLEtBQUs7d0VBRThwQixLQUFLLEVBQUMsSUFBSTs7Ozs7MEJBQXRvQixNQUFNLE9BQUMsS0FBSyxFQUFDLFlBQVksS0FBRyxDQUFDOzBCQUFrQixNQUFNLE9BQUMsS0FBSyxFQUFDLFlBQVksSUFBRSxDQUFDOzs7O3NCQUZsSCxLQUFLO2dDQUV1SSxNQUFNLE9BQUMsS0FBSyxFQUFDLFlBQVksS0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEVBQUU7Ozs7c0JBRmhMLEtBQUs7Z0NBRTZLLFlBQVksT0FBQyxLQUFLLEVBQUMsWUFBWTs7OztzQkFGak4sS0FBSztnQ0FFME4sTUFBTSxPQUFDLEtBQUssRUFBQyxtQkFBbUIsS0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEVBQUU7Ozs7c0JBRjFRLEtBQUs7Z0NBRXVRLE1BQU0sT0FBQyxLQUFLLEVBQUMsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7c0JBRnZULEtBQUs7Z0NBRWlXLFlBQVksT0FBQyxLQUFLLEVBQUMsUUFBUTs7OztzQkFGalksS0FBSztnQ0FFcWEsWUFBWSxPQUFDLEtBQUssRUFBQyxZQUFZOzs7O3NCQUZ6YyxLQUFLO2dDQUU2ZixZQUFZLE9BQUMsS0FBSyxFQUFDLFdBQVc7Ozs7c0JBRmhpQixLQUFLO2dDQUVpaUIsTUFBTSxPQUFDLEtBQUssRUFBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7OzhCQUFXLFNBQU0sUUFBMkksYUFBYSxPQUFDLEtBQUs7Ozs7O2lCQUEwQixJQUFDO21DQUFELElBQUM7O3FCQUFELElBQUM7OzsyQkFGaHhCLEtBQUssbUJBRWszQixLQUFLLE9BQUMsS0FBSyxFQUFDLFFBQVE7OztnQ0FBNUgsSUFBQzs7Ozs7O3FCQUZoeEIsS0FBSztxREFFM0MsS0FBSyxFQUFDLFlBQVksRUFBRyxJQUFJOzs7Ozs7Ozs7O2VBQzdCLFFBQU07ZUFBRSxPQUFJLFdBQVosUUFBTTtpQ0FBRSxPQUFJOzttQkFBSixPQUFJOzttQ0FBSixPQUFJOzttQ0FBMFMsZUFBZSw0QkFBZSxlQUFlLE9BQUMsS0FBSyxFQUFDLEVBQUU7bUJBQTVXLFFBQU07O21DQUFOLFFBQU07Ozs7Ozs7OztxQkFIb0MsS0FBSzsyREFJeUMsS0FBSyxFQUFDLEVBQUU7Ozs7cUJBSnRELEtBQUs7NENBSTBFLEtBQUssT0FBQyxLQUFLLEVBQUMsa0JBQWtCLENBQUMsTUFBTTs7OztxQkFBaEgsV0FBVzs7Ozs7Ozs7Ozs7Z0NBQXlKLENBQUM7dUJBQUEsMkJBQTJCLFFBQUMsS0FBSzs7dUJBQUMscUJBQXFCO2tCQUFFLE1BQU0sRUFBQyxNQUFNLE9BQUMsS0FBSyxFQUFDLGtCQUFrQixDQUFDLE1BQU07a0JBQUUsS0FBSyxFQUFDLE1BQU0sT0FBQyxLQUFLLEVBQUMsV0FBVyxJQUFFLEVBQUU7O2dCQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7cUJBSnRULEtBQUs7cURBSTNDLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxNQUFNLEVBQUcsS0FBSzs7Ozs7Ozs7OzttQkFKSyxTQUFPOzs7O3NDQUFQLFNBQU87OzZCQUFQLFNBQU87b0JBQWQsS0FBSztrREFBaUYsS0FBSyxFQUFDLEVBQUU7Ozt3Q0FBOUYsS0FBSyx5QkFDeUIsS0FBSyxFQUFDLElBQUk7NkJBQVcsT0FBSSx1QkFEdkQsS0FBSyxtQ0FDd0gsS0FBSyxFQUFDLElBQUk7OztvQkE5S0UsZUFBZTtvQkE2S3hKLEtBQUs7b0RBQzJTLGVBQWUsU0FBRyxLQUFLLEVBQUMsRUFBRSxJQUFDLEdBQUcsR0FBQyxJQUFJOzs7MkNBRG5WLEtBQUsseUJBQzhWLEtBQUssRUFBQyxNQUFNO29CQUQvVyxLQUFLO29DQUM0VyxLQUFLLEVBQUMsUUFBUSxlQUFPLEtBQUssRUFBQyxRQUFRLEtBQUcsRUFBRTs7Ozs7OztvQkFEelosS0FBSzsyQ0FBOEIsVUFBVSxPQUFDLEtBQUssRUFBQyxFQUFFOzs7OzJDQUE2RCxNQUFNLE9BQUMsS0FBSyxFQUFDLEVBQUUsR0FBSSxNQUFNLE9BQUMsa0JBQWtCOzs7O29CQUEvSixLQUFLOztvQ0FHUixLQUFLLEVBQUMsaUJBQWlCO21DQUFtQixZQUFZLE9BQUMsS0FBSyxFQUFDLGlCQUFpQixDQUFDLE1BQU0sa0JBQVksS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcseUJBQUcsS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRyxDQUFDO2tCQUFDLElBQUk7d0NBQUMsS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRyxDQUFDO21CQUFDLElBQUk7eUNBQUMsS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRyxDQUFDLElBQUMsSUFBSSxHQUFDLElBQUk7aUJBQUcsaUJBQWlCOzs7Ozs0QkFGaE4sT0FBSSxRQUF1SCxXQUFXLE9BQUMsS0FBSzs7OEJBQTVJLE9BQUksR0FBd0osS0FBSyxLQUFHLENBQUM7Z0NBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRyxPQUFPLHFCQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUcsR0FBRyxHQUFDLENBQUM7YUFBQSxLQUFLLENBQUMsY0FBYzthQUFHLFdBQVcsT0FBQyxLQUFLO1lBQUUsQ0FBQztXQUFBLENBQUM7OzhCQUR0UyxTQUFPOzs7Ozs7OztpQkFBMUQsTUFBRzs7Ozs7YUFNRSxJQUFDOzs0QkFBRCxJQUFDOzs7Ozs7O3NCQW5MWCxNQUFNLHlCQTJLTSxNQUFNLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQURiLFdBQVcsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUQxQixXQUFXLEdBQUcsU0FBUzs7Ozs7Ozs7O09BVzNCLFNBQU07O1dBYlIsVUFBTzs7T0FlUCxVQUFPLGFBZlAsVUFBTztPQWVtRCxNQUFHLFdBQTdELFVBQU87bUNBQW1ELE1BQUc7Ozs7U0FBd0ksTUFBRztTQUFtRCxJQUFDLHFCQUF2RCxNQUFHOzJCQUFtRCxJQUFDOzthQUFELElBQUM7YUFBdkQsTUFBRzs7OzthQW5LcEYsZUFBZTt1QkFtSzJILEtBQUssT0FBQyxlQUFlOzs7O3dCQUE5RSxNQUFHOzs7Ozs7YUFuSzFNLFdBQVc7NkJBbUt3SyxXQUFXLEVBQUMsTUFBTTs7Ozs7Ozs7OztXQUF6SSxNQUFHOzsyQkFBSCxNQUFHOzs7O1NBQy9CLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUEyRSxNQUFHO1dBQTJCLE9BQUksV0FBbEMsTUFBRzs2QkFBMkIsT0FBSTs7ZUFBSixPQUFJOztXQUFvQixTQUFNLGFBQTlCLE9BQUk7O2VBQWxDLE1BQUc7eURBQWlDLFNBQVM7d0JBQVMsU0FBTSxFQUFXLFNBQVM7MEJBQWhGLE1BQUc7Ozs7Ozs7Ozs7Ozs7K0NBQTJJLFdBQVcsdUJBQUksSUFBSTtpQkFBUyxRQUFRLDJDQUFyQixJQUFJLG1CQUFrQixZQUFZLE9BQUMsSUFBSTs7aUJBQTFCLFFBQVE7O2VBQXFCLFNBQU87O2VBQThGLE1BQUcscUJBQXhHLFNBQU87ZUFBbUcsU0FBTSxXQUFYLE1BQUc7aUNBQUUsU0FBTTtlQUFtQyxTQUFNO2VBQXdILFNBQU0sYUFBcEksU0FBTTtpQ0FBd0gsU0FBTTs7bUJBQU4sU0FBTTttQkFBN0ssU0FBTTs7ZUFBOFcsUUFBSyxhQUF6WCxTQUFNO2lDQUE4VyxRQUFLOzttQkFBTCxRQUFLO21CQUE5WCxNQUFHOztlQUFvZSxNQUFHLGFBQTFlLE1BQUc7ZUFBeWUsSUFBQyxXQUFOLE1BQUc7aUNBQUUsSUFBQzs7bUJBQUQsSUFBQzs7ZUFBdUMsUUFBSyxhQUE3QyxJQUFDO2lDQUF1QyxRQUFLOzttQkFBTCxRQUFLO21CQUFsRCxNQUFHOzttQ0FBSCxNQUFHOzttQ0FBd0csZUFBZSw0QkFBZSxlQUFlLE9BQUMsSUFBSTs7Ozs7O2lCQUFtQixNQUFHO2lCQUF3QixNQUFHLFdBQTlCLE1BQUc7aUJBQTZCLE9BQUksV0FBVCxNQUFHO21DQUFFLE9BQUk7O3FCQUFKLE9BQUk7cUJBQVQsTUFBRzs7aUJBQXdGLEdBQUMsYUFBNUYsTUFBRzs7cUJBQTlCLE1BQUc7Ozs7dUNBQTV4QixRQUFRO3FDQUF1ekIsUUFBUSxFQUFDLEdBQUc7O3VDQUEzMEIsUUFBUTtxQ0FBeTBCLFFBQVEsRUFBQyxNQUFNOzs7MEJBQStDLEdBQUM7dUNBQWg1QixRQUFRO3dEQUFtNkIsUUFBUSxFQUFDLE9BQU87Ozs7Z0NBQWxLLE1BQUc7Ozs7O3dCQUFiLFFBQVE7Ozs7Ozs7Ozs7Ozs7aUJBQWlRLE1BQUc7aUJBQXVILFNBQU0scUJBQWhJLE1BQUc7bUNBQXVILFNBQU07O3FCQUFOLFNBQU07cUJBQWhJLE1BQUc7OztjQUF1SCxTQUFNLGtDQUE2RCxrQkFBa0IsR0FBRyxJQUFJOzs7cUJBcExoOUMsa0JBQWtCO3FCQW9CdEUscUJBQXFCO3FEQWdLMmlELGtCQUFrQixTQUFHLHFCQUFxQixFQUFDLEVBQUUsSUFBQyxzQkFBc0IsR0FBQyxxQkFBcUI7Ozs7OEJBQWxQLFNBQU0sUUFBc0csa0JBQWtCLE9BQUMscUJBQXFCO2dDQUE5USxNQUFHOzs7Ozs7cUJBQXhpQyxJQUFJO3FCQXBMaE0saUJBQWlCO3FCQW9COUYscUJBQXFCOytDQWdLcXRDLE1BQU0sT0FBQyxJQUFJLEVBQUMsRUFBRSxHQUFJLE1BQU0sT0FBQyxpQkFBaUIsYUFBRyxxQkFBcUI7Ozs7Ozs7Ozs7bUJBQXovQixTQUFPOzs7O3NDQUFQLFNBQU87d0NBQWpELElBQUkseUJBQTBLLElBQUksRUFBQyxRQUFROzZCQUFFLFNBQU0sdUJBQW5NLElBQUksaUNBQXdRLElBQUksRUFBQyxRQUFROzs2QkFBa0MsU0FBTTtvQkFBalUsSUFBSTs4Q0FBd1ksSUFBSSxFQUFDLFFBQVE7OzthQUE5RixTQUFNLGtDQUEwSCxjQUFjLEdBQUcsSUFBSTs7O29CQXJNN25CLGNBQWM7b0JBcU0rSixJQUFJO29EQUErYyxjQUFjLFNBQUcsSUFBSSxFQUFDLEVBQUUsSUFBQyxHQUFHLEdBQUMsSUFBSTs7OzJDQUFwZixJQUFJLHlCQUEyZ0IsSUFBSSxFQUFDLFVBQVUsbUNBQTloQixJQUFJLHlCQUFxa0IsSUFBSSxFQUFDLGlCQUFpQjs7Ozs7OzBDQUE1Z0IsTUFBTSxPQUFDLElBQUksRUFBQyxFQUFFLEdBQUksTUFBTSxPQUFDLGlCQUFpQjs7OztvQkFBN0gsSUFBSTtvQ0FBK2hCLElBQUksRUFBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBQyxHQUFHOzs7O29CQUFua0IsSUFBSTs4QkFBMG5CLEtBQUssT0FBQyxJQUFJLEVBQUMsZ0JBQWdCOzs7O29CQUF6cEIsSUFBSTs4QkFBc3FCLEtBQUssT0FBQyxJQUFJLEVBQUMsaUJBQWlCOzs7Ozs0QkFBemdCLFNBQU0sUUFBaUMsWUFBWSxPQUFDLElBQUk7NEJBQXNFLFNBQU0sUUFBbUMsVUFBVSxPQUFDLElBQUk7OEJBQXpVLFNBQU87Ozs7Ozs7Ozs7OzthQUE4NEMsSUFBQzs7NEJBQUQsSUFBQzs7Ozs7Ozs7a0JBcEt6c0QsV0FBVztrQ0FvS3FOLFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUE1SixVQUFVLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBbEcsVUFBVSxHQUFHLFNBQVM7Ozs7Ozs7Ozs7Ozs7O1NBQ0YsU0FBTTs0QkFBTixTQUFNO1NBQW1MLE9BQUk7NEJBQUosT0FBSTs7YUFBSixPQUFJO2FBQTdMLFNBQU07OzZCQUFOLFNBQU07Ozs7V0FBdVAsTUFBRzs7O3FCQUFILE1BQUcsaUJBQWtDLFdBQVcsdUJBQUksSUFBSTs7Ozs7Z0JBQUUsYUFBYTs7eUJBQUUsSUFBSTs7O1dBQUcsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7ZUFBckYsTUFBRzswQkFBSCxNQUFHOzs7OztrQkFBcEIsZUFBZTs7Ozs7Ozs7OztzQkFBM1AsU0FBTSx5QkFBOEUsZUFBZTs7O2FBcktwRSxXQUFXOzZCQXFLMkgsV0FBVyxFQUFDLE1BQU07OztpQ0FBUSxlQUFlLElBQUMsR0FBRyxHQUFDLEdBQUc7OztzQkFBdE4sU0FBTSxjQUE2RyxlQUFlLFNBQUUsZUFBZTs7Ozs7OzthQXJLcEgsV0FBVzs2QkFxSzlELFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7O09BQ3RCLFNBQU07O1dBSFIsVUFBTzs7V0ExQlQsVUFBTztXQURULE1BQUc7b0JBRUMsU0FBTSxFQUF5QixVQUFVO29CQUltK0QsU0FBTSxRQUFvQyxrQkFBa0I7b0JBQzNuQyxTQUFNLFFBQW9DLGtCQUFrQjtvQkFJaThFLFNBQU0sRUFBZ0Msa0JBQWtCO29CQWNoZ0gsU0FBTSxFQUFnQyxhQUFhO29CQUtuRCxTQUFNLFFBQW9DLFlBQVk7O29CQTdCMUQsVUFBTzs7OztvQkFEVCxNQUFHLEVBQWtDLFVBQVU7c0JBQS9DLE1BQUcsR0FBMkQsS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsS0FBRSxVQUFVO3NCQUF0RyxNQUFHOzs7OztjQURELFNBQVM7Ozs7Ozs7Ozs7Ozs7T0FxQ1csTUFBRztPQUF5QixVQUFPLFdBQW5DLE1BQUc7T0FBMEYsU0FBTSxXQUF2RSxVQUFPO09BQStLLElBQUUsYUFBdkgsU0FBTTswQkFBK0csSUFBRTs7V0FBRixJQUFFOztPQUF5TCxPQUFLLGFBQWhNLElBQUU7T0FBb00sT0FBSyxxQkFBaEIsT0FBSzs7MkJBQU0sT0FBSztXQUFoQixPQUFLOztPQUFxRyxPQUFLLGFBQS9HLE9BQUs7T0FBbUksT0FBSyxxQkFBbkMsT0FBSzs7MkJBQXlCLE9BQUs7V0FBbkMsT0FBSzs7T0FBaUksT0FBSyxhQUEzSSxPQUFLO09BQTJMLE9BQUsscUJBQS9ELE9BQUs7OzJCQUFxRCxPQUFLO1dBQS9ELE9BQUs7O09BQXVJLE9BQUssYUFBakosT0FBSztPQUEwSixNQUFNLHFCQUF6QixPQUFLOzs7VUFBaUMsY0FBYzs7OztPQUFjLFFBQU0sV0FBckQsTUFBTTs7R0FBeUMsUUFBTSxTQUFOLFFBQU07O09BQXFDLFFBQU0sYUFBakQsUUFBTTs7R0FBcUMsUUFBTSxTQUFOLFFBQU07V0FBaEcsTUFBTTtXQUF6QixPQUFLOzsyQkFBTCxPQUFLOzs7O1NBQWdNLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixlQUFlO3dCQUFyQyxJQUFDOzs7OztnQkFBbEIsZUFBZTs7Ozs7Ozs7O09BQWtELE1BQUc7T0FBd0IsU0FBTSxXQUFqQyxNQUFHO09BQXlHLFNBQU0sYUFBdkYsU0FBTTswQkFBMkUsU0FBTTs7V0FBTixTQUFNO1dBQWxILE1BQUc7V0FBcitCLFVBQU87V0FBbkMsTUFBRzs7OytDQUFtTixtQkFBbUIsR0FBRyxJQUFJO09BQUMsNkJBQTZCO09BQUMseUJBQXlCOztJQUFrMEIsU0FBTSxrQkFBcUQsZ0JBQWdCOzsrQkFBRyxnQkFBZ0I7T0FBQyxTQUFTOzZCQUFDLG1CQUFtQixHQUFHLElBQUksSUFBQyxnQkFBZ0IsR0FBQyxjQUFjOzs7b0JBQWhyQyxTQUFNLGNBQTZCLGtCQUFrQixFQUFDLEtBQUs7OztJQUFnUSxPQUFLO2FBQUMsR0FBVTtrQkFBRSxjQUFjLEVBQUMsS0FBSzs7YUFBaEMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsS0FBSzs7Ozs7SUFBdUYsT0FBSzthQUE4QyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxjQUFjOzthQUF6QyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxjQUFjOzs7OztJQUFzRSxPQUFLO2FBQWdDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLE1BQU07O2FBQWpDLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLE1BQU07Ozs7O0lBQStCLE1BQU07YUFBQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxVQUFVOzthQUFyQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxVQUFVOzs7O29CQUFpTixTQUFNLGNBQWlDLGtCQUFrQixFQUFDLEtBQUs7b0JBQWtCLFNBQU0sRUFBMkIsY0FBYztzQkFBenBDLE1BQUc7Ozs7O2NBQXZCLGtCQUFrQjs7Ozs7Ozs7Ozs7OztPQUNFLE1BQUc7T0FBeUIsVUFBTyxXQUFuQyxNQUFHO09BQTBGLFNBQU0sV0FBdkUsVUFBTztPQUFnTCxJQUFFLGFBQXhILFNBQU07MEJBQWdILElBQUU7O1dBQUYsSUFBRTs7T0FBcU4sT0FBSyxhQUE1TixJQUFFO09BQTRPLFFBQU0scUJBQTdCLE9BQUs7OztVQUFxQyxjQUFjOzs7Ozs7OztPQUFzQixRQUFNLFdBQTdELFFBQU07O0dBQWlELFFBQU0sU0FBTixRQUFNOzsyQkFBTixRQUFNOzs7Ozs7O1lBaE5qaEIsV0FBVzs0QkFnTmdrQixXQUFXLEVBQUMsUUFBUTs7O2dCQUFJLE9BQU87VUFBRSxRQUFNOzZCQUFOLFFBQU07O2NBQU4sUUFBTTs7Ozs7O29DQUFmLE9BQU8seUJBQXFDLE9BQU8sRUFBQyxJQUFJOzs7U0FBL0MsUUFBTSxVQUFOLFFBQU07Ozs7cUJBQWYsT0FBTyxtQkFBZ0IsTUFBTSxPQUFDLE9BQU8sRUFBQyxFQUFFOzs7O3lCQUEvQixRQUFNOzs7Ozs7Ozs7V0FBOUosUUFBTTtXQUE3QixPQUFLOztPQUE0UCxPQUFLLGFBQXRRLE9BQUs7T0FBNFEsT0FBSyxxQkFBckIsT0FBSzs7MkJBQVcsT0FBSztXQUFyQixPQUFLOztPQUE2RyxPQUFLLGFBQXZILE9BQUs7T0FBbUksT0FBSyxxQkFBM0IsT0FBSzs7MkJBQWlCLE9BQUs7V0FBM0IsT0FBSzs7T0FBcUgsT0FBSyxhQUEvSCxPQUFLO09BQStJLE9BQUsscUJBQS9CLE9BQUs7OzJCQUFxQixPQUFLO1dBQS9CLE9BQUs7O09BQTZHLE9BQUssYUFBdkgsT0FBSztPQUFtSSxPQUFLLHFCQUEzQixPQUFLOzsyQkFBaUIsT0FBSztXQUEzQixPQUFLOzsyQkFBTCxPQUFLOzs7O1NBQXdILElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixlQUFlO3dCQUFyQyxJQUFDOzs7OztnQkFBbEIsZUFBZTs7Ozs7Ozs7O09BQWtELE1BQUc7T0FBd0IsU0FBTSxXQUFqQyxNQUFHO09BQXlHLFNBQU0sYUFBdkYsU0FBTTswQkFBMkUsU0FBTTs7V0FBTixTQUFNO1dBQWxILE1BQUc7V0FBN3BDLFVBQU87V0FBbkMsTUFBRzs7OytDQUFvTixtQkFBbUIsR0FBRyxJQUFJLElBQUMsbUJBQW1CLEdBQUMsa0JBQWtCO0lBQTBnQyxTQUFNLGtCQUFxRCxnQkFBZ0IsMkJBQUUsYUFBYSxHQUFHLE9BQU87OytCQUFHLGdCQUFnQjtPQUFDLFNBQVM7NkJBQUMsbUJBQW1CLEdBQUcsSUFBSSxJQUFDLGlCQUFpQixHQUFDLGNBQWM7OztvQkFBbDRDLFNBQU0sY0FBNkIsa0JBQWtCLEVBQUMsS0FBSzs7O0lBQXlTLFFBQU07YUFBQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxrQkFBa0I7O2FBQTdDLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLGtCQUFrQjs7Ozs7SUFBc00sT0FBSzthQUFDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLFFBQVE7O2FBQW5DLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLFFBQVE7Ozs7O0lBQStFLE9BQUs7YUFBQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxVQUFVOzthQUFyQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxVQUFVOzs7OztJQUFtRixPQUFLO2FBQWdDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLFlBQVk7O2FBQXZDLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLFlBQVk7Ozs7O0lBQWtDLE9BQUs7YUFBZ0MsR0FBVTtrQkFBRSxjQUFjLEVBQUMsTUFBTTs7YUFBakMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsTUFBTTs7OztvQkFBNEcsU0FBTSxjQUFpQyxrQkFBa0IsRUFBQyxLQUFLO29CQUFrQixTQUFNLEVBQTJCLGNBQWM7c0JBQWoxQyxNQUFHOzs7OztjQUF2QixrQkFBa0I7Ozs7Ozs7Ozs7Ozs7T0FDRixNQUFHO09BQThDLFVBQU8sV0FBeEQsTUFBRztPQUFpSCxTQUFNLFdBQXpFLFVBQU87T0FBNFYsTUFBRyxhQUFuUyxTQUFNOzs7O0tBQTBSLE1BQUc7OztNQUErQixhQUFhO01BQUMscUJBQXFCO01BQUMsc0JBQXNCO01BQUMsdUJBQXVCO01BQUMsYUFBYTs7O2dCQUFLLEtBQUs7VUFBRSxTQUFNOzs2QkFBTixTQUFNOztjQUFOLFNBQU07Ozs7aUNBQU4sU0FBTTt1Q0FBZSxVQUFVLEVBQUMsV0FBVyxFQUFHLEtBQUssMkJBQUUsVUFBVSxFQUFDLGdCQUFnQixFQUFHLE9BQU87Ozs7O2VBQWpHLEtBQUssa0JBQWtMLGdCQUFnQixDQUFDLEtBQUs7Ozt1QkFBdE0sU0FBTSxRQUFvRyxDQUFDO2dCQUFBLFVBQVUsUUFBVixVQUFVLEVBQUMsZ0JBQWdCLEdBQUMsT0FBTztnQkFBQyxVQUFVLFFBQVYsVUFBVSxFQUFDLFdBQVcsR0FBQyxLQUFLO01BQUMsQ0FBQzs7eUJBQTdLLFNBQU07Ozs7Ozs7OztXQUFwSixNQUFHOztPQUEwVyxTQUFNLGFBQW5YLE1BQUc7MEJBQTBXLFNBQU07O1dBQU4sU0FBTTs7MkJBQU4sU0FBTTs7OztTQUFxUyxRQUFLO1NBQTBCLE9BQUsscUJBQXBDLFFBQUs7OzZCQUEwQixPQUFLO2FBQXBDLFFBQUs7OztNQUEwQixPQUFLO2VBQTJDLEdBQVU7b0JBQUUsVUFBVSxFQUFDLGtCQUFrQjs7ZUFBekMsR0FBVTtnQkFBRSxVQUFVLFFBQVYsVUFBVSxFQUFDLGtCQUFrQjs7Ozt3QkFBeEgsUUFBSzs7Ozs7O2FBcE1oa0MsVUFBVTs2Q0FvTTBnQyxVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTzs7Ozs7Ozs7OztPQUErSyxRQUFLO09BQTJCLFFBQU0scUJBQXRDLFFBQUs7OztVQUE4QyxVQUFVOzs7OztpQkFBN0IsUUFBTSxZQUFpRCxTQUFTLEVBQUMsZUFBZSxFQUFDLFFBQVEsRUFBQyxXQUFXLHVCQUFLLFNBQVM7U0FBRSxRQUFNOzRCQUFOLFFBQU07O2FBQU4sUUFBTTs7Ozs7Ozs7Z0RBQVEsU0FBUztRQUF2QixRQUFNLFVBQU4sUUFBTSxXQUFRLFNBQVM7Ozs7O1FBQWxDLFNBQVM7d0JBQTRCLFNBQVMsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFDLEdBQUcsRUFBRSxXQUFXOzs7Ozt3QkFBbkUsUUFBTTs7Ozs7Ozs7V0FBM0gsUUFBTTtXQUF0QyxRQUFLOzsyQkFBTCxRQUFLOzs7O1NBQXlRLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixXQUFXO3dCQUFqQyxJQUFDOzs7OztnQkFBZCxXQUFXOzs7Ozs7Ozs7T0FBOEMsTUFBRztPQUF3QixTQUFNLFdBQWpDLE1BQUc7T0FBb0ssU0FBTSxhQUFsSixTQUFNOzBCQUFzSSxTQUFNOztXQUFOLFNBQU07V0FBN0ssTUFBRztXQUFyK0MsVUFBTztXQUF4RCxNQUFHOzs7O1dBcE1sQixVQUFVOzsyQ0FvTXE1QixVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTztRQUFDLHFCQUFxQjtRQUFDLDBDQUEwQzs7O0lBQXdqQixTQUFNLGtCQUFrRyxZQUFZO0lBQXdCLFNBQU0sa0JBQWlELFlBQVk7K0JBQUcsWUFBWSxJQUFDLFNBQVMsR0FBQyxxQkFBcUI7OztvQkFBeHJELFNBQU0sY0FBNkIsY0FBYyxFQUFDLEtBQUs7b0JBQXNsQixTQUFNLGlCQUFxRCxVQUFVLFFBQVYsVUFBVSxFQUFDLGdCQUFnQix5QkFBQyxVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTyxJQUFDLE9BQU8sR0FBQyxPQUFPOzs7SUFBNFcsUUFBTTthQUFDLEdBQVU7a0JBQUUsVUFBVSxFQUFDLGVBQWU7O2FBQXRDLEdBQVU7Y0FBRSxVQUFVLFFBQVYsVUFBVSxFQUFDLGVBQWU7Ozs7b0JBQXdRLFNBQU0sUUFBaUMsQ0FBQzthQUFBLFVBQVUsUUFBVixVQUFVLEVBQUMsZ0JBQWdCLEdBQUMsU0FBUztJQUFDLFVBQVU7R0FBRyxDQUFDOztvQkFBZ0QsU0FBTSxFQUEyQixVQUFVO3NCQUFydUQsTUFBRzs7Ozs7Y0FBbkIsY0FBYzs7Ozs7Ozs7Ozs7OztPQUVoQixNQUFHO09BQWdFLFVBQU8sV0FBMUUsTUFBRztPQUErSSxTQUFNLFdBQXJGLFVBQU87T0FBaUwsSUFBRSxhQUEzRyxTQUFNOzBCQUFtRyxJQUFFOztXQUFGLElBQUU7O09BQWdKLFFBQUssYUFBdkosSUFBRTtPQUFnSyxPQUFLLHFCQUFyQixRQUFLOzsyQkFBVyxPQUFLO1dBQXJCLFFBQUs7O09BQTZHLFFBQUssYUFBdkgsUUFBSztPQUE2SCxRQUFNLHFCQUF0QixRQUFLOzs7VUFBOEIsUUFBUTs7Ozs7O0tBQTNCLFFBQU07OztNQUF3QyxNQUFNO01BQUMsU0FBUztNQUFDLFVBQVU7TUFBQyxXQUFXO01BQUMsaUJBQWlCO01BQUMsT0FBTzs7O2dCQUFLLElBQUk7VUFBRSxRQUFNOzZCQUFOLFFBQU07O2NBQU4sUUFBTTs7Ozs7Ozs7aURBQVEsSUFBSTtTQUFsQixRQUFNLFVBQU4sUUFBTSxXQUFRLElBQUk7OztlQUF4QixJQUFJLGtCQUF1QixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBQyxHQUFHOzs7eUJBQTVDLFFBQU07Ozs7Ozs7OztXQUFoSSxRQUFNO1dBQXRCLFFBQUs7O09BQXFOLFFBQUssYUFBL04sUUFBSztPQUFtUCxRQUFLLHFCQUFuQyxRQUFLOzsyQkFBeUIsUUFBSztXQUFuQyxRQUFLOztPQUF1SixRQUFLLGFBQWpLLFFBQUs7T0FBZ0wsUUFBSyxxQkFBOUIsUUFBSzs7MkJBQW9CLFFBQUs7V0FBOUIsUUFBSzs7T0FBK0ksUUFBSyxhQUF6SixRQUFLO09BQTRLLFFBQUsscUJBQWxDLFFBQUs7OzJCQUF3QixRQUFLO1dBQWxDLFFBQUs7O09BQWtKLFFBQUssYUFBNUosUUFBSztPQUEySyxRQUFLLHFCQUE5QixRQUFLOzsyQkFBb0IsUUFBSztXQUE5QixRQUFLOztPQUF1RixRQUFLLGFBQWpHLFFBQUs7T0FBMkcsUUFBSyxxQkFBekIsUUFBSzs7MkJBQWUsUUFBSztXQUF6QixRQUFLOztPQUE4RyxRQUFLLGFBQXhILFFBQUs7T0FBaUssUUFBSyxxQkFBeEQsUUFBSzs7MkJBQThDLFFBQUs7V0FBeEQsUUFBSzs7MkJBQUwsUUFBSzs7OztTQUErSSxJQUFDOzRCQUFELElBQUM7O2FBQUQsSUFBQzt3REFBcUIsU0FBUzt3QkFBL0IsSUFBQzs7Ozs7Z0JBQVosU0FBUzs7Ozs7Ozs7O09BQTRDLE1BQUc7T0FBd0IsU0FBTSxXQUFqQyxNQUFHO09BQW1HLFNBQU0sYUFBakYsU0FBTTswQkFBcUUsU0FBTTs7V0FBTixTQUFNO1dBQTVHLE1BQUc7V0FBNytDLFVBQU87V0FBMUUsTUFBRzs7O3dDQUE0UCxhQUFhLEdBQUUsSUFBSSxJQUFDLFlBQVksR0FBQyxXQUFXO0lBQXcyQyxTQUFNLGtCQUErQyxVQUFVOzsrQkFBRyxVQUFVO09BQUMsU0FBUztzQkFBQyxhQUFhLEdBQUUsSUFBSSxJQUFDLFVBQVUsR0FBQyxjQUFjOzs7b0JBQXJvRCxTQUFNLGNBQTZCLFlBQVksRUFBQyxLQUFLOzs7SUFBc04sT0FBSzthQUFDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLFFBQVE7O2FBQTdCLEdBQVU7Y0FBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLFFBQVE7Ozs7O0lBQStFLFFBQU07YUFBQyxHQUFVO2tCQUFFLFFBQVEsRUFBQyxRQUFROzthQUE3QixHQUFVO2NBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxRQUFROzs7OztJQUFvTSxRQUFLO2FBQTJDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLGlCQUFpQjs7YUFBdEMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsaUJBQWlCOzs7OztJQUFpRSxRQUFLO2FBQTJDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLGdCQUFnQjs7YUFBckMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsZ0JBQWdCOzs7OztJQUFtRSxRQUFLO2FBQTJDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLGlCQUFpQjs7YUFBdEMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsaUJBQWlCOzs7OztJQUE2RCxRQUFLO2FBQWEsR0FBVTtrQkFBRSxRQUFRLEVBQUMsZUFBZTs7YUFBcEMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsZUFBZTs7Ozs7SUFBaUMsUUFBSzthQUFDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLFVBQVU7O2FBQS9CLEdBQVU7Y0FBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLFVBQVU7Ozs7O0lBQTZHLFFBQUs7YUFBQyxHQUFVO2tCQUFFLFFBQVEsRUFBQyxLQUFLOzthQUExQixHQUFVO2NBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxLQUFLOzs7O29CQUFzSSxTQUFNLGNBQWlDLFlBQVksRUFBQyxLQUFLO29CQUFrQixTQUFNLEVBQTJCLFFBQVE7c0JBQTVyRCxNQUFHOzs7OztjQURELFlBQVk7Ozs7Ozs7Ozs7Ozs7T0FJZCxNQUFHO09BQWdFLFVBQU8sV0FBMUUsTUFBRztPQUErSSxTQUFNLFdBQXJGLFVBQU87MkJBQXdFLFNBQU07Ozs7U0FDdkksTUFBRztTQUFxQyxJQUFDLHFCQUF6QyxNQUFHOzRCQUFxQyxJQUFDOzthQUFELElBQUM7O1NBQTRFLElBQUUsYUFBL0UsSUFBQzs0QkFBNEUsSUFBRTs7YUFBRixJQUFFOztTQUEwRSxJQUFDLGFBQTdFLElBQUU7NEJBQTBFLElBQUM7O2FBQUQsSUFBQzs7U0FBbVQsU0FBTSxhQUExVCxJQUFDOzthQUFsTSxNQUFHOzs7OztjQS9MakIsUUFBUTs4Q0ErTHFFLFFBQVEsRUFBQyxNQUFNLEVBQUcsS0FBSyxJQUFDLFdBQVcsR0FBQyxZQUFZOzs7O2NBL0w3SCxRQUFROzhDQStMK0gsUUFBUSxFQUFDLE1BQU0sRUFBRyxLQUFLLElBQUMsb0JBQW9CLEdBQUMsb0JBQW9COzs7Ozs7O2NBL0x4TSxRQUFRO2NBVndELGNBQWM7OzhDQXlNb0ksUUFBUSxFQUFDLE1BQU0sRUFBRyxLQUFLO2NBQUksS0FBSyxPQUFDLFFBQVEsRUFBQyxTQUFTLHVDQUFpQyxjQUFjLEVBQUMsVUFBVSx5Q0FBeUMsVUFBVSxPQUFDLFFBQVEsRUFBQyxVQUFVO29CQUFRLGNBQWMsRUFBQyxVQUFVOzs7OztzQkFBNEYsU0FBTSxjQUErQixrQkFBa0IsRUFBQyxLQUFLO3dCQUFsakIsTUFBRzs7Ozs7U0FFaEIsTUFBRztTQUF1RSxRQUFLLHFCQUEvRSxNQUFHO1NBQTRILFFBQUsscUJBQTFELFFBQUs7OzZCQUFnRCxRQUFLOzs2QkFBTCxRQUFLOzs7O1dBQThMLE1BQUc7NkJBQUgsTUFBRzs7OzthQUEwRCxJQUFDOzs0QkFBRCxJQUFDOzs7Ozs7Ozs7ZUFBOEQsSUFBQzs7OEJBQUQsSUFBQzs7Ozs7Ozs7Ozs7eUJBQXdELGFBQWE7O3dCQUFJLE1BQU07a0JBQUUsU0FBTTtrQkFBdUUsU0FBTSxXQUFuRixTQUFNO3FDQUF1RSxTQUFNOztzQkFBTixTQUFNOztrQkFBOEIsUUFBSyxhQUF6QyxTQUFNO3FDQUE4QixRQUFLOztzQkFBTCxRQUFLO3NCQUF0SCxTQUFNOzs7OzRDQUFkLE1BQU0seUJBQXVGLE1BQU0sRUFBQyxVQUFVOzJEQUE5RyxNQUFNLHlCQUFzSSxNQUFNLEVBQUMsVUFBVTs7Ozt1QkFBN0osTUFBTTs7Z0RBQTRKLE1BQU0sRUFBQyxTQUFTLEVBQUUsSUFBSTtvQkFBQyx3QkFBd0I7a0NBQWUsWUFBWSxPQUFDLE1BQU0sRUFBQyxTQUFTOzs7OzttQ0FBclAsU0FBTSx5QkFBZ0QsWUFBWSxPQUFDLE1BQU07aUNBQXpFLFNBQU07OztrQkFBNFEsSUFBQzs7aUNBQUQsSUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBM00xd0IsV0FBVztvQ0EyTTZYLFdBQVcsRUFBQyxJQUFJLEdBQUcsTUFBTSxHQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O29DQUE3RixrQkFBa0IsR0FBRyxTQUFTOzs7Ozs7Ozs7ZUFBM0QsTUFBRzswQkFBSCxNQUFHOzs7OztrQkFBbkIsY0FBYzs7Ozs7Ozs7O2FBQXRQLFFBQUs7OzZCQUFMLFFBQUs7Ozs7V0FBc3lCLE1BQUc7V0FBeUMsTUFBRyxxQkFBL0MsTUFBRztXQUF3RixRQUFLLHFCQUFwRCxNQUFHOzhCQUE0QyxRQUFLOztlQUFMLFFBQUs7ZUFBcEQsTUFBRztlQUEvQyxNQUFHOzs7O2VBM016ekIsY0FBYzsrQkEyTSs0QixjQUFjLEVBQUMsVUFBVTs7OztnQkEzTXQ3QixjQUFjOzt5Q0EyTTY2QixjQUFjLEVBQUMsU0FBUyxFQUFFLElBQUk7YUFBQyx3QkFBd0I7MkJBQWUsWUFBWSxPQUFDLGNBQWMsRUFBQyxTQUFTOzs7OzswQkFBaFAsTUFBRzs7Ozs7a0JBQW5CLGNBQWM7Ozs7Ozs7OzthQUFuM0IsTUFBRzs7U0FDSCxNQUFHLGFBREgsTUFBRztTQUN3RixRQUFRLHFCQUFuRyxNQUFHO1NBQTJKLFFBQUsscUJBQXhFLFFBQVE7U0FBaUYsUUFBSyxXQUEzQixRQUFLOzs2QkFBaUIsUUFBSztLQUFMLFFBQUssU0FBTCxRQUFLOzthQUEzQixRQUFLOztTQUE0RixRQUFLLGFBQXRHLFFBQUs7U0FBa0gsUUFBSyxXQUEzQixRQUFLOzs2QkFBaUIsUUFBSztLQUFMLFFBQUssU0FBTCxRQUFLOzthQUEzQixRQUFLO2FBQXpLLFFBQVE7OzZCQUFSLFFBQVE7Ozs7O1dBQW1TLFFBQUs7V0FBb0IsUUFBSyxxQkFBOUIsUUFBSzs7K0JBQW9CLFFBQUs7ZUFBOUIsUUFBSzs7V0FBK0csTUFBRyxhQUF2SCxRQUFLO1dBQTRJLFFBQUssV0FBbEMsTUFBRztXQUF5QyxRQUFNLHFCQUFyQixRQUFLOzs7Y0FBNkIsUUFBUTs7Ozs7Ozs7cUJBQTNCLFFBQU0sV0FBc0MsS0FBSyxDQUFDLEVBQUUsdUJBQUssQ0FBQzthQUFRLFFBQU07O1NBQU4sUUFBTSxrQkFBa0IsS0FBSyxHQUFDLENBQUMsbUJBQUUsS0FBSyxFQUFHLENBQUM7WUFBQyxJQUFJOzRCQUFDLEtBQUssRUFBRyxDQUFDLElBQUMsSUFBSSxtQkFBQyxLQUFLLEVBQUcsQ0FBQyxJQUFDLElBQUksR0FBQyxJQUFJOztTQUFsRixRQUFNLFNBQU4sUUFBTSxXQUFRLEtBQUssR0FBQyxDQUFDOzRCQUFyQixRQUFNOzs7Ozs7OztlQUF4RSxRQUFNO2VBQXJCLFFBQUs7O1dBQWdOLFFBQUssYUFBMU4sUUFBSztXQUFrTyxRQUFLLHFCQUF2QixRQUFLOzsrQkFBYSxRQUFLO2VBQXZCLFFBQUs7ZUFBdlAsTUFBRzs7O1FBQTlGLFFBQUs7aUJBQTJDLEdBQVU7c0JBQUUsUUFBUSxFQUFDLFNBQVM7O2lCQUE5QixHQUFVO2tCQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsU0FBUzs7Ozs7UUFBeUQsUUFBTTtpQkFBQyxHQUFVO3NCQUFFLFFBQVEsRUFBQyxPQUFPOztpQkFBNUIsR0FBVTtrQkFBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLE9BQU87Ozs7O1FBQXFMLFFBQUs7aUJBQWMsR0FBVTtzQkFBRSxRQUFRLEVBQUMsVUFBVTs7aUJBQS9CLEdBQVU7a0JBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxVQUFVOzs7Ozs7Ozs7O2VBbE1qekIsUUFBUTsrQ0FrTXNXLFFBQVEsRUFBQyxNQUFNLEVBQUcsS0FBSzs7Ozs7Ozs7OzthQUFwWSxNQUFHOztTQUNILE1BQUcsYUFESCxNQUFHO1NBQ3FHLFVBQVEscUJBQWhILE1BQUc7U0FBOEosUUFBSyxxQkFBOUQsVUFBUTtTQUF1RSxRQUFLLFdBQTNCLFFBQUs7OzZCQUFpQixRQUFLO0tBQUwsUUFBSyxTQUFMLFFBQUs7O2FBQTNCLFFBQUs7O1NBQThGLFFBQUssYUFBeEcsUUFBSztTQUFvSCxRQUFLLFdBQTNCLFFBQUs7OzZCQUFpQixRQUFLO0tBQUwsUUFBSyxTQUFMLFFBQUs7O2FBQTNCLFFBQUs7YUFBakssVUFBUTs7NkJBQVIsVUFBUTs7Ozs7V0FBcVMsTUFBRztXQUEwQixRQUFLLFdBQWxDLE1BQUc7V0FBOEMsUUFBSyxxQkFBekIsUUFBSzs7K0JBQWUsUUFBSztlQUF6QixRQUFLOztXQUE4SCxRQUFLLGFBQXhJLFFBQUs7V0FBMEosUUFBSyxxQkFBakMsUUFBSzs7K0JBQXVCLFFBQUs7ZUFBakMsUUFBSztlQUFySyxNQUFHOzs7O1FBQThDLFFBQUs7aUJBQTRELEdBQVU7c0JBQUUsUUFBUSxFQUFDLFlBQVk7O2lCQUFqQyxHQUFVO2tCQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsWUFBWTs7Ozs7UUFBeUMsUUFBSztpQkFBOEMsR0FBVTtzQkFBRSxRQUFRLEVBQUMsYUFBYTs7aUJBQWxDLEdBQVU7a0JBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxhQUFhOzs7Ozs7Ozs7O2VBbk12cUIsUUFBUTsrQ0FtTWlYLFFBQVEsRUFBQyxVQUFVLEVBQUcsS0FBSzs7Ozs7Ozs7OzthQUFuWixNQUFHOzs2QkFBSCxNQUFHOzs7O1dBQ1ksSUFBQzs4QkFBRCxJQUFDOztlQUFELElBQUM7MERBQXFCLFNBQVM7MEJBQS9CLElBQUM7Ozs7O2tCQUFaLFNBQVM7Ozs7Ozs7OztTQUE0QyxNQUFHO1NBQXdCLFNBQU0sV0FBakMsTUFBRztTQUF5RyxTQUFNLGFBQXZGLFNBQU07NEJBQTJFLFNBQU07O2FBQU4sU0FBTTthQUFsSCxNQUFHOzs7a0JBSG1FLFFBQUssUUFBUSxXQUFXO01BR2MsU0FBTSxrQkFBcUQsVUFBVTtpQ0FBRyxVQUFVLElBQUMsV0FBVyxHQUFDLGlCQUFpQjs7O3NCQUh0SixRQUFLLGNBQW1DLGNBQWMsRUFBQyxJQUFJO3NCQUEzRCxRQUFLLEdBQWtFLENBQUMsS0FBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLOzs7OztNQUN4RCxRQUFLO2VBQWMsR0FBVTtvQkFBRSxRQUFRLEVBQUMsTUFBTTs7ZUFBM0IsR0FBVTtnQkFBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLE1BQU07Ozs7Ozs7TUFBbUQsUUFBSztlQUFjLEdBQVU7b0JBQUUsUUFBUSxFQUFDLE1BQU07O2VBQTNCLEdBQVU7Z0JBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxNQUFNOzs7Ozs7O01BQzVJLFFBQUs7ZUFBYyxHQUFVO29CQUFFLFFBQVEsRUFBQyxVQUFVOztlQUEvQixHQUFVO2dCQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsVUFBVTs7Ozs7OztNQUFpRCxRQUFLO2VBQWMsR0FBVTtvQkFBRSxRQUFRLEVBQUMsVUFBVTs7ZUFBL0IsR0FBVTtnQkFBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLFVBQVU7Ozs7c0JBQ3hQLFNBQU0sY0FBaUMsa0JBQWtCLEVBQUMsS0FBSztzQkFBa0IsU0FBTSxFQUEyQixjQUFjOzs7Ozs7Z0JBTGxOLFNBQVM7Ozs7Ozs7OztXQURvRCxVQUFPO1dBQTFFLE1BQUc7b0JBQStJLFNBQU0sY0FBNkIsa0JBQWtCLEVBQUMsS0FBSztzQkFBN00sTUFBRzs7Ozs7Y0FERCxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7T0FXcEIsTUFBRztPQUFnRSxVQUFPLFdBQTFFLE1BQUc7T0FBK0ksU0FBTSxXQUFyRixVQUFPO09BQWdYLE1BQUcsYUFBM1MsU0FBTTtPQUE2VyxRQUFLLHFCQUFoRixNQUFHO09BQTRILFFBQUsscUJBQXpELFFBQUs7OzJCQUErQyxRQUFLOzsyQkFBTCxRQUFLOzs7O1NBQW9MLE1BQUc7NEJBQUgsTUFBRzs7OztXQUF5RCxJQUFDOzswQkFBRCxJQUFDOzs7Ozs7Ozs7YUFBb0UsSUFBQzs7NEJBQUQsSUFBQzs7Ozs7Ozs7Ozs7dUJBQTJDLFlBQVk7O3NCQUFJLEtBQUs7Z0JBQUUsU0FBTTtnQkFBcUUsU0FBTSxXQUFqRixTQUFNO21DQUFxRSxTQUFNOztvQkFBTixTQUFNOztnQkFBcUMsUUFBSyxhQUFoRCxTQUFNO21DQUFxQyxRQUFLOztvQkFBTCxRQUFLO29CQUEzSCxTQUFNOzs7OztxQkFBYixLQUFLO3FDQUFxRixLQUFLLEVBQUMsSUFBSSxVQUFFLEtBQUssRUFBQyxNQUFNOzs7NkNBQWxILEtBQUsseUJBQStILEtBQUssRUFBQyxNQUFNO3FCQUFoSixLQUFLO3FDQUE2SSxLQUFLLEVBQUMsUUFBUSxlQUFPLEtBQUssRUFBQyxRQUFRLEtBQUcsRUFBRTs7Ozs7cUJBQTFMLEtBQUs7OzhDQUEwTCxLQUFLLEVBQUMsV0FBVyxFQUFFLElBQUk7a0JBQUMsMEJBQTBCO2tDQUFpQixZQUFZLE9BQUMsS0FBSyxFQUFDLFdBQVc7Ozs7O2lDQUF6UixTQUFNLHlCQUFnRCxXQUFXLE9BQUMsS0FBSzsrQkFBdkUsU0FBTTs7O2dCQUFnVCxJQUFDOzsrQkFBRCxJQUFDOzs7Ozs7Ozs7Ozs7Ozs7O3FDQUF2WixpQkFBaUIsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2tDQUFsRyxpQkFBaUIsR0FBRyxTQUFTOzs7Ozs7Ozs7YUFBMUQsTUFBRzt3QkFBSCxNQUFHOzs7Ozs7YUFoTi9xQixVQUFVO2FBQUssYUFBYTs2QkFnTm1tQixVQUFVLEVBQUMsSUFBSSxHQUFHLE1BQU0sSUFBRSxDQUFDLFdBQUcsYUFBYTs7Ozs7Ozs7OztXQUEzTyxRQUFLOzs0QkFBTCxRQUFLOzs7O1NBQTB6QixNQUFHO1NBQXlDLE1BQUcscUJBQS9DLE1BQUc7U0FBcUYsUUFBSyxxQkFBakQsTUFBRzs0QkFBeUMsUUFBSzs7YUFBTCxRQUFLO2FBQWpELE1BQUc7YUFBL0MsTUFBRzs7OzthQWhObHZDLGFBQWE7NkJBZ05pMEMsYUFBYSxFQUFDLE1BQU07O2FBaE5sMkMsYUFBYTs2QkFnTnUxQyxhQUFhLEVBQUMsUUFBUSxlQUFPLGFBQWEsRUFBQyxRQUFRLEtBQUcsRUFBRTs7OztjQWhONTVDLGFBQWE7O3VDQWdObzVDLGFBQWEsRUFBQyxXQUFXLEVBQUUsSUFBSTtXQUFDLDBCQUEwQjsyQkFBaUIsWUFBWSxPQUFDLGFBQWEsRUFBQyxXQUFXOzs7Ozt3QkFBblMsTUFBRzs7Ozs7Z0JBQWxCLGFBQWE7Ozs7Ozs7OztXQUF4NEIsTUFBRzs7T0FBOHNDLE1BQUcsYUFBcHRDLE1BQUc7T0FBMnhDLE9BQUcscUJBQWhGLE1BQUc7T0FBdUcsUUFBSyxXQUFsQyxPQUFHO09BQTRDLFFBQUsscUJBQXZCLFFBQUs7OzJCQUFhLFFBQUs7V0FBdkIsUUFBSzs7T0FBeUgsUUFBSyxhQUFuSSxRQUFLO09BQXFKLFFBQUsscUJBQWpDLFFBQUs7OzJCQUF1QixRQUFLO1dBQWpDLFFBQUs7V0FBaEssT0FBRztXQUFoRixNQUFHOzs0QkFBSCxNQUFHOzs7O1NBQWdZLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixVQUFVO3dCQUFoQyxJQUFDOzs7OztnQkFBYixVQUFVOzs7Ozs7Ozs7T0FBNkMsT0FBRztPQUF3QixTQUFNLFdBQWpDLE9BQUc7T0FBb0csU0FBTSxhQUFsRixTQUFNOzBCQUFzRSxTQUFNOztXQUFOLFNBQU07V0FBN0csT0FBRztXQUF6L0QsVUFBTztXQUExRSxNQUFHOzs7Z0JBQXNqQixRQUFLLFFBQVEsVUFBVTtJQUFnbEQsU0FBTSxrQkFBZ0QsV0FBVzsrQkFBRyxXQUFXLElBQUMsU0FBUyxHQUFDLFdBQVc7OztvQkFBbm5FLFNBQU0sY0FBNkIsYUFBYSxFQUFDLEtBQUs7b0JBQWlYLFFBQUssR0FBOEIsQ0FBQyxLQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUs7OztJQUF3b0MsUUFBSzthQUE0RCxHQUFVO2tCQUFFLFNBQVMsRUFBQyxRQUFROzthQUE5QixHQUFVO2NBQUUsU0FBUyxRQUFULFNBQVMsRUFBQyxRQUFROzs7OztJQUF5QyxRQUFLO2FBQThDLEdBQVU7a0JBQUUsU0FBUyxFQUFDLGFBQWE7O2FBQW5DLEdBQVU7Y0FBRSxTQUFTLFFBQVQsU0FBUyxFQUFDLGFBQWE7Ozs7b0JBQStHLFNBQU0sY0FBaUMsYUFBYSxFQUFDLEtBQUs7b0JBQWtCLFNBQU0sRUFBMkIsU0FBUztzQkFBMXNFLE1BQUc7Ozs7O2NBREQsYUFBYTs7Ozs7Ozs7Ozs7OztPQUdFLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQTZHLFNBQU0sV0FBdkUsVUFBTztPQUFrSyxJQUFFLGFBQTFHLFNBQU07MEJBQWtHLElBQUU7O1dBQUYsSUFBRTs7T0FBb0osUUFBSyxhQUEzSixJQUFFO09BQXlLLFFBQUsscUJBQTFCLFFBQUs7OzJCQUFnQixRQUFLO1dBQTFCLFFBQUs7O09BQXlGLFFBQUssYUFBbkcsUUFBSztPQUF3RyxRQUFLLHFCQUFwQixRQUFLOzsyQkFBVSxRQUFLO1dBQXBCLFFBQUs7O09BQXNGLFFBQUssYUFBaEcsUUFBSztPQUF3RyxRQUFLLHFCQUF2QixRQUFLOzsyQkFBYSxRQUFLO1dBQXZCLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBNkYsSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLFNBQVM7d0JBQS9CLElBQUM7Ozs7O2dCQUFaLFNBQVM7Ozs7Ozs7OztPQUE0QyxPQUFHO09BQXdCLFNBQU0sV0FBakMsT0FBRztPQUFtRyxTQUFNLGFBQWpGLFNBQU07MEJBQXFFLFNBQU07O1dBQU4sU0FBTTtXQUE1RyxPQUFHO1dBQXZvQixVQUFPO1dBQXRELE9BQUc7Ozs7V0F6TWpCLGFBQWE7MkJBeU00TyxhQUFhLEVBQUMsVUFBVTs7O0lBQXNoQixTQUFNLGtCQUFzRCxhQUFhOytCQUFHLGFBQWEsSUFBQyxTQUFTLEdBQUMsVUFBVTs7O29CQUF2eEIsU0FBTSxjQUE2QixhQUFhLEVBQUMsSUFBSTs7O0lBQThOLFFBQUs7YUFBMEIsR0FBVTtrQkFBRSxXQUFXLEVBQUMsTUFBTTs7YUFBOUIsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsTUFBTTs7Ozs7SUFBMkIsUUFBSzthQUFnQyxHQUFVO2tCQUFFLFdBQVcsRUFBQyxHQUFHOzthQUEzQixHQUFVO2NBQUUsV0FBVyxRQUFYLFdBQVcsRUFBQyxHQUFHOzs7OztJQUE4QixRQUFLO2FBQWMsR0FBVTtrQkFBRSxXQUFXLEVBQUMsVUFBVTs7YUFBbEMsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsVUFBVTs7OztvQkFBZ0csU0FBTSxjQUFpQyxhQUFhLEVBQUMsSUFBSTtvQkFBa0IsU0FBTSxFQUEyQixlQUFlO3NCQUF6MEIsT0FBRzs7Ozs7Y0FBbEIsYUFBYTs7Ozs7Ozs7Ozs7OztPQUNJLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQTZHLFNBQU0sV0FBdkUsVUFBTztPQUF5SyxJQUFFLGFBQWpILFNBQU07MEJBQXlHLElBQUU7O1dBQUYsSUFBRTs7T0FBa0MsUUFBSyxhQUF6QyxJQUFFO09BQXVELFFBQUsscUJBQTFCLFFBQUs7OzJCQUFnQixRQUFLO1dBQTFCLFFBQUs7O09BQTJGLFFBQUssYUFBckcsUUFBSztPQUFnSCxRQUFLLHFCQUExQixRQUFLOzsyQkFBZ0IsUUFBSztXQUExQixRQUFLOztPQUE4RixRQUFLLGFBQXhHLFFBQUs7T0FBZ0gsUUFBSyxxQkFBdkIsUUFBSzs7MkJBQWEsUUFBSztXQUF2QixRQUFLOztPQUFnRixPQUFHLGFBQXhGLFFBQUs7T0FBMkcsU0FBTSxXQUFqQyxPQUFHO09BQXFHLFNBQU0sYUFBbkYsU0FBTTswQkFBdUUsU0FBTTs7V0FBTixTQUFNO1dBQTlHLE9BQUc7V0FBL2UsVUFBTztXQUF0RCxPQUFHOzs7O1dBbE5uQixlQUFlOzJCQWtOeU8sZUFBZSxFQUFDLElBQUk7OztJQUF1WSxTQUFNLGtCQUFvRCxlQUFlOytCQUFHLGVBQWUsSUFBQyxTQUFTLEdBQUMsbUJBQW1COzs7b0JBQTVvQixTQUFNLGNBQTZCLGVBQWUsRUFBQyxJQUFJOzs7SUFBaUgsUUFBSzthQUEwQixHQUFVO2tCQUFFLGFBQWEsRUFBQyxNQUFNOzthQUFoQyxHQUFVO2NBQUUsYUFBYSxRQUFiLGFBQWEsRUFBQyxNQUFNOzs7OztJQUFpQyxRQUFLO2FBQWdDLEdBQVU7a0JBQUUsYUFBYSxFQUFDLEdBQUc7O2FBQTdCLEdBQVU7Y0FBRSxhQUFhLFFBQWIsYUFBYSxFQUFDLEdBQUc7Ozs7O0lBQThCLFFBQUs7YUFBYyxHQUFVO2tCQUFFLGFBQWEsRUFBQyxVQUFVOzthQUFwQyxHQUFVO2NBQUUsYUFBYSxRQUFiLGFBQWEsRUFBQyxVQUFVOzs7O29CQUF1QyxTQUFNLGNBQWlDLGVBQWUsRUFBQyxJQUFJO29CQUFrQixTQUFNLEVBQTJCLGFBQWE7c0JBQWpyQixPQUFHOzs7OztjQUFwQixlQUFlOzs7Ozs7Ozs7Ozs7O09BQ2MsT0FBRztPQUE0QyxVQUFPLFdBQXRELE9BQUc7T0FBNkcsU0FBTSxXQUF2RSxVQUFPO09BQWtPLFFBQUssYUFBN0ssU0FBTTtPQUF3TCxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUFvRyxRQUFLLGFBQTlHLFFBQUs7T0FBZ0ksUUFBSyxxQkFBakMsUUFBSzs7MkJBQXVCLFFBQUs7V0FBakMsUUFBSzs7T0FBMkcsT0FBRyxhQUFuSCxRQUFLO09BQXNJLFNBQU0sV0FBakMsT0FBRztPQUFpSCxTQUFNLGFBQS9GLFNBQU07O1dBQWpDLE9BQUc7V0FBcmMsVUFBTztXQUF0RCxPQUFHO29CQUE2RyxTQUFNLGNBQTZCLDJCQUEyQixFQUFDLElBQUk7OztJQUEySCxRQUFLO2FBQTBCLEdBQVU7a0JBQUUscUJBQXFCLEVBQUMsTUFBTTs7YUFBeEMsR0FBVTtjQUFFLHFCQUFxQixRQUFyQixxQkFBcUIsRUFBQyxNQUFNOzs7OztJQUF3QyxRQUFLO2FBQTRCLEdBQVU7a0JBQUUscUJBQXFCLEVBQUMsS0FBSzs7YUFBdkMsR0FBVTtjQUFFLHFCQUFxQixRQUFyQixxQkFBcUIsRUFBQyxLQUFLOzs7O29CQUF1QyxTQUFNLGNBQWlDLDJCQUEyQixFQUFDLElBQUk7b0JBQWtCLFNBQU0sRUFBMkIsZ0JBQWdCO3NCQUF0cEIsT0FBRzs7Ozs7Y0FBaEMsMkJBQTJCOzs7Ozs7Ozs7Ozs7O09BQ2QsT0FBRztPQUE0QyxVQUFPLFdBQXRELE9BQUc7T0FBK0csU0FBTSxXQUF6RSxVQUFPOzRCQUE0RCxTQUFNOzs7O1NBQTZGLEtBQUU7O3dCQUFGLEtBQUU7Ozs7Ozs7OztXQUFtRSxLQUFFOzswQkFBRixLQUFFOzs7OztXQUE4RSxLQUFFOzhCQUFGLEtBQUU7O2VBQUYsS0FBRTs7V0FBK0IsT0FBRyxhQUFwQyxLQUFFO1dBQXdELE9BQUcsV0FBNUIsT0FBRztXQUFnRCxJQUFDLHFCQUEzQixPQUFHOzhCQUF1QixJQUFDOztlQUFELElBQUM7ZUFBM0IsT0FBRzs7V0FBdUUsT0FBRyxhQUE3RSxPQUFHO1dBQStGLElBQUMscUJBQXpCLE9BQUc7OEJBQXFCLElBQUM7O2VBQUQsSUFBQztlQUF6QixPQUFHO2VBQXRHLE9BQUc7O1dBQTBMLFVBQU8sYUFBcE0sT0FBRzt3Q0FBMEwsVUFBTzs7Ozs7OztnQkFwTnJiLFdBQVc7Z0NBb053ZSxXQUFXLEVBQUMsT0FBTzs7O29CQUFJLEtBQUs7Y0FBRSxPQUFHO2NBQWlDLE9BQUksV0FBeEMsT0FBRztpQ0FBaUMsT0FBSTs7a0JBQUosT0FBSTs7Y0FBMkMsU0FBTSxhQUFyRCxPQUFJO2lDQUEyQyxTQUFNOztrQkFBTixTQUFNOztjQUF3RSxPQUFJLGFBQWxGLFNBQU07Y0FBcUcsSUFBQyxXQUE5QixPQUFJO2lDQUF5QixJQUFDOztrQkFBRCxJQUFDO2tCQUE5QixPQUFJOztjQUE0RCxRQUFLLGFBQXJFLE9BQUk7aUNBQTRELFFBQUs7O2tCQUFMLFFBQUs7a0JBQXRPLE9BQUc7Ozs7Ozs7bUJBQVYsS0FBSzttREFBNkYsS0FBSyxFQUFDLElBQUksRUFBRyxLQUFLLElBQUMsc0JBQXNCLEdBQUMsaUJBQWlCOzs7Ozs7OzttQkFBN0osS0FBSzs2QkFBNEMsU0FBUyxPQUFDLEtBQUssRUFBQyxlQUFlOzs7eUJBQWhGLEtBQUssbUJBQW1NLEtBQUssT0FBQyxLQUFLLEVBQUMsTUFBTTs7O21CQUExTixLQUFLOzZCQUFnUCxZQUFZLE9BQUMsS0FBSyxFQUFDLGNBQWM7Ozs7bUJBQXRSLEtBQUs7NkJBQXVSLE1BQU0sT0FBQyxLQUFLLEVBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDOzs7Ozs2QkFBbFQsT0FBRzs7Ozs7Ozs7O2VBQXRHLFVBQU87Ozs7O2dCQXBOcmIsV0FBVztnQ0FvTnlNLFdBQVcsRUFBQyxLQUFLLENBQUMsSUFBSTs7Ozs7Ozs7Z0JBcE4xTyxXQUFXOzBCQW9ONFIsS0FBSyxPQUFDLFdBQVcsRUFBQyxLQUFLLENBQUMsUUFBUTs7OztnQkFwTnZVLFdBQVc7MEJBb05vVyxNQUFNLE9BQUMsV0FBVyxFQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7Ozs7Ozs7OzttQ0FBeFQsaUJBQWlCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBbEcsaUJBQWlCLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQXBLLFVBQU87V0FBdEQsT0FBRztvQkFBK0csU0FBTSxjQUE2QixXQUFXLEVBQUMsSUFBSTtzQkFBckssT0FBRzs7Ozs7Y0FBaEIsV0FBVzs7Ozs7Ozs7Ozs7OztPQUVDLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQStHLFNBQU0sV0FBekUsVUFBTzs0QkFBNEQsU0FBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7V0FBNFEsSUFBQzs4QkFBRCxJQUFDOztlQUFELElBQUM7O1dBQXVCLFNBQU0sYUFBOUIsSUFBQzs7MERBQUUsZUFBZTt3QkFBTSxTQUFNLFFBQStCLGNBQWMsT0FBQyxVQUFVLEVBQUMsRUFBRTs7Ozs7YUFBb0MsYUFBYTs7ZUFsTnpoQixVQUFVO3lCQWtOZ2hCLFdBQVcsT0FBQyxVQUFVLEVBQUMsRUFBRTs7Ozs7YUFBdkMsYUFBYTs7O1dBQW9FLEtBQUU7OEJBQUYsS0FBRTs7ZUFBRixLQUFFOztXQUE4QixPQUFHLGFBQW5DLEtBQUU7V0FBa0YsU0FBTSxxQkFBMUQsT0FBRzs4QkFBaUQsU0FBTTs7ZUFBTixTQUFNO2VBQTFELE9BQUc7O1dBQXdHLE9BQUcsYUFBOUcsT0FBRzs7V0FBaVEsU0FBTSxxQkFBL0osT0FBRzs4QkFBc0osU0FBTTs7ZUFBTixTQUFNOztXQUFzRixJQUFDLGFBQTdGLFNBQU07OEJBQXNGLElBQUM7O2VBQUQsSUFBQztlQUF0UCxPQUFHOztXQUFxVyxPQUFHLGFBQTNXLE9BQUc7V0FBOFgsT0FBRyxXQUE1QixPQUFHO1dBQWdELElBQUMscUJBQTNCLE9BQUc7OEJBQXVCLElBQUM7O2VBQUQsSUFBQztlQUEzQixPQUFHOztXQUFnRSxPQUFHLGFBQXRFLE9BQUc7V0FBdUYsSUFBQyxxQkFBeEIsT0FBRzs4QkFBb0IsSUFBQzs7ZUFBRCxJQUFDO2VBQXhCLE9BQUc7O1dBQXNFLE9BQUcsYUFBNUUsT0FBRztXQUFtRyxJQUFDLHFCQUE5QixPQUFHOzhCQUEwQixJQUFDOztlQUFELElBQUM7ZUFBOUIsT0FBRzs7V0FBNEUsT0FBRyxhQUFsRixPQUFHO1dBQXlHLElBQUMscUJBQTlCLE9BQUc7OEJBQTBCLElBQUM7O2VBQUQsSUFBQztlQUE5QixPQUFHO2VBQXZQLE9BQUc7O2dDQUFILE9BQUc7Ozs7YUFBc1csVUFBTzswQ0FBUCxVQUFPOzs7Ozs7O2tCQWxOaDhDLFVBQVU7a0NBa05vL0MsVUFBVSxFQUFDLE9BQU87OztzQkFBSSxLQUFLO2dCQUFFLE9BQUc7Z0JBQWlDLE9BQUksV0FBeEMsT0FBRzttQ0FBaUMsT0FBSTs7b0JBQUosT0FBSTs7Z0JBQTJDLFNBQU0sYUFBckQsT0FBSTttQ0FBMkMsU0FBTTs7b0JBQU4sU0FBTTs7Z0JBQXlGLE9BQUksYUFBbkcsU0FBTTtnQkFBc0gsSUFBQyxXQUE5QixPQUFJO21DQUF5QixJQUFDOztvQkFBRCxJQUFDOztnQkFBMkIsU0FBTSxhQUFsQyxJQUFDOztvQkFBOUIsT0FBSTs7Z0JBQXVOLFFBQUssYUFBaE8sT0FBSTttQ0FBdU4sUUFBSzs7b0JBQUwsUUFBSztvQkFBbFosT0FBRzs7Ozs7OztxQkFBVixLQUFLOztxREFBNkYsS0FBSyxFQUFDLElBQUksRUFBRyxLQUFLO2tCQUFDLEtBQUs7d0NBQUMsS0FBSyxFQUFDLElBQUksRUFBRyxTQUFTLElBQUMsVUFBVSxHQUFDLGlCQUFpQjs7Ozs7Ozs7cUJBQTlLLEtBQUs7K0JBQTRDLFNBQVMsT0FBQyxLQUFLLEVBQUMsZUFBZTs7OzJCQUFoRixLQUFLLG1CQUFvTixLQUFLLE9BQUMsS0FBSyxFQUFDLE1BQU07OztxQkFBM08sS0FBSzsrQkFBMFosWUFBWSxPQUFDLEtBQUssRUFBQyxHQUFHOzs7O3FCQUFyYixLQUFLOytCQUFzYixNQUFNLE9BQUMsS0FBSyxFQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQzs7Ozs7NkJBQXRPLFNBQU0sUUFBb0MsZUFBZSxPQUFDLGFBQWEsU0FBQyxLQUFLOytCQUF4VCxPQUFHOzs7Ozs7Ozs7aUJBQXJHLFVBQU87NEJBQVAsVUFBTzs7Ozs7O2lCQWxOaDhDLFVBQVU7aUNBa05tNUMsVUFBVSxFQUFDLE9BQU8sRUFBRSxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Z0JBbE52N0MsVUFBVTtnQ0FrTnVsQixVQUFVLEVBQUMsVUFBVTs7OztrQ0FBa0gsT0FBRzs7Ozs7Ozs7OztnQkFsTjN1QixVQUFVOzBCQWtOK3FCLEtBQUssT0FBQyxVQUFVLEVBQUMsWUFBWTs7OztvQkFBc0MsTUFBTSxPQUFDLFVBQVUsRUFBQyxZQUFZLEtBQUcsQ0FBQztvQkFBa0IsTUFBTSxPQUFDLFVBQVUsRUFBQyxZQUFZLElBQUUsQ0FBQzs7OztnQkFsTmoxQixVQUFVOzBCQWtOKzNCLE1BQU0sT0FBQyxVQUFVLEVBQUMsWUFBWSxLQUFHLENBQUMsR0FBQyxHQUFHLEdBQUMsRUFBRTs7OztnQkFsTmw3QixVQUFVOzBCQWtOMDZCLEtBQUssT0FBQyxVQUFVLEVBQUMsWUFBWTs7OztnQkFsTmo5QixVQUFVOzBCQWtOczlCLE1BQU0sT0FBQyxVQUFVLEVBQUMsbUJBQW1CLEtBQUcsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFOzs7O2dCQWxOaGhDLFVBQVU7MEJBa053Z0MsTUFBTSxPQUFDLFVBQVUsRUFBQyxtQkFBbUIsRUFBRSxPQUFPLENBQUMsQ0FBQzs7OztnQkFsTmxrQyxVQUFVOzBCQWtONG5DLEtBQUssT0FBQyxVQUFVLEVBQUMsUUFBUTs7OztnQkFsTi9wQyxVQUFVOzBCQWtONHJDLE1BQU0sT0FBQyxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDOzs7O2dCQWxOeHVDLFVBQVU7MEJBa04yd0MsWUFBWSxPQUFDLFVBQVUsRUFBQyxVQUFVOzs7O2dCQWxOdnpDLFVBQVU7MEJBa04wMUMsWUFBWSxPQUFDLFVBQVUsRUFBQyxVQUFVOzs7Ozs7Ozs7Ozs7bUNBQTFsQyxnQkFBZ0IsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUF0SSxnQkFBZ0IsR0FBRyxTQUFTOzs7Ozs7Ozs7V0FBbEssVUFBTztXQUF0RCxPQUFHO29CQUErRyxTQUFNLGNBQTZCLFVBQVUsRUFBQyxJQUFJO3NCQUFwSyxPQUFHOzs7OztjQUFmLFVBQVU7Ozs7Ozs7Ozs7Ozs7T0FDRyxPQUFHO09BQTRDLFVBQU8sV0FBdEQsT0FBRztPQUE2RyxTQUFNLFdBQXZFLFVBQU87T0FBd0ssS0FBRSxhQUFoSCxTQUFNOzBCQUF3RyxLQUFFOztXQUFGLEtBQUU7O09BQTZKLFFBQUssYUFBcEssS0FBRTtPQUFtTCxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUFzRyxRQUFLLGFBQWhILFFBQUs7T0FBNkgsUUFBSyxxQkFBNUIsUUFBSzs7MkJBQWtCLFFBQUs7V0FBNUIsUUFBSzs7T0FBdUYsUUFBSyxhQUFqRyxRQUFLO09BQWlHLFFBQUsscUJBQWYsUUFBSzs7MkJBQUssUUFBSztXQUFmLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBc0ksSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLFlBQVk7d0JBQWxDLElBQUM7Ozs7O2dCQUFmLFlBQVk7Ozs7Ozs7OztPQUErQyxPQUFHO09BQXdCLFNBQU0sV0FBakMsT0FBRztPQUFpRyxTQUFNLGFBQS9FLFNBQU07MEJBQW1FLFNBQU07O1dBQU4sU0FBTTtXQUExRyxPQUFHO1dBQWh0QixVQUFPO1dBQXRELE9BQUc7Ozs7V0FuTitDLFdBQVc7MkJBbU40SyxXQUFXLEVBQUMsVUFBVTs7O0lBQWltQixTQUFNLGtCQUFrRCxhQUFhOytCQUFHLGFBQWEsSUFBQyxTQUFTLEdBQUMsY0FBYzs7O29CQUE5MUIsU0FBTSxjQUE2QixXQUFXLEVBQUMsSUFBSTs7O0lBQWdQLFFBQUs7YUFBc0MsR0FBVTtrQkFBRSxXQUFXLEVBQUMsTUFBTTs7YUFBOUIsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsTUFBTTs7Ozs7SUFBbUMsUUFBSzthQUFhLEdBQVU7a0JBQUUsV0FBVyxFQUFDLGVBQWU7O2FBQXZDLEdBQVU7Y0FBRSxXQUFXLFFBQVgsV0FBVyxFQUFDLGVBQWU7Ozs7O0lBQXNCLFFBQUs7YUFBMEMsR0FBVTtrQkFBRSxXQUFXLEVBQUMsR0FBRzs7YUFBM0IsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsR0FBRzs7OztvQkFBK0gsU0FBTSxjQUFpQyxXQUFXLEVBQUMsSUFBSTtvQkFBa0IsU0FBTSxFQUEyQixXQUFXO3NCQUE1NEIsT0FBRzs7Ozs7Y0FBaEIsV0FBVzs7Ozs7Ozs7Ozs7OztPQUNJLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQTZHLFNBQU0sV0FBdkUsVUFBTztPQUF5VixPQUFHLGFBQWxTLFNBQU07T0FBa1QsU0FBTSxXQUEvQixPQUFHOzBCQUFzQixTQUFNOztXQUFOLFNBQU07O09BQTBDLE9BQUksYUFBcEQsU0FBTTswQkFBMEMsT0FBSTs7V0FBSixPQUFJO1dBQTdFLE9BQUc7O09BQTZJLFFBQUssYUFBckosT0FBRztPQUFtSyxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUF5RyxRQUFLLGFBQW5ILFFBQUs7T0FBZ0ksUUFBSyxxQkFBNUIsUUFBSzs7MkJBQWtCLFFBQUs7V0FBNUIsUUFBSzs7T0FBMEYsUUFBSyxhQUFwRyxRQUFLO09BQTRJLFFBQUsscUJBQXZELFFBQUs7OzJCQUE2QyxRQUFLO1dBQXZELFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBb0wsSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLGVBQWU7d0JBQXJDLElBQUM7Ozs7O2dCQUFsQixlQUFlOzs7Ozs7Ozs7T0FBa0QsT0FBRztPQUF3QixTQUFNLFdBQWpDLE9BQUc7T0FBbUcsU0FBTSxhQUFqRixTQUFNOzBCQUFxRSxTQUFNOztXQUFOLFNBQU07V0FBNUcsT0FBRztXQUF6NkIsVUFBTztXQUF0RCxPQUFHOzs7O1dBck5qQixhQUFhOzJCQXFOaWIsYUFBYSxFQUFDLElBQUksQ0FBQyxVQUFVOzs7O1dBck4zZCxhQUFhOzJCQXFOK2QsYUFBYSxFQUFDLFVBQVUsQ0FBQyxjQUFjOzs7SUFBc2pCLFNBQU0sa0JBQTBELGdCQUFnQjsrQkFBRyxnQkFBZ0IsSUFBQyxhQUFhLEdBQUMsa0JBQWtCOzs7b0JBQS9rQyxTQUFNLGNBQTZCLGFBQWEsRUFBQyxJQUFJOzs7SUFBZ1osUUFBSzthQUFzQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxNQUFNOzthQUFqQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxNQUFNOzs7OztJQUFtQyxRQUFLO2FBQWEsR0FBVTtrQkFBRSxjQUFjLEVBQUMsZUFBZTs7YUFBMUMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsZUFBZTs7Ozs7SUFBOEQsUUFBSzthQUEwQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxHQUFHOzthQUE5QixHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxHQUFHOzs7O29CQUFxSSxTQUFNLGNBQWlDLGFBQWEsRUFBQyxJQUFJO29CQUFrQixTQUFNLEVBQTJCLG1CQUFtQjtzQkFBL21DLE9BQUc7Ozs7O2NBQWxCLGFBQWE7Ozs7Ozs7Ozs7Ozs7T0FDVyxPQUFHO09BQTRDLFVBQU8sV0FBdEQsT0FBRztPQUE2RyxTQUFNLFdBQXZFLFVBQU87T0FBK0ssS0FBRSxhQUF2SCxTQUFNOzBCQUErRyxLQUFFOztXQUFGLEtBQUU7O09BQWdSLFFBQUssYUFBdlIsS0FBRTtPQUFzUyxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUE4RyxRQUFLLGFBQXhILFFBQUs7T0FBcUksUUFBSyxxQkFBNUIsUUFBSzs7MkJBQWtCLFFBQUs7V0FBNUIsUUFBSzs7T0FBK0YsUUFBSyxhQUF6RyxRQUFLO09BQXlHLFFBQUsscUJBQWYsUUFBSzs7MkJBQUssUUFBSztXQUFmLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBNkgsSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLG9CQUFvQjt3QkFBMUMsSUFBQzs7Ozs7Z0JBQXZCLG9CQUFvQjs7Ozs7Ozs7O09BQXVELE9BQUc7T0FBd0IsU0FBTSxXQUFqQyxPQUFHO09BQTRHLFNBQU0sYUFBMUYsU0FBTTswQkFBOEUsU0FBTTs7V0FBTixTQUFNO1dBQXJILE9BQUc7V0FBejFCLFVBQU87V0FBdEQsT0FBRzs7OztXQXBOMUIsc0JBQXNCOzsyQ0FvTjBPLHNCQUFzQixFQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUcsS0FBSztRQUFDLHFCQUFxQjs4QkFBQyxzQkFBc0IsRUFBQyxLQUFLLENBQUMsSUFBSSxFQUFHLFNBQVMsSUFBQyxlQUFlLEdBQUMsc0JBQXNCOzs7SUFBdW5CLFNBQU0sa0JBQTBELHFCQUFxQjsrQkFBRyxxQkFBcUIsSUFBQyxTQUFTLEdBQUMsY0FBYzs7O29CQUExZ0MsU0FBTSxjQUE2QixzQkFBc0IsRUFBQyxJQUFJOzs7SUFBK1YsUUFBSzthQUFzQyxHQUFVO2tCQUFFLG1CQUFtQixFQUFDLE1BQU07O2FBQXRDLEdBQVU7Y0FBRSxtQkFBbUIsUUFBbkIsbUJBQW1CLEVBQUMsTUFBTTs7Ozs7SUFBbUMsUUFBSzthQUFhLEdBQVU7a0JBQUUsbUJBQW1CLEVBQUMsZUFBZTs7YUFBL0MsR0FBVTtjQUFFLG1CQUFtQixRQUFuQixtQkFBbUIsRUFBQyxlQUFlOzs7OztJQUFzQixRQUFLO2FBQTBDLEdBQVU7a0JBQUUsbUJBQW1CLEVBQUMsR0FBRzs7YUFBbkMsR0FBVTtjQUFFLG1CQUFtQixRQUFuQixtQkFBbUIsRUFBQyxHQUFHOzs7O29CQUFzSCxTQUFNLGNBQWlDLHNCQUFzQixFQUFDLElBQUk7b0JBQWtCLFNBQU0sRUFBMkIsbUJBQW1CO3NCQUF4aUMsT0FBRzs7Ozs7Y0FBM0Isc0JBQXNCOzs7Ozs7Ozs7Ozs7O09BRUgsT0FBRztPQUFtSyxVQUFPLFdBQTdLLE9BQUc7T0FBaVIsTUFBTSxXQUFwSCxVQUFPO09BQThQLFNBQU0scUJBQTdKLE1BQU07O1dBQU4sTUFBTTs7T0FBbU4sT0FBRyxhQUE1TixNQUFNOzBCQUFtTixPQUFHOzsyQkFBaUMsYUFBYTtXQUFqRCxPQUFHO1dBQTFVLFVBQU87V0FBN0ssT0FBRztvQkFBd2EsU0FBTSxjQUFlLGlCQUFpQixFQUFDLEtBQUs7O29CQUFqVCxVQUFPOzs7O29CQUE3SyxPQUFHLGNBQW1FLGlCQUFpQixFQUFDLEtBQUs7c0JBQTdGLE9BQUcsR0FBeUcsS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsV0FBRyxpQkFBaUIsRUFBQyxLQUFLO3NCQUFsSyxPQUFHOzs7OztjQUF0QixpQkFBaUI7Ozs7Ozs7Ozs7Ozs7T0FFSixPQUFHO09BQW1KLFVBQU8sV0FBN0osT0FBRztPQUF3UCxTQUFNLFdBQTNHLFVBQU87T0FBb0wsSUFBQyxhQUF2RixTQUFNOzBCQUFnRixJQUFDOztXQUFELElBQUM7OzRCQUFELElBQUM7Ozs7V0FBaUgsS0FBSzs7YUFqUHBkLFdBQVc7NkJBaVAwYyxXQUFXLEVBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLEVBQUUsQ0FBQyxFQUFDLENBQUMsTUFBSSxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUM7Ozs7O1dBQTFFLEtBQUs7O1dBQWdGLFdBQVc7OytCQUFoRyxLQUFLO2FBalB6VSxVQUFVOzZCQWlQMlosS0FBSyxRQUFDLFVBQVU7Ozs7O1dBQTVCLFdBQVc7O1NBQW9CLE9BQUc7NEJBQUgsT0FBRzs7OztXQUF5QyxPQUFHOzs7cUJBQUgsT0FBRyxpQkFBK0IsS0FBSyx1QkFBSSxDQUFDO2FBQVEsR0FBQzs7OzBEQUFELEdBQUMscURBQWUsS0FBSyxRQUFHLFVBQVU7NEJBQWxDLEdBQUM7Ozs7Ozs7O2VBQXJELE9BQUc7MEJBQUgsT0FBRzs7Ozs7O2lDQUFuSyxLQUFLOytCQUEySSxLQUFLLEVBQUMsTUFBTSxHQUFDLENBQUM7Ozs7Ozs7Ozs7U0FBaUgsU0FBTzs0QkFBUCxTQUFPOzs7O1dBQTBOLElBQUM7OEJBQUQsSUFBQzs7ZUFBRCxJQUFDOzs7Z0NBQTVaLFdBQVc7OEJBQXlhLFdBQVcsRUFBQyxPQUFPOzs7MEJBQTVDLElBQUM7Ozs7OztpQ0FBNVosV0FBVzsrQkFBMlgsV0FBVyxFQUFDLE9BQU87Ozs7Ozs7Ozs7Ozs7O1dBQTRILE9BQUc7V0FBdUIsT0FBSSxXQUE5QixPQUFHOzhCQUF1QixPQUFJOztlQUFKLE9BQUk7O1dBQTBDLFNBQU0sYUFBcEQsT0FBSTs4QkFBMEMsU0FBTTs7ZUFBTixTQUFNO2VBQTlFLE9BQUc7Ozs7aUNBQXhoQixXQUFXOytCQUEwaUIsV0FBVyxFQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsS0FBSzs7OztpQ0FBcGxCLFdBQVc7K0JBQTBsQixXQUFXLEVBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxZQUFZOzs7OzBCQUF0SCxPQUFHOzs7Ozs7aUNBQXhoQixXQUFXOytDQUEyYyxXQUFXLEVBQUMsTUFBTSxFQUFHLFdBQVcsV0FBRSxXQUFXLEVBQUMsVUFBVSxHQUFHLENBQUM7Ozs7Ozs7Ozs7U0FBK0ksSUFBRTs0QkFBRixJQUFFOzthQUFGLElBQUU7O1NBQTBCLElBQUMsYUFBN0IsSUFBRTs0QkFBMEIsSUFBQzs7YUFBRCxJQUFDOzs4QkFBRCxJQUFDOzs7O1dBQTRELE9BQUc7Ozs7U0FBSCxPQUFHOzs7a0NBQTd2QixXQUFXO2dDQUF5eEIsV0FBVyxFQUFDLFVBQVU7OztvQkFBSSxTQUFTO2NBQUUsT0FBRztjQUFFLE9BQUksV0FBVCxPQUFHO2lDQUFFLE9BQUk7O2tCQUFKLE9BQUk7O2NBQTBCLFNBQU0sYUFBcEMsT0FBSTtpQ0FBMEIsU0FBTTs7a0JBQU4sU0FBTTtrQkFBekMsT0FBRzs7O3VDQUFkLFNBQVMseUJBQWEsU0FBUyxFQUFDLEtBQUs7OztrQkFBckMsU0FBUztrQ0FBNkMsU0FBUyxFQUFDLFlBQVk7Ozs7NkJBQWpFLE9BQUc7Ozs7Ozs7OztlQUFsRixPQUFHOzBCQUFILE9BQUc7Ozs7OztpQ0FBN3ZCLFdBQVc7K0JBQStzQixXQUFXLEVBQUMsVUFBVSxFQUFFLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7O2dDQUF4dkIsV0FBVzs4QkFBdzZCLFdBQVcsRUFBQyxPQUFPOzs7a0JBQVEsTUFBTTs7Ozs7O2NBQXFDLFNBQU07aUNBQU4sU0FBTTs7a0JBQU4sU0FBTTs4REFBakQsTUFBTSx5QkFBMkksTUFBTSxFQUFDLEtBQUs7MkJBQWxILFNBQU0sRUFBd0UscUJBQXFCOzZCQUFuRyxTQUFNOzs7Ozs7Ozs7Z0JBQXFLLFNBQU07bUNBQU4sU0FBTTs7b0JBQU4sU0FBTTtnRUFBNU4sTUFBTSx5QkFBNFIsTUFBTSxFQUFDLEtBQUs7OzZCQUF4RixTQUFNLFFBQW9DLENBQUM7bUJBQUEsV0FBVyxFQUFDLElBQUk7YUFBQyxTQUFTO1lBQUcsQ0FBQzs7K0JBQXpFLFNBQU07Ozs7Ozs7OztrQkFBcUksVUFBTTtxQ0FBTixVQUFNOztzQkFBTixVQUFNO2tFQUF2VyxNQUFNLHlCQUF1YixNQUFNLEVBQUMsS0FBSzs7K0JBQXhHLFVBQU07NkJBQStELG9CQUFvQjs7O2lDQUF6RixVQUFNOzs7Ozs7Ozt1QkFBdlcsTUFBTTt1REFBNFQsTUFBTSxFQUFDLElBQUksRUFBRyxlQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFBL1YsTUFBTTtxREFBMkssTUFBTSxFQUFDLElBQUksRUFBRyxxQkFBcUI7Ozs7Ozs7Ozs7Ozs7Ozs7OztrQkFBcE4sTUFBTTtrREFBTSxNQUFNLEVBQUMsSUFBSSxFQUFHLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFBN3pCLFNBQU87OzhCQUFQLFNBQU87Ozs7V0FBMndDLE9BQUc7V0FBOEIsVUFBTSxXQUF2QyxPQUFHO1dBQXVHLE9BQUksYUFBN0UsVUFBTTs4QkFBbUUsT0FBSTs7ZUFBSixPQUFJOztXQUF5QyxVQUFNLGFBQW5ELE9BQUk7O2VBQTlHLE9BQUc7OztRQUE4QixVQUFNLGtDQUFXLFVBQVUsR0FBRyxDQUFDOztzQ0FBZ0QsVUFBVSxJQUFDLENBQUM7aUNBQTdwRCxLQUFLOytCQUE4cEQsS0FBSyxFQUFDLE1BQU07OztRQUFTLFVBQU07ZUFqUGxnRSxVQUFVO2lDQWlQMFQsS0FBSzsrQ0FBb3NELFVBQVUsU0FBRyxLQUFLLEVBQUMsTUFBTSxHQUFDLENBQUM7Ozs7d0JBQWxLLFVBQU0sY0FBeUMsVUFBVSxRQUFWLFVBQVUsSUFBRSxDQUFDO3dCQUEwRCxVQUFNLGNBQXNELFVBQVUsUUFBVixVQUFVLElBQUUsQ0FBQzswQkFBaE8sT0FBRzs7Ozs7O2lDQUFwaUQsS0FBSzsrQkFBNGdELEtBQUssRUFBQyxNQUFNLEdBQUMsQ0FBQzs7Ozs7Ozs7OzthQUEzNkMsT0FBRzs7O2tCQUF3SixTQUFPOytCQUFqTSxXQUFXO3VEQUF3TixXQUFXLEVBQUMsS0FBSyxJQUFFLGNBQWM7Ozs7K0JBQXBRLFdBQVc7NkJBQTBwQixXQUFXLEVBQUMsS0FBSzs7OzsrQkFBdHJCLFdBQVc7NkJBQXFyQixXQUFXLEVBQUMsSUFBSTs7OzsyQkFBdGhCLFNBQU8sR0FBc0YsS0FBSyxXQUFHLGVBQWUsRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPO3lCQUE3SSxTQUFPLEdBQXNKLEtBQUssS0FBRSxhQUFhLENBQUMsS0FBSyxRQUFDLEtBQUssRUFBQyxNQUFNO3dCQUEvVixPQUFHOzs7OztVQUF2SSxPQUFPOzs7Ozs7Ozs7V0FBcFMsVUFBTztXQUE3SixPQUFHOzs7O1dBalBmLFdBQVc7cUJBaVB5VyxXQUFXLE9BQUMsV0FBVyxHQUFFLFdBQVc7Ozs7V0FqUHhaLFdBQVc7cUJBaVBvWixTQUFTLE9BQUMsV0FBVzs7OztvQkFBN0ssU0FBTSxjQUFtQyxXQUFXLEVBQUMsSUFBSTs7b0JBQTlKLFVBQU87Ozs7b0JBQTdKLE9BQUcsY0FBaUUsV0FBVyxFQUFDLElBQUk7c0JBQXBGLE9BQUcsR0FBZ0csS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsV0FBRyxXQUFXLEVBQUMsSUFBSTtzQkFBbEosT0FBRzs7Ozs7Y0FBaEIsV0FBVzs7Ozs7Ozs7Ozs7OztPQUVXLE9BQUc7T0FBeUIsVUFBTyxXQUFuQyxPQUFHO09BQWdGLFVBQU0sV0FBN0QsVUFBTzs0QkFBZ0QsVUFBTTs7OztTQUFrVCxJQUFDOzt3QkFBRCxJQUFDOzs7Ozs7Ozs7V0FBeUUsSUFBQzs4QkFBRCxJQUFDOztlQUFELElBQUM7MERBQXFCLGVBQWU7MEJBQXJDLElBQUM7Ozs7Ozs7OzhDQUF1RCxnQkFBZ0IsdUJBQUksU0FBUzs7YUFBRSxPQUFHO2FBQXNCLFNBQU0sV0FBL0IsT0FBRztnQ0FBc0IsU0FBTTs7aUJBQU4sU0FBTTs7YUFBcUYsT0FBSSxhQUEvRixTQUFNO2dDQUFxRixPQUFJOztpQkFBSixPQUFJO2lCQUF4SCxPQUFHOztrQ0FBSCxPQUFHOzs7aURBQWQsU0FBUyx5QkFBeU4sU0FBUyxFQUFDLE9BQU8sd0JBQUksTUFBTTtlQUFFLFVBQU07a0NBQU4sVUFBTTs7bUJBQU4sVUFBTTs7O1lBQU4sVUFBTTttQkFyTzN1QixrQkFBa0I7bUJBcU9vZCxTQUFTO21EQUErVixrQkFBa0IsU0FBRyxTQUFTLEVBQUMsYUFBYTs7O3dDQUE3SixNQUFNLHlCQUEwSixNQUFNLEVBQUMsS0FBSzs7OzRCQUFwSyxVQUFNLFFBQW9DLGdCQUFnQixPQUFDLFNBQVMsRUFBQyxhQUFhLFFBQUMsTUFBTSxFQUFDLEVBQUU7OEJBQTVGLFVBQU07Ozs7Ozs7O2FBQWdMLFVBQU07Ozs7d0RBQTNiLFNBQVMseUJBQStELFNBQVMsRUFBQyxRQUFRO2tCQUExRixTQUFTO2tDQUFzRixTQUFTLEVBQUMsV0FBVzs7Ozs7V0FBaVUsVUFBTTtrQkFyT2o2QixrQkFBa0I7a0JBcU9vZCxTQUFTO2tEQUE2Z0Isa0JBQWtCLFNBQUcsU0FBUyxFQUFDLGFBQWE7Ozs7O2tCQUFsa0IsU0FBUzs0QkFBbUMsS0FBSyxPQUFDLFNBQVMsRUFBQyxNQUFNOzs7O2tCQUFsRSxTQUFTOzRCQUE0SCxTQUFTLE9BQUMsU0FBUyxFQUFDLGVBQWU7Ozs7OzBCQUE2USxVQUFNLFFBQWlDLGdCQUFnQixPQUFDLFNBQVMsRUFBQyxhQUFhLEVBQUMsSUFBSTs7Ozs7Ozs7Ozs7OzthQUFrSSxJQUFDOzs0QkFBRCxJQUFDOzs7Ozs7aUJBck90cUMsZ0JBQWdCO2tDQXFPNG5DLGdCQUFnQixFQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUF2dkIsc0JBQXNCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBNUcsc0JBQXNCLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQTdXLFVBQU87V0FBbkMsT0FBRztvQkFBZ0YsVUFBTSxjQUE2QixvQkFBb0IsRUFBQyxLQUFLO3NCQUFoSixPQUFHOzs7OztjQUF6QixvQkFBb0I7Ozs7Ozs7Ozs7Ozs7T0FDRCxPQUFHO09BQTBKLFVBQU8sV0FBcEssT0FBRztPQUF3UCxVQUFNLFdBQXBHLFVBQU87T0FBNk0sS0FBRSxhQUF4SCxVQUFNOzBCQUFnSCxLQUFFOztXQUFGLEtBQUU7OzRCQUFGLEtBQUU7Ozs7O1NBQTZHLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDOztTQUFrSCxPQUFHLGFBQXRILElBQUM7OzttQkFBa0gsT0FBRyxpQkFBOEIsYUFBYSx1QkFBSSxJQUFJO2FBQVMsUUFBUTs7ZUFBckIsSUFBSTswQkFBa0IsT0FBTyxFQUFDLElBQUksT0FBQyxJQUFJLEVBQUMsUUFBUTs7Ozs7YUFBbkMsUUFBUTs7YUFBcUMsUUFBUTs7ZUFBbEUsSUFBSTsrQ0FBK0QsSUFBSSxFQUFDLFVBQVUsRUFBRyxpQkFBaUI7Ozs7O2FBQTVDLFFBQVE7O2FBQTZDLFNBQVM7O2VBQXhILElBQUk7K0NBQXFILElBQUksRUFBQyxVQUFVLEVBQUcsb0JBQW9COzs7OzthQUFoRCxTQUFTOzthQUFnRCxhQUFhOztlQUFyTCxJQUFJOytDQUFrTCxJQUFJLEVBQUMsVUFBVSxFQUFHLHNCQUFzQjs7Ozs7YUFBdEQsYUFBYTs7YUFBa0QsZUFBZTs7ZUFBdFAsSUFBSTt5QkFBbVAsbUJBQW1CLE9BQUMsSUFBSSxFQUFDLFFBQVEsR0FBRyxNQUFNOzs7OzthQUExRCxlQUFlOztXQUE2QyxPQUFHOztXQUFzWCxPQUFHLFdBQTVYLE9BQUc7V0FBMlgsU0FBTSxXQUFYLE9BQUc7OEJBQUUsU0FBTTs7ZUFBTixTQUFNOztXQUEwQixPQUFJLGFBQXBDLFNBQU07OEJBQTBCLE9BQUk7O2VBQUosT0FBSTtlQUF6QyxPQUFHOztXQUFrSCxJQUFDLGFBQXRILE9BQUc7OEJBQWtILElBQUM7O2VBQUQsSUFBQzs7Z0NBQUQsSUFBQzs7OzthQUFpQyxVQUFNOzswQkFBTixVQUFNLEVBQW9FLGdCQUFnQjs0QkFBMUYsVUFBTTs7Ozs7Ozs7O2VBQXlILFVBQU07O21EQUFOLFVBQU07a0JBQXg3QixJQUFJO3FFQUF1L0IsSUFBSSxFQUFDLFFBQVE7Ozs0QkFBdEYsVUFBTSxRQUFrRyxzQkFBc0IsT0FBQyxJQUFJOzhCQUFuSSxVQUFNOzs7Ozs7Ozs7aUJBQW9LLFVBQU07O3FEQUFOLFVBQU07b0JBQWxtQyxJQUFJO2lFQUEycEMsSUFBSSxFQUFDLFFBQVE7Ozs4QkFBaEYsVUFBTSxRQUE0RixpQkFBaUIsT0FBQyxJQUFJO2dDQUF4SCxVQUFNOzs7Ozs7Ozs7bUJBQTZKLFVBQU07O3VEQUFOLFVBQU07c0JBQXJ3QyxJQUFJO3VFQUFrMEMsSUFBSSxFQUFDLFFBQVE7OztnQ0FBcEYsVUFBTSxRQUFnRyxzQkFBc0IsT0FBQyxJQUFJO2tDQUFqSSxVQUFNOzs7Ozs7OzJCQUFyQixhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7eUJBQTVLLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFBbEwsUUFBUTs7Ozs7Ozs7Ozs7Ozs7OztvQkFBdkksUUFBUTs7Ozs7Ozs7O2VBQTlnQixPQUFHOzs7O2tDQUFILE9BQUc7cUNBQXRTLElBQUkseUJBQXFxQixJQUFJLEVBQUMsUUFBUTs7d0NBQXRyQixJQUFJLHlCQUFtc0IsSUFBSSxFQUFDLElBQUk7Z0JBQWh0QixJQUFJO2dDQUE4c0IsSUFBSSxFQUFDLElBQUksVUFBRSxJQUFJLEVBQUMsUUFBUSxHQUFDLEtBQUssR0FBQyxFQUFFOzBCQUFudkIsSUFBSSx5QkFBaXZCLElBQUksRUFBQyxRQUFROztxQ0FBbHdCLElBQUkseUJBQWd4QixJQUFJLEVBQUMsTUFBTTs7OztrQ0FBamUsUUFBUSxLQUFFLHNCQUFzQixZQUFNLFFBQVEsS0FBRSxRQUFRLE9BQUMsSUFBSSxZQUFLLFNBQVMsMkJBQUUsTUFBTSxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFJLE1BQU0sT0FBQyxJQUFJLEVBQUMsUUFBUSxLQUFJLGtCQUFrQixFQUFFLE1BQU0sRUFBRyxLQUFLLFdBQUksYUFBYSwyQkFBRSxlQUFlLEdBQUcsS0FBSzt3Q0FBZ0MsUUFBUSxLQUFFLGNBQWMsT0FBQyxJQUFJLFlBQUssYUFBYSwyQkFBRSxlQUFlLEdBQUcsV0FBVzs7Ozs7MEJBQWhXLE9BQUc7Ozs7Ozs7O2FBQXhWLE9BQUc7OztZQTdMem1CLGFBQWE7NEJBNkxnZ0IsYUFBYSxFQUFDLE1BQU07O1lBN0xqaUIsYUFBYTs0Q0E2TGdpQixhQUFhLEVBQUMsTUFBTSxFQUFHLENBQUMsSUFBQyxZQUFZLEdBQUMsYUFBYTs7Ozs7OztTQUEwK0MsT0FBRzs7d0JBQUgsT0FBRzs7Ozs7O2FBN0w3a0UsYUFBYTs2QkE2TGdkLGFBQWEsRUFBQyxNQUFNOzs7Ozs7Ozs7O1dBQWpVLFVBQU87V0FBcEssT0FBRzs7OztXQXBQckIsV0FBVztxQkFvUDRYLFlBQVksT0FBQyxXQUFXLEtBQUUsMEJBQTBCLEdBQUMscUJBQXFCOzs7O29CQUFwTSxVQUFNLGNBQTZCLGlCQUFpQixFQUFDLEtBQUs7O29CQUF4SixVQUFPOzs7O29CQUFwSyxPQUFHLGNBQXNDLGlCQUFpQixFQUFDLEtBQUs7c0JBQWhFLE9BQUcsR0FBNEUsS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsV0FBRyxpQkFBaUIsRUFBQyxLQUFLO3NCQUFySSxPQUFHOzs7OztjQUF0QixpQkFBaUI7Ozs7Ozs7Ozs7Ozs7T0FDUixPQUFHO09BQXlCLFVBQU8sV0FBbkMsT0FBRztPQUE4RixVQUFNLFdBQTNFLFVBQU87T0FBK1QsUUFBSyxhQUF0USxVQUFNO09BQXdRLFFBQUsscUJBQWxCLFFBQUs7OzJCQUFRLFFBQUs7V0FBbEIsUUFBSzs7T0FBeUcsUUFBSyxhQUFuSCxRQUFLO09BQWdJLFFBQUsscUJBQTVCLFFBQUs7OzJCQUFrQixRQUFLO1dBQTVCLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBOEksSUFBQzs7d0JBQUQsSUFBQzs7Ozs7Ozs7O1dBQWdILElBQUM7OEJBQUQsSUFBQzs7ZUFBRCxJQUFDOzBEQUFxQixZQUFZOzBCQUFsQyxJQUFDOzs7OztXQUE4QyxRQUFLO1dBQVUsUUFBTSxxQkFBckIsUUFBSztXQUFzRSxRQUFNLFdBQWxFLFFBQU07O09BQXNELFFBQU0sU0FBTixRQUFNOztnQ0FBTixRQUFNOzs7Ozs7O2dCQWxQNTFCLFdBQVc7Z0NBa1BxNEIsV0FBVyxFQUFDLFVBQVU7OztvQkFBSSxNQUFNO2NBQUUsUUFBTTtpQ0FBTixRQUFNOztrQkFBTixRQUFNOzs7Ozt1Q0FBZCxNQUFNLHlCQUE4QixNQUFNLEVBQUMsSUFBSTs7MkRBQS9DLE1BQU0seUJBQWdCLE1BQU0sRUFBQyxJQUFJO1lBQXpCLFFBQU0sVUFBTixRQUFNLGtCQUFkLE1BQU0seUJBQWdCLE1BQU0sRUFBQyxJQUFJOzs7OzZCQUF6QixRQUFNOzs7Ozs7Ozs7ZUFBOUosUUFBTTs7OztxQkFBTixRQUFNO2VBQXJCLFFBQUs7O1dBQTRPLFFBQUssYUFBdFAsUUFBSztXQUE4UCxRQUFNLHFCQUF4QixRQUFLOzs7Y0FBZ0MsZUFBZTs7Ozs7Ozs7V0FBNEIsU0FBTSxXQUFwRSxRQUFNOztPQUF3RCxTQUFNLFNBQU4sU0FBTTs7Z0NBQU4sU0FBTTs7OzhDQUF1RCxpQkFBaUIsdUJBQUksTUFBTTthQUFFLFNBQU07Z0NBQU4sU0FBTTs7aUJBQU4sU0FBTTs7Ozs7cUNBQWlCLE1BQU07OzJEQUFmLE1BQU07V0FBcEIsU0FBTSxVQUFOLFNBQU0saUJBQVEsTUFBTTs7Ozs0QkFBcEIsU0FBTTs7Ozs7Ozs7ZUFBOUosUUFBTTtlQUF4QixRQUFLOztXQUFxTyxRQUFLLGFBQS9PLFFBQUs7V0FBb1AsUUFBTSxxQkFBckIsUUFBSzs7O2NBQTZCLGNBQWM7Ozs7Ozs7O1dBQUcsU0FBTSxXQUExQyxRQUFNOztPQUE4QixTQUFNLFNBQU4sU0FBTTs7Z0NBQU4sU0FBTTs7Ozs7OztnQkFsUC94QyxXQUFXO2dDQWtQdzBDLFdBQVcsRUFBQyxTQUFTOzs7b0JBQUksTUFBTTtjQUFFLFNBQU07aUNBQU4sU0FBTTs7a0JBQU4sU0FBTTs7Ozs7O3dDQUFkLE1BQU0seUJBQW9DLE1BQU0sRUFBQyxJQUFJOzs7YUFBN0MsU0FBTSxVQUFOLFNBQU07Ozs7eUJBQWQsTUFBTSxtQkFBZ0IsTUFBTSxPQUFDLE1BQU0sRUFBQyxFQUFFOzs7OzZCQUE5QixTQUFNOzs7Ozs7Ozs7ZUFBckksUUFBTTtlQUFyQixRQUFLOztXQUF5TixRQUFLLGFBQW5PLFFBQUs7V0FBOE8sUUFBTSxxQkFBM0IsUUFBSzs7O2NBQW1DLGFBQWE7Ozs7Ozs7O1dBQUcsU0FBTSxXQUF6QyxRQUFNOztPQUE2QixTQUFNLFNBQU4sU0FBTTs7Z0NBQU4sU0FBTTs7Ozs7OztnQkFsUGxnRCxXQUFXO2dDQWtQMmlELFdBQVcsRUFBQyxRQUFROzs7b0JBQUksTUFBTTtjQUFFLFNBQU07aUNBQU4sU0FBTTs7a0JBQU4sU0FBTTs7Ozs7O3dDQUFkLE1BQU0seUJBQW9DLE1BQU0sRUFBQyxJQUFJOzs7YUFBN0MsU0FBTSxVQUFOLFNBQU07Ozs7eUJBQWQsTUFBTSxtQkFBZ0IsTUFBTSxPQUFDLE1BQU0sRUFBQyxFQUFFOzs7OzZCQUE5QixTQUFNOzs7Ozs7Ozs7ZUFBbkksUUFBTTtlQUEzQixRQUFLOzs7dURBQWpxQixZQUFZOztVQUExQixRQUFNLFVBQU4sUUFBTSxpQkFBUSxZQUFZOzBCQUExQixRQUFNLFFBQVEsWUFBWTs7OztRQUEwTixRQUFNLG1CQUF5QyxZQUFZOzs7eUJBQS9TLFFBQU0sRUFBaUMsa0JBQWtCOzs7UUFBMkwsUUFBTTtpQkFBQyxHQUFVO3NCQUFFLGVBQWU7O2lCQUEzQixHQUFVO2VBQUUsZUFBZTs7Ozs7UUFBcU0sUUFBTTtpQkFBQyxHQUFVO3NCQUFFLGNBQWM7O2lCQUExQixHQUFVO2VBQUUsY0FBYzs7Ozs7UUFBbU0sUUFBTTtpQkFBQyxHQUFVO3NCQUFFLGFBQWE7O2lCQUF6QixHQUFVO2VBQUUsYUFBYTs7Ozs7Ozs7Ozs7bUNBQXR6QixhQUFhLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBMUksYUFBYSxHQUFHLFNBQVM7Ozs7Ozs7Ozs7Ozs7U0FBbWxDLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixXQUFXO3dCQUFqQyxJQUFDOzs7OztnQkFBZCxXQUFXOzs7Ozs7Ozs7T0FBOEMsT0FBRztPQUF3QixVQUFNLFdBQWpDLE9BQUc7T0FBNkYsVUFBTSxhQUEzRSxVQUFNOzBCQUErRCxVQUFNOztXQUFOLFVBQU07V0FBdEcsT0FBRztXQUF2c0QsVUFBTztXQUFuQyxPQUFHOzs7O3FCQUFvZSxRQUFLO0tBQW8xQyxVQUFNLGtCQUErQyxNQUFNLDJCQUFFLGFBQWEsR0FBRyxPQUFPO2dDQUFHLE1BQU0sSUFBQyxTQUFTLEdBQUMsY0FBYzs7O2dDQUFwN0MsSUFBSSxHQUFHLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFDLEVBQUU7Ozs7b0JBQWhjLFVBQU0sY0FBNkIsT0FBTyxFQUFDLElBQUk7OztJQUErTixRQUFLO2FBQTBELEdBQVU7a0JBQUUsVUFBVTs7YUFBdEIsR0FBVTtXQUFFLFVBQVU7Ozs7O0lBQW1DLFFBQUs7YUFBd0QsR0FBVTtrQkFBRSxRQUFROzthQUFwQixHQUFVO1dBQUUsUUFBUTs7OztvQkFBbXNDLFVBQU0sY0FBaUMsT0FBTyxFQUFDLElBQUk7b0JBQWtCLFVBQU0sRUFBMkIsUUFBUTtzQkFBejJELE9BQUc7Ozs7O2NBQVosT0FBTzs7Ozs7Ozs7Ozs7OztPQUNHLE9BQUc7T0FBeUIsVUFBTyxXQUFuQyxPQUFHO09BQWdKLEtBQUUscUJBQXpILFVBQU87MEJBQWdILEtBQUU7O1dBQUYsS0FBRTs7T0FBdUYsT0FBRyxhQUE1RixLQUFFO09BQWtILFVBQU0sV0FBakMsT0FBRztPQUE4RixVQUFNLGFBQTVFLFVBQU07O1dBQWpDLE9BQUc7V0FBbk4sVUFBTztXQUFuQyxPQUFHOzs7aUJBcFBzSCxRQUFRLG1CQW9QNkIsUUFBUSxPQUFDLFFBQVE7OztvQkFBd0YsVUFBTSxjQUFpQyxRQUFRLEVBQUMsSUFBSTtvQkFBa0IsVUFBTSxFQUEwQyxhQUFhO3NCQUExWSxPQUFHOzs7OztjQUFiLFFBQVE7Ozs7Ozs7Ozs7Ozs7T0FDQyxPQUFHO09BQXlCLFVBQU8sV0FBbkMsT0FBRztPQUErRyxVQUFNLFdBQTVGLFVBQU87T0FBaU4sSUFBQyxhQUFuSSxVQUFNOzBCQUE0SCxJQUFDOztXQUFELElBQUM7OzRCQUFELElBQUM7Ozs7U0FBd0csR0FBQzs7NkNBQUQsR0FBQyxpQkF2UHBWLE9BQU8seUJBdVAwWCxPQUFPLEVBQUMsV0FBVzt3QkFBakUsR0FBQzs7Ozs7aUJBdlBwVixPQUFPLHlCQXVQdVQsT0FBTyxFQUFDLFdBQVc7Ozs7Ozs7OztPQUEySCxVQUFNOztXQUFoYyxVQUFPO1dBQW5DLE9BQUc7Ozs7V0F2UE8sT0FBTztxQkF1UHVRLFNBQVMsVUFBSSxPQUFPLEVBQUMsSUFBSTs7OztvQkFBL0wsVUFBTSxjQUE2QixPQUFPLEVBQUMsSUFBSTtvQkFBcVQsVUFBTSxjQUFzQyxPQUFPLEVBQUMsSUFBSTtzQkFBOWdCLE9BQUc7Ozs7O2NBQVosT0FBTzs7Ozs7Ozs7Ozs7O0NBckdaIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIb21lLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8IS0tIEZJTi1FUElDLTAwMiwgRklOLUVQSUMtMDAzLCBGSU4tRVBJQy0wMDUsIGFuZCBGSU4tRVBJQy0wMDY6IHNlZSBkb2NzL2ppcmEvcGVyc29uYWwtZXhwZW5zZS9GSU4tRVBJQy0wMDItY29ycmVjdG5lc3MubWQsIEZJTi1FUElDLTAwMy1pbnNpZ2h0cy5tZCwgRklOLUVQSUMtMDA1LXBsYW5uaW5nLm1kLCBhbmQgRklOLUVQSUMtMDA2LWVzc2VudGlhbC1jb21taXRtZW50cy5tZC4gLS0+XG48c2NyaXB0PlxuICBpbXBvcnQgJy4vY29tbWl0bWVudC5jc3MnO1xuICBpbXBvcnQgJy4vY29tcG9uZW50cy9kZXRhaWwtc2hlZXQuY3NzJztcbiAgaW1wb3J0IHsgb25Nb3VudCwgdGljayB9IGZyb20gJ3N2ZWx0ZSc7XG4gIGltcG9ydCB7IEFwaUVycm9yLCBjb21wbGV0ZUFjdGlvbiwgY29tcGxldGVSZWN1cnJpbmdDb21taXRtZW50LCBjb25maXJtU2lwT2NjdXJyZW5jZSwgY29uZmlybVN0b2NrTW9udGhseVBsYW4sIGNyZWF0ZUNyZWRpdENhcmQsIGNyZWF0ZUxvYW4sIGNyZWF0ZU1pc3NpbmdEYXRlQ29udGV4dCwgY3JlYXRlTXV0dWFsRnVuZCwgY3JlYXRlTXV0dWFsRnVuZEx1bXBTdW0sIGNyZWF0ZU11dHVhbEZ1bmRTaXAsIGNyZWF0ZVN0b2NrLCBjcmVhdGVTdG9ja01vbnRobHlQbGFuLCBjcmVhdGVSZWN1cnJpbmdDb21taXRtZW50LCBkZWxldGVFeHBlbnNlLCBkZWxldGVMb2FuLCBkZWxldGVNdXR1YWxGdW5kLCBkZWxldGVSZWN1cnJpbmdDb21taXRtZW50LCBkZWxldGVTdG9jaywgZ2V0QWN0aW9ucywgZ2V0Q29tbWl0bWVudFJldmlldywgZ2V0Q3JlZGl0Q2FyZHMsIGdldEV4cGVuc2VPcHRpb25zLCBnZXRFeHBlbnNlc0ZvckRhdGUsIGdldEluY29tZU91dGxvb2ssIGdldExvYW5IaXN0b3J5LCBnZXRMb2FucywgZ2V0TXV0dWFsRnVuZCwgZ2V0TXV0dWFsRnVuZHMsIGdldFJlY3VycmluZ0NvbW1pdG1lbnRIaXN0b3J5LCBnZXRSZWN1cnJpbmdDb21taXRtZW50cywgZ2V0U3RvY2ssIGdldFN0b2NrcywgbG9nb3V0LCBtYXJrTG9hbkVtaVBhaWQsIHJlc29sdmVDb21taXRtZW50UmV2aWV3LCBzYXZlSW5jb21lUHJvZmlsZSwgc2VhcmNoTXV0dWFsRnVuZHMsIHNlYXJjaFN0b2NrcywgdXBkYXRlQ3JlZGl0Q2FyZCwgdXBkYXRlRXhwZW5zZSwgdXBkYXRlTG9hbiwgdXBkYXRlUmVjdXJyaW5nQ29tbWl0bWVudCwgdXBkYXRlU2lwT2NjdXJyZW5jZSwgdXBkYXRlTXV0dWFsRnVuZFRyYW5zYWN0aW9uIH0gZnJvbSAnLi9saWIvYXBpLmpzJztcbiAgaW1wb3J0IFNlY3Rpb25TdGF0ZSBmcm9tICcuL1NlY3Rpb25TdGF0ZS5zdmVsdGUnO1xuICBpbXBvcnQgTm9ybWFsaXphdGlvbiBmcm9tICcuL05vcm1hbGl6YXRpb24uc3ZlbHRlJztcbiAgaW1wb3J0IEFwcEhlYWRlciBmcm9tICcuL2NvbXBvbmVudHMvQXBwSGVhZGVyLnN2ZWx0ZSc7XG4gIGltcG9ydCBCb3R0b21OYXYgZnJvbSAnLi9jb21wb25lbnRzL0JvdHRvbU5hdi5zdmVsdGUnO1xuICBpbXBvcnQgRHVlUmVtaW5kZXIgZnJvbSAnLi9jb21wb25lbnRzL0R1ZVJlbWluZGVyLnN2ZWx0ZSc7XG4gIGltcG9ydCBWaWV3RGV0YWlsc0xpbmsgZnJvbSAnLi9jb21wb25lbnRzL1ZpZXdEZXRhaWxzTGluay5zdmVsdGUnO1xuICBpbXBvcnQgQ2xvc2VkTG9hblJvdyBmcm9tICcuL2NvbXBvbmVudHMvQ2xvc2VkTG9hblJvdy5zdmVsdGUnO1xuICBpbXBvcnQgUHJvZmlsZVNldHRpbmdzIGZyb20gJy4vZmVhdHVyZXMvcHJvZmlsZS9Qcm9maWxlU2V0dGluZ3Muc3ZlbHRlJztcbiAgZXhwb3J0IGxldCBjYWxlbmRhclNlY3Rpb247IGV4cG9ydCBsZXQgcmVjZW50U2VjdGlvbjsgZXhwb3J0IGxldCBzdG9yaWVzU2VjdGlvbjsgZXhwb3J0IGxldCBzZWxlY3RlZE1vbnRoOyBleHBvcnQgbGV0IGNvbm5lY3Rpb25TdGF0dXM7IGV4cG9ydCBsZXQgY2FjaGVVcGRhdGVkQXQ7IGV4cG9ydCBsZXQgZGVtb01vZGU7IGV4cG9ydCBsZXQgb25EZW1vTW9kZUNoYW5nZTsgZXhwb3J0IGxldCBvbk1vbnRoQ2hhbmdlOyBleHBvcnQgbGV0IHJlZnJlc2hDYWxlbmRhcjsgZXhwb3J0IGxldCByZWZyZXNoUmVjZW50OyBleHBvcnQgbGV0IHJlZnJlc2hTdG9yaWVzOyBleHBvcnQgbGV0IG9uUmV0cnlDb25uZWN0aW9uOyBleHBvcnQgbGV0IG9uTG9nb3V0O1xuXG4gIGxldCB2aWV3PSdob21lJywgc2hvd01vbmV5PWZhbHNlLCBzaG93Tm9ybWFsaXphdGlvbj1mYWxzZSwgc2VsZWN0ZWREYXk9bnVsbCwgYWN0aXZpdHlUYWI9J3JlY2VudCcsIGRheUl0ZW1zPVtdLCBkYXlTdGF0dXM9J2lkbGUnLCBzaG93QWxsPWZhbHNlLCBleHBhbmRlZElkPW51bGw7XG4gIGxldCBvcGVuZWRTdG9yeT1udWxsLCBoYW5kb2ZmPW51bGwsIGFkZGluZ0NvbnRleHQ9ZmFsc2UsIGFjdGlvbkVycm9yPScnLCBsb2dnaW5nT3V0PWZhbHNlLCBzaWduT3V0RXJyb3I9JycsIGRlbW9Td2l0Y2hpbmc9ZmFsc2UsIGRlbW9FcnJvcj0nJywgc3RvcnlTbGlkZT0wLCBzdG9yeVRvdWNoU3RhcnQ9bnVsbCwgc2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2UsIHN0b3J5RmlsdGVyPSdBbGwnLCBob21lU3RvcnlJbmRleD0wLCBzdG9yaWVzUmFpbEluZGV4PTAsIHN0b3J5UmFpbFRvdWNoU3RhcnQ9bnVsbDtcbiAgbGV0IGNvbW1pdG1lbnRTdHlsZT0ncGxheWZ1bCc7XG4gIGxldCBlZGl0aW5nPW51bGwsIGVkaXRBbW91bnQ9JycsIGVkaXREYXRlPScnLCBlZGl0Q2F0ZWdvcnk9JycsIGVkaXRTdWJjYXRlZ29yeT0nJywgZWRpdE1lcmNoYW50SWQ9JycsIGVkaXRBY2NvdW50SWQ9JycsIHNhdmluZz1mYWxzZSwgZGVsZXRpbmc9bnVsbDtcbiAgbGV0IGVkaXRPcHRpb25zPXtjYXRlZ29yaWVzOltdLG1lcmNoYW50czpbXSxhY2NvdW50czpbXX0sIG9wdGlvbnNTdGF0dXM9J2lkbGUnLCBvcHRpb25zRXJyb3I9Jyc7XG4gIGxldCBzdG9yeUNvbnRyb2xzPXtzcGVuZGluZzp0cnVlLGludmVzdG1lbnRzOnRydWUscGxhbm5pbmc6dHJ1ZX07XG4gIGxldCBzaG93TG9hbkZvcm09ZmFsc2UsIGxvYW5FcnJvcj0nJywgbG9hblN0YXR1cz0naWRsZScsIGxvYW5FZGl0aW5nSWQ9bnVsbCwgbG9hblNhdmluZz1mYWxzZSwgbG9hbkRlbGV0aW5nSWQ9bnVsbCwgc2hvd0Nsb3NlZExvYW5zPWZhbHNlO1xuICBsZXQgbG9hbkZvcm09e2xvYW5OYW1lOicnLGxvYW5UeXBlOidIT01FJyxsZW5kZXJOYW1lOicnLG9yaWdpbmFsUHJpbmNpcGFsOicnLG1vbnRobHlFbWlBbW91bnQ6JycsdG90YWxUZW51cmVNb250aHM6JycsZmlyc3RFbWlEdWVEYXRlOicnLG5vdGVzOicnfTtcbiAgbGV0IGxvYW5zPVtdO1xuICBsZXQgbG9hbkhpc3Rvcnk9bnVsbCwgbG9hbkhpc3RvcnlTdGF0dXM9J2lkbGUnLCBsb2FuSGlzdG9yeUVycm9yPScnO1xuICBsZXQgY29tbWl0bWVudHM9W10sIGNvbW1pdG1lbnRTdGF0dXM9J2lkbGUnLCBjb21taXRtZW50RXJyb3I9JycsIHNob3dDb21taXRtZW50Rm9ybT1mYWxzZSwgY29tbWl0bWVudFNhdmluZz1mYWxzZSwgY29tbWl0bWVudEVkaXRpbmdJZD1udWxsLCBjb21taXRtZW50RGVsZXRpbmdJZD1udWxsLCBjb21wbGV0aW5nQ29tbWl0bWVudElkPW51bGw7XG4gIGxldCBjb21taXRtZW50SGlzdG9yeT1udWxsLCBjb21taXRtZW50SGlzdG9yeVN0YXR1cz0naWRsZScsIGNvbW1pdG1lbnRIaXN0b3J5RXJyb3I9Jyc7XG4gIGxldCBjb21taXRtZW50Rm9ybT17bGFiZWw6JycscGxhbm5pbmdBbW91bnQ6JycsZHVlRGF5OicnLGFtb3VudE1vZGU6J0ZJWEVEJ307XG4gIGxldCBjcmVkaXRDYXJkcz1bXSwgY3JlZGl0Q2FyZFN0YXR1cz0naWRsZScsIGNyZWRpdENhcmRFcnJvcj0nJywgc2hvd0NyZWRpdENhcmRGb3JtPWZhbHNlLCBjcmVkaXRDYXJkU2F2aW5nPWZhbHNlLCBjcmVkaXRDYXJkRWRpdGluZ0lkPW51bGw7XG4gIGxldCBjcmVkaXRDYXJkRm9ybT17YWNjb3VudFJlZmVyZW5jZUlkOicnLGNhcmROYW1lOicnLGlzc3Vlck5hbWU6Jycsc3RhdGVtZW50RGF5OicnLGR1ZURheTonJ307XG4gIGxldCBzaG93Q29tbWl0bWVudFJldmlldz1mYWxzZSwgY29tbWl0bWVudFJldmlldz1bXSwgY29tbWl0bWVudFJldmlld1N0YXR1cz0naWRsZScsIHJlc29sdmluZ0NhbmRpZGF0ZT1udWxsO1xuICBsZXQgaW5jb21lT3V0bG9vaz17c2FsYXJ5Om51bGx9LCBpbmNvbWVTdGF0dXM9J2lkbGUnLCBpbmNvbWVFcnJvcj0nJywgaW5jb21lU2F2aW5nPWZhbHNlLCBzaG93SW5jb21lRmxvdz1mYWxzZTtcbiAgbGV0IHNhbGFyeUZvcm09e3NhbGFyeVZpc2liaWxpdHk6J1JBTkdFJyxzYWxhcnlSYW5nZTonRlJPTV81MDAwMF9UT18xMDAwMDAnLGV4YWN0TW9udGhseVNhbGFyeTonJyxzYWxhcnlGcmVxdWVuY3k6J01PTlRITFknfTtcbiAgbGV0IHNob3dNdXR1YWxGdW5kRm9ybT1mYWxzZSwgc2NoZW1lUXVlcnk9JycsIHNob3dTY2hlbWVNZW51PWZhbHNlLCBzZWxlY3RlZFNjaGVtZT1udWxsLCBmdW5kRXJyb3I9JycsIGZ1bmRTYXZlZD1mYWxzZSwgZnVuZFNhdmluZz1mYWxzZSwgc2NoZW1lU2VhcmNoU3RhdHVzPSdpZGxlJywgc2NoZW1lUmVzdWx0cz1bXSwgc2NoZW1lU2VhcmNoUmVxdWVzdD0wO1xuICBsZXQgbXV0dWFsRnVuZHM9W10sIG11dHVhbEZ1bmRTdGF0dXM9J2lkbGUnLCBtdXR1YWxGdW5kRXJyb3I9JycsIG11dHVhbEZ1bmREZWxldGluZ0lkPW51bGw7XG4gIGxldCBzdG9ja3M9W10sIHN0b2NrU3RhdHVzPSdpZGxlJywgc3RvY2tFcnJvcj0nJywgc2hvd1N0b2NrRm9ybT1mYWxzZSwgc3RvY2tRdWVyeT0nJywgc2VsZWN0ZWRTdG9jaz1udWxsLCBzdG9ja1Jlc3VsdHM9W10sIHN0b2NrU2VhcmNoU3RhdHVzPSdpZGxlJywgc3RvY2tTZWFyY2hSZXF1ZXN0PTAsIHN0b2NrU2F2aW5nPWZhbHNlLCBzdG9ja0RlbGV0aW5nSWQ9bnVsbDtcbiAgbGV0IHN0b2NrUGxhblRhcmdldD1udWxsLHN0b2NrUGxhbkZvcm09e2Ftb3VudDonJyxkYXk6Jycsc3RhcnRNb250aDonJ30sc3RvY2tQbGFuU2F2aW5nPWZhbHNlLHN0b2NrUGxhbkNvbmZpcm1hdGlvblRhcmdldD1udWxsLHN0b2NrUGxhbkNvbmZpcm1hdGlvbj17YW1vdW50OicnLHByaWNlOicnfSxzdG9ja0RldGFpbD1udWxsLHN0b2NrRGV0YWlsU3RhdHVzPSdpZGxlJyxoaWdobGlnaHRlZFN0b2NrSWQ9bnVsbDtcbiAgbGV0IHN0b2NrRm9ybT17cXVhbnRpdHk6JycsdG90YWxJbnZlc3RlZDonJ307XG4gIGxldCBhY3Rpb25zPVtdLCBhY3Rpb25zU3RhdHVzPSdpZGxlJywgYWN0aW9uc0Vycm9yPScnLCBjb21wbGV0aW5nQWN0aW9uSWQ9bnVsbCwgaGlnaGxpZ2h0ZWRMb2FuSWQ9bnVsbCwgaGlnaGxpZ2h0ZWRGdW5kSWQ9bnVsbDtcbiAgbGV0IGNvbmZpcm1pbmdTaXA9bnVsbCwgc2lwQ29uZmlybUVycm9yPScnLCBzaXBDb25maXJtU2F2aW5nPWZhbHNlLCBzaXBDb25maXJtRm9ybT17YW1vdW50OicnLHRyYW5zYWN0aW9uRGF0ZTpuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwxMCksbmF2OicnfTtcbiAgbGV0IGZ1bmREZXRhaWw9bnVsbCwgZnVuZERldGFpbFN0YXR1cz0naWRsZScsIGZ1bmREZXRhaWxFcnJvcj0nJywgbHVtcFN1bUZ1bmQ9bnVsbCwgbHVtcFN1bVNhdmluZz1mYWxzZSwgbHVtcFN1bUVycm9yPScnLCBsdW1wU3VtRm9ybT17YW1vdW50OicnLHRyYW5zYWN0aW9uRGF0ZTonJyxuYXY6Jyd9O1xuICBsZXQgZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbj1udWxsLCBmdW5kVHJhbnNhY3Rpb25TYXZpbmc9ZmFsc2UsIGZ1bmRUcmFuc2FjdGlvbkVycm9yPScnLCBmdW5kVHJhbnNhY3Rpb25Gb3JtPXthbW91bnQ6JycsdHJhbnNhY3Rpb25EYXRlOicnLG5hdjonJ307XG4gIGNvbnN0IE1PTkVZX01PRFVMRVNfQ0FDSEVfS0VZPSdtb25leS1zdG9yaWVzLm1vbmV5LW1vZHVsZXMtY2FjaGUudjEnO1xuICBsZXQgZnVuZEZvcm09e2hhc1NpcDonWUVTJyxzaXBBbW91bnQ6JzI1MDAwJyxzaXBEYXRlOic1JyxzdGFydE1vbnRoOicyMDI2LTEwJyxoYXNIb2xkaW5nOidZRVMnLGN1cnJlbnRVbml0czonMTI4LjQ1NicsdG90YWxJbnZlc3RlZDonMTAwMDAnfTtcbiAgbGV0IGZ1bmRTaXBUYXJnZXQ9bnVsbCwgZnVuZFNpcEZvcm09e2Ftb3VudDonJyxkYXk6Jycsc3RhcnRNb250aDonJ30sIGZ1bmRTaXBTYXZpbmc9ZmFsc2U7XG4gICQ6IGRhdGE9Y2FsZW5kYXJTZWN0aW9uLmRhdGF8fHt9OyAkOiBjdXJyZW5jeT1kYXRhLmN1cnJlbmN5fHwnSU5SJzsgJDogY2FsZW5kYXI9YnVpbGRDYWxlbmRhcihzZWxlY3RlZE1vbnRoLGRhdGEuZGF5c3x8W10pO1xuICAkOiByZWNlbnREYXRhPXJlY2VudFNlY3Rpb24uZGF0YXx8e307ICQ6IHJlY2VudEl0ZW1zPShyZWNlbnREYXRhLml0ZW1zfHxyZWNlbnREYXRhLmV4cGVuc2VzfHxbXSkuc2xpY2UoMCw1KTtcbiAgJDogc3RvcnlEYXRhPXN0b3JpZXNTZWN0aW9uLmRhdGF8fHt9OyAkOiBzdG9yaWVzPXN0b3J5RGF0YS5zdG9yaWVzfHxzdG9yeURhdGEubW9uZXlTdG9yaWVzfHxzdG9yeURhdGEuc3RvcnlDYXJkc3x8W107XG4gICQ6IGZpbHRlcmVkU3Rvcmllcz1zdG9yeUZpbHRlcj09PSdBbGwnP3N0b3JpZXM6c3Rvcmllcy5maWx0ZXIoc3Rvcnk9PnN0b3J5U291cmNlKHN0b3J5KS50b0xvd2VyQ2FzZSgpPT09c3RvcnlGaWx0ZXIudG9Mb3dlckNhc2UoKSk7XG4gICQ6IGhvbWVTdG9yaWVzPXN0b3JpZXMuc2xpY2UoMCwzKTtcbiAgJDogaWYoaG9tZVN0b3J5SW5kZXg+PWhvbWVTdG9yaWVzLmxlbmd0aClob21lU3RvcnlJbmRleD0wO1xuICAkOiBpZihzdG9yaWVzUmFpbEluZGV4Pj1maWx0ZXJlZFN0b3JpZXMubGVuZ3RoKXN0b3JpZXNSYWlsSW5kZXg9MDtcbiAgJDogc2VsZWN0ZWQ9c2VsZWN0ZWREYXk9PW51bGw/bnVsbDpjYWxlbmRhci5kYXlzLmZpbmQoZGF5PT5kYXkuZGF5PT09c2VsZWN0ZWREYXkpOyAkOiBhY3RpdmVJdGVtcz1hY3Rpdml0eVRhYj09PSdyZWNlbnQnP3JlY2VudEl0ZW1zOmRheUl0ZW1zOyAkOiB2aXNpYmxlSXRlbXM9c2hvd0FsbD9hY3RpdmVJdGVtczphY3RpdmVJdGVtcy5zbGljZSgwLDUpO1xuICAkOiBlZGl0U3ViY2F0ZWdvcmllcz1lZGl0T3B0aW9ucy5jYXRlZ29yaWVzLmZpbmQob3B0aW9uPT5vcHRpb24ubmFtZT09PWVkaXRDYXRlZ29yeSk/LnN1YmNhdGVnb3JpZXN8fFtdO1xuICAkOiBhY3RpdmVMb2Fucz1sb2Fucy5maWx0ZXIobG9hbj0+bG9hbi5zdGF0dXM9PT0nQUNUSVZFJyk7ICQ6IGNsb3NlZExvYW5zPWxvYW5zLmZpbHRlcihsb2FuPT5sb2FuLnN0YXR1cz09PSdDTE9TRUQnKTsgJDogdG90YWxNb250aGx5RW1pPWFjdGl2ZUxvYW5zLnJlZHVjZSgodG90YWwsbG9hbik9PnRvdGFsK051bWJlcihsb2FuLm1vbnRobHlFbWlBbW91bnR8fDApLDApO1xuICAkOiBtdXR1YWxQb3J0Zm9saW89e2ludmVzdGVkOm11dHVhbEZ1bmRzLnJlZHVjZSgodG90YWwsZnVuZCk9PnRvdGFsK051bWJlcihmdW5kLmludmVzdGVkfHwwKSwwKSxjdXJyZW50Om11dHVhbEZ1bmRzLnNvbWUoZnVuZD0+ZnVuZC5jdXJyZW50VmFsdWUhPT1udWxsKT9tdXR1YWxGdW5kcy5yZWR1Y2UoKHRvdGFsLGZ1bmQpPT50b3RhbCtOdW1iZXIoZnVuZC5jdXJyZW50VmFsdWV8fDApLDApOm51bGwscG5sOm11dHVhbEZ1bmRzLnNvbWUoZnVuZD0+ZnVuZC5wcm9maXRPckxvc3MhPT1udWxsKT9tdXR1YWxGdW5kcy5yZWR1Y2UoKHRvdGFsLGZ1bmQpPT50b3RhbCtOdW1iZXIoZnVuZC5wcm9maXRPckxvc3N8fDApLDApOm51bGx9O1xuICAkOiBzdG9ja1BvcnRmb2xpbz17aW52ZXN0ZWQ6c3RvY2tzLnJlZHVjZSgodG90YWwsc3RvY2spPT50b3RhbCtOdW1iZXIoc3RvY2suaW52ZXN0ZWR8fDApLDApLGN1cnJlbnQ6c3RvY2tzLnNvbWUoc3RvY2s9PnN0b2NrLmN1cnJlbnRWYWx1ZSE9PW51bGwpP3N0b2Nrcy5yZWR1Y2UoKHRvdGFsLHN0b2NrKT0+dG90YWwrTnVtYmVyKHN0b2NrLmN1cnJlbnRWYWx1ZXx8MCksMCk6bnVsbCxwbmw6c3RvY2tzLnNvbWUoc3RvY2s9PnN0b2NrLnByb2ZpdE9yTG9zcyE9PW51bGwpP3N0b2Nrcy5yZWR1Y2UoKHRvdGFsLHN0b2NrKT0+dG90YWwrTnVtYmVyKHN0b2NrLnByb2ZpdE9yTG9zc3x8MCksMCk6bnVsbH07XG4gICQ6IHZpc2libGVBY3Rpb25zPWFjdGlvbnMubWFwKGFjdGlvbj0+KHthY3Rpb24scHJlc2VudGF0aW9uOmFjdGlvblByZXNlbnRhdGlvbihhY3Rpb24pfSkpLmZpbHRlcihpdGVtPT5pdGVtLnByZXNlbnRhdGlvbik7XG4gICQ6IGhpZ2hsaWdodGVkTG9hbkFjdGlvbj1hY3Rpb25zLmZpbmQoYWN0aW9uPT5TdHJpbmcoYWN0aW9uLnJlZmVyZW5jZUlkKT09PVN0cmluZyhoaWdobGlnaHRlZExvYW5JZCkmJmFjdGlvbi5hY3Rpb25UeXBlPT09J0xPQU5fQ0xPU1VSRV9DT05GSVJNQVRJT04nKTtcbiAgY29uc3QgbW9uZXk9dmFsdWU9Pm5ldyBJbnRsLk51bWJlckZvcm1hdCgnZW4tSU4nLHtzdHlsZTonY3VycmVuY3knLGN1cnJlbmN5LG1heGltdW1GcmFjdGlvbkRpZ2l0czowfSkuZm9ybWF0KE51bWJlcih2YWx1ZXx8MCkpO1xuICBjb25zdCBtb25leURlY2ltYWw9dmFsdWU9Pm5ldyBJbnRsLk51bWJlckZvcm1hdCgnZW4tSU4nLHtzdHlsZTonY3VycmVuY3knLGN1cnJlbmN5LG1pbmltdW1GcmFjdGlvbkRpZ2l0czoyLG1heGltdW1GcmFjdGlvbkRpZ2l0czoyfSkuZm9ybWF0KE51bWJlcih2YWx1ZXx8MCkpO1xuICBjb25zdCBjb21wYWN0TW9uZXk9dmFsdWU9Pm5ldyBJbnRsLk51bWJlckZvcm1hdCgnZW4tSU4nLHtzdHlsZTonY3VycmVuY3knLGN1cnJlbmN5LG5vdGF0aW9uOidjb21wYWN0JyxtYXhpbXVtRnJhY3Rpb25EaWdpdHM6Mn0pLmZvcm1hdChOdW1iZXIodmFsdWV8fDApKTtcbiAgY29uc3QgZnVuZFN1YnRpdGxlPW5hbWU9Pi9ncm93dGgvaS50ZXN0KG5hbWUpPydHcm93dGggwrcgRGlyZWN0IHBsYW4nOidWZXJpZmllZCBzY2hlbWUnOyBjb25zdCBmdW5kQWNjZW50PWlkPT5bJ2NvcmFsJywnZ29sZCcsJ3Zpb2xldCcsJ2JsdWUnXVtOdW1iZXIoaWR8fDApJTRdO1xuICBjb25zdCBtZXJjaGFudD1pdGVtPT5pdGVtLm1lcmNoYW50fHxpdGVtLm1lcmNoYW50TmFtZXx8aXRlbS5kZXNjcmlwdGlvbnx8aXRlbS5vcmlnaW5hbE1lc3NhZ2V8fCdFeHBlbnNlJzsgY29uc3QgY2F0ZWdvcnk9aXRlbT0+aXRlbS5jYXRlZ29yeT8ubmFtZXx8aXRlbS5jYXRlZ29yeXx8J1VuY2F0ZWdvcmlzZWQnOyBjb25zdCB0cmFuc2FjdGlvbkRhdGU9aXRlbT0+aXRlbS50cmFuc2FjdGlvbkRhdGV8fGl0ZW0udHJhbnNhY3Rpb25UaW1lfHxpdGVtLmRhdGU7XG4gIGNvbnN0IGRhdGVMYWJlbD12YWx1ZT0+dmFsdWU/bmV3IEludGwuRGF0ZVRpbWVGb3JtYXQodW5kZWZpbmVkLHtkYXk6J251bWVyaWMnLG1vbnRoOidzaG9ydCd9KS5mb3JtYXQobmV3IERhdGUodmFsdWUpKTonJztcbiAgY29uc3QgbW9udGhMYWJlbD12YWx1ZT0+e2NvbnN0W3ksbV09dmFsdWUuc3BsaXQoJy0nKS5tYXAoTnVtYmVyKTtyZXR1cm4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQodW5kZWZpbmVkLHttb250aDonbG9uZycseWVhcjonbnVtZXJpYyd9KS5mb3JtYXQobmV3IERhdGUoeSxtLTEpKTt9O1xuICBjb25zdCBncmVldGluZz0oKT0+bmV3IERhdGUoKS5nZXRIb3VycygpPDEyPydHb29kIG1vcm5pbmcnOm5ldyBEYXRlKCkuZ2V0SG91cnMoKTwxNz8nR29vZCBhZnRlcm5vb24nOidHb29kIGV2ZW5pbmcnOyBjb25zdCBpc29EYXRlPWRheT0+YCR7c2VsZWN0ZWRNb250aH0tJHtTdHJpbmcoZGF5KS5wYWRTdGFydCgyLCcwJyl9YDtcbiAgY29uc3QgaGFzRGVjaz1zdG9yeT0+QXJyYXkuaXNBcnJheShzdG9yeS5jYXJkcykmJnN0b3J5LmNhcmRzLmxlbmd0aD4wOyBjb25zdCBzdG9yeU5hbWU9c3Rvcnk9PlN0cmluZyhzdG9yeS5zdG9yeVR5cGV8fHN0b3J5LnR5cGV8fCdNb25leSBzdG9yeScpLnJlcGxhY2VBbGwoJ18nLCcgJyk7IGNvbnN0IHN0b3J5VG9uZT1zdG9yeT0+c3RvcnkuY2FyZEZhY2U/LnRoZW1lfHwnY2FsbSc7IGNvbnN0IHN0b3J5Q2FyZEZhY2U9c3Rvcnk9PnN0b3J5LmNhcmRGYWNlfHx7aGVhZGluZzonTW9uZXkgc3RvcnknLGRpc3BsYXlWYWx1ZTonVmlldycsdGhlbWU6J2NhbG0nfTsgY29uc3Qgc3RvcnlTb3VyY2U9c3Rvcnk9PnN0b3J5LnNvdXJjZXx8c3RvcnkuZG9tYWlufHwoc3Rvcnkuc3RvcnlUeXBlPT09J01PTlRITFlfQ09NTUlUTUVOVCc/J1BsYW5uaW5nJzonU3BlbmRpbmcnKTtcbiAgY29uc3QgaXNDb21taXRtZW50PXN0b3J5PT5zdG9yeT8uc3RvcnlUeXBlPT09J01PTlRITFlfQ09NTUlUTUVOVCc7IGNvbnN0IHN0b3J5SWNvbj1zdG9yeT0+aXNDb21taXRtZW50KHN0b3J5KT8n8J+OrCc6Jyc7IGNvbnN0IHN0b3J5SGVhZGluZz1zdG9yeT0+c3RvcnlDYXJkRmFjZShzdG9yeSkuaGVhZGluZztcbiAgZnVuY3Rpb24gc2V0Q29tbWl0bWVudFN0eWxlKHN0eWxlKXtjb21taXRtZW50U3R5bGU9c3R5bGU7dHJ5e2xvY2FsU3RvcmFnZS5zZXRJdGVtKCdtb25leS1zdG9yaWVzLmNvbW1pdG1lbnQtc3R5bGUnLHN0eWxlKTt9Y2F0Y2h7fX1cbiAgJDogY29ubmVjdGlvbkxhYmVsPWNvbm5lY3Rpb25TdGF0dXM9PT0nb25saW5lJz8nT25saW5lJzpjb25uZWN0aW9uU3RhdHVzPT09J29mZmxpbmUnPydPZmZsaW5lJzonQ2hlY2tpbmcnO1xuICAkOiBldmlkZW5jZUl0ZW1zPShjb21taXRtZW50cyxldmlkZW5jZUZvcihvcGVuZWRTdG9yeSxzdG9yeVNsaWRlKSk7XG4gIGZ1bmN0aW9uIGxvY2FsSW5wdXREYXRlKHZhbHVlKXtpZighdmFsdWUpcmV0dXJuICcnO2NvbnN0IHRleHQ9U3RyaW5nKHZhbHVlKTtpZigvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC8udGVzdCh0ZXh0KSlyZXR1cm4gdGV4dDtjb25zdCBkYXRlPW5ldyBEYXRlKHRleHQpO3JldHVybiBOdW1iZXIuaXNOYU4oZGF0ZS5nZXRUaW1lKCkpP3RleHQuc2xpY2UoMCwxMCk6YCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyhkYXRlLmdldE1vbnRoKCkrMSkucGFkU3RhcnQoMiwnMCcpfS0ke1N0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwnMCcpfWA7fVxuICBmdW5jdGlvbiBldmlkZW5jZUZvcihzdG9yeSxzbGlkZT0wKXtjb25zdCBjYXJkPXN0b3J5Py5jYXJkcz8uc2xpY2UoKS5zb3J0KChhLGIpPT4oYS5zZXF1ZW5jZXx8MCktKGIuc2VxdWVuY2V8fDApKVtzbGlkZV07Y29uc3QgZXZpZGVuY2U9c3Rvcnk/LmV2aWRlbmNlPy5ieUNhcmQ/LltjYXJkPy5jYXJkSWRdfHxzdG9yeT8uZXZpZGVuY2U7Y29uc3QgcmF3PUFycmF5LmlzQXJyYXkoZXZpZGVuY2UpP2V2aWRlbmNlOmV2aWRlbmNlPy50cmFuc2FjdGlvbnN8fGV2aWRlbmNlPy5pdGVtc3x8c3Rvcnk/LnRyYW5zYWN0aW9uc3x8W107cmV0dXJuIHJhdy5tYXAoaXRlbT0+e2NvbnN0W2lkVHlwZSxpZF09U3RyaW5nKGl0ZW0udHJhbnNhY3Rpb25JZHx8aXRlbS5pZHx8JycpLnNwbGl0KCc6Jyk7cmV0dXJue3NvdXJjZVR5cGU6aWRUeXBlLHNvdXJjZUlkOmlkLG1lcmNoYW50Oml0ZW0ubWVyY2hhbnRMYWJlbHx8aXRlbS5tZXJjaGFudHx8aXRlbS5tZXJjaGFudE5hbWV8fGl0ZW0uZGVzY3JpcHRpb258fCdFeHBlbnNlJyxjYXRlZ29yeTppdGVtLmNhdGVnb3J5TGFiZWx8fGl0ZW0uY2F0ZWdvcnk/Lm5hbWV8fGl0ZW0uY2F0ZWdvcnl8fCdVbmNhdGVnb3Jpc2VkJyxkZXRhaWw6aXRlbS5zdWJjYXRlZ29yeUxhYmVsfHxpdGVtLmRldGFpbHx8JycsZGF0ZTppdGVtLmRhdGVMYWJlbHx8ZGF0ZUxhYmVsKGl0ZW0udHJhbnNhY3Rpb25EYXRlfHxpdGVtLnRyYW5zYWN0aW9uVGltZXx8aXRlbS5kYXRlKSxhbW91bnQ6aXRlbS5hbW91bnQ/LmRpc3BsYXlWYWx1ZXx8aXRlbS5kaXNwbGF5QW1vdW50fHxtb25leShpdGVtLmFtb3VudCl9fSk7fVxuICBmdW5jdGlvbiBsb2FuU2NoZWR1bGUobG9hbil7Y29uc3QgZmlyc3Q9bmV3IERhdGUoYCR7bG9hbi5maXJzdEVtaUR1ZURhdGV9VDEyOjAwOjAwYCk7aWYoTnVtYmVyLmlzTmFOKGZpcnN0LmdldFRpbWUoKSkpcmV0dXJuIG51bGw7Y29uc3QgdGVudXJlPU51bWJlcihsb2FuLnRvdGFsVGVudXJlTW9udGhzKXx8MCxkdWU9TnVtYmVyLmlzSW50ZWdlcihsb2FuLmNvbXBsZXRlZEVtaUNvdW50KT9sb2FuLmNvbXBsZXRlZEVtaUNvdW50OjAscmVtYWluaW5nPU51bWJlci5pc0ludGVnZXIobG9hbi5yZW1haW5pbmdFbWlDb3VudCk/bG9hbi5yZW1haW5pbmdFbWlDb3VudDpNYXRoLm1heCgwLHRlbnVyZS1kdWUpLGZpbmFsRHVlPW5ldyBEYXRlKGZpcnN0LmdldEZ1bGxZZWFyKCksZmlyc3QuZ2V0TW9udGgoKStNYXRoLm1heCgwLHRlbnVyZS0xKSxmaXJzdC5nZXREYXRlKCkpO3JldHVybntkdWUscmVtYWluaW5nLHRlbnVyZSxwZXJjZW50OnRlbnVyZT9NYXRoLnJvdW5kKGR1ZS90ZW51cmUqMTAwKTowLGVuZExhYmVsOm5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHVuZGVmaW5lZCx7bW9udGg6J3Nob3J0Jyx5ZWFyOidudW1lcmljJ30pLmZvcm1hdChmaW5hbER1ZSl9O31cbiAgZnVuY3Rpb24gYWN0aW9uUHJlc2VudGF0aW9uKGFjdGlvbil7aWYoYWN0aW9uLmFjdGlvblR5cGU9PT0nTE9BTl9DTE9TVVJFX0NPTkZJUk1BVElPTicpe2NvbnN0IHNjaGVkdWxlZD1hY3Rpb24uc2NoZWR1bGVkQ29tcGxldGlvbkRhdGU/bmV3IEludGwuRGF0ZVRpbWVGb3JtYXQodW5kZWZpbmVkLHtkYXk6J251bWVyaWMnLG1vbnRoOidzaG9ydCcseWVhcjonbnVtZXJpYyd9KS5mb3JtYXQobmV3IERhdGUoYCR7YWN0aW9uLnNjaGVkdWxlZENvbXBsZXRpb25EYXRlfVQxMjowMDowMGApKTonJztjb25zdCBkZXNjcmlwdGlvbj0oYWN0aW9uLmRlc2NyaXB0aW9ufHxgRU1JIHdhcyBzY2hlZHVsZWQgdG8gZmluaXNoIG9uICR7c2NoZWR1bGVkfS5gKS5yZXBsYWNlKGFjdGlvbi5zY2hlZHVsZWRDb21wbGV0aW9uRGF0ZXx8Jycsc2NoZWR1bGVkKS5yZXBsYWNlKC9cXHMqTWFyayBpdCBjbG9zZWQgaWYgdGhlIGZpbmFsIEVNSSB3YXMgcGFpZFxcLj9cXHMqJC9pLCcnKTtyZXR1cm57dGl0bGU6J0xvYW4gY2xvc3VyZSBjb25maXJtYXRpb24nLGRlc2NyaXB0aW9uLGN0YTonUmV2aWV3IGxvYW4nfTt9cmV0dXJuIG51bGw7fVxuICBjb25zdCBtb25leU1vZHVsZXNDYWNoZUtleT0oKT0+YCR7TU9ORVlfTU9EVUxFU19DQUNIRV9LRVl9LiR7ZGVtb01vZGU/J2RlbW8nOidyZWFsJ31gO1xuICBmdW5jdGlvbiByZWFkTW9uZXlNb2R1bGVzQ2FjaGUoKXt0cnl7Y29uc3QgY2FjaGVkPUpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0obW9uZXlNb2R1bGVzQ2FjaGVLZXkoKSl8fCdudWxsJyk7aWYoIWNhY2hlZClyZXR1cm4gZmFsc2U7aWYoQXJyYXkuaXNBcnJheShjYWNoZWQubG9hbnMpKXtsb2Fucz1jYWNoZWQubG9hbnM7bG9hblN0YXR1cz0ncmVhZHknO31pZihBcnJheS5pc0FycmF5KGNhY2hlZC5tdXR1YWxGdW5kcykpe211dHVhbEZ1bmRzPWNhY2hlZC5tdXR1YWxGdW5kczttdXR1YWxGdW5kU3RhdHVzPSdyZWFkeSc7fWlmKEFycmF5LmlzQXJyYXkoY2FjaGVkLnN0b2Nrcykpe3N0b2Nrcz1jYWNoZWQuc3RvY2tzO3N0b2NrU3RhdHVzPSdyZWFkeSc7fXJldHVybiB0cnVlO31jYXRjaHtyZXR1cm4gZmFsc2U7fX1cbiAgZnVuY3Rpb24gc2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCl7dHJ5e2xvY2FsU3RvcmFnZS5zZXRJdGVtKG1vbmV5TW9kdWxlc0NhY2hlS2V5KCksSlNPTi5zdHJpbmdpZnkoe3VwZGF0ZWRBdDpuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksbG9hbnMsbXV0dWFsRnVuZHMsc3RvY2tzfSkpO31jYXRjaHsvKiBUaGUgbGl2ZSBtb2R1bGVzIHN0aWxsIHdvcmsgaWYgc3RvcmFnZSBpcyB1bmF2YWlsYWJsZS4gKi99fVxuICBhc3luYyBmdW5jdGlvbiBsb2FkTG9hbnMoKXtsb2FuU3RhdHVzPWxvYW5zLmxlbmd0aD8ncmVmcmVzaGluZyc6J2xvYWRpbmcnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0TG9hbnMoKTtsb2Fucz1yZXN1bHQubG9hbnN8fFtdO2xvYW5TdGF0dXM9J3JlYWR5JztzYXZlTW9uZXlNb2R1bGVzQ2FjaGUoKTt9Y2F0Y2goY2F1c2Upe2lmKGxvYW5zLmxlbmd0aCl7bG9hblN0YXR1cz0ncmVhZHknO3JldHVybjt9bG9hblN0YXR1cz0nZXJyb3InO2xvYW5FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIGxvYW5zLic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZENvbW1pdG1lbnRzKCl7Y29tbWl0bWVudFN0YXR1cz0nbG9hZGluZyc7Y29tbWl0bWVudEVycm9yPScnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0UmVjdXJyaW5nQ29tbWl0bWVudHMoKTtjb21taXRtZW50cz1yZXN1bHQuaXRlbXN8fFtdO2NvbW1pdG1lbnRTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2NvbW1pdG1lbnRTdGF0dXM9J2Vycm9yJztjb21taXRtZW50RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBjb21taXRtZW50cy4nO319XG4gIGZ1bmN0aW9uIG9wZW5Db21taXRtZW50Rm9ybShpdGVtPW51bGwpe2NvbnN0IGVkaXRpbmdFeGlzdGluZz1Cb29sZWFuKGl0ZW0mJidwbGFubmluZ0Ftb3VudCcgaW4gaXRlbSk7Y29tbWl0bWVudEVycm9yPScnO2NvbW1pdG1lbnRFZGl0aW5nSWQ9ZWRpdGluZ0V4aXN0aW5nP2l0ZW0uaWQ6bnVsbDtjb21taXRtZW50Rm9ybT1pdGVtP3tsYWJlbDplZGl0aW5nRXhpc3Rpbmc/aXRlbS5sYWJlbDptZXJjaGFudChpdGVtKSxwbGFubmluZ0Ftb3VudDpTdHJpbmcoZWRpdGluZ0V4aXN0aW5nP2l0ZW0ucGxhbm5pbmdBbW91bnQ6aXRlbS5hbW91bnR8fCcnKSxkdWVEYXk6U3RyaW5nKGVkaXRpbmdFeGlzdGluZz9pdGVtLmR1ZURheT8/Jyc6bmV3IERhdGUodHJhbnNhY3Rpb25EYXRlKGl0ZW0pKS5nZXREYXRlKCl8fCcnKSxhbW91bnRNb2RlOmVkaXRpbmdFeGlzdGluZz9pdGVtLmFtb3VudE1vZGV8fCdGSVhFRCc6J0ZJWEVEJywuLi4oZWRpdGluZ0V4aXN0aW5nP3t9Ontzb3VyY2VUcmFuc2FjdGlvbklkOml0ZW0uaWR9KX06e2xhYmVsOicnLHBsYW5uaW5nQW1vdW50OicnLGR1ZURheTonJyxhbW91bnRNb2RlOidGSVhFRCd9O3Nob3dDb21taXRtZW50Rm9ybT10cnVlO31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZUNvbW1pdG1lbnQoKXtjb25zdCBwbGFubmluZ0Ftb3VudD1OdW1iZXIoY29tbWl0bWVudEZvcm0ucGxhbm5pbmdBbW91bnQpLGR1ZURheT1jb21taXRtZW50Rm9ybS5kdWVEYXk/TnVtYmVyKGNvbW1pdG1lbnRGb3JtLmR1ZURheSk6bnVsbDtpZighY29tbWl0bWVudEZvcm0ubGFiZWwudHJpbSgpfHwhKHBsYW5uaW5nQW1vdW50PjApfHxkdWVEYXkhPT1udWxsJiYoZHVlRGF5PDF8fGR1ZURheT4yOCkpe2NvbW1pdG1lbnRFcnJvcj0nQWRkIGEgbmFtZSwgYSBwb3NpdGl2ZSBwbGFubmluZyBhbW91bnQsIGFuZCBhbiBvcHRpb25hbCBkdWUgZGF5IGZyb20gMSB0byAyOC4nO3JldHVybjt9Y29tbWl0bWVudFNhdmluZz10cnVlO3RyeXtjb25zdCBwYXlsb2FkPXsuLi5jb21taXRtZW50Rm9ybSxsYWJlbDpjb21taXRtZW50Rm9ybS5sYWJlbC50cmltKCkscGxhbm5pbmdBbW91bnQsZHVlRGF5LGVmZmVjdGl2ZU1vbnRoOnNlbGVjdGVkTW9udGh9O2lmKGNvbW1pdG1lbnRFZGl0aW5nSWQhPT1udWxsKWRlbGV0ZSBwYXlsb2FkLnNvdXJjZVRyYW5zYWN0aW9uSWQ7YXdhaXQgKGNvbW1pdG1lbnRFZGl0aW5nSWQ9PT1udWxsP2NyZWF0ZVJlY3VycmluZ0NvbW1pdG1lbnQocGF5bG9hZCk6dXBkYXRlUmVjdXJyaW5nQ29tbWl0bWVudChjb21taXRtZW50RWRpdGluZ0lkLHBheWxvYWQpKTtzaG93Q29tbWl0bWVudEZvcm09ZmFsc2U7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRDb21taXRtZW50cygpLHJlZnJlc2hTdG9yaWVzKCldKTt9Y2F0Y2goY2F1c2Upe2NvbW1pdG1lbnRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzYXZlIHRoaXMgY29tbWl0bWVudC4nO31maW5hbGx5e2NvbW1pdG1lbnRTYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlQ29tbWl0bWVudChjb21taXRtZW50KXtpZihjb21taXRtZW50RGVsZXRpbmdJZCE9PW51bGwpcmV0dXJuO2NvbW1pdG1lbnREZWxldGluZ0lkPWNvbW1pdG1lbnQuaWQ7Y29tbWl0bWVudEVycm9yPScnO3RyeXthd2FpdCBkZWxldGVSZWN1cnJpbmdDb21taXRtZW50KGNvbW1pdG1lbnQuaWQpO2NvbW1pdG1lbnRzPWNvbW1pdG1lbnRzLmZpbHRlcihpdGVtPT5pdGVtLmlkIT09Y29tbWl0bWVudC5pZCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe2NvbW1pdG1lbnRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBkZWxldGUgdGhpcyBjb21taXRtZW50Lic7fWZpbmFsbHl7Y29tbWl0bWVudERlbGV0aW5nSWQ9bnVsbDt9fVxuICBhc3luYyBmdW5jdGlvbiBsb2FkTXV0dWFsRnVuZHMoKXttdXR1YWxGdW5kU3RhdHVzPW11dHVhbEZ1bmRzLmxlbmd0aD8ncmVmcmVzaGluZyc6J2xvYWRpbmcnO211dHVhbEZ1bmRFcnJvcj0nJzt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldE11dHVhbEZ1bmRzKCk7bXV0dWFsRnVuZHM9cmVzdWx0Lm11dHVhbEZ1bmRzfHxbXTttdXR1YWxGdW5kU3RhdHVzPSdyZWFkeSc7c2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCk7fWNhdGNoKGNhdXNlKXtpZihtdXR1YWxGdW5kcy5sZW5ndGgpe211dHVhbEZ1bmRTdGF0dXM9J3JlYWR5JztyZXR1cm47fW11dHVhbEZ1bmRTdGF0dXM9J2Vycm9yJzttdXR1YWxGdW5kRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBtdXR1YWwgZnVuZHMuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBsb2FkU3RvY2tzKCl7c3RvY2tTdGF0dXM9c3RvY2tzLmxlbmd0aD8ncmVmcmVzaGluZyc6J2xvYWRpbmcnO3N0b2NrRXJyb3I9Jyc7dHJ5e2NvbnN0IHJlc3VsdD1hd2FpdCBnZXRTdG9ja3MoKTtzdG9ja3M9cmVzdWx0LnN0b2Nrc3x8W107c3RvY2tTdGF0dXM9J3JlYWR5JztzYXZlTW9uZXlNb2R1bGVzQ2FjaGUoKTt9Y2F0Y2goY2F1c2Upe2lmKHN0b2Nrcy5sZW5ndGgpe3N0b2NrU3RhdHVzPSdyZWFkeSc7cmV0dXJuO31zdG9ja1N0YXR1cz0nZXJyb3InO3N0b2NrRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBzdG9ja3MuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBsb2FkQWN0aW9ucygpe2FjdGlvbnNTdGF0dXM9YWN0aW9ucy5sZW5ndGg/J3JlZnJlc2hpbmcnOidsb2FkaW5nJzthY3Rpb25zRXJyb3I9Jyc7dHJ5e2NvbnN0IHJlc3VsdD1hd2FpdCBnZXRBY3Rpb25zKCk7YWN0aW9ucz1yZXN1bHQuYWN0aW9uc3x8W107YWN0aW9uc1N0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7YWN0aW9uc1N0YXR1cz0nZXJyb3InO2FjdGlvbnNFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIGFjdGlvbnMuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBjb21wbGV0ZU9wZW5BY3Rpb24oYWN0aW9uKXtpZihjb21wbGV0aW5nQWN0aW9uSWQhPT1udWxsKXJldHVybjtjb21wbGV0aW5nQWN0aW9uSWQ9YWN0aW9uLmlkO2FjdGlvbnNFcnJvcj0nJzt0cnl7YXdhaXQgY29tcGxldGVBY3Rpb24oYWN0aW9uLmlkKTthY3Rpb25zPWFjdGlvbnMuZmlsdGVyKGl0ZW09Pml0ZW0uaWQhPT1hY3Rpb24uaWQpO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkTG9hbnMoKSxsb2FkQWN0aW9ucygpXSk7fWNhdGNoKGNhdXNlKXthY3Rpb25zRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgY29tcGxldGUgdGhpcyBhY3Rpb24uJzt9ZmluYWxseXtjb21wbGV0aW5nQWN0aW9uSWQ9bnVsbDt9fVxuICBmdW5jdGlvbiBtb25leVJldmlld1RhcmdldCh0eXBlLGlkKXtpZih0eXBlPT09J2xvYW4nKXtjb25zdCBsb2FuPWxvYW5zLmZpbmQoaXRlbT0+U3RyaW5nKGl0ZW0uaWQpPT09U3RyaW5nKGlkKSk7cmV0dXJuIGxvYW4mJlsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10ZXN0aWQ9XCJsb2Fucy1zZWN0aW9uXCJdIC5sb2FuLXJvdycpXS5maW5kKHJvdz0+cm93LnF1ZXJ5U2VsZWN0b3IoJy5sb2FuLW5hbWUnKT8udGV4dENvbnRlbnQudHJpbSgpLnN0YXJ0c1dpdGgobG9hbi5sb2FuTmFtZSkpO31pZih0eXBlPT09J2NvbW1pdG1lbnQnKXJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBbZGF0YS10ZXN0aWQ9XCJtb250aGx5LWNvbW1pdG1lbnQtJHtpZH1cIl1gKTtpZih0eXBlPT09J3N0b2NrJylyZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgW2RhdGEtdGVzdGlkPVwic3RvY2stY2FyZC0ke2lkfVwiXWApO2NvbnN0IGZ1bmQ9ZnVuZFN1bW1hcnkoaWQpO3JldHVybiBmdW5kJiZbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLm11dHVhbC1mdW5kcy1tb2R1bGU6bm90KC5zdG9ja3MtbW9kdWxlKSAuZnVuZC1jYXJkJyldLmZpbmQoY2FyZD0+Y2FyZC5nZXRBdHRyaWJ1dGUoJ2FyaWEtbGFiZWwnKT09PWBPcGVuICR7ZnVuZC5zY2hlbWVOYW1lfSBkZXRhaWxzYCk7fVxuICBhc3luYyBmdW5jdGlvbiBmb2N1c01vbmV5VGFyZ2V0KHR5cGUsaWQpe2F3YWl0IHRpY2soKTthd2FpdCBuZXcgUHJvbWlzZShyZXNvbHZlPT5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUocmVzb2x2ZSkpO2NvbnN0IHRhcmdldD1tb25leVJldmlld1RhcmdldCh0eXBlLGlkKTtpZighdGFyZ2V0KXJldHVybjt0YXJnZXQudGFiSW5kZXg9LTE7dGFyZ2V0LnNjcm9sbEludG9WaWV3KHtiZWhhdmlvcjonc21vb3RoJyxibG9jazonY2VudGVyJ30pO3RhcmdldC5mb2N1cyh7cHJldmVudFNjcm9sbDp0cnVlfSk7fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuTG9hbkR1ZUFjdGlvbihhY3Rpb24pe2hpZ2hsaWdodGVkTG9hbklkPWFjdGlvbi5yZWZlcmVuY2VJZDtzaG93TW9uZXk9dHJ1ZTthd2FpdCBQcm9taXNlLmFsbChbbG9hZExvYW5zKCksbG9hZEFjdGlvbnMoKV0pO2F3YWl0IGZvY3VzTW9uZXlUYXJnZXQoJ2xvYW4nLGFjdGlvbi5yZWZlcmVuY2VJZCk7fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuQ29tbWl0bWVudFNvdXJjZXMoKXtzaG93U3RvcnlFdmlkZW5jZT10cnVlO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkTXV0dWFsRnVuZHMoKSxsb2FkQ29tbWl0bWVudHMoKV0pO31cbiAgYXN5bmMgZnVuY3Rpb24gb3BlbkluY2x1ZGVkTG9hbihldmVudCl7Y29uc3QgbG9hbkl0ZW1zPWV2aWRlbmNlSXRlbXMuZmlsdGVyKGl0ZW09Pi9sb2FuL2kudGVzdChpdGVtLmNhdGVnb3J5KSk7Y29uc3QgYnV0dG9ucz1bLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtdGVzdGlkPVwiaW5jbHVkZWQtbG9hbi1jb21taXRtZW50XCJdJyldO2NvbnN0IGl0ZW09bG9hbkl0ZW1zW2J1dHRvbnMuaW5kZXhPZihldmVudC5jdXJyZW50VGFyZ2V0KV07aWYoIWl0ZW0pcmV0dXJuO3Nob3dTdG9yeUV2aWRlbmNlPWZhbHNlO29wZW5lZFN0b3J5PW51bGw7YXdhaXQgb3Blbk1vbmV5KCk7YXdhaXQgZm9jdXNNb25leVRhcmdldCgnbG9hbicsaXRlbS5zb3VyY2VJZCk7fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuSW5jbHVkZWRNdXR1YWxGdW5kKGl0ZW0pe2hpZ2hsaWdodGVkRnVuZElkPWl0ZW0uc291cmNlSWQ7c2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2U7b3BlbmVkU3Rvcnk9bnVsbDthd2FpdCBvcGVuTW9uZXkoKTthd2FpdCBmb2N1c01vbmV5VGFyZ2V0KCdmdW5kJyxpdGVtLnNvdXJjZUlkKTt9XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5JbmNsdWRlZFN0b2NrKGl0ZW0pe2hpZ2hsaWdodGVkU3RvY2tJZD1pdGVtLnNvdXJjZUlkO3Nob3dTdG9yeUV2aWRlbmNlPWZhbHNlO29wZW5lZFN0b3J5PW51bGw7YXdhaXQgb3Blbk1vbmV5KCk7YXdhaXQgZm9jdXNNb25leVRhcmdldCgnc3RvY2snLGl0ZW0uc291cmNlSWQpO31cbiAgYXN5bmMgZnVuY3Rpb24gb3BlbkluY2x1ZGVkQ29tbWl0bWVudChpdGVtKXtzaG93U3RvcnlFdmlkZW5jZT1mYWxzZTtvcGVuZWRTdG9yeT1udWxsO2F3YWl0IG9wZW5Nb25leSgpO2F3YWl0IGZvY3VzTW9uZXlUYXJnZXQoJ2NvbW1pdG1lbnQnLGl0ZW0uc291cmNlSWQpO31cbiAgY29uc3QgcmVjdXJyaW5nT2NjdXJyZW5jZT1pdGVtPT57Y29uc3QgaWQ9dHlwZW9mIGl0ZW09PT0nb2JqZWN0Jz9pdGVtLnNvdXJjZUlkOml0ZW07Y29uc3QgbWF0Y2g9Y29tbWl0bWVudHMuZmluZCh2YWx1ZT0+U3RyaW5nKHZhbHVlLmlkKT09PVN0cmluZyhpZCkpfHxjb21taXRtZW50cy5maW5kKHZhbHVlPT52YWx1ZS5sYWJlbD09PWl0ZW0/Lm1lcmNoYW50KTtyZXR1cm4gKG1hdGNofHxjb21taXRtZW50cy5sZW5ndGg9PT0xJiZjb21taXRtZW50c1swXSk/LmN1cnJlbnRPY2N1cnJlbmNlO307XG4gIGFzeW5jIGZ1bmN0aW9uIG1hcmtDb21taXRtZW50RG9uZShjb21taXRtZW50KXtpZihjb21wbGV0aW5nQ29tbWl0bWVudElkIT09bnVsbClyZXR1cm47Y29uc3Qgb2NjdXJyZW5jZT1jb21taXRtZW50LmN1cnJlbnRPY2N1cnJlbmNlO2lmKCFvY2N1cnJlbmNlPy5tb250aClyZXR1cm47Y29tcGxldGluZ0NvbW1pdG1lbnRJZD1jb21taXRtZW50LmlkO2NvbW1pdG1lbnRFcnJvcj0nJzt0cnl7YXdhaXQgY29tcGxldGVSZWN1cnJpbmdDb21taXRtZW50KGNvbW1pdG1lbnQuaWQsb2NjdXJyZW5jZS5tb250aCk7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRDb21taXRtZW50cygpLHJlZnJlc2hTdG9yaWVzKCldKTt9Y2F0Y2goY2F1c2Upe2NvbW1pdG1lbnRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBtYXJrIHRoaXMgY29tbWl0bWVudCBkb25lLic7fWZpbmFsbHl7Y29tcGxldGluZ0NvbW1pdG1lbnRJZD1udWxsO319XG4gIGZ1bmN0aW9uIHNpcElzRHVlKGl0ZW0pe3JldHVybiBtdXR1YWxGdW5kcy5maW5kKGZ1bmQ9PlN0cmluZyhmdW5kLmlkKT09PVN0cmluZyhpdGVtLnNvdXJjZUlkKSk/LmN1cnJlbnRTaXA/LnN0YXR1cz09PSdEVUUnO31cbiAgZnVuY3Rpb24gc2lwSXNDb25maXJtZWQoaXRlbSl7cmV0dXJuIG11dHVhbEZ1bmRzLmZpbmQoZnVuZD0+U3RyaW5nKGZ1bmQuaWQpPT09U3RyaW5nKGl0ZW0uc291cmNlSWQpKT8uY3VycmVudFNpcD8uc3RhdHVzPT09J0NPTkZJUk1FRCc7fVxuICBmdW5jdGlvbiBjdXJyZW50Q29tbWl0bWVudElzRHVlKCl7Y29uc3QgY2FyZD1vcGVuZWRTdG9yeT8uY2FyZHM/LnNsaWNlKCkuc29ydCgoYSxiKT0+KGEuc2VxdWVuY2V8fDApLShiLnNlcXVlbmNlfHwwKSlbc3RvcnlTbGlkZV07cmV0dXJuIGNhcmQ/LmNvbXBvbmVudHM/LnNvbWUoY29tcG9uZW50PT5jb21wb25lbnQubGFiZWw9PT0nVGhpcyBtb250aCcmJmNvbXBvbmVudC5kaXNwbGF5VmFsdWU/LnN0YXJ0c1dpdGgoJ0R1ZScpKTt9XG4gIGNvbnN0IGluY29tZVJhbmdlTGFiZWw9dmFsdWU9Pih7VU5ERVJfMjUwMDA6J1VuZGVyIOKCuTI1aycsRlJPTV8yNTAwMF9UT181MDAwMDon4oK5MjVr4oCT4oK5NTBrJyxGUk9NXzUwMDAwX1RPXzEwMDAwMDon4oK5NTBr4oCT4oK5MUwnLEZST01fMTAwMDAwX1RPXzIwMDAwMDon4oK5MUzigJPigrkyTCcsT1ZFUl8yMDAwMDA6J092ZXIg4oK5MkwnfSlbdmFsdWVdfHwnTm90IHNoYXJlZCc7XG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRJbmNvbWVPdXRsb29rKCl7aW5jb21lU3RhdHVzPSdsb2FkaW5nJztpbmNvbWVFcnJvcj0nJzt0cnl7aW5jb21lT3V0bG9vaz1hd2FpdCBnZXRJbmNvbWVPdXRsb29rKCk7aW5jb21lU3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtpbmNvbWVTdGF0dXM9J2Vycm9yJztpbmNvbWVFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIHlvdXIgaW5jb21lIG91dGxvb2suJzt9fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuTW9uZXkoKXtzaG93TW9uZXk9dHJ1ZTtyZWFkTW9uZXlNb2R1bGVzQ2FjaGUoKTthd2FpdCBQcm9taXNlLmFsbChbbG9hZExvYW5zKCksbG9hZE11dHVhbEZ1bmRzKCksbG9hZFN0b2NrcygpLGxvYWRJbmNvbWVPdXRsb29rKCksbG9hZENvbW1pdG1lbnRzKCksbG9hZENyZWRpdENhcmRzKCksbG9hZEV4cGVuc2VPcHRpb25zKCldKTt9XG4gIGZ1bmN0aW9uIGNsb3NlTW9uZXkoKXtzaG93TW9uZXk9ZmFsc2U7aGlnaGxpZ2h0ZWRMb2FuSWQ9bnVsbDtoaWdobGlnaHRlZEZ1bmRJZD1udWxsO31cbiAgY29uc3QgZnVuZFN1bW1hcnk9aWQ9Pm11dHVhbEZ1bmRzLmZpbmQoZnVuZD0+U3RyaW5nKGZ1bmQuaWQpPT09U3RyaW5nKGlkKSk7XG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRDcmVkaXRDYXJkcygpe2NyZWRpdENhcmRTdGF0dXM9J2xvYWRpbmcnO2NyZWRpdENhcmRFcnJvcj0nJzt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldENyZWRpdENhcmRzKCk7Y3JlZGl0Q2FyZHM9cmVzdWx0LmNhcmRzfHxbXTtjcmVkaXRDYXJkU3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtjcmVkaXRDYXJkU3RhdHVzPSdlcnJvcic7Y3JlZGl0Q2FyZEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgY3JlZGl0IGNhcmRzLic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZEV4cGVuc2VPcHRpb25zKCl7aWYob3B0aW9uc1N0YXR1cz09PSdsb2FkaW5nJylyZXR1cm47dHJ5e2NvbnN0IHJlc3VsdD1hd2FpdCBnZXRFeHBlbnNlT3B0aW9ucygpO2VkaXRPcHRpb25zPXtjYXRlZ29yaWVzOnJlc3VsdC5jYXRlZ29yaWVzfHxbXSxtZXJjaGFudHM6cmVzdWx0Lm1lcmNoYW50c3x8W10sYWNjb3VudHM6cmVzdWx0LmFjY291bnRzfHxbXX07b3B0aW9uc1N0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7b3B0aW9uc1N0YXR1cz0nZXJyb3InO29wdGlvbnNFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIGFjY291bnRzLic7fX1cbiAgZnVuY3Rpb24gb3BlbkNyZWRpdENhcmRGb3JtKGNhcmQ9bnVsbCl7Y3JlZGl0Q2FyZEVycm9yPScnO2NyZWRpdENhcmRFZGl0aW5nSWQ9Y2FyZD8uaWQ/P251bGw7Y3JlZGl0Q2FyZEZvcm09Y2FyZD97YWNjb3VudFJlZmVyZW5jZUlkOlN0cmluZyhjYXJkLmFjY291bnRSZWZlcmVuY2VJZCksY2FyZE5hbWU6Y2FyZC5jYXJkTmFtZSxpc3N1ZXJOYW1lOmNhcmQuaXNzdWVyTmFtZSxzdGF0ZW1lbnREYXk6U3RyaW5nKGNhcmQuc3RhdGVtZW50RGF5KSxkdWVEYXk6U3RyaW5nKGNhcmQuZHVlRGF5KX06e2FjY291bnRSZWZlcmVuY2VJZDonJyxjYXJkTmFtZTonJyxpc3N1ZXJOYW1lOicnLHN0YXRlbWVudERheTonJyxkdWVEYXk6Jyd9O3Nob3dDcmVkaXRDYXJkRm9ybT10cnVlO31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZUNyZWRpdENhcmQoKXtjb25zdCBzdGF0ZW1lbnREYXk9TnVtYmVyKGNyZWRpdENhcmRGb3JtLnN0YXRlbWVudERheSksZHVlRGF5PU51bWJlcihjcmVkaXRDYXJkRm9ybS5kdWVEYXkpO2lmKCFjcmVkaXRDYXJkRm9ybS5hY2NvdW50UmVmZXJlbmNlSWR8fCFjcmVkaXRDYXJkRm9ybS5jYXJkTmFtZS50cmltKCl8fCFjcmVkaXRDYXJkRm9ybS5pc3N1ZXJOYW1lLnRyaW0oKXx8c3RhdGVtZW50RGF5PDF8fHN0YXRlbWVudERheT4yOHx8ZHVlRGF5PDF8fGR1ZURheT4yOCl7Y3JlZGl0Q2FyZEVycm9yPSdDaG9vc2UgdGhlIGNhcHR1cmVkIGNhcmQgYWNjb3VudCBhbmQgZW50ZXIgZGF5cyBmcm9tIDEgdG8gMjguJztyZXR1cm47fWNyZWRpdENhcmRTYXZpbmc9dHJ1ZTtjcmVkaXRDYXJkRXJyb3I9Jyc7Y29uc3QgcGF5bG9hZD17YWNjb3VudFJlZmVyZW5jZUlkOk51bWJlcihjcmVkaXRDYXJkRm9ybS5hY2NvdW50UmVmZXJlbmNlSWQpLGNhcmROYW1lOmNyZWRpdENhcmRGb3JtLmNhcmROYW1lLnRyaW0oKSxpc3N1ZXJOYW1lOmNyZWRpdENhcmRGb3JtLmlzc3Vlck5hbWUudHJpbSgpLHN0YXRlbWVudERheSxkdWVEYXl9O3RyeXtjb25zdCBzYXZlZD1jcmVkaXRDYXJkRWRpdGluZ0lkPT09bnVsbD9hd2FpdCBjcmVhdGVDcmVkaXRDYXJkKHBheWxvYWQpOmF3YWl0IHVwZGF0ZUNyZWRpdENhcmQoY3JlZGl0Q2FyZEVkaXRpbmdJZCxwYXlsb2FkKTtjcmVkaXRDYXJkcz1jcmVkaXRDYXJkRWRpdGluZ0lkPT09bnVsbD9bc2F2ZWQsLi4uY3JlZGl0Q2FyZHNdOmNyZWRpdENhcmRzLm1hcChjYXJkPT5jYXJkLmlkPT09c2F2ZWQuaWQ/c2F2ZWQ6Y2FyZCk7Y3JlZGl0Q2FyZFN0YXR1cz0ncmVhZHknO3Nob3dDcmVkaXRDYXJkRm9ybT1mYWxzZTthd2FpdCByZWZyZXNoU3RvcmllcygpO31jYXRjaChjYXVzZSl7Y3JlZGl0Q2FyZEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgdGhpcyBjcmVkaXQgY2FyZC4nO31maW5hbGx5e2NyZWRpdENhcmRTYXZpbmc9ZmFsc2U7fX1cbiAgZnVuY3Rpb24gb3BlbkluY29tZUZsb3coKXtpbmNvbWVFcnJvcj0nJztzYWxhcnlGb3JtPXtzYWxhcnlWaXNpYmlsaXR5OidSQU5HRScsc2FsYXJ5UmFuZ2U6J0ZST01fNTAwMDBfVE9fMTAwMDAwJyxleGFjdE1vbnRobHlTYWxhcnk6Jycsc2FsYXJ5RnJlcXVlbmN5OidNT05USExZJ307c2hvd0luY29tZUZsb3c9dHJ1ZTt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVTYWxhcnkoKXtpbmNvbWVTYXZpbmc9dHJ1ZTtpbmNvbWVFcnJvcj0nJzt0cnl7YXdhaXQgc2F2ZUluY29tZVByb2ZpbGUoey4uLnNhbGFyeUZvcm0sZXhhY3RNb250aGx5U2FsYXJ5OnNhbGFyeUZvcm0uc2FsYXJ5VmlzaWJpbGl0eT09PSdFWEFDVCc/TnVtYmVyKHNhbGFyeUZvcm0uZXhhY3RNb250aGx5U2FsYXJ5KTpudWxsfSk7YXdhaXQgbG9hZEluY29tZU91dGxvb2soKTtzaG93SW5jb21lRmxvdz1mYWxzZTt9Y2F0Y2goY2F1c2Upe2luY29tZUVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgdGhpcyBwcmVmZXJlbmNlLic7fWZpbmFsbHl7aW5jb21lU2F2aW5nPWZhbHNlO319XG4gIGZ1bmN0aW9uIG9wZW5Mb2FuRm9ybShsb2FuPW51bGwpe2xvYW5FcnJvcj0nJztsb2FuRWRpdGluZ0lkPWxvYW4/LmlkPz9udWxsO2xvYW5Gb3JtPWxvYW4/e2xvYW5OYW1lOmxvYW4ubG9hbk5hbWV8fCcnLGxvYW5UeXBlOmxvYW4ubG9hblR5cGV8fCdIT01FJyxsZW5kZXJOYW1lOmxvYW4ubGVuZGVyTmFtZXx8Jycsb3JpZ2luYWxQcmluY2lwYWw6U3RyaW5nKGxvYW4ub3JpZ2luYWxQcmluY2lwYWw/PycnKSxtb250aGx5RW1pQW1vdW50OlN0cmluZyhsb2FuLm1vbnRobHlFbWlBbW91bnQ/PycnKSx0b3RhbFRlbnVyZU1vbnRoczpTdHJpbmcobG9hbi50b3RhbFRlbnVyZU1vbnRocz8/JycpLGZpcnN0RW1pRHVlRGF0ZTpsb2NhbElucHV0RGF0ZShsb2FuLmZpcnN0RW1pRHVlRGF0ZSksbm90ZXM6bG9hbi5ub3Rlc3x8Jyd9Ontsb2FuTmFtZTonJyxsb2FuVHlwZTonSE9NRScsbGVuZGVyTmFtZTonJyxvcmlnaW5hbFByaW5jaXBhbDonJyxtb250aGx5RW1pQW1vdW50OicnLHRvdGFsVGVudXJlTW9udGhzOicnLGZpcnN0RW1pRHVlRGF0ZTonJyxub3RlczonJ307c2hvd0xvYW5Gb3JtPXRydWU7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlTG9hbigpe2NvbnN0IG9yaWdpbmFsUHJpbmNpcGFsPU51bWJlcihsb2FuRm9ybS5vcmlnaW5hbFByaW5jaXBhbCksbW9udGhseUVtaUFtb3VudD1OdW1iZXIobG9hbkZvcm0ubW9udGhseUVtaUFtb3VudCksdG90YWxUZW51cmVNb250aHM9TnVtYmVyKGxvYW5Gb3JtLnRvdGFsVGVudXJlTW9udGhzKTtpZighbG9hbkZvcm0ubG9hbk5hbWUudHJpbSgpfHwhbG9hbkZvcm0ubGVuZGVyTmFtZS50cmltKCl8fCFsb2FuRm9ybS5maXJzdEVtaUR1ZURhdGV8fG9yaWdpbmFsUHJpbmNpcGFsPD0wfHxtb250aGx5RW1pQW1vdW50PD0wfHwhTnVtYmVyLmlzSW50ZWdlcih0b3RhbFRlbnVyZU1vbnRocyl8fHRvdGFsVGVudXJlTW9udGhzPD0wKXtsb2FuRXJyb3I9J0NvbXBsZXRlIGV2ZXJ5IHJlcXVpcmVkIGxvYW4gZGV0YWlsIHdpdGggdmFsaWQgcG9zaXRpdmUgYW1vdW50cy4nO3JldHVybjt9Y29uc3QgcGF5bG9hZD17bG9hbk5hbWU6bG9hbkZvcm0ubG9hbk5hbWUudHJpbSgpLGxvYW5UeXBlOmxvYW5Gb3JtLmxvYW5UeXBlLGxlbmRlck5hbWU6bG9hbkZvcm0ubGVuZGVyTmFtZS50cmltKCksb3JpZ2luYWxQcmluY2lwYWwsbW9udGhseUVtaUFtb3VudCx0b3RhbFRlbnVyZU1vbnRocyxmaXJzdEVtaUR1ZURhdGU6bG9hbkZvcm0uZmlyc3RFbWlEdWVEYXRlLG5vdGVzOmxvYW5Gb3JtLm5vdGVzfTtsb2FuU2F2aW5nPXRydWU7bG9hbkVycm9yPScnO3RyeXtjb25zdCBzYXZlZD1sb2FuRWRpdGluZ0lkPT1udWxsP2F3YWl0IGNyZWF0ZUxvYW4ocGF5bG9hZCk6YXdhaXQgdXBkYXRlTG9hbihsb2FuRWRpdGluZ0lkLHBheWxvYWQpO2xvYW5zPWxvYW5FZGl0aW5nSWQ9PW51bGw/Wy4uLmxvYW5zLHNhdmVkXTpsb2Fucy5tYXAobG9hbj0+bG9hbi5pZD09PXNhdmVkLmlkP3NhdmVkOmxvYW4pO3Nob3dMb2FuRm9ybT1mYWxzZTtsb2FuU3RhdHVzPSdyZWFkeSc7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe2xvYW5FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzYXZlIHRoaXMgbG9hbi4nO31maW5hbGx5e2xvYW5TYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlTG9hbihsb2FuKXtpZihsb2FuRGVsZXRpbmdJZCE9PW51bGwpcmV0dXJuO2xvYW5EZWxldGluZ0lkPWxvYW4uaWQ7bG9hbkVycm9yPScnO3RyeXthd2FpdCBkZWxldGVMb2FuKGxvYW4uaWQpO2xvYW5zPWxvYW5zLmZpbHRlcihpdGVtPT5pdGVtLmlkIT09bG9hbi5pZCk7c2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe2xvYW5FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBkZWxldGUgdGhpcyBsb2FuLic7fWZpbmFsbHl7bG9hbkRlbGV0aW5nSWQ9bnVsbDt9fVxuICBhc3luYyBmdW5jdGlvbiBwYXlMb2FuRW1pKGxvYW4sIG9jY3VycmVuY2Upe3RyeXthd2FpdCBtYXJrTG9hbkVtaVBhaWQobG9hbi5pZCxvY2N1cnJlbmNlLm1vbnRoKTthd2FpdCBQcm9taXNlLmFsbChbbG9hZExvYW5zKCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7bG9hbkVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IG1hcmsgdGhpcyBFTUkgcGFpZC4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5Mb2FuSGlzdG9yeShsb2FuKXtsb2FuSGlzdG9yeT17bG9hbk5hbWU6bG9hbi5sb2FuTmFtZX07bG9hbkhpc3RvcnlTdGF0dXM9J2xvYWRpbmcnO2xvYW5IaXN0b3J5RXJyb3I9Jyc7dHJ5e2xvYW5IaXN0b3J5PWF3YWl0IGdldExvYW5IaXN0b3J5KGxvYW4uaWQpO2xvYW5IaXN0b3J5U3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtsb2FuSGlzdG9yeVN0YXR1cz0nZXJyb3InO2xvYW5IaXN0b3J5RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBwYXltZW50IGhpc3RvcnkuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBwYXlMb2FuSGlzdG9yeUVtaShvY2N1cnJlbmNlKXtpZighbG9hbkhpc3RvcnkpcmV0dXJuO3RyeXthd2FpdCBtYXJrTG9hbkVtaVBhaWQobG9hbkhpc3RvcnkuaWQsb2NjdXJyZW5jZS5tb250aCk7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRMb2FucygpLG9wZW5Mb2FuSGlzdG9yeShsb2FuSGlzdG9yeSkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7bG9hbkhpc3RvcnlFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBtYXJrIHRoaXMgRU1JIHBhaWQuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuQ29tbWl0bWVudEhpc3RvcnkoY29tbWl0bWVudCl7Y29tbWl0bWVudEhpc3Rvcnk9e2xhYmVsOmNvbW1pdG1lbnQubGFiZWx9O2NvbW1pdG1lbnRIaXN0b3J5U3RhdHVzPSdsb2FkaW5nJztjb21taXRtZW50SGlzdG9yeUVycm9yPScnO3RyeXtjb21taXRtZW50SGlzdG9yeT1hd2FpdCBnZXRSZWN1cnJpbmdDb21taXRtZW50SGlzdG9yeShjb21taXRtZW50LmlkKTtjb21taXRtZW50SGlzdG9yeVN0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7Y29tbWl0bWVudEhpc3RvcnlTdGF0dXM9J2Vycm9yJztjb21taXRtZW50SGlzdG9yeUVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgcGF5bWVudCBoaXN0b3J5Lic7fX1cbiAgZnVuY3Rpb24gb3Blbk11dHVhbEZ1bmRGb3JtKCl7ZnVuZEVycm9yPScnO2Z1bmRTYXZlZD1mYWxzZTtzY2hlbWVRdWVyeT0nJztzZWxlY3RlZFNjaGVtZT1udWxsO3Nob3dTY2hlbWVNZW51PWZhbHNlO2Z1bmRGb3JtPXtoYXNTaXA6J1lFUycsc2lwQW1vdW50OicyNTAwMCcsc2lwRGF0ZTonNScsc3RhcnRNb250aDonMjAyNi0xMCcsaGFzSG9sZGluZzonWUVTJyxjdXJyZW50VW5pdHM6JzEyOC40NTYnLHRvdGFsSW52ZXN0ZWQ6JzEwMDAwJ307c2hvd011dHVhbEZ1bmRGb3JtPXRydWU7fVxuICBhc3luYyBmdW5jdGlvbiBzZWFyY2hTY2hlbWVzKHZhbHVlKXtzY2hlbWVRdWVyeT12YWx1ZTtzZWxlY3RlZFNjaGVtZT1udWxsO3Nob3dTY2hlbWVNZW51PXRydWU7ZnVuZEVycm9yPScnO2lmKHZhbHVlLnRyaW0oKS5sZW5ndGg8Mil7c2NoZW1lUmVzdWx0cz1bXTtzY2hlbWVTZWFyY2hTdGF0dXM9J2lkbGUnO3JldHVybjt9Y29uc3QgcmVxdWVzdElkPSsrc2NoZW1lU2VhcmNoUmVxdWVzdDtzY2hlbWVTZWFyY2hTdGF0dXM9J2xvYWRpbmcnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgc2VhcmNoTXV0dWFsRnVuZHModmFsdWUudHJpbSgpKTtpZihyZXF1ZXN0SWQhPT1zY2hlbWVTZWFyY2hSZXF1ZXN0KXJldHVybjtzY2hlbWVSZXN1bHRzPUFycmF5LmlzQXJyYXkocmVzdWx0KT9yZXN1bHQ6cmVzdWx0LnNjaGVtZXN8fFtdO3NjaGVtZVNlYXJjaFN0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7aWYocmVxdWVzdElkIT09c2NoZW1lU2VhcmNoUmVxdWVzdClyZXR1cm47c2NoZW1lUmVzdWx0cz1bXTtzY2hlbWVTZWFyY2hTdGF0dXM9J2Vycm9yJztmdW5kRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc2VhcmNoIHRoZSBzY2hlbWUgbWFzdGVyLic7fX1cbiAgZnVuY3Rpb24gc2VsZWN0U2NoZW1lKHNjaGVtZSl7c2VsZWN0ZWRTY2hlbWU9c2NoZW1lO3NjaGVtZVF1ZXJ5PXNjaGVtZS5zY2hlbWVOYW1lO3Nob3dTY2hlbWVNZW51PWZhbHNlO2Z1bmRFcnJvcj0nJzt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVNdXR1YWxGdW5kKCl7Y29uc3Qgc2lwQW1vdW50PU51bWJlcihmdW5kRm9ybS5zaXBBbW91bnQpLHVuaXRzPU51bWJlcihmdW5kRm9ybS5jdXJyZW50VW5pdHMpLGludmVzdGVkPU51bWJlcihmdW5kRm9ybS50b3RhbEludmVzdGVkKTtpZighc2VsZWN0ZWRTY2hlbWUpe2Z1bmRFcnJvcj0nQ2hvb3NlIGEgc2NoZW1lIGZyb20gdGhlIHZlcmlmaWVkIHNjaGVtZSBtYXN0ZXIuJztyZXR1cm47fWlmKGZ1bmRGb3JtLmhhc1NpcD09PSdZRVMnJiYoc2lwQW1vdW50PD0wfHwhZnVuZEZvcm0uc2lwRGF0ZXx8IWZ1bmRGb3JtLnN0YXJ0TW9udGgpKXtmdW5kRXJyb3I9J0FkZCBhIHZhbGlkIG1vbnRobHkgYW1vdW50LCBTSVAgZGF0ZSwgYW5kIHN0YXJ0IG1vbnRoLic7cmV0dXJuO31pZihmdW5kRm9ybS5oYXNIb2xkaW5nPT09J1lFUycmJighKHVuaXRzPjApfHwhKGludmVzdGVkPjApKSl7ZnVuZEVycm9yPSdFbnRlciBjdXJyZW50IHVuaXRzIGFuZCBpbnZlc3RlZCBhbW91bnQgZ3JlYXRlciB0aGFuIHplcm8uJztyZXR1cm47fWNvbnN0IHBheWxvYWQ9e3NjaGVtZUNvZGU6c2VsZWN0ZWRTY2hlbWUuc2NoZW1lQ29kZSxzY2hlbWVOYW1lOnNlbGVjdGVkU2NoZW1lLnNjaGVtZU5hbWUsLi4uKGZ1bmRGb3JtLmhhc1NpcD09PSdZRVMnP3ttb250aGx5U2lwQW1vdW50OnNpcEFtb3VudCxzaXBEYXk6TnVtYmVyKGZ1bmRGb3JtLnNpcERhdGUpLHN0YXJ0TW9udGg6ZnVuZEZvcm0uc3RhcnRNb250aH06e30pLC4uLihzZWxlY3RlZFNjaGVtZS5pc2luP3tpc2luOnNlbGVjdGVkU2NoZW1lLmlzaW59Ont9KSwuLi4oZnVuZEZvcm0uaGFzSG9sZGluZz09PSdZRVMnP3tleGlzdGluZ0hvbGRpbmc6e2N1cnJlbnRVbml0czp1bml0cyx0b3RhbEludmVzdGVkQW1vdW50OmludmVzdGVkfX06e30pfTtmdW5kU2F2aW5nPXRydWU7ZnVuZEVycm9yPScnO3RyeXthd2FpdCBjcmVhdGVNdXR1YWxGdW5kKHBheWxvYWQpO2Z1bmRTYXZlZD10cnVlO2F3YWl0IGxvYWRNdXR1YWxGdW5kcygpO2F3YWl0IHJlZnJlc2hTdG9yaWVzKCk7fWNhdGNoKGNhdXNlKXtmdW5kRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgY3JlYXRlIHRoaXMgbXV0dWFsIGZ1bmQuJzt9ZmluYWxseXtmdW5kU2F2aW5nPWZhbHNlO319XG4gIGFzeW5jIGZ1bmN0aW9uIHJlbW92ZU11dHVhbEZ1bmQoZnVuZCl7aWYobXV0dWFsRnVuZERlbGV0aW5nSWQhPT1udWxsKXJldHVybjttdXR1YWxGdW5kRGVsZXRpbmdJZD1mdW5kLmlkO211dHVhbEZ1bmRFcnJvcj0nJzt0cnl7YXdhaXQgZGVsZXRlTXV0dWFsRnVuZChmdW5kLmlkKTttdXR1YWxGdW5kcz1tdXR1YWxGdW5kcy5maWx0ZXIoaXRlbT0+aXRlbS5pZCE9PWZ1bmQuaWQpO3NhdmVNb25leU1vZHVsZXNDYWNoZSgpO2F3YWl0IHJlZnJlc2hTdG9yaWVzKCk7fWNhdGNoKGNhdXNlKXttdXR1YWxGdW5kRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgZGVsZXRlIHRoaXMgbXV0dWFsIGZ1bmQuJzt9ZmluYWxseXttdXR1YWxGdW5kRGVsZXRpbmdJZD1udWxsO319XG4gIGZ1bmN0aW9uIG9wZW5GdW5kU2lwUGxhbihmdW5kKXtmdW5kU2lwVGFyZ2V0PWZ1bmQ7ZnVuZFNpcEZvcm09e2Ftb3VudDonJyxkYXk6Jycsc3RhcnRNb250aDpuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCw3KX07ZnVuZEVycm9yPScnO31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZUZ1bmRTaXBQbGFuKCl7Y29uc3QgYW1vdW50PU51bWJlcihmdW5kU2lwRm9ybS5hbW91bnQpLGRheT1OdW1iZXIoZnVuZFNpcEZvcm0uZGF5KTtpZighKGFtb3VudD4wKXx8IShkYXk+PTEmJmRheTw9MjgpfHwhZnVuZFNpcEZvcm0uc3RhcnRNb250aCl7ZnVuZEVycm9yPSdFbnRlciBhIHBvc2l0aXZlIG1vbnRobHkgYW1vdW50LCBhIGRheSBmcm9tIDEgdG8gMjgsIGFuZCBhIHN0YXJ0IG1vbnRoLic7cmV0dXJuO31mdW5kU2lwU2F2aW5nPXRydWU7dHJ5e2F3YWl0IGNyZWF0ZU11dHVhbEZ1bmRTaXAoZnVuZFNpcFRhcmdldC5pZCx7YW1vdW50LGRheSxzdGFydE1vbnRoOmZ1bmRTaXBGb3JtLnN0YXJ0TW9udGh9KTtmdW5kU2lwVGFyZ2V0PW51bGw7YXdhaXQgbG9hZE11dHVhbEZ1bmRzKCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe2Z1bmRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzYXZlIHRoaXMgU0lQLic7fWZpbmFsbHl7ZnVuZFNpcFNhdmluZz1mYWxzZTt9fVxuICBmdW5jdGlvbiBvcGVuU3RvY2tGb3JtKCl7c3RvY2tFcnJvcj0nJztzdG9ja1F1ZXJ5PScnO3NlbGVjdGVkU3RvY2s9bnVsbDtzdG9ja1Jlc3VsdHM9W107c3RvY2tGb3JtPXtxdWFudGl0eTonJyx0b3RhbEludmVzdGVkOicnfTtzaG93U3RvY2tGb3JtPXRydWU7fVxuICBhc3luYyBmdW5jdGlvbiBmaW5kU3RvY2tzKHZhbHVlKXtzdG9ja1F1ZXJ5PXZhbHVlO3NlbGVjdGVkU3RvY2s9bnVsbDtzdG9ja0Vycm9yPScnO2lmKHZhbHVlLnRyaW0oKS5sZW5ndGg8Mil7c3RvY2tSZXN1bHRzPVtdO3N0b2NrU2VhcmNoU3RhdHVzPSdpZGxlJztyZXR1cm47fWNvbnN0IHJlcXVlc3RJZD0rK3N0b2NrU2VhcmNoUmVxdWVzdDtzdG9ja1NlYXJjaFN0YXR1cz0nbG9hZGluZyc7dHJ5e2NvbnN0IHJlc3VsdD1hd2FpdCBzZWFyY2hTdG9ja3ModmFsdWUudHJpbSgpKTtpZihyZXF1ZXN0SWQhPT1zdG9ja1NlYXJjaFJlcXVlc3QpcmV0dXJuO3N0b2NrUmVzdWx0cz1BcnJheS5pc0FycmF5KHJlc3VsdCk/cmVzdWx0OltdO3N0b2NrU2VhcmNoU3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtpZihyZXF1ZXN0SWQhPT1zdG9ja1NlYXJjaFJlcXVlc3QpcmV0dXJuO3N0b2NrUmVzdWx0cz1bXTtzdG9ja1NlYXJjaFN0YXR1cz0nZXJyb3InO3N0b2NrRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc2VhcmNoIHN0b2NrIHN5bWJvbHMuJzt9fVxuICBmdW5jdGlvbiBzZWxlY3RTdG9jayhzdG9jayl7c2VsZWN0ZWRTdG9jaz1zdG9jaztzdG9ja1F1ZXJ5PWAke3N0b2NrLm5hbWV9ICgke3N0b2NrLnN5bWJvbH0pYDtzdG9ja1Jlc3VsdHM9W107c3RvY2tFcnJvcj0nJzt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVTdG9jaygpe2NvbnN0IHF1YW50aXR5PU51bWJlcihzdG9ja0Zvcm0ucXVhbnRpdHkpLHRvdGFsSW52ZXN0ZWRBbW91bnQ9TnVtYmVyKHN0b2NrRm9ybS50b3RhbEludmVzdGVkKTtpZighc2VsZWN0ZWRTdG9jayl7c3RvY2tFcnJvcj0nQ2hvb3NlIGEgc3RvY2sgZnJvbSB0aGUgc2VhcmNoIHJlc3VsdHMuJztyZXR1cm47fWlmKCEocXVhbnRpdHk+MCl8fCEodG90YWxJbnZlc3RlZEFtb3VudD4wKSl7c3RvY2tFcnJvcj0nRW50ZXIgdmFsaWQgcG9zaXRpdmUgcXVhbnRpdHkgYW5kIHRvdGFsIGludmVzdGVkIGFtb3VudC4nO3JldHVybjt9c3RvY2tTYXZpbmc9dHJ1ZTtzdG9ja0Vycm9yPScnO3RyeXthd2FpdCBjcmVhdGVTdG9jayh7c3ltYm9sOnNlbGVjdGVkU3RvY2suc3ltYm9sLG5hbWU6c2VsZWN0ZWRTdG9jay5uYW1lLGV4Y2hhbmdlOnNlbGVjdGVkU3RvY2suZXhjaGFuZ2UscXVhbnRpdHksdG90YWxJbnZlc3RlZEFtb3VudH0pO3Nob3dTdG9ja0Zvcm09ZmFsc2U7YXdhaXQgbG9hZFN0b2NrcygpO31jYXRjaChjYXVzZSl7c3RvY2tFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBhZGQgdGhpcyBzdG9jay4nO31maW5hbGx5e3N0b2NrU2F2aW5nPWZhbHNlO319XG4gIGFzeW5jIGZ1bmN0aW9uIHJlbW92ZVN0b2NrKHN0b2NrKXtpZihzdG9ja0RlbGV0aW5nSWQhPT1udWxsKXJldHVybjtzdG9ja0RlbGV0aW5nSWQ9c3RvY2suaWQ7c3RvY2tFcnJvcj0nJzt0cnl7YXdhaXQgZGVsZXRlU3RvY2soc3RvY2suaWQpO3N0b2Nrcz1zdG9ja3MuZmlsdGVyKGl0ZW09Pml0ZW0uaWQhPT1zdG9jay5pZCk7c2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCk7fWNhdGNoKGNhdXNlKXtzdG9ja0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGRlbGV0ZSB0aGlzIHN0b2NrLic7fWZpbmFsbHl7c3RvY2tEZWxldGluZ0lkPW51bGw7fX1cbiAgZnVuY3Rpb24gb3BlblN0b2NrUGxhbihzdG9jayl7c3RvY2tQbGFuVGFyZ2V0PXN0b2NrO3N0b2NrUGxhbkZvcm09e2Ftb3VudDpzdG9jay5hY3RpdmVNb250aGx5UGxhbj8uYW1vdW50fHwnJyxkYXk6c3RvY2suYWN0aXZlTW9udGhseVBsYW4/LmRheXx8Jycsc3RhcnRNb250aDpzdG9jay5hY3RpdmVNb250aGx5UGxhbj8uc3RhcnRNb250aHx8bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsNyl9O3N0b2NrRXJyb3I9Jyc7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlU3RvY2tQbGFuKCl7Y29uc3QgYW1vdW50PU51bWJlcihzdG9ja1BsYW5Gb3JtLmFtb3VudCksZGF5PU51bWJlcihzdG9ja1BsYW5Gb3JtLmRheSk7aWYoIShhbW91bnQ+MCl8fCEoZGF5Pj0xJiZkYXk8PTI4KXx8IXN0b2NrUGxhbkZvcm0uc3RhcnRNb250aCl7c3RvY2tFcnJvcj0nRW50ZXIgYSBwb3NpdGl2ZSBhbW91bnQsIGEgZGF5IGZyb20gMSB0byAyOCwgYW5kIGEgc3RhcnQgbW9udGguJztyZXR1cm47fXN0b2NrUGxhblNhdmluZz10cnVlO3RyeXthd2FpdCBjcmVhdGVTdG9ja01vbnRobHlQbGFuKHN0b2NrUGxhblRhcmdldC5pZCx7YW1vdW50LGRheSxzdGFydE1vbnRoOnN0b2NrUGxhbkZvcm0uc3RhcnRNb250aH0pO3N0b2NrUGxhblRhcmdldD1udWxsO2F3YWl0IGxvYWRTdG9ja3MoKTthd2FpdCByZWZyZXNoU3RvcmllcygpO31jYXRjaChjYXVzZSl7c3RvY2tFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzYXZlIHRoaXMgbW9udGhseSBwbGFuLic7fWZpbmFsbHl7c3RvY2tQbGFuU2F2aW5nPWZhbHNlO319XG4gIGFzeW5jIGZ1bmN0aW9uIGNvbmZpcm1TdG9ja1BsYW4oKXtjb25zdCBhbW91bnQ9TnVtYmVyKHN0b2NrUGxhbkNvbmZpcm1hdGlvbi5hbW91bnQpLGV4ZWN1dGlvblByaWNlPU51bWJlcihzdG9ja1BsYW5Db25maXJtYXRpb24ucHJpY2UpO2lmKCEoYW1vdW50PjApfHwhKGV4ZWN1dGlvblByaWNlPjApKXJldHVybjt0cnl7YXdhaXQgY29uZmlybVN0b2NrTW9udGhseVBsYW4oc3RvY2tQbGFuQ29uZmlybWF0aW9uVGFyZ2V0LmlkLHN0b2NrUGxhbkNvbmZpcm1hdGlvblRhcmdldC5jdXJyZW50TW9udGhseVBsYW4ubW9udGgse2Ftb3VudCxleGVjdXRpb25QcmljZSx0cmFuc2FjdGlvbkRhdGU6bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsMTApfSk7c3RvY2tQbGFuQ29uZmlybWF0aW9uVGFyZ2V0PW51bGw7YXdhaXQgbG9hZFN0b2NrcygpO2F3YWl0IHJlZnJlc2hTdG9yaWVzKCk7fWNhdGNoKGNhdXNlKXtzdG9ja0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGNvbmZpcm0gdGhpcyBFVEYgaW52ZXN0bWVudC4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5TdG9ja0RldGFpbChpZCl7c3RvY2tEZXRhaWw9e2lkfTtzdG9ja0RldGFpbFN0YXR1cz0nbG9hZGluZyc7dHJ5e3N0b2NrRGV0YWlsPWF3YWl0IGdldFN0b2NrKGlkKTtzdG9ja0RldGFpbFN0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7c3RvY2tEZXRhaWxTdGF0dXM9J2Vycm9yJztzdG9ja0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgdGhpcyBzdG9jay4nO319XG4gIGZ1bmN0aW9uIG9wZW5TaXBDb25maXJtYXRpb24oZnVuZCxvY2N1cnJlbmNlKXtjb25maXJtaW5nU2lwPXtmdW5kLG9jY3VycmVuY2V9O3NpcENvbmZpcm1FcnJvcj0nJztzaXBDb25maXJtRm9ybT17YW1vdW50OlN0cmluZyhvY2N1cnJlbmNlLmFtb3VudHx8ZnVuZC5tb250aGx5U2lwQW1vdW50fHwnJyksdHJhbnNhY3Rpb25EYXRlOm9jY3VycmVuY2UudHJhbnNhY3Rpb25EYXRlfHxuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwxMCksbmF2Om9jY3VycmVuY2UubmF2PT1udWxsPycnOlN0cmluZyhvY2N1cnJlbmNlLm5hdil9O31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZVNpcENvbmZpcm1hdGlvbigpe2NvbnN0IGFtb3VudD1OdW1iZXIoc2lwQ29uZmlybUZvcm0uYW1vdW50KSxuYXY9TnVtYmVyKHNpcENvbmZpcm1Gb3JtLm5hdik7aWYoIShhbW91bnQ+MCl8fCFzaXBDb25maXJtRm9ybS50cmFuc2FjdGlvbkRhdGV8fCEobmF2PjApKXtzaXBDb25maXJtRXJyb3I9J0VudGVyIGEgdmFsaWQgYW1vdW50LCB0cmFuc2FjdGlvbiBkYXRlLCBhbmQgTkFWLic7cmV0dXJuO31zaXBDb25maXJtU2F2aW5nPXRydWU7c2lwQ29uZmlybUVycm9yPScnO3RyeXtjb25zdCBwYXlsb2FkPXthbW91bnQsdHJhbnNhY3Rpb25EYXRlOnNpcENvbmZpcm1Gb3JtLnRyYW5zYWN0aW9uRGF0ZSxuYXYsY2FsY3VsYXRpb25Tb3VyY2U6J05BVl9FU1RJTUFURUQnfTtpZihjb25maXJtaW5nU2lwLm9jY3VycmVuY2Uuc3RhdHVzPT09J0NPTkZJUk1FRCcpYXdhaXQgdXBkYXRlU2lwT2NjdXJyZW5jZShjb25maXJtaW5nU2lwLmZ1bmQuaWQsY29uZmlybWluZ1NpcC5vY2N1cnJlbmNlLnNjaGVkdWxlZE1vbnRoLHBheWxvYWQpO2Vsc2UgYXdhaXQgY29uZmlybVNpcE9jY3VycmVuY2UoY29uZmlybWluZ1NpcC5mdW5kLmlkLGNvbmZpcm1pbmdTaXAub2NjdXJyZW5jZS5zY2hlZHVsZWRNb250aCxwYXlsb2FkKTtjb25maXJtaW5nU2lwPW51bGw7YXdhaXQgbG9hZE11dHVhbEZ1bmRzKCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe3NpcENvbmZpcm1FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzYXZlIHRoaXMgU0lQIGFsbG9jYXRpb24uJzt9ZmluYWxseXtzaXBDb25maXJtU2F2aW5nPWZhbHNlO319XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5GdW5kRGV0YWlsKGlkKXtmdW5kRGV0YWlsPXtpZH07ZnVuZERldGFpbFN0YXR1cz0nbG9hZGluZyc7ZnVuZERldGFpbEVycm9yPScnO3RyeXtmdW5kRGV0YWlsPWF3YWl0IGdldE11dHVhbEZ1bmQoaWQpO2Z1bmREZXRhaWxTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2Z1bmREZXRhaWxTdGF0dXM9J2Vycm9yJztmdW5kRGV0YWlsRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCB0aGlzIGZ1bmQuJzt9fVxuICBmdW5jdGlvbiBvcGVuTHVtcFN1bShmdW5kKXtsdW1wU3VtRnVuZD1mdW5kO2x1bXBTdW1FcnJvcj0nJztsdW1wU3VtRm9ybT17YW1vdW50OicnLHRyYW5zYWN0aW9uRGF0ZTpuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwxMCksbmF2OicnfTt9XG4gIGZ1bmN0aW9uIG9wZW5IaXN0b3J5RWRpdChmdW5kLGVudHJ5KXtlZGl0aW5nRnVuZFRyYW5zYWN0aW9uPXtmdW5kLGVudHJ5fTtmdW5kVHJhbnNhY3Rpb25FcnJvcj0nJztmdW5kVHJhbnNhY3Rpb25Gb3JtPXthbW91bnQ6U3RyaW5nKGVudHJ5LmFtb3VudHx8JycpLHRyYW5zYWN0aW9uRGF0ZTplbnRyeS50cmFuc2FjdGlvbkRhdGV8fCcnLG5hdjplbnRyeS5uYXY9PW51bGw/Jyc6U3RyaW5nKGVudHJ5Lm5hdil9O31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZUZ1bmRUcmFuc2FjdGlvbigpe2NvbnN0IGFtb3VudD1OdW1iZXIoZnVuZFRyYW5zYWN0aW9uRm9ybS5hbW91bnQpLG5hdj1OdW1iZXIoZnVuZFRyYW5zYWN0aW9uRm9ybS5uYXYpO2lmKCEoYW1vdW50PjApfHwhZnVuZFRyYW5zYWN0aW9uRm9ybS50cmFuc2FjdGlvbkRhdGV8fCEobmF2PjApKXtmdW5kVHJhbnNhY3Rpb25FcnJvcj0nRW50ZXIgYSB2YWxpZCBhbW91bnQsIHRyYW5zYWN0aW9uIGRhdGUsIGFuZCBOQVYuJztyZXR1cm47fWZ1bmRUcmFuc2FjdGlvblNhdmluZz10cnVlO2Z1bmRUcmFuc2FjdGlvbkVycm9yPScnO3RyeXthd2FpdCB1cGRhdGVNdXR1YWxGdW5kVHJhbnNhY3Rpb24oZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbi5mdW5kLmlkLGVkaXRpbmdGdW5kVHJhbnNhY3Rpb24uZW50cnkuaWQse2Ftb3VudCx0cmFuc2FjdGlvbkRhdGU6ZnVuZFRyYW5zYWN0aW9uRm9ybS50cmFuc2FjdGlvbkRhdGUsbmF2LGNhbGN1bGF0aW9uU291cmNlOidVU0VSX0VOVEVSRUQnfSk7Y29uc3QgaWQ9ZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbi5mdW5kLmlkO2VkaXRpbmdGdW5kVHJhbnNhY3Rpb249bnVsbDthd2FpdCBQcm9taXNlLmFsbChbbG9hZE11dHVhbEZ1bmRzKCksb3BlbkZ1bmREZXRhaWwoaWQpLHJlZnJlc2hTdG9yaWVzKCldKTt9Y2F0Y2goY2F1c2Upe2Z1bmRUcmFuc2FjdGlvbkVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHVwZGF0ZSB0aGlzIGludmVzdG1lbnQuJzt9ZmluYWxseXtmdW5kVHJhbnNhY3Rpb25TYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZUx1bXBTdW0oKXtjb25zdCBhbW91bnQ9TnVtYmVyKGx1bXBTdW1Gb3JtLmFtb3VudCksbmF2PU51bWJlcihsdW1wU3VtRm9ybS5uYXYpO2lmKCEoYW1vdW50PjApfHwhbHVtcFN1bUZvcm0udHJhbnNhY3Rpb25EYXRlfHwhKG5hdj4wKSl7bHVtcFN1bUVycm9yPSdFbnRlciBhIHBvc2l0aXZlIGFtb3VudCwgdHJhbnNhY3Rpb24gZGF0ZSwgYW5kIE5BVi4nO3JldHVybjt9bHVtcFN1bVNhdmluZz10cnVlO3RyeXthd2FpdCBjcmVhdGVNdXR1YWxGdW5kTHVtcFN1bShsdW1wU3VtRnVuZC5pZCx7YW1vdW50LHRyYW5zYWN0aW9uRGF0ZTpsdW1wU3VtRm9ybS50cmFuc2FjdGlvbkRhdGUsbmF2LGNhbGN1bGF0aW9uU291cmNlOidOQVZfRVNUSU1BVEVEJ30pO2x1bXBTdW1GdW5kPW51bGw7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRNdXR1YWxGdW5kcygpLHJlZnJlc2hTdG9yaWVzKCldKTt9Y2F0Y2goY2F1c2Upe2x1bXBTdW1FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBhZGQgdGhpcyBsdW1wIHN1bS4nO31maW5hbGx5e2x1bXBTdW1TYXZpbmc9ZmFsc2U7fX1cbiAgZnVuY3Rpb24gbmF2aWdhdGUobmV4dCl7dmlldz1uZXh0O2lmKG5leHQhPT0ndHJhbnNhY3Rpb25zJyl7c2VsZWN0ZWREYXk9bnVsbDthY3Rpdml0eVRhYj0ncmVjZW50Jzt9d2luZG93LnNjcm9sbFRvKHt0b3A6MCxiZWhhdmlvcjonc21vb3RoJ30pO31cbiAgZnVuY3Rpb24gY3VycmVudExvY2FsTW9udGgoKXtjb25zdCBub3c9bmV3IERhdGUoKTtyZXR1cm4gYCR7bm93LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKG5vdy5nZXRNb250aCgpKzEpLnBhZFN0YXJ0KDIsJzAnKX1gO31cbiAgZnVuY3Rpb24gY2hhbmdlTW9udGgob2Zmc2V0KXtjb25zdFt5LG1dPXNlbGVjdGVkTW9udGguc3BsaXQoJy0nKS5tYXAoTnVtYmVyKSxuZXh0PW5ldyBEYXRlKERhdGUuVVRDKHksbS0xK29mZnNldCwxKSkudG9JU09TdHJpbmcoKS5zbGljZSgwLDcpO2lmKG5leHQ8PWN1cnJlbnRMb2NhbE1vbnRoKCkpe3NlbGVjdGVkRGF5PW51bGw7ZGF5SXRlbXM9W107YWN0aXZpdHlUYWI9J3JlY2VudCc7b25Nb250aENoYW5nZShuZXh0KTt9fVxuICBmdW5jdGlvbiBidWlsZENhbGVuZGFyKG1vbnRoVmFsdWUsYXBpRGF5cyl7Y29uc3RbeSxtXT1tb250aFZhbHVlLnNwbGl0KCctJykubWFwKE51bWJlciksY291bnQ9bmV3IERhdGUoeSxtLDApLmdldERhdGUoKSxsZWFkaW5nPShuZXcgRGF0ZSh5LG0tMSwxKS5nZXREYXkoKSs2KSU3LHZhbHVlcz1uZXcgTWFwKGFwaURheXMubWFwKHg9PltOdW1iZXIoU3RyaW5nKHguZGF0ZSkuc2xpY2UoLTIpKSx4XSkpLHRvZGF5PW5ldyBEYXRlKCksY3VycmVudD10b2RheS5nZXRGdWxsWWVhcigpPT09eSYmdG9kYXkuZ2V0TW9udGgoKSsxPT09bTtyZXR1cm57bGVhZGluZyxkYXlzOkFycmF5LmZyb20oe2xlbmd0aDpjb3VudH0sKF8saSk9Pntjb25zdCBkYXk9aSsxLHY9dmFsdWVzLmdldChkYXkpfHx7fTtyZXR1cm57ZGF5LHRvdGFsU3BlbmQ6TnVtYmVyKHYudG90YWxTcGVuZHx8MCksdHJhbnNhY3Rpb25Db3VudDpOdW1iZXIodi50cmFuc2FjdGlvbkNvdW50fHwwKSxpbnRlbnNpdHk6TWF0aC5tYXgoMCxNYXRoLm1pbig0LE51bWJlcih2LmludGVuc2l0eXx8MCkpKSxmdXR1cmU6Y3VycmVudCYmZGF5PnRvZGF5LmdldERhdGUoKX07fSl9O31cbiAgYXN5bmMgZnVuY3Rpb24gc2VsZWN0RGF0ZShkYXkpe2lmKCFkYXl8fGRheS5mdXR1cmUpcmV0dXJuO3NlbGVjdGVkRGF5PWRheS5kYXk7YWN0aXZpdHlUYWI9J2RheSc7c2hvd0FsbD1mYWxzZTtleHBhbmRlZElkPW51bGw7YXdhaXQgbG9hZERheSgpO31cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZERheSgpe2lmKHNlbGVjdGVkRGF5PT1udWxsKXJldHVybjtkYXlTdGF0dXM9J2xvYWRpbmcnO3RyeXtjb25zdCBwYWdlPWF3YWl0IGdldEV4cGVuc2VzRm9yRGF0ZShzZWxlY3RlZE1vbnRoLGlzb0RhdGUoc2VsZWN0ZWREYXkpLDUwKTtkYXlJdGVtcz1wYWdlLml0ZW1zfHxwYWdlLmV4cGVuc2VzfHxbXTtkYXlTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2h7ZGF5U3RhdHVzPSdlcnJvcic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gb3BlblN0b3J5KHN0b3J5KXtvcGVuZWRTdG9yeT1zdG9yeTtzdG9yeVNsaWRlPTA7c2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2U7Y29uc3QgaGFzUmV2aWV3PShzdG9yeS5jYXJkc3x8W10pLnNvbWUoY2FyZD0+KGNhcmQuYWN0aW9uc3x8W10pLnNvbWUoYWN0aW9uPT5hY3Rpb24udHlwZT09PSdPUEVOX0NPTU1JVE1FTlRfUkVWSUVXJykpO2lmKGhhc1Jldmlldyl7Y29tbWl0bWVudFJldmlld1N0YXR1cz0nbG9hZGluZyc7c2hvd0NvbW1pdG1lbnRSZXZpZXc9dHJ1ZTt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldENvbW1pdG1lbnRSZXZpZXcoc2VsZWN0ZWRNb250aCk7Y29tbWl0bWVudFJldmlldz1yZXN1bHQuaXRlbXN8fFtdO2NvbW1pdG1lbnRSZXZpZXdTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2NvbW1pdG1lbnRSZXZpZXdTdGF0dXM9J2Vycm9yJztjb21taXRtZW50RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBwYXltZW50cyBuZWVkaW5nIHJldmlldy4nO319fVxuICBmdW5jdGlvbiBzdG9yeUhhc0xvYW4oc3Rvcnkpe3JldHVybiBpc0NvbW1pdG1lbnQoc3RvcnkpJiZldmlkZW5jZUZvcihzdG9yeSxzdG9yeVNsaWRlKS5zb21lKGl0ZW09Pi9sb2FuL2kudGVzdChpdGVtLmNhdGVnb3J5KSk7fVxuICBhc3luYyBmdW5jdGlvbiByZXNvbHZlQ2FuZGlkYXRlKHRyYW5zYWN0aW9uSWQsY29tbWl0bWVudElkKXtyZXNvbHZpbmdDYW5kaWRhdGU9dHJhbnNhY3Rpb25JZDt0cnl7YXdhaXQgcmVzb2x2ZUNvbW1pdG1lbnRSZXZpZXcodHJhbnNhY3Rpb25JZCxjb21taXRtZW50SWQpO2NvbW1pdG1lbnRSZXZpZXc9Y29tbWl0bWVudFJldmlldy5maWx0ZXIoaXRlbT0+aXRlbS50cmFuc2FjdGlvbklkIT09dHJhbnNhY3Rpb25JZCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTtpZighY29tbWl0bWVudFJldmlldy5sZW5ndGgpc2hvd0NvbW1pdG1lbnRSZXZpZXc9ZmFsc2U7fWNhdGNoKGNhdXNlKXtjb21taXRtZW50RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc2F2ZSB0aGlzIHJldmlldy4nO31maW5hbGx5e3Jlc29sdmluZ0NhbmRpZGF0ZT1udWxsO319XG4gIGZ1bmN0aW9uIGVuZFN0b3J5U3dpcGUoZXZlbnQsbGVuZ3RoKXtpZihzdG9yeVRvdWNoU3RhcnQ9PT1udWxsKXJldHVybjtjb25zdCBkaXN0YW5jZT1ldmVudC5jaGFuZ2VkVG91Y2hlc1swXS5jbGllbnRYLXN0b3J5VG91Y2hTdGFydDtpZihNYXRoLmFicyhkaXN0YW5jZSk+NDUpc3RvcnlTbGlkZT1NYXRoLm1heCgwLE1hdGgubWluKGxlbmd0aC0xLHN0b3J5U2xpZGUrKGRpc3RhbmNlPDA/MTotMSkpKTtzdG9yeVRvdWNoU3RhcnQ9bnVsbDt9XG4gIGZ1bmN0aW9uIGVuZFJhaWxTd2lwZShldmVudCxsZW5ndGgscmFpbCl7aWYoc3RvcnlSYWlsVG91Y2hTdGFydD09PW51bGwpcmV0dXJuO2NvbnN0IGRpc3RhbmNlPWV2ZW50LmNoYW5nZWRUb3VjaGVzWzBdLmNsaWVudFgtc3RvcnlSYWlsVG91Y2hTdGFydDtpZihNYXRoLmFicyhkaXN0YW5jZSk+NDUpe2NvbnN0IG5leHQ9TWF0aC5tYXgoMCxNYXRoLm1pbihsZW5ndGgtMSwocmFpbD09PSdob21lJz9ob21lU3RvcnlJbmRleDpzdG9yaWVzUmFpbEluZGV4KSsoZGlzdGFuY2U8MD8xOi0xKSkpO2lmKHJhaWw9PT0naG9tZScpaG9tZVN0b3J5SW5kZXg9bmV4dDtlbHNlIHN0b3JpZXNSYWlsSW5kZXg9bmV4dDt9c3RvcnlSYWlsVG91Y2hTdGFydD1udWxsO31cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRFZGl0KGl0ZW0pe2VkaXRpbmc9aXRlbTtlZGl0QW1vdW50PVN0cmluZyhpdGVtLmFtb3VudD8/JycpO2VkaXREYXRlPWxvY2FsSW5wdXREYXRlKHRyYW5zYWN0aW9uRGF0ZShpdGVtKSk7ZWRpdENhdGVnb3J5PWNhdGVnb3J5KGl0ZW0pPT09J1VuY2F0ZWdvcmlzZWQnPycnOmNhdGVnb3J5KGl0ZW0pO2VkaXRTdWJjYXRlZ29yeT1pdGVtLnN1YmNhdGVnb3J5Py5uYW1lfHxpdGVtLnN1YmNhdGVnb3J5fHwnJztlZGl0TWVyY2hhbnRJZD1TdHJpbmcoaXRlbS5tZXJjaGFudElkPz9pdGVtLm1lcmNoYW50Py5pZD8/JycpO2VkaXRBY2NvdW50SWQ9U3RyaW5nKGl0ZW0uYWNjb3VudElkPz9pdGVtLmFjY291bnQ/LmlkPz9pdGVtLnNvdXJjZUFjY291bnRJZD8/JycpO2FjdGlvbkVycm9yPScnO29wdGlvbnNFcnJvcj0nJztpZihvcHRpb25zU3RhdHVzPT09J3JlYWR5Jyl7c2VsZWN0Q3VycmVudFJlZmVyZW5jZXMoaXRlbSk7cmV0dXJuO31vcHRpb25zU3RhdHVzPSdsb2FkaW5nJzt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldEV4cGVuc2VPcHRpb25zKCk7ZWRpdE9wdGlvbnM9e2NhdGVnb3JpZXM6cmVzdWx0LmNhdGVnb3JpZXN8fFtdLG1lcmNoYW50czpyZXN1bHQubWVyY2hhbnRzfHxbXSxhY2NvdW50czpyZXN1bHQuYWNjb3VudHN8fFtdfTtvcHRpb25zU3RhdHVzPSdyZWFkeSc7c2VsZWN0Q3VycmVudFJlZmVyZW5jZXMoaXRlbSk7fWNhdGNoKGNhdXNlKXtvcHRpb25zU3RhdHVzPSdlcnJvcic7b3B0aW9uc0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgZXhwZW5zZSBvcHRpb25zLic7fX1cbiAgZnVuY3Rpb24gc2VsZWN0Q3VycmVudFJlZmVyZW5jZXMoaXRlbSl7aWYoIWVkaXRNZXJjaGFudElkKXtjb25zdCBtYXRjaD1lZGl0T3B0aW9ucy5tZXJjaGFudHMuZmluZChvcHRpb249Pm9wdGlvbi5uYW1lPy50b0xvd2VyQ2FzZSgpPT09bWVyY2hhbnQoaXRlbSkudG9Mb3dlckNhc2UoKSk7aWYobWF0Y2gpZWRpdE1lcmNoYW50SWQ9U3RyaW5nKG1hdGNoLmlkKTt9aWYoIWVkaXRBY2NvdW50SWQpe2NvbnN0IGN1cnJlbnQ9U3RyaW5nKGl0ZW0uYWNjb3VudD8ubmFtZT8/aXRlbS5zb3VyY2VBY2NvdW50Py5uYW1lPz9pdGVtLmFjY291bnROYW1lPz8nJykudG9Mb3dlckNhc2UoKSxtYXRjaD1lZGl0T3B0aW9ucy5hY2NvdW50cy5maW5kKG9wdGlvbj0+b3B0aW9uLm5hbWU/LnRvTG93ZXJDYXNlKCk9PT1jdXJyZW50KTtpZihtYXRjaCllZGl0QWNjb3VudElkPVN0cmluZyhtYXRjaC5pZCk7fX1cbiAgZnVuY3Rpb24gY2hhbmdlRWRpdENhdGVnb3J5KGV2ZW50KXtlZGl0Q2F0ZWdvcnk9ZXZlbnQuY3VycmVudFRhcmdldC52YWx1ZTtpZighZWRpdFN1YmNhdGVnb3JpZXMuaW5jbHVkZXMoZWRpdFN1YmNhdGVnb3J5KSllZGl0U3ViY2F0ZWdvcnk9Jyc7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlRWRpdCgpe2NvbnN0IGFtb3VudD1OdW1iZXIoZWRpdEFtb3VudCksbWVyY2hhbnRJZD1OdW1iZXIoZWRpdE1lcmNoYW50SWQpLGFjY291bnRJZD1OdW1iZXIoZWRpdEFjY291bnRJZCk7aWYoIWVkaXRpbmd8fHNhdmluZ3x8b3B0aW9uc1N0YXR1cyE9PSdyZWFkeSd8fCFOdW1iZXIuaXNGaW5pdGUoYW1vdW50KXx8YW1vdW50PD0wfHwhZWRpdERhdGV8fCFlZGl0Q2F0ZWdvcnl8fCFlZGl0U3ViY2F0ZWdvcnl8fCFOdW1iZXIuaXNGaW5pdGUobWVyY2hhbnRJZCl8fCFOdW1iZXIuaXNGaW5pdGUoYWNjb3VudElkKSlyZXR1cm47c2F2aW5nPXRydWU7YWN0aW9uRXJyb3I9Jyc7dHJ5e2F3YWl0IHVwZGF0ZUV4cGVuc2UoZWRpdGluZy5pZCx7YW1vdW50LHRyYW5zYWN0aW9uRGF0ZTplZGl0RGF0ZSxjYXRlZ29yeTplZGl0Q2F0ZWdvcnksc3ViY2F0ZWdvcnk6ZWRpdFN1YmNhdGVnb3J5LG1lcmNoYW50SWQsYWNjb3VudElkfSk7ZWRpdGluZz1udWxsO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkRGF5KCkscmVmcmVzaFJlY2VudCgpLHJlZnJlc2hDYWxlbmRhcigpLHJlZnJlc2hTdG9yaWVzKCldKTt9Y2F0Y2goY2F1c2Upe2FjdGlvbkVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHVwZGF0ZSB0aGUgdHJhbnNhY3Rpb24uJzt9ZmluYWxseXtzYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gY29uZmlybURlbGV0ZSgpe2lmKCFkZWxldGluZylyZXR1cm47dHJ5e2F3YWl0IGRlbGV0ZUV4cGVuc2UoZGVsZXRpbmcuaWQpO2RlbGV0aW5nPW51bGw7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWREYXkoKSxyZWZyZXNoUmVjZW50KCkscmVmcmVzaENhbGVuZGFyKCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7YWN0aW9uRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgZGVsZXRlIHRoZSB0cmFuc2FjdGlvbi4nO2RlbGV0aW5nPW51bGw7fX1cbiAgYXN5bmMgZnVuY3Rpb24gYWRkTWlzc2luZ0RhdGUoKXtpZighc2VsZWN0ZWR8fGFkZGluZ0NvbnRleHQpcmV0dXJuO2FkZGluZ0NvbnRleHQ9dHJ1ZTt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGNyZWF0ZU1pc3NpbmdEYXRlQ29udGV4dChpc29EYXRlKHNlbGVjdGVkLmRheSksZGF0YS50aW1lem9uZXx8SW50bC5EYXRlVGltZUZvcm1hdCgpLnJlc29sdmVkT3B0aW9ucygpLnRpbWVab25lKTtoYW5kb2ZmPXsuLi5yZXN1bHQsZGF0ZTppc29EYXRlKHNlbGVjdGVkLmRheSl9O31jYXRjaChjYXVzZSl7YWN0aW9uRXJyb3I9Y2F1c2UgaW5zdGFuY2VvZiBBcGlFcnJvcj9jYXVzZS5tZXNzYWdlOidDb3VsZCBub3QgcHJlcGFyZSBXaGF0c0FwcCByZWNvcmRpbmcuJzt9ZmluYWxseXthZGRpbmdDb250ZXh0PWZhbHNlO319XG4gIGFzeW5jIGZ1bmN0aW9uIHNpZ25PdXQoKXtsb2dnaW5nT3V0PXRydWU7dHJ5e2F3YWl0IGxvZ291dCgpO3RyeXtsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShgJHtNT05FWV9NT0RVTEVTX0NBQ0hFX0tFWX0ucmVhbGApO2xvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGAke01PTkVZX01PRFVMRVNfQ0FDSEVfS0VZfS5kZW1vYCk7fWNhdGNoe31vbkxvZ291dCgpO31jYXRjaHtsb2dnaW5nT3V0PWZhbHNlO3NpZ25PdXRFcnJvcj0nQ291bGQgbm90IHNpZ24gb3V0Lic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gc3dpdGNoRGVtb01vZGUoKXtpZihkZW1vU3dpdGNoaW5nKXJldHVybjtkZW1vU3dpdGNoaW5nPXRydWU7ZGVtb0Vycm9yPScnO3RyeXthd2FpdCBvbkRlbW9Nb2RlQ2hhbmdlKCFkZW1vTW9kZSk7bG9hbnM9W107bXV0dWFsRnVuZHM9W107c3RvY2tzPVtdO2FjdGlvbnM9W107bG9hblN0YXR1cz0naWRsZSc7bXV0dWFsRnVuZFN0YXR1cz0naWRsZSc7c3RvY2tTdGF0dXM9J2lkbGUnO2FjdGlvbnNTdGF0dXM9J2lkbGUnO2Z1bmREZXRhaWw9bnVsbDtkYXlJdGVtcz1bXTtzZWxlY3RlZERheT1udWxsO2VkaXRPcHRpb25zPXtjYXRlZ29yaWVzOltdLG1lcmNoYW50czpbXSxhY2NvdW50czpbXX07b3B0aW9uc1N0YXR1cz0naWRsZSc7c2hvd01vbmV5PWZhbHNlO2F3YWl0IGxvYWRBY3Rpb25zKCk7fWNhdGNoKGNhdXNlKXtkZW1vRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc3dpdGNoIHByb2ZpbGVzLic7fWZpbmFsbHl7ZGVtb1N3aXRjaGluZz1mYWxzZTt9fVxuICBvbk1vdW50KCgpPT57dHJ5e2NvbW1pdG1lbnRTdHlsZT1sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbW9uZXktc3Rvcmllcy5jb21taXRtZW50LXN0eWxlJyl8fCdwbGF5ZnVsJzt9Y2F0Y2h7fWxvYWRBY3Rpb25zKCk7fSk7XG48L3NjcmlwdD5cbnsjaWYgbG9hbkhpc3Rvcnl9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1kZXRhaWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PmxvYW5IaXN0b3J5PW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkxPQU4gREVUQUlMUzwvcD48aDI+e2xvYW5IaXN0b3J5LmxvYW5OYW1lfTwvaDI+eyNpZiBsb2FuSGlzdG9yeVN0YXR1cz09PSdsb2FkaW5nJ308cD5Mb2FkaW5nIHBheW1lbnQgaGlzdG9yeeKApjwvcD57OmVsc2UgaWYgbG9hbkhpc3RvcnlTdGF0dXM9PT0nZXJyb3InfTxwPntsb2FuSGlzdG9yeUVycm9yfTwvcD57OmVsc2V9PHNlY3Rpb24gY2xhc3M9XCJpbnZlc3RtZW50LWhpc3RvcnlcIj48aDM+RU1JIHRpbWVsaW5lPC9oMz57I2lmIGxvYW5IaXN0b3J5Lmhpc3Rvcnk/Lmxlbmd0aH17I2VhY2ggbG9hbkhpc3RvcnkuaGlzdG9yeSBhcyBlbnRyeX08ZGl2IGNsYXNzPVwiaW52ZXN0bWVudC1oaXN0b3J5LXJvd1wiIGNsYXNzOmR1ZT17ZW50cnkuc3RhdHVzPT09J0RVRSd9PjxzcGFuPntkYXRlTGFiZWwoZW50cnkuZHVlRGF0ZSl9PC9zcGFuPjxzdHJvbmc+e21vbnRoTGFiZWwoZW50cnkubW9udGgpfSBFTUk8L3N0cm9uZz48c3BhbiBjbGFzcz1cImhpc3RvcnktYW1vdW50XCI+PGI+e21vbmV5KGVudHJ5LnBhaWRBbW91bnR8fGVudHJ5LnBsYW5uZWRBbW91bnQpfTwvYj48L3NwYW4+PHNtYWxsPntlbnRyeS5zdGF0dXM9PT0nUEFJRCc/YFBhaWQgb24gJHtkYXRlTGFiZWwoZW50cnkucGFpZEF0KX1gOmVudHJ5LnN0YXR1cz09PSdEVUUnPydEdWUgbm93JzplbnRyeS5zdGF0dXMudG9Mb3dlckNhc2UoKX08L3NtYWxsPnsjaWYgZW50cnkuc3RhdHVzPT09J0RVRSd9PGRpdiBjbGFzcz1cImxvYW4taGlzdG9yeS1hY3Rpb25cIj48RHVlUmVtaW5kZXIgZGV0YWlsPXtgRHVlIG5vdyDCtyAke21vbmV5KGVudHJ5LnBsYW5uZWRBbW91bnQpfWB9IGFjdGlvbkxhYmVsPXtgTWFyayAke21vbnRoTGFiZWwoZW50cnkubW9udGgpfSBFTUkgcGFpZGB9IG9uQWN0aW9uPXsoKT0+cGF5TG9hbkhpc3RvcnlFbWkoZW50cnkpfS8+PC9kaXY+ey9pZn08L2Rpdj57L2VhY2h9ezplbHNlfTxwPk5vIHBheW1lbnRzIHJlY29yZGVkIHlldC48L3A+ey9pZn08L3NlY3Rpb24+ey9pZn08L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgY29tbWl0bWVudEhpc3Rvcnl9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1kZXRhaWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PmNvbW1pdG1lbnRIaXN0b3J5PW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkNPTU1JVE1FTlQgREVUQUlMUzwvcD48aDI+e2NvbW1pdG1lbnRIaXN0b3J5LmxhYmVsfTwvaDI+eyNpZiBjb21taXRtZW50SGlzdG9yeVN0YXR1cz09PSdsb2FkaW5nJ308cD5Mb2FkaW5nIHBheW1lbnQgaGlzdG9yeeKApjwvcD57OmVsc2UgaWYgY29tbWl0bWVudEhpc3RvcnlTdGF0dXM9PT0nZXJyb3InfTxwPntjb21taXRtZW50SGlzdG9yeUVycm9yfTwvcD57OmVsc2V9PHNlY3Rpb24gY2xhc3M9XCJpbnZlc3RtZW50LWhpc3RvcnlcIj48aDM+UGF5bWVudCBoaXN0b3J5PC9oMz57I2lmIGNvbW1pdG1lbnRIaXN0b3J5Lmhpc3Rvcnk/Lmxlbmd0aH17I2VhY2ggY29tbWl0bWVudEhpc3RvcnkuaGlzdG9yeSBhcyBlbnRyeX08ZGl2IGNsYXNzPVwiaW52ZXN0bWVudC1oaXN0b3J5LXJvd1wiPjxzcGFuPntkYXRlTGFiZWwoZW50cnkuZHVlRGF0ZSl9PC9zcGFuPjxzdHJvbmc+e21vbnRoTGFiZWwoZW50cnkubW9udGgpfSBwYXltZW50PC9zdHJvbmc+PHNwYW4gY2xhc3M9XCJoaXN0b3J5LWFtb3VudFwiPjxiPnttb25leShjb21taXRtZW50SGlzdG9yeS5wbGFubmluZ0Ftb3VudCl9PC9iPjwvc3Bhbj48c21hbGw+RG9uZSBvbiB7ZGF0ZUxhYmVsKGVudHJ5LmNvbXBsZXRlZEF0KX08L3NtYWxsPjwvZGl2PnsvZWFjaH17OmVsc2V9PHA+Tm8gcGF5bWVudHMgcmVjb3JkZWQgeWV0LjwvcD57L2lmfTwvc2VjdGlvbj57L2lmfTwvc2VjdGlvbj48L2Rpdj57L2lmfVxuXG48QXBwSGVhZGVyIHtjb25uZWN0aW9uU3RhdHVzfSB7Y29ubmVjdGlvbkxhYmVsfSBvblJldHJ5PXtvblJldHJ5Q29ubmVjdGlvbn0gb25Ib21lPXsoKSA9PiBuYXZpZ2F0ZSgnaG9tZScpfSBvblByb2ZpbGU9eygpID0+IG5hdmlnYXRlKCd5b3UnKX0gLz5cbjxtYWluIGNsYXNzPVwiYXBwLXNoZWxsXCI+XG57I2lmIGNvbm5lY3Rpb25TdGF0dXM9PT0nb2ZmbGluZSd9PHNlY3Rpb24gY2xhc3M9XCJvZmZsaW5lLW5vdGljZVwiPjxzcGFuPuKXjDwvc3Bhbj48ZGl2PjxzdHJvbmc+e2NhY2hlVXBkYXRlZEF0PydTaG93aW5nIHlvdXIgbGFzdCBzYXZlZCB2aWV3JzonWW914oCZcmUgb2ZmbGluZSd9PC9zdHJvbmc+PHA+e2NhY2hlVXBkYXRlZEF0PydXZeKAmWxsIHJlZnJlc2ggYXV0b21hdGljYWxseSB3aGVuIHRoZSBzZXJ2aWNlIGlzIGJhY2suJzonWW91ciBsYXlvdXQgaXMgcmVhZHkuIENvbm5lY3Qgb25jZSB0byBsb2FkIHlvdXIgZXhwZW5zZXMgYW5kIHN0b3JpZXMuJ308L3A+PC9kaXY+PGJ1dHRvbiBvbjpjbGljaz17b25SZXRyeUNvbm5lY3Rpb259PlJldHJ5PC9idXR0b24+PC9zZWN0aW9uPnsvaWZ9XG57I2lmIHZpZXc9PT0naG9tZSd9XG4gIDxzZWN0aW9uIGNsYXNzPVwiYXBwLWhlYWRpbmdcIj48ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj57bW9udGhMYWJlbChzZWxlY3RlZE1vbnRoKS50b1VwcGVyQ2FzZSgpfTwvcD48aDE+e2dyZWV0aW5nKCl9PC9oMT48cD5IZXJl4oCZcyBob3cgeW91ciBtb250aCBpcyB1bmZvbGRpbmcuPC9wPjwvZGl2Pjwvc2VjdGlvbj5cbiAgPFNlY3Rpb25TdGF0ZSBzZWN0aW9uPXtjYWxlbmRhclNlY3Rpb259IHRpdGxlPVwiU3BlbmRpbmcgb3ZlcnZpZXdcIiByZXRyeT17cmVmcmVzaENhbGVuZGFyfT48YnV0dG9uIGNsYXNzPVwic3BlbmRpbmctaGVyb1wiIG9uOmNsaWNrPXsoKT0+bmF2aWdhdGUoJ3RyYW5zYWN0aW9ucycpfT48c3Bhbj5NT05USExZIFNQRU5ESU5HPC9zcGFuPjxzdHJvbmc+e21vbmV5KGRhdGEudG90YWxTcGVuZCl9IDxzbWFsbD5zcGVudDwvc21hbGw+PC9zdHJvbmc+PGI+e2RhdGEudHJhbnNhY3Rpb25Db3VudHx8MH0gdHJhbnNhY3Rpb25zIMK3IFZpZXcgdHJhbnNhY3Rpb25zIOKGkjwvYj48L2J1dHRvbj48L1NlY3Rpb25TdGF0ZT5cbiAgPHNlY3Rpb24gY2xhc3M9XCJob21lLXNlY3Rpb25cIj48ZGl2IGNsYXNzPVwic2VjdGlvbi10aXRsZVwiPjxkaXY+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPllPVVIgU1RPUklFUzwvcD48aDI+U21hbGwgc2lnbmFscywgY2xlYXJseSB0b2xkPC9oMj48L2Rpdj48YnV0dG9uIGNsYXNzPVwidGV4dC1saW5rXCIgb246Y2xpY2s9eygpPT5uYXZpZ2F0ZSgnc3RvcmllcycpfT5TZWUgYWxsPC9idXR0b24+PC9kaXY+PFNlY3Rpb25TdGF0ZSBzZWN0aW9uPXtzdG9yaWVzU2VjdGlvbn0gdGl0bGU9XCJZb3VyIHN0b3JpZXNcIiByZXRyeT17cmVmcmVzaFN0b3JpZXN9PnsjaWYgaG9tZVN0b3JpZXMubGVuZ3RofTxkaXYgY2xhc3M9XCJzdG9yeS1jYXJvdXNlbFwiIGFyaWEtbGFiZWw9XCJZb3VyIHN0b3JpZXNcIj48ZGl2IGNsYXNzPVwic3RvcnktZG90c1wiIGFyaWEtbGFiZWw9XCJDaG9vc2UgYSBzdG9yeVwiPnsjZWFjaCBob21lU3RvcmllcyBhcyBzdG9yeSxpbmRleH08YnV0dG9uIGNsYXNzOmFjdGl2ZT17aW5kZXg9PT1ob21lU3RvcnlJbmRleH0gYXJpYS1sYWJlbD17YFNob3cgc3RvcnkgJHtpbmRleCsxfSBvZiAke2hvbWVTdG9yaWVzLmxlbmd0aH06ICR7c3RvcnlDYXJkRmFjZShzdG9yeSkuaGVhZGluZ31gfSBhcmlhLWN1cnJlbnQ9e2luZGV4PT09aG9tZVN0b3J5SW5kZXg/J3RydWUnOnVuZGVmaW5lZH0gb246Y2xpY2s9eygpPT5ob21lU3RvcnlJbmRleD1pbmRleH0+PC9idXR0b24+ey9lYWNofTxzcGFuPntob21lU3RvcnlJbmRleCsxfSAvIHtob21lU3Rvcmllcy5sZW5ndGh9PC9zcGFuPjwvZGl2PjxkaXYgY2xhc3M9XCJzdG9yeS1jYXJvdXNlbC12aWV3cG9ydFwiIG9uOnRvdWNoc3RhcnQ9e2V2ZW50PT4oc3RvcnlSYWlsVG91Y2hTdGFydD1ldmVudC50b3VjaGVzWzBdLmNsaWVudFgpfSBvbjp0b3VjaGVuZD17ZXZlbnQ9PmVuZFJhaWxTd2lwZShldmVudCxob21lU3Rvcmllcy5sZW5ndGgsJ2hvbWUnKX0+PGRpdiBjbGFzcz1cInN0b3J5LWNhcm91c2VsLXRyYWNrXCIgc3R5bGU9e2B0cmFuc2Zvcm06dHJhbnNsYXRlWChjYWxjKCR7aG9tZVN0b3J5SW5kZXh9ICogLTkyJSkpYH0+eyNlYWNoIGhvbWVTdG9yaWVzIGFzIHN0b3J5LGluZGV4fTxidXR0b24gY2xhc3M9e2BzdG9yeS1jYXJvdXNlbC1jYXJkICR7c3RvcnlUb25lKHN0b3J5KX1gfSBjbGFzczpjdXJyZW50PXtpbmRleD09PWhvbWVTdG9yeUluZGV4fSBvbjpjbGljaz17KCk9Pm9wZW5TdG9yeShzdG9yeSl9PjxzcGFuIGNsYXNzPVwic3Rvcnktc291cmNlXCI+e3N0b3J5U291cmNlKHN0b3J5KX08L3NwYW4+PHN0cm9uZz57c3RvcnlDYXJkRmFjZShzdG9yeSkuaGVhZGluZ308L3N0cm9uZz48Yj57c3RvcnlDYXJkRmFjZShzdG9yeSkuZGlzcGxheVZhbHVlfTwvYj48aT7igLo8L2k+PC9idXR0b24+ey9lYWNofTwvZGl2PjwvZGl2PjwvZGl2Pns6ZWxzZX08ZGl2IGNsYXNzPVwic3RvcnktcmFpbC1lbXB0eVwiPllvdXIgc3RvcmllcyB3aWxsIGFwcGVhciBoZXJlIGFzIHlvdSBhZGQgZXhwZW5zZXMuPC9kaXY+ey9pZn08L1NlY3Rpb25TdGF0ZT48L3NlY3Rpb24+XG4gIDxzZWN0aW9uIGNsYXNzPVwiaG9tZS1zZWN0aW9uXCI+PGRpdiBjbGFzcz1cInNlY3Rpb24tdGl0bGVcIj48ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5SRUNFTlQgQUNUSVZJVFk8L3A+PGgyPllvdXIgbGF0ZXN0IGV4cGVuc2VzPC9oMj48L2Rpdj48YnV0dG9uIGNsYXNzPVwidGV4dC1saW5rXCIgb246Y2xpY2s9eygpPT5uYXZpZ2F0ZSgndHJhbnNhY3Rpb25zJyl9PlNlZSBhbGw8L2J1dHRvbj48L2Rpdj48ZGl2IGNsYXNzPVwiY29tcGFjdC1saXN0XCI+eyNlYWNoIHJlY2VudEl0ZW1zLnNsaWNlKDAsMykgYXMgaXRlbX08YnV0dG9uIGNsYXNzPVwicm93LW1haW5cIiBvbjpjbGljaz17KCk9PntuYXZpZ2F0ZSgndHJhbnNhY3Rpb25zJyk7c3RhcnRFZGl0KGl0ZW0pO319PjxkaXY+PHN0cm9uZz57bWVyY2hhbnQoaXRlbSl9PC9zdHJvbmc+PHNwYW4+e2NhdGVnb3J5KGl0ZW0pfSDCtyB7ZGF0ZUxhYmVsKHRyYW5zYWN0aW9uRGF0ZShpdGVtKSl9PC9zcGFuPjwvZGl2PjxiPuKIkiB7bW9uZXkoaXRlbS5hbW91bnQpfTwvYj48L2J1dHRvbj57OmVsc2V9PHAgY2xhc3M9XCJlbXB0eS1jb3B5XCI+Tm8gZXhwZW5zZXMgcmVjb3JkZWQgeWV0LjwvcD57L2VhY2h9PC9kaXY+PC9zZWN0aW9uPlxuICA8YnV0dG9uIGNsYXNzPVwieW91ci1tb25leS1jYXJkXCIgb246Y2xpY2s9e29wZW5Nb25leX0+PHNwYW4+4peSPC9zcGFuPjxkaXY+PHN0cm9uZz5Zb3VyIG1vbmV5PC9zdHJvbmc+PHNtYWxsPlNlZSB5b3VyIGluY29taW5nIGFuZCBvdXRnb2luZyBwbGFuLCBvbmx5IHdoZW4geW914oCZcmUgcmVhZHkuPC9zbWFsbD48L2Rpdj48Yj5FeHBsb3JlIOKAujwvYj48L2J1dHRvbj5cbns6ZWxzZSBpZiB2aWV3PT09J3RyYW5zYWN0aW9ucyd9XG4gIDxzZWN0aW9uIGNsYXNzPVwid29ya3NwYWNlLWhlYWRpbmdcIj48ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5FWFBFTlNFIFdPUktTUEFDRTwvcD48aDE+VHJhbnNhY3Rpb25zPC9oMT48cD5BSS1jYXB0dXJlZCBleHBlbnNlcywgcmVhZHkgZm9yIHlvdXIgcmV2aWV3LjwvcD48L2Rpdj48bGFiZWwgY2xhc3M9XCJtb250aC1zd2l0Y2hlclwiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uOmNsaWNrPXsoKT0+Y2hhbmdlTW9udGgoLTEpfT7ihpA8L2J1dHRvbj48aW5wdXQgdHlwZT1cIm1vbnRoXCIgdmFsdWU9e3NlbGVjdGVkTW9udGh9IG1heD17Y3VycmVudExvY2FsTW9udGgoKX0gb246Y2hhbmdlPXtlPT5vbk1vbnRoQ2hhbmdlKGUuY3VycmVudFRhcmdldC52YWx1ZSl9Lz48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbjpjbGljaz17KCk9PmNoYW5nZU1vbnRoKDEpfT7ihpI8L2J1dHRvbj48L2xhYmVsPjwvc2VjdGlvbj5cbiAgPFNlY3Rpb25TdGF0ZSBzZWN0aW9uPXtjYWxlbmRhclNlY3Rpb259IHRpdGxlPVwiU3BlbmRpbmcgY2FsZW5kYXJcIiByZXRyeT17cmVmcmVzaENhbGVuZGFyfT48c2VjdGlvbiBjbGFzcz1cIm1vbnRoLWNhcmRcIj48ZGl2IGNsYXNzPVwibW9udGgtc3VtbWFyeVwiPjxkaXY+PHNwYW4+VG90YWwgcmVjb3JkZWQ8L3NwYW4+PHN0cm9uZz57bW9uZXkoZGF0YS50b3RhbFNwZW5kKX08L3N0cm9uZz48L2Rpdj48ZGl2PjxzcGFuPlRyYW5zYWN0aW9uczwvc3Bhbj48c3Ryb25nPntkYXRhLnRyYW5zYWN0aW9uQ291bnR8fDB9PC9zdHJvbmc+PC9kaXY+PGRpdj48c3Bhbj5IaWdoZXN0IGRheTwvc3Bhbj48c3Ryb25nPnttb25leShkYXRhLmhpZ2hlc3RTcGVuZCl9PC9zdHJvbmc+PC9kaXY+PC9kaXY+PGRpdiBjbGFzcz1cIndlZWtkYXlzXCI+eyNlYWNoIFsnTW9uJywnVHVlJywnV2VkJywnVGh1JywnRnJpJywnU2F0JywnU3VuJ10gYXMgZH08c3Bhbj57ZH08L3NwYW4+ey9lYWNofTwvZGl2PjxkaXYgY2xhc3M9XCJjYWxlbmRhclwiPnsjZWFjaCBBcnJheShjYWxlbmRhci5sZWFkaW5nKSBhcyBffTxzcGFuPjwvc3Bhbj57L2VhY2h9eyNlYWNoIGNhbGVuZGFyLmRheXMgYXMgZH08YnV0dG9uIGNsYXNzOmZ1dHVyZT17ZC5mdXR1cmV9IGNsYXNzOnNlbGVjdGVkPXtzZWxlY3RlZERheT09PWQuZGF5fSBjbGFzcz17YGxldmVsLSR7ZC5pbnRlbnNpdHl9YH0gZGlzYWJsZWQ9e2QuZnV0dXJlfSBvbjpjbGljaz17KCk9PnNlbGVjdERhdGUoZCl9PntkLmRheX08L2J1dHRvbj57L2VhY2h9PC9kaXY+PGRpdiBjbGFzcz1cImxlZ2VuZFwiPjxzcGFuPkxvd2VyIHNwZW5kPC9zcGFuPjxkaXY+eyNlYWNoIFswLDEsMiwzLDRdIGFzIGx9PGkgY2xhc3M9e2BsZXZlbC0ke2x9YH0+PC9pPnsvZWFjaH08L2Rpdj48c3Bhbj5IaWdoZXIgc3BlbmQ8L3NwYW4+PC9kaXY+PC9zZWN0aW9uPjwvU2VjdGlvblN0YXRlPlxuICA8c2VjdGlvbiBjbGFzcz1cImFjdGl2aXR5LXBhbmVsIGFkYXB0aXZlLWFjdGl2aXR5XCI+PGRpdiBjbGFzcz1cImFjdGl2aXR5LXRhYnNcIj48YnV0dG9uIGNsYXNzOmFjdGl2ZT17YWN0aXZpdHlUYWI9PT0ncmVjZW50J30gb246Y2xpY2s9eygpPT5hY3Rpdml0eVRhYj0ncmVjZW50J30+UmVjZW50PC9idXR0b24+PGJ1dHRvbiBjbGFzczphY3RpdmU9e2FjdGl2aXR5VGFiPT09J2RheSd9IG9uOmNsaWNrPXsoKT0+YWN0aXZpdHlUYWI9J2RheSd9PntzZWxlY3RlZD9gJHtzZWxlY3RlZC5kYXl9IHNlbGVjdGVkYDonU2VsZWN0IGEgZGF0ZSd9PC9idXR0b24+PC9kaXY+eyNpZiBhY3Rpdml0eVRhYj09PSdkYXknJiZkYXlTdGF0dXM9PT0nbG9hZGluZyd9PGRpdiBjbGFzcz1cImFjdGl2aXR5LWxvYWRpbmdcIj5Mb2FkaW5nIHRyYW5zYWN0aW9uc+KApjwvZGl2Pns6ZWxzZSBpZiBhY3Rpdml0eVRhYj09PSdkYXknJiZkYXlTdGF0dXM9PT0nZXJyb3InfTxkaXYgY2xhc3M9XCJzZWN0aW9uLWVycm9yXCI+PHA+Q291bGQgbm90IGxvYWQgdGhpcyBkYXRlLjwvcD48YnV0dG9uIG9uOmNsaWNrPXtsb2FkRGF5fT5UcnkgYWdhaW48L2J1dHRvbj48L2Rpdj57OmVsc2V9PGRpdiBjbGFzcz1cImFjdGl2aXR5LXN1bW1hcnlcIj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+e2FjdGl2aXR5VGFiPT09J3JlY2VudCc/J1JFQ0VOVCBFWFBFTlNFUyc6c2VsZWN0ZWQ/YCR7c2VsZWN0ZWQuZGF5fSAke21vbnRoTGFiZWwoc2VsZWN0ZWRNb250aCl9YDonU0VMRUNUIEEgREFURSd9PC9wPjxoMj57YWN0aXZpdHlUYWI9PT0ncmVjZW50Jz9gJHtyZWNlbnRJdGVtcy5sZW5ndGh9IHJlY2VudCB0cmFuc2FjdGlvbnNgOnNlbGVjdGVkP2Ake3NlbGVjdGVkLnRyYW5zYWN0aW9uQ291bnR9IHRyYW5zYWN0aW9ucyDCtyAke21vbmV5KHNlbGVjdGVkLnRvdGFsU3BlbmQpfWA6J0Nob29zZSBhIGRhdGUgaW4gdGhlIGNhbGVuZGFyJ308L2gyPjwvZGl2PjxkaXYgY2xhc3M9XCJjb21wYWN0LWxpc3RcIj57I2VhY2ggdmlzaWJsZUl0ZW1zIGFzIGl0ZW19PGFydGljbGUgY2xhc3M6ZXhwYW5kZWQ9e2V4cGFuZGVkSWQ9PT1pdGVtLmlkfSBjbGFzcz1cImNvbXBhY3Qtcm93XCI+PGJ1dHRvbiBjbGFzcz1cInJvdy1tYWluXCIgb246Y2xpY2s9eygpPT5leHBhbmRlZElkPWV4cGFuZGVkSWQ9PT1pdGVtLmlkP251bGw6aXRlbS5pZH0+PGRpdj48c3Ryb25nPnttZXJjaGFudChpdGVtKX08L3N0cm9uZz48c3Bhbj57Y2F0ZWdvcnkoaXRlbSl9IMK3IHtkYXRlTGFiZWwodHJhbnNhY3Rpb25EYXRlKGl0ZW0pKX08L3NwYW4+PC9kaXY+PGRpdiBjbGFzcz1cInJvdy12YWx1ZVwiPjxiPuKIkiB7bW9uZXkoaXRlbS5hbW91bnQpfTwvYj48c3BhbiBjbGFzczpvcGVuPXtleHBhbmRlZElkPT09aXRlbS5pZH0gY2xhc3M9XCJyb3ctY2hldnJvblwiPuKMhDwvc3Bhbj48L2Rpdj48L2J1dHRvbj57I2lmIGV4cGFuZGVkSWQ9PT1pdGVtLmlkfTxkaXYgY2xhc3M9XCJyb3ctYWN0aW9uc1wiPjxidXR0b24gb246Y2xpY2s9eygpPT5zdGFydEVkaXQoaXRlbSl9PkVkaXQgdHJhbnNhY3Rpb248L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwiZGFuZ2VyXCIgb246Y2xpY2s9eygpPT5kZWxldGluZz1pdGVtfT5EZWxldGU8L2J1dHRvbj48L2Rpdj57L2lmfTwvYXJ0aWNsZT57OmVsc2V9PHAgY2xhc3M9XCJlbXB0eS1jb3B5XCI+Tm8gdHJhbnNhY3Rpb25zIGZvciB0aGlzIHZpZXcuPC9wPnsvZWFjaH08L2Rpdj57I2lmIGFjdGl2ZUl0ZW1zLmxlbmd0aD41fTxidXR0b24gY2xhc3M9XCJ2aWV3LWFsbFwiIG9uOmNsaWNrPXsoKT0+c2hvd0FsbD0hc2hvd0FsbH0+e3Nob3dBbGw/J1Nob3cgZmV3ZXIg4oaRJzpgVmlldyBhbGwgJHthY3RpdmVJdGVtcy5sZW5ndGh9IHRyYW5zYWN0aW9ucyDihpNgfTwvYnV0dG9uPnsvaWZ9ey9pZn08L3NlY3Rpb24+XG4gIDxidXR0b24gY2xhc3M9XCJ3aWRlLWJ1dHRvblwiIGRpc2FibGVkPXshc2VsZWN0ZWR8fGFkZGluZ0NvbnRleHR9IG9uOmNsaWNrPXthZGRNaXNzaW5nRGF0ZX0+e2FkZGluZ0NvbnRleHQ/J1ByZXBhcmluZyBXaGF0c0FwcOKApic6c2VsZWN0ZWQ/JysgQWRkIG1pc3NpbmcgZXhwZW5zZSc6J1NlbGVjdCBhIGRhdGUgdG8gYWRkIGFuIGV4cGVuc2UnfTwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJjbGVhbnVwLWNhcmRcIiBvbjpjbGljaz17KCk9PnNob3dOb3JtYWxpemF0aW9uPXRydWV9PjxzcGFuPuKcpjwvc3Bhbj48ZGl2PjxzdHJvbmc+RXhwZW5zZSBjbGVhbnVwPC9zdHJvbmc+PHNtYWxsPkZpeCBtZXJjaGFudCBhbmQgYWNjb3VudCBuYW1lcyBjYXB0dXJlZCBieSBBSS48L3NtYWxsPjwvZGl2PjxiPk9wZW4g4oC6PC9iPjwvYnV0dG9uPlxuezplbHNlIGlmIHZpZXc9PT0nc3Rvcmllcyd9XG4gIDxzZWN0aW9uIGNsYXNzPVwid29ya3NwYWNlLWhlYWRpbmdcIj48ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5ZT1VSIE1PTkVZLCBFWFBMQUlORUQ8L3A+PGgxPlN0b3JpZXM8L2gxPjxwPkluc2lnaHRzIGFjcm9zcyB0aGUgaW5mb3JtYXRpb24geW91IGNob29zZSB0byBzaGFyZS48L3A+PC9kaXY+PC9zZWN0aW9uPjxkaXYgY2xhc3M9XCJzdG9yeS1maWx0ZXJzXCI+eyNlYWNoIFsnQWxsJywnU3BlbmRpbmcnLCdJbnZlc3RpbmcnLCdQbGFubmluZyddIGFzIGZpbHRlcn08YnV0dG9uIGNsYXNzOmFjdGl2ZT17c3RvcnlGaWx0ZXI9PT1maWx0ZXJ9IG9uOmNsaWNrPXsoKT0+e3N0b3J5RmlsdGVyPWZpbHRlcjtzdG9yaWVzUmFpbEluZGV4PTA7fX0+e2ZpbHRlcn08L2J1dHRvbj57L2VhY2h9PC9kaXY+PGRpdiBjbGFzcz1cImNvbW1pdG1lbnQtc3R5bGUtY29udHJvbFwiPjxzcGFuPkNvbW1pdG1lbnQgc3R5bGU8L3NwYW4+PGJ1dHRvbiBjbGFzczphY3RpdmU9e2NvbW1pdG1lbnRTdHlsZT09PSdjYWxtJ30gb246Y2xpY2s9eygpPT5zZXRDb21taXRtZW50U3R5bGUoJ2NhbG0nKX0+Q2FsbTwvYnV0dG9uPjxidXR0b24gY2xhc3M6YWN0aXZlPXtjb21taXRtZW50U3R5bGU9PT0ncGxheWZ1bCd9IG9uOmNsaWNrPXsoKT0+c2V0Q29tbWl0bWVudFN0eWxlKCdwbGF5ZnVsJyl9PlBsYXlmdWwg4pyoPC9idXR0b24+PC9kaXY+PFNlY3Rpb25TdGF0ZSBzZWN0aW9uPXtzdG9yaWVzU2VjdGlvbn0gdGl0bGU9XCJTdG9yaWVzXCIgcmV0cnk9e3JlZnJlc2hTdG9yaWVzfT57I2lmIGZpbHRlcmVkU3Rvcmllcy5sZW5ndGh9PGRpdiBjbGFzcz1cInN0b3J5LWNhcm91c2VsIHN0b3J5LWNhcm91c2VsLWZ1bGxcIiBhcmlhLWxhYmVsPXtgJHtzdG9yeUZpbHRlcn0gc3Rvcmllc2B9PjxkaXYgY2xhc3M9XCJzdG9yeS1kb3RzXCIgYXJpYS1sYWJlbD1cIkNob29zZSBhIHN0b3J5XCI+eyNlYWNoIGZpbHRlcmVkU3RvcmllcyBhcyBzdG9yeSxpbmRleH08YnV0dG9uIGNsYXNzOmFjdGl2ZT17aW5kZXg9PT1zdG9yaWVzUmFpbEluZGV4fSBhcmlhLWxhYmVsPXtgU2hvdyBzdG9yeSAke2luZGV4KzF9IG9mICR7ZmlsdGVyZWRTdG9yaWVzLmxlbmd0aH06ICR7c3RvcnlDYXJkRmFjZShzdG9yeSkuaGVhZGluZ31gfSBhcmlhLWN1cnJlbnQ9e2luZGV4PT09c3Rvcmllc1JhaWxJbmRleD8ndHJ1ZSc6dW5kZWZpbmVkfSBvbjpjbGljaz17KCk9PnN0b3JpZXNSYWlsSW5kZXg9aW5kZXh9PjwvYnV0dG9uPnsvZWFjaH08c3Bhbj57c3Rvcmllc1JhaWxJbmRleCsxfSAvIHtmaWx0ZXJlZFN0b3JpZXMubGVuZ3RofTwvc3Bhbj48L2Rpdj48ZGl2IGNsYXNzPVwic3RvcnktY2Fyb3VzZWwtdmlld3BvcnRcIiBvbjp0b3VjaHN0YXJ0PXtldmVudD0+KHN0b3J5UmFpbFRvdWNoU3RhcnQ9ZXZlbnQudG91Y2hlc1swXS5jbGllbnRYKX0gb246dG91Y2hlbmQ9e2V2ZW50PT5lbmRSYWlsU3dpcGUoZXZlbnQsZmlsdGVyZWRTdG9yaWVzLmxlbmd0aCwnZnVsbCcpfT48ZGl2IGNsYXNzPVwic3RvcnktY2Fyb3VzZWwtdHJhY2tcIiBzdHlsZT17YHRyYW5zZm9ybTp0cmFuc2xhdGVYKGNhbGMoJHtzdG9yaWVzUmFpbEluZGV4fSAqIC05MiUpKWB9PnsjZWFjaCBmaWx0ZXJlZFN0b3JpZXMgYXMgc3RvcnksaW5kZXh9PGJ1dHRvbiBjbGFzcz17YHN0b3J5LWNhcm91c2VsLWNhcmQgJHtzdG9yeVRvbmUoc3RvcnkpfWB9IGNsYXNzOmNvbW1pdG1lbnQtY2FyZD17aXNDb21taXRtZW50KHN0b3J5KX0gY2xhc3M6cGxheWZ1bD17aXNDb21taXRtZW50KHN0b3J5KSYmY29tbWl0bWVudFN0eWxlPT09J3BsYXlmdWwnfSBjbGFzczpjdXJyZW50PXtpbmRleD09PXN0b3JpZXNSYWlsSW5kZXh9IG9uOmNsaWNrPXsoKT0+b3BlblN0b3J5KHN0b3J5KX0+PHNwYW4gY2xhc3M9XCJzdG9yeS1zb3VyY2VcIj57c3RvcnlTb3VyY2Uoc3RvcnkpfTwvc3Bhbj57I2lmIHN0b3J5SWNvbihzdG9yeSl9PHNwYW4gY2xhc3M9XCJjb21taXRtZW50LWljb25cIj57c3RvcnlJY29uKHN0b3J5KX08L3NwYW4+ey9pZn08c3Ryb25nPntzdG9yeUhlYWRpbmcoc3RvcnkpfTwvc3Ryb25nPjxiPntzdG9yeUNhcmRGYWNlKHN0b3J5KS5kaXNwbGF5VmFsdWV9PC9iPjxpPuKAujwvaT48L2J1dHRvbj57L2VhY2h9PC9kaXY+PC9kaXY+PC9kaXY+ezplbHNlfTxkaXYgY2xhc3M9XCJlbXB0eS1zdGF0ZVwiPjxzcGFuPuKcpjwvc3Bhbj48aDI+Tm8ge3N0b3J5RmlsdGVyLnRvTG93ZXJDYXNlKCl9IHN0b3JpZXMgeWV0PC9oMj48cD5BcyB5b3UgY2hvb3NlIHRvIGFkZCBtb3JlIGluZm9ybWF0aW9uLCByZWxldmFudCBzdG9yaWVzIHdpbGwgYXBwZWFyIGhlcmUuPC9wPjwvZGl2PnsvaWZ9PC9TZWN0aW9uU3RhdGU+XG57OmVsc2V9XG4gIDxQcm9maWxlU2V0dGluZ3Mge2RlbW9Nb2RlfSB7ZGVtb1N3aXRjaGluZ30ge2RlbW9FcnJvcn0ge2xvZ2dpbmdPdXR9IHtzaWduT3V0RXJyb3J9IHtzdG9yeUNvbnRyb2xzfSBvbk5hdmlnYXRlPXtuYXZpZ2F0ZX0gb25PcGVuTW9uZXk9e29wZW5Nb25leX0gb25EZW1vTW9kZUNoYW5nZT17c3dpdGNoRGVtb01vZGV9IG9uU2lnbk91dD17c2lnbk91dH0gLz5cbnsvaWZ9XG48L21haW4+XG48Qm90dG9tTmF2IHt2aWV3fSBvbk5hdmlnYXRlPXtuYXZpZ2F0ZX0gLz5cblxuPCEtLSBzdmVsdGUtaWdub3JlIGExMXlfY2xpY2tfZXZlbnRzX2hhdmVfa2V5X2V2ZW50cyAtLT5cbnsjaWYgc2hvd01vbmV5fVxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIiBvbjpjbGljaz17Y2xvc2VNb25leX0gb246a2V5ZG93bj17KGV2ZW50KT0+ZXZlbnQua2V5PT09J0VzY2FwZScmJmNsb3NlTW9uZXkoKX0gcm9sZT1cInByZXNlbnRhdGlvblwiPlxuICAgIDxzZWN0aW9uIGNsYXNzPVwibW9kYWwgbW9uZXktbW9kYWxcIiBvbjpjbGlja3xzdG9wUHJvcGFnYXRpb24gcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9e2Nsb3NlTW9uZXl9PsOXPC9idXR0b24+XG4gICAgICA8cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+T1BUSU9OQUwsIFBSSVZBVEUsIFlPVVJTPC9wPjxoMj5CdWlsZCB5b3VyIGNvbXBsZXRlIG1vbmV5IHBpY3R1cmU8L2gyPlxuICAgICAgPHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5Zb3UgY2hvb3NlIHdoYXQgdG8gYWRkLiBOb3RoaW5nIGlzIHJlcXVpcmVkLCBhbmQgeW91IGNhbiByZW1vdmUgYSBtb2R1bGUgYW55dGltZS48L3A+XG4gICAgICA8c2VjdGlvbiBjbGFzcz1cImluY29tZS1tb2R1bGVcIj48ZGl2IGNsYXNzPVwibG9hbnMtaGVhZGluZ1wiPjxkaXY+PHN0cm9uZz5TYWxhcnkgb3V0bG9vazwvc3Ryb25nPjxzbWFsbD5Qcml2YXRlIGVzdGltYXRlIOKAlCBuZXZlciB0cmVhdGVkIGFzIHlvdXIgYWNjb3VudCBiYWxhbmNlPC9zbWFsbD48L2Rpdj48c3BhbiBjbGFzcz1cInZlcmlmaWVkLXBpbGxcIj5PcHRpb25hbDwvc3Bhbj48L2Rpdj57I2lmIGluY29tZVN0YXR1cz09PSdsb2FkaW5nJ308cD5Mb2FkaW5nIHlvdXIgcHJpdmF0ZSBvdXRsb29r4oCmPC9wPns6ZWxzZSBpZiBpbmNvbWVTdGF0dXM9PT0nZXJyb3InfTxkaXYgY2xhc3M9XCJsb2FuLXN0YXRlIGVycm9yXCI+PHNwYW4+e2luY29tZUVycm9yfTwvc3Bhbj48YnV0dG9uIG9uOmNsaWNrPXtsb2FkSW5jb21lT3V0bG9va30+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+ezplbHNlIGlmIGluY29tZU91dGxvb2suc2FsYXJ5fTxkaXYgY2xhc3M9XCJpbmNvbWUtc3VtbWFyeSBtYXNrZWRcIj48c3Bhbj5TYWxhcnkgc2F2ZWQ8L3NwYW4+PHN0cm9uZz57aW5jb21lT3V0bG9vay5zYWxhcnkubWFza2VkVmFsdWV9PC9zdHJvbmc+PGJ1dHRvbiBjbGFzcz1cImluY29tZS1lZGl0XCIgb246Y2xpY2s9e29wZW5JbmNvbWVGbG93fSBhcmlhLWxhYmVsPVwiVXBkYXRlIHNhbGFyeSBvdXRsb29rXCIgdGl0bGU9XCJVcGRhdGUgc2FsYXJ5IG91dGxvb2tcIj7wn5SnPC9idXR0b24+PHNtYWxsPk1hc2tlZCBiZWZvcmUgaXQgcmVhY2hlcyB0aGlzIHNjcmVlbi48L3NtYWxsPjwvZGl2Pns6ZWxzZX08ZGl2IGNsYXNzPVwiaW5jb21lLXN1bW1hcnlcIj48c3Ryb25nPlN0YXJ0IHdpdGggYSByYW5nZTwvc3Ryb25nPjxzbWFsbD5Pbmx5IHlvdSBkZWNpZGUgd2hldGhlciB0byBzaGFyZSBhIHJhbmdlIG9yIGFuIGV4YWN0IGFtb3VudC48L3NtYWxsPjwvZGl2PjxidXR0b24gY2xhc3M9XCJhZGQtZnVuZC1yb3dcIiBvbjpjbGljaz17b3BlbkluY29tZUZsb3d9PlNldCB1cCBzYWxhcnkgb3V0bG9vazwvYnV0dG9uPnsvaWZ9PC9zZWN0aW9uPlxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJsb2Fucy1tb2R1bGVcIiBkYXRhLXRlc3RpZD1cIm1vbnRobHktY29tbWl0bWVudHMtc2VjdGlvblwiPjxkaXYgY2xhc3M9XCJsb2Fucy1oZWFkaW5nXCI+PGRpdj48c3Ryb25nPk1vbnRobHkgY29tbWl0bWVudHM8L3N0cm9uZz48c21hbGw+UmVudCwgYmlsbHMsIHN1YnNjcmlwdGlvbnMgYW5kIG90aGVyIHJlcGVhdGFibGUgb2JsaWdhdGlvbnM8L3NtYWxsPjwvZGl2PjwvZGl2PnsjaWYgY29tbWl0bWVudFN0YXR1cz09PSdsb2FkaW5nJ308cCBjbGFzcz1cImxvYW4tc3RhdGVcIj5Mb2FkaW5nIGNvbW1pdG1lbnRz4oCmPC9wPns6ZWxzZSBpZiBjb21taXRtZW50U3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwibG9hbi1zdGF0ZSBlcnJvclwiPjxzcGFuPntjb21taXRtZW50RXJyb3J9PC9zcGFuPjxidXR0b24gb246Y2xpY2s9e2xvYWRDb21taXRtZW50c30+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+ezplbHNlIGlmIGNvbW1pdG1lbnRzLmxlbmd0aH17I2VhY2ggY29tbWl0bWVudHMgYXMgY29tbWl0bWVudH08YXJ0aWNsZSBjbGFzcz1cImxvYW4tcm93XCIgZGF0YS10ZXN0aWQ9e2Btb250aGx5LWNvbW1pdG1lbnQtJHtjb21taXRtZW50LmlkfWB9IGNsYXNzOmR1ZS1yZWN1cnJpbmc9e2NvbW1pdG1lbnQuY3VycmVudE9jY3VycmVuY2U/LnN0YXR1cz09PSdEVUUnfT48c3Bhbj7ihrs8L3NwYW4+PGRpdj48c3Ryb25nIGNsYXNzPVwibG9hbi1uYW1lXCI+e2NvbW1pdG1lbnQubGFiZWx9PGJ1dHRvbiBjbGFzcz1cImxvYW4tZWRpdFwiIG9uOmNsaWNrPXsoKT0+b3BlbkNvbW1pdG1lbnRGb3JtKGNvbW1pdG1lbnQpfSBhcmlhLWxhYmVsPXtgRWRpdCAke2NvbW1pdG1lbnQubGFiZWx9YH0gdGl0bGU9XCJFZGl0IG1vbnRobHkgY29tbWl0bWVudFwiPvCflKc8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwibG9hbi1kZWxldGVcIiBvbjpjbGljaz17KCk9PnJlbW92ZUNvbW1pdG1lbnQoY29tbWl0bWVudCl9IGFyaWEtbGFiZWw9e2BEZWxldGUgJHtjb21taXRtZW50LmxhYmVsfWB9IHRpdGxlPVwiRGVsZXRlIG1vbnRobHkgY29tbWl0bWVudFwiIGRpc2FibGVkPXtjb21taXRtZW50RGVsZXRpbmdJZCE9PW51bGx9Pntjb21taXRtZW50RGVsZXRpbmdJZD09PWNvbW1pdG1lbnQuaWQ/J+KApic6J/Cfl5EnfTwvYnV0dG9uPjwvc3Ryb25nPjxzbWFsbD57Y29tbWl0bWVudC5hbW91bnRNb2RlPT09J1JFQ0VOVF9CSUxMX0VTVElNQVRFJz8nUmVjZW50LWJpbGwgZXN0aW1hdGUnOidNb250aGx5IHBsYW5uaW5nIGFtb3VudCd9e2NvbW1pdG1lbnQuZHVlRGF5P2AgwrcgZHVlIGFyb3VuZCB0aGUgJHtjb21taXRtZW50LmR1ZURheX1gOicnfTwvc21hbGw+PC9kaXY+PGRpdj48Yj57bW9uZXkoY29tbWl0bWVudC5wbGFubmluZ0Ftb3VudCl9L21vPC9iPjxzbWFsbD57Y29tbWl0bWVudC5jdXJyZW50T2NjdXJyZW5jZT8uc3RhdHVzPT09J0NPTVBMRVRFRCc/J2RvbmUnOmNvbW1pdG1lbnQuc3RhdHVzLnRvTG93ZXJDYXNlKCl9PC9zbWFsbD48L2Rpdj48Vmlld0RldGFpbHNMaW5rIG9uQWN0aW9uPXsoKT0+b3BlbkNvbW1pdG1lbnRIaXN0b3J5KGNvbW1pdG1lbnQpfS8+eyNpZiBjb21taXRtZW50LmN1cnJlbnRPY2N1cnJlbmNlPy5zdGF0dXM9PT0nRFVFJ308ZGl2IGNsYXNzPVwibG9hbi1kdWUtYWN0aW9uXCI+PER1ZVJlbWluZGVyIGRldGFpbD17YER1ZSBub3cgwrcgJHttb25leShjb21taXRtZW50LnBsYW5uaW5nQW1vdW50KX1gfSBhY3Rpb25MYWJlbD1cIk1hcmsgY29tbWl0bWVudCBkb25lXCIgb25BY3Rpb249eygpPT5tYXJrQ29tbWl0bWVudERvbmUoY29tbWl0bWVudCl9Lz48L2Rpdj57OmVsc2UgaWYgY29tbWl0bWVudC5jdXJyZW50T2NjdXJyZW5jZT8uc3RhdHVzPT09J0NPTVBMRVRFRCd9PGRpdiBjbGFzcz1cImxvYW4tZHVlLWFjdGlvblwiPjxzbWFsbD5Eb25lIG9uIHtkYXRlTGFiZWwoYCR7Y29tbWl0bWVudC5jdXJyZW50T2NjdXJyZW5jZS5jb21wbGV0ZWRBdH1UMTI6MDA6MDBgKX08L3NtYWxsPjwvZGl2PnsvaWZ9PC9hcnRpY2xlPnsvZWFjaH17OmVsc2V9PHAgY2xhc3M9XCJsb2FuLXN0YXRlXCI+Tm8gcmVjdXJyaW5nIGNvbW1pdG1lbnRzIHlldC48L3A+ey9pZn08YnV0dG9uIGNsYXNzPVwiYWRkLWxvYW4tcm93XCIgb246Y2xpY2s9eygpPT5vcGVuQ29tbWl0bWVudEZvcm0oKX0+77yLIEFkZCBhIG1vbnRobHkgY29tbWl0bWVudDwvYnV0dG9uPjwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzPVwibG9hbnMtbW9kdWxlXCI+PGRpdiBjbGFzcz1cImxvYW5zLWhlYWRpbmdcIj48ZGl2PjxzdHJvbmc+Q3JlZGl0IGNhcmRzPC9zdHJvbmc+PHNtYWxsPlR1cm4gY2FwdHVyZWQgY2FyZCBzcGVuZGluZyBpbnRvIHRoZSBiaWxsIGR1ZSBuZXh0IG1vbnRoPC9zbWFsbD48L2Rpdj48L2Rpdj57I2lmIGNyZWRpdENhcmRTdGF0dXM9PT0nbG9hZGluZyd9PHAgY2xhc3M9XCJsb2FuLXN0YXRlXCI+TG9hZGluZyBjcmVkaXQgY2FyZHPigKY8L3A+ezplbHNlIGlmIGNyZWRpdENhcmRTdGF0dXM9PT0nZXJyb3InfTxkaXYgY2xhc3M9XCJsb2FuLXN0YXRlIGVycm9yXCI+PHNwYW4+e2NyZWRpdENhcmRFcnJvcn08L3NwYW4+PGJ1dHRvbiBvbjpjbGljaz17bG9hZENyZWRpdENhcmRzfT5UcnkgYWdhaW48L2J1dHRvbj48L2Rpdj57OmVsc2UgaWYgY3JlZGl0Q2FyZHMubGVuZ3RofXsjZWFjaCBjcmVkaXRDYXJkcyBhcyBjYXJkfTxhcnRpY2xlIGNsYXNzPVwibG9hbi1yb3dcIj48c3Bhbj7ilqM8L3NwYW4+PGRpdj48c3Ryb25nIGNsYXNzPVwibG9hbi1uYW1lXCI+e2NhcmQuY2FyZE5hbWV9PGJ1dHRvbiBjbGFzcz1cImxvYW4tZWRpdFwiIG9uOmNsaWNrPXsoKT0+b3BlbkNyZWRpdENhcmRGb3JtKGNhcmQpfSBhcmlhLWxhYmVsPXtgRWRpdCAke2NhcmQuY2FyZE5hbWV9YH0gdGl0bGU9XCJFZGl0IGNyZWRpdCBjYXJkXCI+8J+UpzwvYnV0dG9uPjwvc3Ryb25nPjxzbWFsbD57Y2FyZC5pc3N1ZXJOYW1lfSDCtyBjYXB0dXJlZCBhcyB7Y2FyZC5hY2NvdW50TmFtZX08L3NtYWxsPjwvZGl2PjxkaXY+PGI+RHVlIHtjYXJkLmR1ZURheX08L2I+PHNtYWxsPlN0YXRlbWVudCB7Y2FyZC5zdGF0ZW1lbnREYXl9PC9zbWFsbD48L2Rpdj48L2FydGljbGU+ey9lYWNofXs6ZWxzZX08cCBjbGFzcz1cImxvYW4tc3RhdGVcIj5BZGQgYSBjYXJkIG9uY2UgaXQgYXBwZWFycyBhcyBhbiBhY2NvdW50IGluIHlvdXIgY2FwdHVyZWQgZXhwZW5zZXMuPC9wPnsvaWZ9PGJ1dHRvbiBjbGFzcz1cImFkZC1sb2FuLXJvd1wiIG9uOmNsaWNrPXsoKT0+b3BlbkNyZWRpdENhcmRGb3JtKCl9Pu+8iyBBZGQgYSBjcmVkaXQgY2FyZDwvYnV0dG9uPjwvc2VjdGlvbj5cbiAgICAgIHsjZWFjaCBbWyfil5InLCdFbWVyZ2VuY3kgZnVuZCcsJ1RyYWNrIHlvdXIgc2FmZXR5IGN1c2hpb24nXSxbJ+KXjicsJ0dvYWxzJywnUGxhbiBmb3Igd2hhdCBtYXR0ZXJzJ10sWyfilqQnLCdCdWRnZXRzJywnU2V0IGdlbnRsZSBzcGVuZGluZyBsaW1pdHMnXV0gYXMgbW9kdWxlfVxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwibW9kdWxlLXJvd1wiIG9uOmNsaWNrPXtjbG9zZU1vbmV5fT48c3Bhbj57bW9kdWxlWzBdfTwvc3Bhbj48ZGl2PjxzdHJvbmc+e21vZHVsZVsxXX08L3N0cm9uZz48c21hbGw+e21vZHVsZVsyXX08L3NtYWxsPjwvZGl2PjxiPkNvbWluZyBzb29uPC9iPjwvYnV0dG9uPlxuICAgICAgey9lYWNofVxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJtdXR1YWwtZnVuZHMtbW9kdWxlXCI+PGRpdiBjbGFzcz1cImxvYW5zLWhlYWRpbmdcIj48ZGl2PjxzdHJvbmc+TXV0dWFsIGZ1bmRzPC9zdHJvbmc+PHNtYWxsPlBvcnRmb2xpbyB2YWx1ZSBmcm9tIHRoZSBsYXRlc3QgYXZhaWxhYmxlIE5BVjwvc21hbGw+PC9kaXY+PHNwYW4gY2xhc3M9XCJ2ZXJpZmllZC1waWxsXCI+U2NoZW1lIEFQSTwvc3Bhbj48L2Rpdj57I2lmIG11dHVhbEZ1bmRTdGF0dXM9PT0nbG9hZGluZyd9PHA+TG9hZGluZyB5b3VyIGZ1bmRz4oCmPC9wPns6ZWxzZSBpZiBtdXR1YWxGdW5kU3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwibG9hbi1zdGF0ZSBlcnJvclwiPjxzcGFuPnttdXR1YWxGdW5kRXJyb3J9PC9zcGFuPjxidXR0b24gb246Y2xpY2s9e2xvYWRNdXR1YWxGdW5kc30+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+ezplbHNlIGlmIG11dHVhbEZ1bmRzLmxlbmd0aH08c2VjdGlvbiBjbGFzcz1cInBvcnRmb2xpby10b3RhbFwiPjxzcGFuPlRvdGFsIHBvcnRmb2xpbyB2YWx1ZTwvc3Bhbj57I2lmIG11dHVhbFBvcnRmb2xpby5jdXJyZW50IT09bnVsbH08c3Ryb25nPnttb25leShtdXR1YWxQb3J0Zm9saW8uY3VycmVudCl9PC9zdHJvbmc+PHNtYWxsIGNsYXNzOnBvc2l0aXZlPXtOdW1iZXIobXV0dWFsUG9ydGZvbGlvLnBubCk+PTB9IGNsYXNzOm5lZ2F0aXZlPXtOdW1iZXIobXV0dWFsUG9ydGZvbGlvLnBubCk8MH0+e211dHVhbFBvcnRmb2xpby5wbmw+PTA/JysnOicnfXttb25leShtdXR1YWxQb3J0Zm9saW8ucG5sKX0gb3ZlcmFsbCBQJmFtcDtMPC9zbWFsbD57OmVsc2V9PHN0cm9uZz57bW9uZXkobXV0dWFsUG9ydGZvbGlvLmludmVzdGVkKX08L3N0cm9uZz48c21hbGw+Q3VycmVudCB2YWx1YXRpb24gaXMgdGVtcG9yYXJpbHkgdW5hdmFpbGFibGU8L3NtYWxsPnsvaWZ9PC9zZWN0aW9uPjxkaXYgY2xhc3M9XCJmdW5kLWNhcmQtbGlzdFwiPnsjZWFjaCBtdXR1YWxGdW5kcyBhcyBmdW5kfTxidXR0b24gY2xhc3M9e2BmdW5kLWNhcmQgJHtmdW5kQWNjZW50KGZ1bmQuaWQpfWB9IG9uOmNsaWNrPXsoKT0+b3BlbkZ1bmREZXRhaWwoZnVuZC5pZCl9IGFyaWEtbGFiZWw9e2BPcGVuICR7ZnVuZC5zY2hlbWVOYW1lfSBkZXRhaWxzYH0+PHNwYW4gY2xhc3M9XCJmdW5kLWNhcmQtb3JiXCI+PC9zcGFuPjxkaXYgY2xhc3M9XCJmdW5kLWNhcmQtdGl0bGVcIj48c3Ryb25nPntmdW5kLnNjaGVtZU5hbWV9PC9zdHJvbmc+PHNwYW4gY2xhc3M9XCJmdW5kLWRlbGV0ZVwiIHJvbGU9XCJidXR0b25cIiB0YWJpbmRleD1cIjBcIiBhcmlhLWxhYmVsPXtgRGVsZXRlICR7ZnVuZC5zY2hlbWVOYW1lfWB9IHRpdGxlPVwiRGVsZXRlIG11dHVhbCBmdW5kXCIgb246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uPXsoKT0+cmVtb3ZlTXV0dWFsRnVuZChmdW5kKX0gb246a2V5ZG93bnxzdG9wUHJvcGFnYXRpb249eyhldmVudCk9PntpZihldmVudC5rZXk9PT0nRW50ZXInfHxldmVudC5rZXk9PT0nICcpe2V2ZW50LnByZXZlbnREZWZhdWx0KCk7cmVtb3ZlTXV0dWFsRnVuZChmdW5kKTt9fX0+e211dHVhbEZ1bmREZWxldGluZ0lkPT09ZnVuZC5pZD8n4oCmJzon8J+XkSd9PC9zcGFuPjxzbWFsbD57ZnVuZFN1YnRpdGxlKGZ1bmQuc2NoZW1lTmFtZSl9PC9zbWFsbD48L2Rpdj57I2lmIGZ1bmQuY3VycmVudFZhbHVlIT09bnVsbH08ZGl2IGNsYXNzPVwiZnVuZC1jYXJkLXZhbHVlc1wiPjxkaXYgY2xhc3M6cG9zaXRpdmU9e051bWJlcihmdW5kLnByb2ZpdE9yTG9zcyk+PTB9IGNsYXNzOm5lZ2F0aXZlPXtOdW1iZXIoZnVuZC5wcm9maXRPckxvc3MpPDB9PjxzcGFuPlAmYW1wO0w8L3NwYW4+PGI+e051bWJlcihmdW5kLnByb2ZpdE9yTG9zcyk+PTA/JysnOicnfXtjb21wYWN0TW9uZXkoZnVuZC5wcm9maXRPckxvc3MpfTwvYj48c21hbGw+e051bWJlcihmdW5kLnByb2ZpdE9yTG9zc1BlcmNlbnQpPj0wPycrJzonJ317TnVtYmVyKGZ1bmQucHJvZml0T3JMb3NzUGVyY2VudCkudG9GaXhlZCgyKX0lPC9zbWFsbD48L2Rpdj48ZGl2PjxzcGFuPkludmVzdGVkPC9zcGFuPjxiPntjb21wYWN0TW9uZXkoZnVuZC5pbnZlc3RlZCl9PC9iPjwvZGl2PjxkaXY+PHNwYW4+Q3VycmVudDwvc3Bhbj48Yj57Y29tcGFjdE1vbmV5KGZ1bmQuY3VycmVudFZhbHVlKX08L2I+PC9kaXY+PC9kaXY+PHAgY2xhc3M9XCJmdW5kLWNhcmQtbmF2XCI+TGF0ZXN0IE5BViB7bW9uZXlEZWNpbWFsKGZ1bmQubGF0ZXN0TmF2KX0geyNpZiAhZnVuZC5hY3RpdmVTaXB9PHNwYW4gY2xhc3M9XCJzdG9jay1yZWN1cnJpbmctYmVsbFwiIHJvbGU9XCJidXR0b25cIiB0YWJpbmRleD1cIjBcIiBhcmlhLWxhYmVsPXtgU2V0IFNJUCBmb3IgJHtmdW5kLnNjaGVtZU5hbWV9YH0gdGl0bGU9XCJTZXQgU0lQXCIgb246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uPXsoKT0+b3BlbkZ1bmRTaXBQbGFuKGZ1bmQpfSBvbjprZXlkb3dufHN0b3BQcm9wYWdhdGlvbj17KGV2ZW50KT0+e2lmKGV2ZW50LmtleT09PSdFbnRlcid8fGV2ZW50LmtleT09PScgJyl7ZXZlbnQucHJldmVudERlZmF1bHQoKTtvcGVuRnVuZFNpcFBsYW4oZnVuZCk7fX19PvCflJQ8L3NwYW4+ey9pZn08L3A+ezplbHNlfTxwIGNsYXNzPVwiZnVuZC12YWx1YXRpb24tdW5hdmFpbGFibGVcIj5DdXJyZW50IHZhbHVhdGlvbiBpcyB0ZW1wb3JhcmlseSB1bmF2YWlsYWJsZS4gWW91ciBpbnZlc3RlZCBhbW91bnQgaXMge21vbmV5KGZ1bmQuaW52ZXN0ZWQpfS48L3A+ey9pZn08Zm9vdGVyPjxzcGFuIGNsYXNzPVwiZnVuZC1zaXAtc3VtbWFyeVwiPntmdW5kLmFjdGl2ZVNpcD9gMSBTSVAgwrcgJHtjb21wYWN0TW9uZXkoZnVuZC5hY3RpdmVTaXAuYW1vdW50KX0gb24gdGhlICR7ZnVuZC5hY3RpdmVTaXAuZGF5fSR7ZnVuZC5hY3RpdmVTaXAuZGF5PT09MT8nc3QnOmZ1bmQuYWN0aXZlU2lwLmRheT09PTI/J25kJzpmdW5kLmFjdGl2ZVNpcC5kYXk9PT0zPydyZCc6J3RoJ30gb2YgZXZlcnkgbW9udGhgOidObyBhY3RpdmUgU0lQJ308L3NwYW4+PHNwYW4gY2xhc3M9XCJmdW5kLWFjdGlvbnNcIj48c3Bhbj5WaWV3IGRldGFpbHMg4oaSPC9zcGFuPjxzcGFuIGNsYXNzPVwiZnVuZC1sdW1wLXN1bVwiIHJvbGU9XCJidXR0b25cIiB0YWJpbmRleD1cIjBcIiBvbjpjbGlja3xzdG9wUHJvcGFnYXRpb249eygpPT5vcGVuTHVtcFN1bShmdW5kKX0+77yLIEx1bXAgc3VtPC9zcGFuPjwvc3Bhbj48L2Zvb3Rlcj57I2lmIGZ1bmQuY3VycmVudFNpcD8uc3RhdHVzPT09XCJEVUVcIn08RHVlUmVtaW5kZXIgdGVzdElkPXtgbXV0dWFsLWZ1bmQtc2lwLSR7ZnVuZC5pZH1gfSBkZXRhaWw9e2BEdWUgbm93IMK3ICR7bW9uZXkoZnVuZC5jdXJyZW50U2lwLmFtb3VudCl9YH0gYWN0aW9uTGFiZWw9XCJDb25maXJtIGFsbG9jYXRpb25cIiBvbkFjdGlvbj17KCk9Pm9wZW5TaXBDb25maXJtYXRpb24oZnVuZCxmdW5kLmN1cnJlbnRTaXApfS8+ey9pZn08L2J1dHRvbj57L2VhY2h9PC9kaXY+ezplbHNlfTxwPkNob29zZSBvbmUgdmVyaWZpZWQgc2NoZW1lLCB0aGVuIGFkZCBpdHMgZXhpc3RpbmcgaG9sZGluZywgYW4gU0lQLCBvciBvY2Nhc2lvbmFsIGx1bXAgc3VtcyB3aGVuZXZlciB5b3UgbmVlZC48L3A+ey9pZn08YnV0dG9uIGNsYXNzPVwiYWRkLWZ1bmQtcm93XCIgb246Y2xpY2s9e29wZW5NdXR1YWxGdW5kRm9ybX0+77yLIEFkZCBhIG11dHVhbCBmdW5kPC9idXR0b24+PC9zZWN0aW9uPlxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJtdXR1YWwtZnVuZHMtbW9kdWxlIHN0b2Nrcy1tb2R1bGVcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImxvYW5zLWhlYWRpbmdcIj48ZGl2PjxzdHJvbmc+U3RvY2tzPC9zdHJvbmc+PHNtYWxsPlBvcnRmb2xpbyB2YWx1ZSBmcm9tIHRoZSBsYXRlc3QgYXZhaWxhYmxlIG1hcmtldCBwcmljZTwvc21hbGw+PC9kaXY+PHNwYW4gY2xhc3M9XCJ2ZXJpZmllZC1waWxsXCI+TWFya2V0IGRhdGE8L3NwYW4+PC9kaXY+XG4gICAgICAgIHsjaWYgc3RvY2tTdGF0dXM9PT0nbG9hZGluZyd9PHA+TG9hZGluZyB5b3VyIHN0b2Nrc+KApjwvcD5cbiAgICAgICAgezplbHNlIGlmIHN0b2NrU3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwibG9hbi1zdGF0ZSBlcnJvclwiPjxzcGFuPntzdG9ja0Vycm9yfTwvc3Bhbj48YnV0dG9uIG9uOmNsaWNrPXtsb2FkU3RvY2tzfT5UcnkgYWdhaW48L2J1dHRvbj48L2Rpdj5cbiAgICAgICAgezplbHNlIGlmIHN0b2Nrcy5sZW5ndGh9XG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3M9XCJwb3J0Zm9saW8tdG90YWxcIj48c3Bhbj5Ub3RhbCBzdG9jayB2YWx1ZTwvc3Bhbj57I2lmIHN0b2NrUG9ydGZvbGlvLmN1cnJlbnQhPT1udWxsfTxzdHJvbmc+e21vbmV5KHN0b2NrUG9ydGZvbGlvLmN1cnJlbnQpfTwvc3Ryb25nPjxzbWFsbCBjbGFzczpwb3NpdGl2ZT17c3RvY2tQb3J0Zm9saW8ucG5sPj0wfSBjbGFzczpuZWdhdGl2ZT17c3RvY2tQb3J0Zm9saW8ucG5sPDB9PntzdG9ja1BvcnRmb2xpby5wbmw+PTA/JysnOicnfXttb25leShzdG9ja1BvcnRmb2xpby5wbmwpfSBvdmVyYWxsIFAmYW1wO0w8L3NtYWxsPns6ZWxzZX08c3Ryb25nPnttb25leShzdG9ja1BvcnRmb2xpby5pbnZlc3RlZCl9PC9zdHJvbmc+PHNtYWxsPkN1cnJlbnQgdmFsdWF0aW9uIGlzIHRlbXBvcmFyaWx5IHVuYXZhaWxhYmxlPC9zbWFsbD57L2lmfTwvc2VjdGlvbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZnVuZC1jYXJkLWxpc3RcIj57I2VhY2ggc3RvY2tzIGFzIHN0b2NrfTxhcnRpY2xlIGNsYXNzPXtgZnVuZC1jYXJkICR7ZnVuZEFjY2VudChzdG9jay5pZCl9YH0gZGF0YS10ZXN0aWQ9e2BzdG9jay1jYXJkLSR7c3RvY2suaWR9YH0gY2xhc3M6ZHVlLXN0b2NrPXtTdHJpbmcoc3RvY2suaWQpPT09U3RyaW5nKGhpZ2hsaWdodGVkU3RvY2tJZCl9PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmdW5kLWNhcmQtb3JiXCI+PC9zcGFuPjxkaXYgY2xhc3M9XCJmdW5kLWNhcmQtdGl0bGVcIj48c3Ryb25nPntzdG9jay5uYW1lfTwvc3Ryb25nPjxzcGFuIGNsYXNzPVwiZnVuZC1kZWxldGVcIiByb2xlPVwiYnV0dG9uXCIgdGFiaW5kZXg9XCIwXCIgYXJpYS1sYWJlbD17YERlbGV0ZSAke3N0b2NrLm5hbWV9YH0gdGl0bGU9XCJEZWxldGUgc3RvY2tcIiBvbjpjbGljaz17KCk9PnJlbW92ZVN0b2NrKHN0b2NrKX0gb246a2V5ZG93bj17KGV2ZW50KT0+e2lmKGV2ZW50LmtleT09PSdFbnRlcid8fGV2ZW50LmtleT09PScgJyl7ZXZlbnQucHJldmVudERlZmF1bHQoKTtyZW1vdmVTdG9jayhzdG9jayk7fX19PntzdG9ja0RlbGV0aW5nSWQ9PT1zdG9jay5pZD8n4oCmJzon8J+XkSd9PC9zcGFuPjxzbWFsbD57c3RvY2suc3ltYm9sfXtzdG9jay5leGNoYW5nZT9gIMK3ICR7c3RvY2suZXhjaGFuZ2V9YDonJ308L3NtYWxsPjwvZGl2PlxuICAgICAgICAgICAgeyNpZiBzdG9jay5jdXJyZW50VmFsdWUhPT1udWxsfTxkaXYgY2xhc3M9XCJmdW5kLWNhcmQtdmFsdWVzXCI+PGRpdiBjbGFzczpwb3NpdGl2ZT17TnVtYmVyKHN0b2NrLnByb2ZpdE9yTG9zcyk+PTB9IGNsYXNzOm5lZ2F0aXZlPXtOdW1iZXIoc3RvY2sucHJvZml0T3JMb3NzKTwwfT48c3Bhbj5QJmFtcDtMPC9zcGFuPjxiPntOdW1iZXIoc3RvY2sucHJvZml0T3JMb3NzKT49MD8nKyc6Jyd9e2NvbXBhY3RNb25leShzdG9jay5wcm9maXRPckxvc3MpfTwvYj48c21hbGw+e051bWJlcihzdG9jay5wcm9maXRPckxvc3NQZXJjZW50KT49MD8nKyc6Jyd9e051bWJlcihzdG9jay5wcm9maXRPckxvc3NQZXJjZW50KS50b0ZpeGVkKDIpfSU8L3NtYWxsPjwvZGl2PjxkaXY+PHNwYW4+SW52ZXN0ZWQ8L3NwYW4+PGI+e2NvbXBhY3RNb25leShzdG9jay5pbnZlc3RlZCl9PC9iPjwvZGl2PjxkaXY+PHNwYW4+Q3VycmVudDwvc3Bhbj48Yj57Y29tcGFjdE1vbmV5KHN0b2NrLmN1cnJlbnRWYWx1ZSl9PC9iPjwvZGl2PjwvZGl2PjxwIGNsYXNzPVwiZnVuZC1jYXJkLW5hdlwiPkxhdGVzdCBwcmljZSB7bW9uZXlEZWNpbWFsKHN0b2NrLmxhdGVzdFByaWNlKX0gwrcge051bWJlcihzdG9jay5xdWFudGl0eSkudG9GaXhlZCgzKX0gc2hhcmVzIDxidXR0b24gY2xhc3M9XCJzdG9jay1yZWN1cnJpbmctYmVsbFwiIGFyaWEtbGFiZWw9e2BTZXQgbW9udGhseSByZWN1cnJpbmcgcGxhbiBmb3IgJHtzdG9jay5uYW1lfWB9IHRpdGxlPVwiU2V0IG1vbnRobHkgcmVjdXJyaW5nIHBsYW5cIiBvbjpjbGljaz17KCk9Pm9wZW5TdG9ja1BsYW4oc3RvY2spfT7wn5SUPC9idXR0b24+PC9wPns6ZWxzZX08cCBjbGFzcz1cImZ1bmQtdmFsdWF0aW9uLXVuYXZhaWxhYmxlXCI+Q3VycmVudCBwcmljZSBpcyB0ZW1wb3JhcmlseSB1bmF2YWlsYWJsZS4gWW91ciBpbnZlc3RlZCBhbW91bnQgaXMge21vbmV5KHN0b2NrLmludmVzdGVkKX0uPC9wPnsvaWZ9XG4gICAgICAgICAgICA8Zm9vdGVyPjxzcGFuIGNsYXNzPVwiZnVuZC1zaXAtc3VtbWFyeVwiPntzdG9jay5hY3RpdmVNb250aGx5UGxhbj9gTW9udGhseSBwbGFuIMK3ICR7Y29tcGFjdE1vbmV5KHN0b2NrLmFjdGl2ZU1vbnRobHlQbGFuLmFtb3VudCl9IG9uIHRoZSAke3N0b2NrLmFjdGl2ZU1vbnRobHlQbGFuLmRheX0ke3N0b2NrLmFjdGl2ZU1vbnRobHlQbGFuLmRheT09PTE/J3N0JzpzdG9jay5hY3RpdmVNb250aGx5UGxhbi5kYXk9PT0yPyduZCc6c3RvY2suYWN0aXZlTW9udGhseVBsYW4uZGF5PT09Mz8ncmQnOid0aCd9YDonTm8gbW9udGhseSBwbGFuJ308L3NwYW4+PFZpZXdEZXRhaWxzTGluayBvbkFjdGlvbj17KCk9Pm9wZW5TdG9ja0RldGFpbChzdG9jay5pZCl9Lz48L2Zvb3Rlcj5cbiAgICAgICAgICAgIHsjaWYgc3RvY2suY3VycmVudE1vbnRobHlQbGFuPy5zdGF0dXM9PT0nRFVFJ308RHVlUmVtaW5kZXIgdGVzdElkPXtgc3RvY2stbW9udGhseS1wbGFuLSR7c3RvY2suaWR9YH0gZGV0YWlsPXtgRHVlIG5vdyDCtyAke21vbmV5KHN0b2NrLmN1cnJlbnRNb250aGx5UGxhbi5hbW91bnQpfWB9IGFjdGlvbkxhYmVsPVwiQ29uZmlybSBhbGxvY2F0aW9uXCIgb25BY3Rpb249eygpPT57c3RvY2tQbGFuQ29uZmlybWF0aW9uVGFyZ2V0PXN0b2NrO3N0b2NrUGxhbkNvbmZpcm1hdGlvbj17YW1vdW50OlN0cmluZyhzdG9jay5jdXJyZW50TW9udGhseVBsYW4uYW1vdW50KSxwcmljZTpTdHJpbmcoc3RvY2subGF0ZXN0UHJpY2V8fCcnKX19fS8+ey9pZn1cbiAgICAgICAgICA8L2FydGljbGU+ey9lYWNofTwvZGl2PlxuICAgICAgICB7OmVsc2V9PHA+U2VhcmNoIGEgbGlzdGVkIHN0b2NrLCB0aGVuIGFkZCB0aGUgc2hhcmVzIGFuZCBhbW91bnQgeW91IGFscmVhZHkgaW52ZXN0ZWQuPC9wPnsvaWZ9XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJhZGQtZnVuZC1yb3dcIiBvbjpjbGljaz17b3BlblN0b2NrRm9ybX0+77yLIEFkZCBhIHN0b2NrPC9idXR0b24+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICA8c2VjdGlvbiBjbGFzcz1cImxvYW5zLW1vZHVsZVwiIGRhdGEtdGVzdGlkPVwibG9hbnMtc2VjdGlvblwiPjxkaXYgY2xhc3M9XCJsb2Fucy1oZWFkaW5nXCI+PGRpdj48c3Ryb25nPkxvYW5zPC9zdHJvbmc+PHNtYWxsPlRyYWNrIHJlcGF5bWVudHMgYW5kIG1vbnRobHkgY29tbWl0bWVudHM8L3NtYWxsPjwvZGl2PnsjaWYgYWN0aXZlTG9hbnMubGVuZ3RofTxkaXYgY2xhc3M9XCJsb2FuLXRvdGFsXCI+PHNwYW4+VG90YWwgbW9udGhseSBFTUk8L3NwYW4+PGI+e21vbmV5KHRvdGFsTW9udGhseUVtaSl9L21vPC9iPjwvZGl2PnsvaWZ9PC9kaXY+XG4gICAgICAgIHsjaWYgbG9hblN0YXR1cz09PSdsb2FkaW5nJ308cCBjbGFzcz1cImxvYW4tc3RhdGVcIj5Mb2FkaW5nIHlvdXIgbG9hbnPigKY8L3A+ezplbHNlIGlmIGxvYW5TdGF0dXM9PT0nZXJyb3InfTxkaXYgY2xhc3M9XCJsb2FuLXN0YXRlIGVycm9yXCI+PHNwYW4+e2xvYW5FcnJvcn08L3NwYW4+PGJ1dHRvbiBvbjpjbGljaz17bG9hZExvYW5zfT5UcnkgYWdhaW48L2J1dHRvbj48L2Rpdj57OmVsc2UgaWYgYWN0aXZlTG9hbnMubGVuZ3RofXsjZWFjaCBhY3RpdmVMb2FucyBhcyBsb2FufXtAY29uc3Qgc2NoZWR1bGU9bG9hblNjaGVkdWxlKGxvYW4pfTxhcnRpY2xlIGNsYXNzPVwibG9hbi1yb3dcIiBjbGFzczpkdWUtbG9hbj17U3RyaW5nKGxvYW4uaWQpPT09U3RyaW5nKGhpZ2hsaWdodGVkTG9hbklkKX0+PHNwYW4+4oK5PC9zcGFuPjxkaXY+PHN0cm9uZyBjbGFzcz1cImxvYW4tbmFtZVwiPntsb2FuLmxvYW5OYW1lfTxidXR0b24gY2xhc3M9XCJsb2FuLWVkaXRcIiBvbjpjbGljaz17KCk9Pm9wZW5Mb2FuRm9ybShsb2FuKX0gYXJpYS1sYWJlbD17YEVkaXQgJHtsb2FuLmxvYW5OYW1lfWB9IHRpdGxlPVwiRWRpdCBsb2FuXCI+8J+UpzwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJsb2FuLWRlbGV0ZVwiIG9uOmNsaWNrPXsoKT0+cmVtb3ZlTG9hbihsb2FuKX0gYXJpYS1sYWJlbD17YERlbGV0ZSAke2xvYW4ubG9hbk5hbWV9YH0gdGl0bGU9XCJEZWxldGUgbG9hblwiIGRpc2FibGVkPXtsb2FuRGVsZXRpbmdJZCE9PW51bGx9Pntsb2FuRGVsZXRpbmdJZD09PWxvYW4uaWQ/J+KApic6J/Cfl5EnfTwvYnV0dG9uPjwvc3Ryb25nPjxzbWFsbD57bG9hbi5sZW5kZXJOYW1lfSDCtyB7bG9hbi5sb2FuVHlwZS5yZXBsYWNlQWxsKCdfJywnICcpfSDCtyB7bG9hbi50b3RhbFRlbnVyZU1vbnRoc30gbW9udGhzPC9zbWFsbD48L2Rpdj48ZGl2PjxiPnttb25leShsb2FuLm1vbnRobHlFbWlBbW91bnQpfS9tbzwvYj48c21hbGw+e21vbmV5KGxvYW4ub3JpZ2luYWxQcmluY2lwYWwpfSBwcmluY2lwYWw8L3NtYWxsPjwvZGl2PjxWaWV3RGV0YWlsc0xpbmsgb25BY3Rpb249eygpPT5vcGVuTG9hbkhpc3RvcnkobG9hbil9Lz57I2lmIHNjaGVkdWxlfTxkaXYgY2xhc3M9XCJsb2FuLXByb2dyZXNzXCI+PGRpdj48c3Bhbj57c2NoZWR1bGUuZHVlfSBvZiB7c2NoZWR1bGUudGVudXJlfSBoaXN0b3JpY2FsIEVNSSBtb250aHMgY29tcGxldGVkPC9zcGFuPjwvZGl2PjxpIHN0eWxlPXtgLS1sb2FuLXByb2dyZXNzOiR7c2NoZWR1bGUucGVyY2VudH0lYH0+PC9pPjwvZGl2PnsvaWZ9eyNpZiBTdHJpbmcobG9hbi5pZCk9PT1TdHJpbmcoaGlnaGxpZ2h0ZWRMb2FuSWQpJiZoaWdobGlnaHRlZExvYW5BY3Rpb259PGRpdiBjbGFzcz1cImxvYW4tZHVlLWFjdGlvblwiPjxzdHJvbmc+RmluYWwgRU1JIGR1ZTwvc3Ryb25nPjxwPkNvbmZpcm0geW91IHBhaWQgdGhlIGZpbmFsIEVNSSBiZWZvcmUgY2xvc2luZyB0aGlzIGxvYW4uPC9wPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgZGF0YS10ZXN0aWQ9XCJtYXJrLWZpbmFsLWVtaS1wYWlkXCIgZGlzYWJsZWQ9e2NvbXBsZXRpbmdBY3Rpb25JZCE9PW51bGx9IG9uOmNsaWNrPXsoKT0+Y29tcGxldGVPcGVuQWN0aW9uKGhpZ2hsaWdodGVkTG9hbkFjdGlvbil9Pntjb21wbGV0aW5nQWN0aW9uSWQ9PT1oaWdobGlnaHRlZExvYW5BY3Rpb24uaWQ/J01hcmtpbmcgbG9hbiBjbG9zZWTigKYnOidNYXJrIGZpbmFsIEVNSSBwYWlkJ308L2J1dHRvbj48L2Rpdj57L2lmfTwvYXJ0aWNsZT57L2VhY2h9ezplbHNlfTxwIGNsYXNzPVwibG9hbi1zdGF0ZVwiPk5vIGFjdGl2ZSBsb2Fucy48L3A+ey9pZn1cbiAgICAgICAgeyNpZiBjbG9zZWRMb2Fucy5sZW5ndGh9PGJ1dHRvbiBjbGFzcz1cImNsb3NlZC1sb2Fucy10b2dnbGVcIiBkYXRhLXRlc3RpZD1cImNsb3NlZC1sb2Fucy10b2dnbGVcIiBhcmlhLWV4cGFuZGVkPXtzaG93Q2xvc2VkTG9hbnN9IG9uOmNsaWNrPXsoKT0+c2hvd0Nsb3NlZExvYW5zPSFzaG93Q2xvc2VkTG9hbnN9PkNsb3NlZCBsb2FucyDCtyB7Y2xvc2VkTG9hbnMubGVuZ3RofTxzcGFuPntzaG93Q2xvc2VkTG9hbnM/J+KMgyc6J+KMhCd9PC9zcGFuPjwvYnV0dG9uPnsjaWYgc2hvd0Nsb3NlZExvYW5zfTxkaXYgY2xhc3M9XCJjbG9zZWQtbG9hbnMtbGlzdFwiPnsjZWFjaCBjbG9zZWRMb2FucyBhcyBsb2FufTxDbG9zZWRMb2FuUm93IHtsb2FufSB7bW9uZXl9Lz57L2VhY2h9PC9kaXY+ey9pZn17L2lmfVxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYWRkLWxvYW4tcm93XCIgb246Y2xpY2s9eygpPT5vcGVuTG9hbkZvcm0oKX0+77yLIEFkZCBhbm90aGVyIGxvYW48L2J1dHRvbj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxwIGNsYXNzPVwibW9kdWxlLWZvb3Rub3RlXCI+VGhlc2UgbW9kdWxlcyB1c2Ugbm9ybWFsIGZvcm1z4oCUbm90IEFJIGNsZWFudXDigJRhbmQgb25seSBpbmZvcm0gc3RvcmllcyBpZiB5b3UgdHVybiB0aGF0IG9uLjwvcD5cbiAgICA8L3NlY3Rpb24+XG4gIDwvZGl2Plxuey9pZn1cbnsjaWYgc2hvd0NvbW1pdG1lbnRGb3JtfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgbG9hbi1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zaG93Q29tbWl0bWVudEZvcm09ZmFsc2V9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPk1PTlRITFkgQ09NTUlUTUVOVDwvcD48aDI+e2NvbW1pdG1lbnRFZGl0aW5nSWQ9PT1udWxsPydBZGQgYSByZXBlYXRhYmxlIG9ibGlnYXRpb24nOidFZGl0IG1vbnRobHkgY29tbWl0bWVudCd9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPlRoaXMgaXMgYSBwbGFubmluZyBlc3RpbWF0ZSwgbm90IHByb29mIHRoYXQgYSBiaWxsIHdhcyBwYWlkLjwvcD48bGFiZWw+TmFtZTxpbnB1dCBiaW5kOnZhbHVlPXtjb21taXRtZW50Rm9ybS5sYWJlbH0gcGxhY2Vob2xkZXI9XCJlLmcuIEhvbWUgcmVudFwiIG1heGxlbmd0aD1cIjEyMFwiLz48L2xhYmVsPjxsYWJlbD5Nb250aGx5IHBsYW5uaW5nIGFtb3VudDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjAuMDFcIiBiaW5kOnZhbHVlPXtjb21taXRtZW50Rm9ybS5wbGFubmluZ0Ftb3VudH0vPjwvbGFiZWw+PGxhYmVsPkV4cGVjdGVkIGRheSA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsXCI+T3B0aW9uYWw8L3NwYW4+PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIxXCIgbWF4PVwiMjhcIiBiaW5kOnZhbHVlPXtjb21taXRtZW50Rm9ybS5kdWVEYXl9Lz48L2xhYmVsPjxsYWJlbD5BbW91bnQgYmFzaXM8c2VsZWN0IGJpbmQ6dmFsdWU9e2NvbW1pdG1lbnRGb3JtLmFtb3VudE1vZGV9PjxvcHRpb24gdmFsdWU9XCJGSVhFRFwiPkZpeGVkIGFtb3VudDwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJVU0VSX0VTVElNQVRFXCI+TXkgZXN0aW1hdGU8L29wdGlvbj48L3NlbGVjdD48L2xhYmVsPnsjaWYgY29tbWl0bWVudEVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntjb21taXRtZW50RXJyb3J9PC9wPnsvaWZ9PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5zaG93Q29tbWl0bWVudEZvcm09ZmFsc2V9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9e3NhdmVDb21taXRtZW50fSBkaXNhYmxlZD17Y29tbWl0bWVudFNhdmluZ30+e2NvbW1pdG1lbnRTYXZpbmc/J1NhdmluZ+KApic6Y29tbWl0bWVudEVkaXRpbmdJZD09PW51bGw/J0FkZCBjb21taXRtZW50JzonU2F2ZSBjaGFuZ2VzJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgc2hvd0NyZWRpdENhcmRGb3JtfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgbG9hbi1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zaG93Q3JlZGl0Q2FyZEZvcm09ZmFsc2V9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkNSRURJVC1DQVJEIEJJTExJTkc8L3A+PGgyPntjcmVkaXRDYXJkRWRpdGluZ0lkPT09bnVsbD8nQWRkIGEgY3JlZGl0IGNhcmQnOidFZGl0IGNyZWRpdCBjYXJkJ308L2gyPjxwIGNsYXNzPVwibW9kdWxlLXJlYXNzdXJhbmNlXCI+V2UgYWRkIG9ubHkgZXhwZW5zZXMgY2FwdHVyZWQgYWdhaW5zdCB0aGlzIGFjY291bnQgYmV0d2VlbiBzdGF0ZW1lbnQgZGF0ZXMgdG8gdGhlIGJpbGwgZHVlIGluIHRoYXQgbW9udGguPC9wPjxsYWJlbD5DYXB0dXJlZCBhY2NvdW50PHNlbGVjdCBiaW5kOnZhbHVlPXtjcmVkaXRDYXJkRm9ybS5hY2NvdW50UmVmZXJlbmNlSWR9PjxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5TZWxlY3QgdGhlIGNhcmQgYWNjb3VudDwvb3B0aW9uPnsjZWFjaCBlZGl0T3B0aW9ucy5hY2NvdW50cyBhcyBhY2NvdW50fTxvcHRpb24gdmFsdWU9e1N0cmluZyhhY2NvdW50LmlkKX0+e2FjY291bnQubmFtZX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+Q2FyZCBuYW1lPGlucHV0IGJpbmQ6dmFsdWU9e2NyZWRpdENhcmRGb3JtLmNhcmROYW1lfSBwbGFjZWhvbGRlcj1cImUuZy4gTWlsbGVubmlhXCIgbWF4bGVuZ3RoPVwiMTIwXCIvPjwvbGFiZWw+PGxhYmVsPklzc3VlciAvIHZlbmRvcjxpbnB1dCBiaW5kOnZhbHVlPXtjcmVkaXRDYXJkRm9ybS5pc3N1ZXJOYW1lfSBwbGFjZWhvbGRlcj1cImUuZy4gSERGQyBCYW5rXCIgbWF4bGVuZ3RoPVwiMTIwXCIvPjwvbGFiZWw+PGxhYmVsPkJpbGwgZ2VuZXJhdGlvbiBkYXk8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiBtYXg9XCIyOFwiIGJpbmQ6dmFsdWU9e2NyZWRpdENhcmRGb3JtLnN0YXRlbWVudERheX0vPjwvbGFiZWw+PGxhYmVsPlBheW1lbnQgZHVlIGRheTxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIG1heD1cIjI4XCIgYmluZDp2YWx1ZT17Y3JlZGl0Q2FyZEZvcm0uZHVlRGF5fS8+PC9sYWJlbD57I2lmIGNyZWRpdENhcmRFcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57Y3JlZGl0Q2FyZEVycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+c2hvd0NyZWRpdENhcmRGb3JtPWZhbHNlfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlQ3JlZGl0Q2FyZH0gZGlzYWJsZWQ9e2NyZWRpdENhcmRTYXZpbmd8fG9wdGlvbnNTdGF0dXMhPT0ncmVhZHknfT57Y3JlZGl0Q2FyZFNhdmluZz8nU2F2aW5n4oCmJzpjcmVkaXRDYXJkRWRpdGluZ0lkPT09bnVsbD8nQWRkIGNyZWRpdCBjYXJkJzonU2F2ZSBjaGFuZ2VzJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgc2hvd0luY29tZUZsb3d9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGluY29tZS1mbG93LWJhY2tkcm9wXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBpbmNvbWUtZmxvd1wiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd0luY29tZUZsb3c9ZmFsc2V9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPlBSSVZBVEUgU0FMQVJZIENPTlRFWFQ8L3A+PGgyPldoYXQgcmFuZ2UgZmVlbHMgY29tZm9ydGFibGUgdG8gc2hhcmU/PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPkEgcmFuZ2UgaXMgZW5vdWdoLiBUaGlzIGlzIG5vdCBhIHJlcXVlc3QgZm9yIGEgcGF5c2xpcCwgYW5kIGl0IG5ldmVyIGNoYW5nZXMgeW91ciBiYWxhbmNlLjwvcD48ZGl2IGNsYXNzPVwicmFuZ2Utb3B0aW9uc1wiPnsjZWFjaCBbJ1VOREVSXzI1MDAwJywnRlJPTV8yNTAwMF9UT181MDAwMCcsJ0ZST01fNTAwMDBfVE9fMTAwMDAwJywnRlJPTV8xMDAwMDBfVE9fMjAwMDAwJywnT1ZFUl8yMDAwMDAnXSBhcyByYW5nZX08YnV0dG9uIGNsYXNzOmFjdGl2ZT17c2FsYXJ5Rm9ybS5zYWxhcnlSYW5nZT09PXJhbmdlJiZzYWxhcnlGb3JtLnNhbGFyeVZpc2liaWxpdHk9PT0nUkFOR0UnfSBvbjpjbGljaz17KCk9PntzYWxhcnlGb3JtLnNhbGFyeVZpc2liaWxpdHk9J1JBTkdFJztzYWxhcnlGb3JtLnNhbGFyeVJhbmdlPXJhbmdlO319PntpbmNvbWVSYW5nZUxhYmVsKHJhbmdlKX08L2J1dHRvbj57L2VhY2h9PC9kaXY+PGJ1dHRvbiBjbGFzcz1cInRleHQtbGluayBpbmNvbWUtZXhhY3QtdG9nZ2xlXCIgb246Y2xpY2s9eygpPT5zYWxhcnlGb3JtLnNhbGFyeVZpc2liaWxpdHk9c2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PT09J0VYQUNUJz8nUkFOR0UnOidFWEFDVCd9PntzYWxhcnlGb3JtLnNhbGFyeVZpc2liaWxpdHk9PT0nRVhBQ1QnPydVc2UgYSByYW5nZSBpbnN0ZWFkJzonSeKAmW0gY29tZm9ydGFibGUgc2hhcmluZyB0aGUgZXhhY3QgYW1vdW50J308L2J1dHRvbj57I2lmIHNhbGFyeUZvcm0uc2FsYXJ5VmlzaWJpbGl0eT09PSdFWEFDVCd9PGxhYmVsPk1vbnRobHkgdGFrZS1ob21lIHNhbGFyeTxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBiaW5kOnZhbHVlPXtzYWxhcnlGb3JtLmV4YWN0TW9udGhseVNhbGFyeX0gcGxhY2Vob2xkZXI9XCJPcHRpb25hbCBleGFjdCBhbW91bnRcIi8+PC9sYWJlbD57L2lmfTxsYWJlbD5Ib3cgb2Z0ZW4gZG9lcyBpdCBhcnJpdmU/PHNlbGVjdCBiaW5kOnZhbHVlPXtzYWxhcnlGb3JtLnNhbGFyeUZyZXF1ZW5jeX0+eyNlYWNoIFsnTU9OVEhMWScsJ1RXSUNFX01PTlRITFknLCdXRUVLTFknLCdJUlJFR1VMQVInXSBhcyBmcmVxdWVuY3l9PG9wdGlvbiB2YWx1ZT17ZnJlcXVlbmN5fT57ZnJlcXVlbmN5LnJlcGxhY2VBbGwoJ18nLCcgJykudG9Mb3dlckNhc2UoKX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD57I2lmIGluY29tZUVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntpbmNvbWVFcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PntzYWxhcnlGb3JtLnNhbGFyeVZpc2liaWxpdHk9J1NLSVBQRUQnO3NhdmVTYWxhcnkoKTt9fSBkaXNhYmxlZD17aW5jb21lU2F2aW5nfT5Ta2lwIGZvciBub3c8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlU2FsYXJ5fSBkaXNhYmxlZD17aW5jb21lU2F2aW5nfT57aW5jb21lU2F2aW5nPydTYXZpbmfigKYnOidTYXZlIHNhbGFyeSBvdXRsb29rJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgc2hvd0xvYW5Gb3JtfVxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgbG9hbi1mb3JtLWJhY2tkcm9wXCIgcm9sZT1cInByZXNlbnRhdGlvblwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgbG9hbi1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd0xvYW5Gb3JtPWZhbHNlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5MT0FOIERFVEFJTFM8L3A+PGgyPntsb2FuRWRpdGluZ0lkPT1udWxsPydBZGQgYSBsb2FuJzonRWRpdCBsb2FuJ308L2gyPjxwIGNsYXNzPVwibW9kdWxlLXJlYXNzdXJhbmNlXCI+WW91ciBsb2FuIGluZm9ybWF0aW9uIGlzIHN0b3JlZCBzZWN1cmVseSBpbiB5b3VyIGFjY291bnQuPC9wPjxsYWJlbD5Mb2FuIG5hbWU8aW5wdXQgYmluZDp2YWx1ZT17bG9hbkZvcm0ubG9hbk5hbWV9IHBsYWNlaG9sZGVyPVwiZS5nLiBIREZDIEhvbWUgTG9hblwiIG1heGxlbmd0aD1cIjI1NVwiIC8+PC9sYWJlbD48bGFiZWw+TG9hbiB0eXBlPHNlbGVjdCBiaW5kOnZhbHVlPXtsb2FuRm9ybS5sb2FuVHlwZX0+eyNlYWNoIFsnSE9NRScsJ1ZFSElDTEUnLCdQRVJTT05BTCcsJ0VEVUNBVElPTicsJ0NSRURJVF9DQVJEX0VNSScsJ09USEVSJ10gYXMgdHlwZX08b3B0aW9uIHZhbHVlPXt0eXBlfT57dHlwZS5yZXBsYWNlQWxsKCdfJywnICcpfTwvb3B0aW9uPnsvZWFjaH08L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5PcmlnaW5hbCBsb2FuIHByaW5jaXBhbDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjFcIiBiaW5kOnZhbHVlPXtsb2FuRm9ybS5vcmlnaW5hbFByaW5jaXBhbH0gcGxhY2Vob2xkZXI9XCJlLmcuIDQyMDAwMDBcIiAvPjwvbGFiZWw+PGxhYmVsPk1vbnRobHkgRU1JIGFtb3VudDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjFcIiBiaW5kOnZhbHVlPXtsb2FuRm9ybS5tb250aGx5RW1pQW1vdW50fSBwbGFjZWhvbGRlcj1cImUuZy4gMzg2MDBcIiAvPjwvbGFiZWw+PGxhYmVsPlRvdGFsIHRlbnVyZSBpbiBtb250aHM8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cIm51bWVyaWNcIiBtaW49XCIxXCIgYmluZDp2YWx1ZT17bG9hbkZvcm0udG90YWxUZW51cmVNb250aHN9IHBsYWNlaG9sZGVyPVwiZS5nLiAyNDBcIiAvPjwvbGFiZWw+PGxhYmVsPkZpcnN0IEVNSSBkdWUgZGF0ZTxpbnB1dCB0eXBlPVwiZGF0ZVwiIGJpbmQ6dmFsdWU9e2xvYW5Gb3JtLmZpcnN0RW1pRHVlRGF0ZX0gLz48L2xhYmVsPjxsYWJlbD5CYW5rIC8gbGVuZGVyPGlucHV0IGJpbmQ6dmFsdWU9e2xvYW5Gb3JtLmxlbmRlck5hbWV9IHBsYWNlaG9sZGVyPVwiZS5nLiBIREZDIEJhbmtcIiBtYXhsZW5ndGg9XCIyNTVcIiAvPjwvbGFiZWw+PGxhYmVsPk5vdGVzIDxzcGFuIGNsYXNzPVwib3B0aW9uYWxcIj5PcHRpb25hbDwvc3Bhbj48aW5wdXQgYmluZDp2YWx1ZT17bG9hbkZvcm0ubm90ZXN9IHBsYWNlaG9sZGVyPVwiZS5nLiBQcmltYXJ5IHJlc2lkZW5jZVwiIC8+PC9sYWJlbD57I2lmIGxvYW5FcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57bG9hbkVycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+c2hvd0xvYW5Gb3JtPWZhbHNlfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlTG9hbn0gZGlzYWJsZWQ9e2xvYW5TYXZpbmd9Pntsb2FuU2F2aW5nPydTYXZpbmfigKYnOmxvYW5FZGl0aW5nSWQ9PW51bGw/J0FkZCBsb2FuJzonU2F2ZSBjaGFuZ2VzJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+XG57L2lmfVxueyNpZiBzaG93TXV0dWFsRnVuZEZvcm19XG4gIDxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIiByb2xlPVwicHJlc2VudGF0aW9uXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBmdW5kLWZvcm1cIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zaG93TXV0dWFsRnVuZEZvcm09ZmFsc2V9PsOXPC9idXR0b24+XG4gICAgeyNpZiBmdW5kU2F2ZWR9PGRpdiBjbGFzcz1cImZ1bmQtc3VjY2Vzc1wiPjxzcGFuPuKckzwvc3Bhbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+e2Z1bmRGb3JtLmhhc1NpcD09PSdZRVMnPydTSVAgUkVBRFknOidGVU5EIEFEREVEJ308L3A+PGgyPntmdW5kRm9ybS5oYXNTaXA9PT0nWUVTJz8nWW91ciBTSVAgaXMgc2V0IHVwJzonWW91ciBmdW5kIGlzIHJlYWR5J308L2gyPjxwPntmdW5kRm9ybS5oYXNTaXA9PT0nWUVTJz9gJHttb25leShmdW5kRm9ybS5zaXBBbW91bnQpfSB3aWxsIGJlIHRyYWNrZWQgbW9udGhseSBmb3IgJHtzZWxlY3RlZFNjaGVtZS5zY2hlbWVOYW1lfS4gVGhlIGZpcnN0IG9jY3VycmVuY2Ugd2lsbCBiZSBkdWUgaW4gJHttb250aExhYmVsKGZ1bmRGb3JtLnN0YXJ0TW9udGgpfS5gOmAke3NlbGVjdGVkU2NoZW1lLnNjaGVtZU5hbWV9IGlzIHJlYWR5IGZvciBvY2Nhc2lvbmFsIGx1bXAgc3Vtcy4gWW91IGNhbiBzZXQgdXAgYSBTSVAgbGF0ZXIgZnJvbSBpdHMgYmVsbCBidXR0b24uYH08L3A+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17KCk9PnNob3dNdXR1YWxGdW5kRm9ybT1mYWxzZX0+RG9uZTwvYnV0dG9uPjwvZGl2PlxuICAgIHs6ZWxzZX08cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TVVUVUFMIEZVTkQ8L3A+PGgyPkFkZCBhIG11dHVhbCBmdW5kPC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPlNlYXJjaCB0aGUgb2ZmaWNpYWwgc2NoZW1lIG1hc3Rlci4gQSByZXR1cm5lZCBuYW1lIGlzIG9uZSB2ZXJpZmllZCBmdW5kLCBwbGFuIGFuZCBvcHRpb24uPC9wPlxuICAgICAgPGRpdiBjbGFzcz1cImZ1bmQtc2VjdGlvblwiPjxzcGFuIGNsYXNzPVwiZnVuZC1zZWN0aW9uLWxhYmVsXCI+MSDCtyBGVU5EPC9zcGFuPjxsYWJlbCBjbGFzcz1cInNjaGVtZS1waWNrZXJcIj5TZWFyY2ggYW5kIHNlbGVjdCBzY2hlbWU8aW5wdXQgdmFsdWU9e3NjaGVtZVF1ZXJ5fSBvbjpmb2N1cz17KCk9PnNob3dTY2hlbWVNZW51PXRydWV9IG9uOmlucHV0PXtlPT5zZWFyY2hTY2hlbWVzKGUuY3VycmVudFRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiVHlwZSBhdCBsZWFzdCAyIGNoYXJhY3RlcnNcIiBhdXRvY29tcGxldGU9XCJvZmZcIiAvPnsjaWYgc2hvd1NjaGVtZU1lbnV9PGRpdiBjbGFzcz1cInNjaGVtZS1tZW51XCI+eyNpZiBzY2hlbWVTZWFyY2hTdGF0dXM9PT0nbG9hZGluZyd9PHA+U2VhcmNoaW5nIHNjaGVtZXPigKY8L3A+ezplbHNlIGlmIHNjaGVtZVF1ZXJ5LnRyaW0oKS5sZW5ndGg8Mn08cD5UeXBlIGF0IGxlYXN0IDIgY2hhcmFjdGVycyB0byBzZWFyY2guPC9wPns6ZWxzZX17I2VhY2ggc2NoZW1lUmVzdWx0cyBhcyBzY2hlbWV9PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb246bW91c2Vkb3dufHByZXZlbnREZWZhdWx0PXsoKT0+c2VsZWN0U2NoZW1lKHNjaGVtZSl9PjxzdHJvbmc+e3NjaGVtZS5zY2hlbWVOYW1lfTwvc3Ryb25nPjxzbWFsbD5TY2hlbWUgY29kZSB7c2NoZW1lLnNjaGVtZUNvZGV9IMK3IHtzY2hlbWUubGF0ZXN0TmF2PT1udWxsPydMYXRlc3QgTkFWIHVuYXZhaWxhYmxlJzpgTGF0ZXN0IE5BViAke21vbmV5RGVjaW1hbChzY2hlbWUubGF0ZXN0TmF2KX1gfTwvc21hbGw+PC9idXR0b24+ezplbHNlfTxwPk5vIG1hdGNoaW5nIHNjaGVtZSBmb3VuZC48L3A+ey9lYWNofXsvaWZ9PC9kaXY+ey9pZn08L2xhYmVsPnsjaWYgc2VsZWN0ZWRTY2hlbWV9PGRpdiBjbGFzcz1cInNjaGVtZS12YWxpZGF0ZWRcIj48c3Bhbj7inJM8L3NwYW4+PGRpdj48c3Ryb25nPlZlcmlmaWVkIGJ5IHNjaGVtZSBtYXN0ZXI8L3N0cm9uZz48c21hbGw+Q29kZSB7c2VsZWN0ZWRTY2hlbWUuc2NoZW1lQ29kZX0gwrcge3NlbGVjdGVkU2NoZW1lLmxhdGVzdE5hdj09bnVsbD8nTGF0ZXN0IE5BViB1bmF2YWlsYWJsZSc6YExhdGVzdCBOQVYgJHttb25leURlY2ltYWwoc2VsZWN0ZWRTY2hlbWUubGF0ZXN0TmF2KX1gfTwvc21hbGw+PC9kaXY+PC9kaXY+ey9pZn08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmdW5kLXNlY3Rpb25cIj48c3BhbiBjbGFzcz1cImZ1bmQtc2VjdGlvbi1sYWJlbFwiPjIgwrcgU0lQIDxlbT5PUFRJT05BTDwvZW0+PC9zcGFuPjxmaWVsZHNldD48bGVnZW5kPkRvIHlvdSBoYXZlIGFuIGFjdHVhbCBTSVAgZm9yIHRoaXMgZnVuZD88L2xlZ2VuZD48bGFiZWwgY2xhc3M9XCJjaG9pY2VcIj48aW5wdXQgdHlwZT1cInJhZGlvXCIgYmluZDpncm91cD17ZnVuZEZvcm0uaGFzU2lwfSB2YWx1ZT1cIllFU1wiIC8+IFllczwvbGFiZWw+PGxhYmVsIGNsYXNzPVwiY2hvaWNlXCI+PGlucHV0IHR5cGU9XCJyYWRpb1wiIGJpbmQ6Z3JvdXA9e2Z1bmRGb3JtLmhhc1NpcH0gdmFsdWU9XCJOT1wiIC8+IE5vPC9sYWJlbD48L2ZpZWxkc2V0PnsjaWYgZnVuZEZvcm0uaGFzU2lwPT09J1lFUyd9PGxhYmVsPk1vbnRobHkgU0lQIGFtb3VudDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjFcIiBiaW5kOnZhbHVlPXtmdW5kRm9ybS5zaXBBbW91bnR9IC8+PC9sYWJlbD48ZGl2IGNsYXNzPVwiZnVuZC1maWVsZC1wYWlyXCI+PGxhYmVsPlNJUCBkYXRlPHNlbGVjdCBiaW5kOnZhbHVlPXtmdW5kRm9ybS5zaXBEYXRlfT57I2VhY2ggQXJyYXkoMjgpIGFzIF8saW5kZXh9PG9wdGlvbiB2YWx1ZT17aW5kZXgrMX0+e2luZGV4KzF9e2luZGV4PT09MD8nc3QnOmluZGV4PT09MT8nbmQnOmluZGV4PT09Mj8ncmQnOid0aCd9IG9mIGV2ZXJ5IG1vbnRoPC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPlN0YXJ0IG1vbnRoPGlucHV0IHR5cGU9XCJtb250aFwiIGJpbmQ6dmFsdWU9e2Z1bmRGb3JtLnN0YXJ0TW9udGh9IC8+PC9sYWJlbD48L2Rpdj57L2lmfTwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cImZ1bmQtc2VjdGlvblwiPjxzcGFuIGNsYXNzPVwiZnVuZC1zZWN0aW9uLWxhYmVsXCI+MyDCtyBFWElTVElORyBIT0xESU5HIDxlbT5PUFRJT05BTDwvZW0+PC9zcGFuPjxmaWVsZHNldD48bGVnZW5kPkRvIHlvdSBhbHJlYWR5IGhvbGQgdGhpcyBmdW5kPzwvbGVnZW5kPjxsYWJlbCBjbGFzcz1cImNob2ljZVwiPjxpbnB1dCB0eXBlPVwicmFkaW9cIiBiaW5kOmdyb3VwPXtmdW5kRm9ybS5oYXNIb2xkaW5nfSB2YWx1ZT1cIk5PXCIgLz4gTm88L2xhYmVsPjxsYWJlbCBjbGFzcz1cImNob2ljZVwiPjxpbnB1dCB0eXBlPVwicmFkaW9cIiBiaW5kOmdyb3VwPXtmdW5kRm9ybS5oYXNIb2xkaW5nfSB2YWx1ZT1cIllFU1wiIC8+IFllczwvbGFiZWw+PC9maWVsZHNldD57I2lmIGZ1bmRGb3JtLmhhc0hvbGRpbmc9PT0nWUVTJ308ZGl2IGNsYXNzPVwiZnVuZC1maWVsZC1wYWlyXCI+PGxhYmVsPkN1cnJlbnQgdW5pdHM8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIwLjAwMVwiIHN0ZXA9XCIwLjAwMVwiIGJpbmQ6dmFsdWU9e2Z1bmRGb3JtLmN1cnJlbnRVbml0c30gLz48L2xhYmVsPjxsYWJlbD5Ub3RhbCBhbW91bnQgaW52ZXN0ZWQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIwLjAxXCIgYmluZDp2YWx1ZT17ZnVuZEZvcm0udG90YWxJbnZlc3RlZH0gLz48L2xhYmVsPjwvZGl2PjxwIGNsYXNzPVwiZnVuZC1kaXNjbGFpbWVyXCI+QXZlcmFnZSBwdXJjaGFzZSBjb3N0IGlzIGNhbGN1bGF0ZWQgYnkgdGhlIGJhY2tlbmQgYWZ0ZXIgdGhlIG9wZW5pbmcgYmFsYW5jZSBpcyByZWNvcmRlZC48L3A+ey9pZn08L2Rpdj5cbiAgICAgIHsjaWYgZnVuZEVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntmdW5kRXJyb3J9PC9wPnsvaWZ9PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5zaG93TXV0dWFsRnVuZEZvcm09ZmFsc2V9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9e3NhdmVNdXR1YWxGdW5kfSBkaXNhYmxlZD17ZnVuZFNhdmluZ30+e2Z1bmRTYXZpbmc/J0NyZWF0aW5n4oCmJzonQWRkIG11dHVhbCBmdW5kJ308L2J1dHRvbj48L2Rpdj5cbiAgICB7L2lmfTwvc2VjdGlvbj48L2Rpdj5cbnsvaWZ9XG57I2lmIHNob3dTdG9ja0Zvcm19XG4gIDxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIiByb2xlPVwicHJlc2VudGF0aW9uXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBmdW5kLWZvcm1cIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zaG93U3RvY2tGb3JtPWZhbHNlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5TVE9DSyBIT0xESU5HPC9wPjxoMj5BZGQgYSBzdG9jazwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5TZWFyY2ggbWFya2V0IHN5bWJvbHMsIHRoZW4gcmVjb3JkIHRoZSBzaGFyZXMgYW5kIHRvdGFsIGFtb3VudCB5b3UgYWxyZWFkeSBpbnZlc3RlZC4gRWRpdGluZyBhbmQgc2VsbGluZyB3aWxsIGZvbGxvdyBpbiBhIGxhdGVyIHVwZGF0ZS48L3A+PGRpdiBjbGFzcz1cImZ1bmQtc2VjdGlvblwiPjxzcGFuIGNsYXNzPVwiZnVuZC1zZWN0aW9uLWxhYmVsXCI+MSDCtyBTVE9DSzwvc3Bhbj48bGFiZWwgY2xhc3M9XCJzY2hlbWUtcGlja2VyXCI+U2VhcmNoIGFuZCBzZWxlY3Qgc3RvY2s8aW5wdXQgdmFsdWU9e3N0b2NrUXVlcnl9IG9uOmlucHV0PXtlPT5maW5kU3RvY2tzKGUuY3VycmVudFRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiVHlwZSBhdCBsZWFzdCAyIGNoYXJhY3RlcnNcIiBhdXRvY29tcGxldGU9XCJvZmZcIiAvPnsjaWYgc3RvY2tRdWVyeS50cmltKCkubGVuZ3RoPj0yJiYhc2VsZWN0ZWRTdG9ja308ZGl2IGNsYXNzPVwic2NoZW1lLW1lbnVcIj57I2lmIHN0b2NrU2VhcmNoU3RhdHVzPT09J2xvYWRpbmcnfTxwPlNlYXJjaGluZyBzdG9jayBzeW1ib2xz4oCmPC9wPns6ZWxzZSBpZiBzdG9ja1NlYXJjaFN0YXR1cz09PSdlcnJvcid9PHA+Q291bGQgbm90IHNlYXJjaCBzdG9ja3MuPC9wPns6ZWxzZX17I2VhY2ggc3RvY2tSZXN1bHRzIGFzIHN0b2NrfTxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uOm1vdXNlZG93bnxwcmV2ZW50RGVmYXVsdD17KCk9PnNlbGVjdFN0b2NrKHN0b2NrKX0+PHN0cm9uZz57c3RvY2submFtZXx8c3RvY2suc3ltYm9sfTwvc3Ryb25nPjxzbWFsbD57c3RvY2suc3ltYm9sfXtzdG9jay5leGNoYW5nZT9gIMK3ICR7c3RvY2suZXhjaGFuZ2V9YDonJ30gwrcge3N0b2NrLmxhdGVzdFByaWNlPT1udWxsPydMYXRlc3QgcHJpY2UgdW5hdmFpbGFibGUnOmBMYXRlc3QgcHJpY2UgJHttb25leURlY2ltYWwoc3RvY2subGF0ZXN0UHJpY2UpfWB9PC9zbWFsbD48L2J1dHRvbj57OmVsc2V9PHA+Tm8gbWF0Y2hpbmcgbGlzdGVkIHN0b2NrIGZvdW5kLjwvcD57L2VhY2h9ey9pZn08L2Rpdj57L2lmfTwvbGFiZWw+eyNpZiBzZWxlY3RlZFN0b2NrfTxkaXYgY2xhc3M9XCJzY2hlbWUtdmFsaWRhdGVkXCI+PHNwYW4+4pyTPC9zcGFuPjxkaXY+PHN0cm9uZz5WZXJpZmllZCBtYXJrZXQgc3ltYm9sPC9zdHJvbmc+PHNtYWxsPntzZWxlY3RlZFN0b2NrLnN5bWJvbH17c2VsZWN0ZWRTdG9jay5leGNoYW5nZT9gIMK3ICR7c2VsZWN0ZWRTdG9jay5leGNoYW5nZX1gOicnfSDCtyB7c2VsZWN0ZWRTdG9jay5sYXRlc3RQcmljZT09bnVsbD8nTGF0ZXN0IHByaWNlIHVuYXZhaWxhYmxlJzpgTGF0ZXN0IHByaWNlICR7bW9uZXlEZWNpbWFsKHNlbGVjdGVkU3RvY2subGF0ZXN0UHJpY2UpfWB9PC9zbWFsbD48L2Rpdj48L2Rpdj57L2lmfTwvZGl2PjxkaXYgY2xhc3M9XCJmdW5kLXNlY3Rpb25cIj48c3BhbiBjbGFzcz1cImZ1bmQtc2VjdGlvbi1sYWJlbFwiPjIgwrcgSE9MRElORzwvc3Bhbj48ZGl2IGNsYXNzPVwiZnVuZC1maWVsZC1wYWlyXCI+PGxhYmVsPlNoYXJlcyBoZWxkPGlucHV0IHR5cGU9XCJudW1iZXJcIiBpbnB1dG1vZGU9XCJkZWNpbWFsXCIgbWluPVwiMC4wMDFcIiBzdGVwPVwiMC4wMDFcIiBiaW5kOnZhbHVlPXtzdG9ja0Zvcm0ucXVhbnRpdHl9IC8+PC9sYWJlbD48bGFiZWw+VG90YWwgYW1vdW50IGludmVzdGVkPGlucHV0IHR5cGU9XCJudW1iZXJcIiBpbnB1dG1vZGU9XCJkZWNpbWFsXCIgbWluPVwiMC4wMVwiIGJpbmQ6dmFsdWU9e3N0b2NrRm9ybS50b3RhbEludmVzdGVkfSAvPjwvbGFiZWw+PC9kaXY+PC9kaXY+eyNpZiBzdG9ja0Vycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntzdG9ja0Vycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+c2hvd1N0b2NrRm9ybT1mYWxzZX0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZVN0b2NrfSBkaXNhYmxlZD17c3RvY2tTYXZpbmd9PntzdG9ja1NhdmluZz8nQWRkaW5n4oCmJzonQWRkIHN0b2NrJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+XG57L2lmfVxueyNpZiBmdW5kU2lwVGFyZ2V0fTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+ZnVuZFNpcFRhcmdldD1udWxsfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5NT05USExZIFNJUDwvcD48aDI+U2V0IHVwIFNJUCBmb3Ige2Z1bmRTaXBUYXJnZXQuc2NoZW1lTmFtZX08L2gyPjxwIGNsYXNzPVwibW9kdWxlLXJlYXNzdXJhbmNlXCI+VGhpcyBjcmVhdGVzIGEgbW9udGhseSBwbGFuLiBPY2Nhc2lvbmFsIGx1bXAgc3VtcyByZW1haW4gc2VwYXJhdGUuPC9wPjxsYWJlbD5Nb250aGx5IGFtb3VudDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMVwiIGJpbmQ6dmFsdWU9e2Z1bmRTaXBGb3JtLmFtb3VudH0vPjwvbGFiZWw+PGxhYmVsPlNJUCBkYXRlPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIxXCIgbWF4PVwiMjhcIiBiaW5kOnZhbHVlPXtmdW5kU2lwRm9ybS5kYXl9Lz48L2xhYmVsPjxsYWJlbD5TdGFydCBtb250aDxpbnB1dCB0eXBlPVwibW9udGhcIiBiaW5kOnZhbHVlPXtmdW5kU2lwRm9ybS5zdGFydE1vbnRofS8+PC9sYWJlbD57I2lmIGZ1bmRFcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57ZnVuZEVycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+ZnVuZFNpcFRhcmdldD1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlRnVuZFNpcFBsYW59IGRpc2FibGVkPXtmdW5kU2lwU2F2aW5nfT57ZnVuZFNpcFNhdmluZz8nU2F2aW5n4oCmJzonU2F2ZSBTSVAnfTwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBzdG9ja1BsYW5UYXJnZXR9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zdG9ja1BsYW5UYXJnZXQ9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TU9OVEhMWSBFVEYgUExBTjwvcD48aDI+UGxhbiB7c3RvY2tQbGFuVGFyZ2V0Lm5hbWV9PC9oMj48bGFiZWw+TW9udGhseSBhbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDFcIiBiaW5kOnZhbHVlPXtzdG9ja1BsYW5Gb3JtLmFtb3VudH0vPjwvbGFiZWw+PGxhYmVsPkludmVzdG1lbnQgZGF5PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIxXCIgbWF4PVwiMjhcIiBiaW5kOnZhbHVlPXtzdG9ja1BsYW5Gb3JtLmRheX0vPjwvbGFiZWw+PGxhYmVsPlN0YXJ0IG1vbnRoPGlucHV0IHR5cGU9XCJtb250aFwiIGJpbmQ6dmFsdWU9e3N0b2NrUGxhbkZvcm0uc3RhcnRNb250aH0vPjwvbGFiZWw+PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5zdG9ja1BsYW5UYXJnZXQ9bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZVN0b2NrUGxhbn0gZGlzYWJsZWQ9e3N0b2NrUGxhblNhdmluZ30+e3N0b2NrUGxhblNhdmluZz8nU2F2aW5n4oCmJzonU2F2ZSBtb250aGx5IHBsYW4nfTwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBzdG9ja1BsYW5Db25maXJtYXRpb25UYXJnZXR9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zdG9ja1BsYW5Db25maXJtYXRpb25UYXJnZXQ9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+Q09ORklSTSBFVEYgSU5WRVNUTUVOVDwvcD48aDI+V2FzIHRoaXMgaW52ZXN0bWVudCBwcm9jZXNzZWQ/PC9oMj48bGFiZWw+QW1vdW50IGludmVzdGVkPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwLjAxXCIgYmluZDp2YWx1ZT17c3RvY2tQbGFuQ29uZmlybWF0aW9uLmFtb3VudH0vPjwvbGFiZWw+PGxhYmVsPkV4ZWN1dGVkIG1hcmtldCBwcmljZTxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMDAxXCIgYmluZDp2YWx1ZT17c3RvY2tQbGFuQ29uZmlybWF0aW9uLnByaWNlfS8+PC9sYWJlbD48ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PnN0b2NrUGxhbkNvbmZpcm1hdGlvblRhcmdldD1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtjb25maXJtU3RvY2tQbGFufT5Db25maXJtIGludmVzdG1lbnQ8L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgc3RvY2tEZXRhaWx9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1kZXRhaWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PnN0b2NrRGV0YWlsPW51bGx9PsOXPC9idXR0b24+eyNpZiBzdG9ja0RldGFpbFN0YXR1cz09PSdsb2FkaW5nJ308aDI+TG9hZGluZyBzdG9jayBkZXRhaWxz4oCmPC9oMj57OmVsc2UgaWYgc3RvY2tEZXRhaWxTdGF0dXM9PT0nZXJyb3InfTxoMj5Db3VsZG7igJl0IGxvYWQgdGhpcyBzdG9jazwvaDI+ezplbHNlfTxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5TVE9DSyBERVRBSUxTPC9wPjxoMj57c3RvY2tEZXRhaWwuc3RvY2submFtZX08L2gyPjxkaXYgY2xhc3M9XCJkZXRhaWwtZ3JpZFwiPjxkaXY+PHNwYW4+SW52ZXN0ZWQ8L3NwYW4+PGI+e21vbmV5KHN0b2NrRGV0YWlsLnN0b2NrLmludmVzdGVkKX08L2I+PC9kaXY+PGRpdj48c3Bhbj5TaGFyZXM8L3NwYW4+PGI+e051bWJlcihzdG9ja0RldGFpbC5zdG9jay5xdWFudGl0eSkudG9GaXhlZCgzKX08L2I+PC9kaXY+PC9kaXY+PHNlY3Rpb24gY2xhc3M9XCJpbnZlc3RtZW50LWhpc3RvcnlcIj48aDM+SW52ZXN0bWVudCBoaXN0b3J5PC9oMz57I2VhY2ggc3RvY2tEZXRhaWwuaGlzdG9yeSBhcyBlbnRyeX08ZGl2IGNsYXNzPVwiaW52ZXN0bWVudC1oaXN0b3J5LXJvd1wiPjxzcGFuPntkYXRlTGFiZWwoZW50cnkudHJhbnNhY3Rpb25EYXRlKX08L3NwYW4+PHN0cm9uZz57ZW50cnkua2luZD09PSdTSVAnPydNb250aGx5IEVURiBwdXJjaGFzZSc6J09wZW5pbmcgaG9sZGluZyd9PC9zdHJvbmc+PHNwYW4gY2xhc3M9XCJoaXN0b3J5LWFtb3VudFwiPjxiPnttb25leShlbnRyeS5hbW91bnQpfTwvYj48L3NwYW4+PHNtYWxsPlByaWNlIHttb25leURlY2ltYWwoZW50cnkuZXhlY3V0aW9uUHJpY2UpfSDCtyB7TnVtYmVyKGVudHJ5LnVuaXRzKS50b0ZpeGVkKDMpfSBzaGFyZXM8L3NtYWxsPjwvZGl2PnsvZWFjaH08L3NlY3Rpb24+ey9pZn08L3NlY3Rpb24+PC9kaXY+ey9pZn1cbjwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5X2NsaWNrX2V2ZW50c19oYXZlX2tleV9ldmVudHMgLS0+XG57I2lmIGZ1bmREZXRhaWx9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1kZXRhaWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PmZ1bmREZXRhaWw9bnVsbH0+w5c8L2J1dHRvbj57I2lmIGZ1bmREZXRhaWxTdGF0dXM9PT0nbG9hZGluZyd9PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkZVTkQgREVUQUlMUzwvcD48aDI+TG9hZGluZyBmdW5kIGRldGFpbHPigKY8L2gyPns6ZWxzZSBpZiBmdW5kRGV0YWlsU3RhdHVzPT09J2Vycm9yJ308cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+RlVORCBERVRBSUxTPC9wPjxoMj5Db3VsZG7igJl0IGxvYWQgdGhpcyBmdW5kPC9oMj48cD57ZnVuZERldGFpbEVycm9yfTwvcD48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXsoKT0+b3BlbkZ1bmREZXRhaWwoZnVuZERldGFpbC5pZCl9PlRyeSBhZ2FpbjwvYnV0dG9uPns6ZWxzZX17QGNvbnN0IGRldGFpbFN1bW1hcnk9ZnVuZFN1bW1hcnkoZnVuZERldGFpbC5pZCl9PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkZVTkQgREVUQUlMUzwvcD48aDI+e2Z1bmREZXRhaWwuc2NoZW1lTmFtZX08L2gyPjxkaXYgY2xhc3M9XCJkZXRhaWwtdmFsdWVcIj48c3Bhbj5DdXJyZW50IHZhbHVlPC9zcGFuPjxzdHJvbmc+e21vbmV5KGZ1bmREZXRhaWwuY3VycmVudFZhbHVlKX08L3N0cm9uZz48L2Rpdj48ZGl2IGNsYXNzOnBvc2l0aXZlPXtOdW1iZXIoZnVuZERldGFpbC5wcm9maXRPckxvc3MpPj0wfSBjbGFzczpuZWdhdGl2ZT17TnVtYmVyKGZ1bmREZXRhaWwucHJvZml0T3JMb3NzKTwwfSBjbGFzcz1cImRldGFpbC1wbmxcIj48c3Bhbj5Ub3RhbCBQJmFtcDtMPC9zcGFuPjxzdHJvbmc+e051bWJlcihmdW5kRGV0YWlsLnByb2ZpdE9yTG9zcyk+PTA/JysnOicnfXttb25leShmdW5kRGV0YWlsLnByb2ZpdE9yTG9zcyl9PC9zdHJvbmc+PGI+e051bWJlcihmdW5kRGV0YWlsLnByb2ZpdE9yTG9zc1BlcmNlbnQpPj0wPycrJzonJ317TnVtYmVyKGZ1bmREZXRhaWwucHJvZml0T3JMb3NzUGVyY2VudCkudG9GaXhlZCgyKX0lPC9iPjwvZGl2PjxkaXYgY2xhc3M9XCJkZXRhaWwtZ3JpZFwiPjxkaXY+PHNwYW4+SW52ZXN0ZWQ8L3NwYW4+PGI+e21vbmV5KGZ1bmREZXRhaWwuaW52ZXN0ZWQpfTwvYj48L2Rpdj48ZGl2PjxzcGFuPlVuaXRzPC9zcGFuPjxiPntOdW1iZXIoZnVuZERldGFpbC51bml0cykudG9GaXhlZCgzKX08L2I+PC9kaXY+PGRpdj48c3Bhbj5BdmVyYWdlIE5BVjwvc3Bhbj48Yj57bW9uZXlEZWNpbWFsKGZ1bmREZXRhaWwuYXZlcmFnZU5hdil9PC9iPjwvZGl2PjxkaXY+PHNwYW4+Q3VycmVudCBOQVY8L3NwYW4+PGI+e21vbmV5RGVjaW1hbChmdW5kRGV0YWlsLmN1cnJlbnROYXYpfTwvYj48L2Rpdj48L2Rpdj57I2lmIGZ1bmREZXRhaWwuaGlzdG9yeT8ubGVuZ3RofTxzZWN0aW9uIGNsYXNzPVwiaW52ZXN0bWVudC1oaXN0b3J5XCI+PGgzPkludmVzdG1lbnQgaGlzdG9yeTwvaDM+eyNlYWNoIGZ1bmREZXRhaWwuaGlzdG9yeSBhcyBlbnRyeX08ZGl2IGNsYXNzPVwiaW52ZXN0bWVudC1oaXN0b3J5LXJvd1wiPjxzcGFuPntkYXRlTGFiZWwoZW50cnkudHJhbnNhY3Rpb25EYXRlKX08L3NwYW4+PHN0cm9uZz57ZW50cnkua2luZD09PVwiU0lQXCI/XCJTSVBcIjplbnRyeS5raW5kPT09XCJMVU1QU1VNXCI/XCJMdW1wIHN1bVwiOlwiT3BlbmluZyBob2xkaW5nXCJ9PC9zdHJvbmc+PHNwYW4gY2xhc3M9XCJoaXN0b3J5LWFtb3VudFwiPjxiPnttb25leShlbnRyeS5hbW91bnQpfTwvYj48YnV0dG9uIGNsYXNzPVwiaGlzdG9yeS1lZGl0XCIgb246Y2xpY2s9eygpPT5vcGVuSGlzdG9yeUVkaXQoZGV0YWlsU3VtbWFyeSxlbnRyeSl9IGFyaWEtbGFiZWw9XCJFZGl0IHRoaXMgaW52ZXN0bWVudFwiIHRpdGxlPVwiRWRpdCB0aGlzIGludmVzdG1lbnRcIj7wn5SnPC9idXR0b24+PC9zcGFuPjxzbWFsbD5OQVYge21vbmV5RGVjaW1hbChlbnRyeS5uYXYpfSDCtyB7TnVtYmVyKGVudHJ5LnVuaXRzKS50b0ZpeGVkKDMpfSB1bml0czwvc21hbGw+PC9kaXY+ey9lYWNofTwvc2VjdGlvbj57L2lmfTxwIGNsYXNzPVwiZnVuZC1kaXNjbGFpbWVyXCI+QXZlcmFnZSBOQVYgaXMgYmFzZWQgb24gY29uZmlybWVkIGludmVzdG1lbnRzLiBDdXJyZW50IE5BViBpcyB0aGUgbGF0ZXN0IGF2YWlsYWJsZSBNRkFQSSB2YWx1ZS48L3A+ey9pZn08L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgbHVtcFN1bUZ1bmR9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5sdW1wU3VtRnVuZD1udWxsfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5MVU1QLVNVTSBJTlZFU1RNRU5UPC9wPjxoMj5BZGQgdG8ge2x1bXBTdW1GdW5kLnNjaGVtZU5hbWV9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPlRoaXMgYWRkcyBjb25maXJtZWQgdW5pdHMgdG8gdGhpcyBmdW5kIG9ubHkuIEl0IGRvZXMgbm90IGNoYW5nZSB0aGUgbW9udGhseSBTSVAgcGxhbi48L3A+PGxhYmVsPkFtb3VudCBpbnZlc3RlZDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMVwiIHN0ZXA9XCIwLjAxXCIgYmluZDp2YWx1ZT17bHVtcFN1bUZvcm0uYW1vdW50fS8+PC9sYWJlbD48bGFiZWw+VHJhbnNhY3Rpb24gZGF0ZTxpbnB1dCB0eXBlPVwiZGF0ZVwiIGJpbmQ6dmFsdWU9e2x1bXBTdW1Gb3JtLnRyYW5zYWN0aW9uRGF0ZX0vPjwvbGFiZWw+PGxhYmVsPk5BVjxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMDAxXCIgc3RlcD1cIjAuMDAwMVwiIGJpbmQ6dmFsdWU9e2x1bXBTdW1Gb3JtLm5hdn0gcGxhY2Vob2xkZXI9XCJlLmcuIDg3LjI1XCIvPjwvbGFiZWw+eyNpZiBsdW1wU3VtRXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e2x1bXBTdW1FcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9Pmx1bXBTdW1GdW5kPW51bGx9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9e3NhdmVMdW1wU3VtfSBkaXNhYmxlZD17bHVtcFN1bVNhdmluZ30+e2x1bXBTdW1TYXZpbmc/J0FkZGluZ+KApic6J0FkZCBsdW1wIHN1bSd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIGNvbmZpcm1pbmdTaXB9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5jb25maXJtaW5nU2lwPW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkNPTkZJUk0gU0lQIElOVkVTVE1FTlQ8L3A+PGgyPldhcyB0aGlzIFNJUCBwcm9jZXNzZWQ/PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPlVuaXRzIHdpbGwgYmUgZXN0aW1hdGVkIGZyb20gdGhlIE5BViBhbmQgbWFya2VkIGFzIGFuIGVzdGltYXRlIHVudGlsIHlvdSBjb3JyZWN0IHRoZW0gZnJvbSB5b3VyIHN0YXRlbWVudC48L3A+PGRpdiBjbGFzcz1cInNvdXJjZS1ub3RlXCI+PHN0cm9uZz57Y29uZmlybWluZ1NpcC5mdW5kLnNjaGVtZU5hbWV9PC9zdHJvbmc+PHNwYW4+e2NvbmZpcm1pbmdTaXAub2NjdXJyZW5jZS5zY2hlZHVsZWRNb250aH0gb2NjdXJyZW5jZTwvc3Bhbj48L2Rpdj48bGFiZWw+QW1vdW50IGludmVzdGVkPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwLjAxXCIgc3RlcD1cIjAuMDFcIiBiaW5kOnZhbHVlPXtzaXBDb25maXJtRm9ybS5hbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5UcmFuc2FjdGlvbiBkYXRlPGlucHV0IHR5cGU9XCJkYXRlXCIgYmluZDp2YWx1ZT17c2lwQ29uZmlybUZvcm0udHJhbnNhY3Rpb25EYXRlfS8+PC9sYWJlbD48bGFiZWw+TkFWIDxzcGFuIGNsYXNzPVwib3B0aW9uYWxcIj5Fc3RpbWF0ZWQ8L3NwYW4+PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwLjAwMDFcIiBzdGVwPVwiMC4wMDAxXCIgYmluZDp2YWx1ZT17c2lwQ29uZmlybUZvcm0ubmF2fSBwbGFjZWhvbGRlcj1cImUuZy4gODcuMjVcIi8+PC9sYWJlbD57I2lmIHNpcENvbmZpcm1FcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57c2lwQ29uZmlybUVycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+Y29uZmlybWluZ1NpcD1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlU2lwQ29uZmlybWF0aW9ufSBkaXNhYmxlZD17c2lwQ29uZmlybVNhdmluZ30+e3NpcENvbmZpcm1TYXZpbmc/J0NvbmZpcm1pbmfigKYnOidDb25maXJtIGVzdGltYXRlJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbn08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgZnVuZC1mb3JtLWJhY2tkcm9wXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBmdW5kLWZvcm1cIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PmVkaXRpbmdGdW5kVHJhbnNhY3Rpb249bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+RURJVCBJTlZFU1RNRU5UPC9wPjxoMj57ZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbi5lbnRyeS5raW5kPT09XCJTSVBcIj9cIkVkaXQgU0lQIGFsbG9jYXRpb25cIjplZGl0aW5nRnVuZFRyYW5zYWN0aW9uLmVudHJ5LmtpbmQ9PT1cIkxVTVBTVU1cIj9cIkVkaXQgbHVtcCBzdW1cIjpcIkVkaXQgb3BlbmluZyBob2xkaW5nXCJ9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPlVwZGF0ZSB0aGlzIHJlY29yZGVkIGludmVzdG1lbnQuIFlvdXIgZnVuZCB0b3RhbHMgd2lsbCByZWNhbGN1bGF0ZSBhdXRvbWF0aWNhbGx5LjwvcD48bGFiZWw+QW1vdW50IGludmVzdGVkPGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwLjAxXCIgc3RlcD1cIjAuMDFcIiBiaW5kOnZhbHVlPXtmdW5kVHJhbnNhY3Rpb25Gb3JtLmFtb3VudH0vPjwvbGFiZWw+PGxhYmVsPlRyYW5zYWN0aW9uIGRhdGU8aW5wdXQgdHlwZT1cImRhdGVcIiBiaW5kOnZhbHVlPXtmdW5kVHJhbnNhY3Rpb25Gb3JtLnRyYW5zYWN0aW9uRGF0ZX0vPjwvbGFiZWw+PGxhYmVsPk5BVjxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMDAxXCIgc3RlcD1cIjAuMDAwMVwiIGJpbmQ6dmFsdWU9e2Z1bmRUcmFuc2FjdGlvbkZvcm0ubmF2fS8+PC9sYWJlbD57I2lmIGZ1bmRUcmFuc2FjdGlvbkVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntmdW5kVHJhbnNhY3Rpb25FcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PmVkaXRpbmdGdW5kVHJhbnNhY3Rpb249bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZUZ1bmRUcmFuc2FjdGlvbn0gZGlzYWJsZWQ9e2Z1bmRUcmFuc2FjdGlvblNhdmluZ30+e2Z1bmRUcmFuc2FjdGlvblNhdmluZz9cIlNhdmluZ+KAplwiOlwiU2F2ZSBjaGFuZ2VzXCJ9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG48IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeV9jbGlja19ldmVudHNfaGF2ZV9rZXlfZXZlbnRzIC0tPlxueyNpZiBzaG93Tm9ybWFsaXphdGlvbn08ZGl2IGNsYXNzPVwiYWNjb3VudC1yZXBhaXItYmFja2Ryb3BcIiByb2xlPVwicHJlc2VudGF0aW9uXCIgb246Y2xpY2s9eygpPT5zaG93Tm9ybWFsaXphdGlvbj1mYWxzZX0gb246a2V5ZG93bj17KGV2ZW50KT0+ZXZlbnQua2V5PT09J0VzY2FwZScmJihzaG93Tm9ybWFsaXphdGlvbj1mYWxzZSl9PjxzZWN0aW9uIGNsYXNzPVwiYWNjb3VudC1yZXBhaXItZGlhbG9nXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiIG9uOmNsaWNrfHN0b3BQcm9wYWdhdGlvbj48aGVhZGVyIGNsYXNzPVwiYWNjb3VudC1yZXBhaXItYmFyXCI+PGRpdj48c3BhbiBjbGFzcz1cInJlcGFpci1zeW1ib2xcIj7inKY8L3NwYW4+PHNwYW4+PHA+RVhQRU5TRSBEQVRBIE9OTFk8L3A+PHN0cm9uZz5FeHBlbnNlIGNsZWFudXA8L3N0cm9uZz48L3NwYW4+PC9kaXY+PGJ1dHRvbiBvbjpjbGljaz17KCk9PnNob3dOb3JtYWxpemF0aW9uPWZhbHNlfT7DlzwvYnV0dG9uPjwvaGVhZGVyPjxkaXYgY2xhc3M9XCJhY2NvdW50LXJlcGFpci1jb250ZW50XCI+PE5vcm1hbGl6YXRpb24gLz48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbjwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5X2NsaWNrX2V2ZW50c19oYXZlX2tleV9ldmVudHMgLS0+XG57I2lmIG9wZW5lZFN0b3J5fTxkaXYgY2xhc3M9XCJzdG9yeS1yZWFkZXItYmFja2Ryb3BcIiByb2xlPVwicHJlc2VudGF0aW9uXCIgb246Y2xpY2s9eygpPT5vcGVuZWRTdG9yeT1udWxsfSBvbjprZXlkb3duPXsoZXZlbnQpPT5ldmVudC5rZXk9PT0nRXNjYXBlJyYmKG9wZW5lZFN0b3J5PW51bGwpfT48c2VjdGlvbiBjbGFzcz1cInN0b3J5LWRldGFpbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIHRhYmluZGV4PVwiLTFcIiBvbjpjbGlja3xzdG9wUHJvcGFnYXRpb24+PGJ1dHRvbiBjbGFzcz1cImJhY2stYnV0dG9uXCIgb246Y2xpY2s9eygpPT5vcGVuZWRTdG9yeT1udWxsfT7ihpAgQmFjayB0byBzdG9yaWVzPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPntzdG9yeVNvdXJjZShvcGVuZWRTdG9yeSkudG9VcHBlckNhc2UoKX0gwrcge3N0b3J5TmFtZShvcGVuZWRTdG9yeSl9PC9wPnsjaWYgaGFzRGVja317QGNvbnN0IGNhcmRzPW9wZW5lZFN0b3J5LmNhcmRzLnNsaWNlKCkuc29ydCgoYSxiKT0+KGEuc2VxdWVuY2V8fDApLShiLnNlcXVlbmNlfHwwKSl9e0Bjb25zdCBjdXJyZW50Q2FyZD1jYXJkc1tzdG9yeVNsaWRlXX08ZGl2IGNsYXNzPVwic3RvcnktZGVja1wiPnsjaWYgY2FyZHMubGVuZ3RoPjF9PGRpdiBjbGFzcz1cInN0b3J5LXByb2dyZXNzXCI+eyNlYWNoIGNhcmRzIGFzIF8saW5kZXh9PGkgY2xhc3M6YWN0aXZlPXtpbmRleD09PXN0b3J5U2xpZGV9PjwvaT57L2VhY2h9PC9kaXY+ey9pZn08YXJ0aWNsZSBjbGFzcz17YHN0b3J5LXNsaWRlIGRlY2stdGhlbWUtJHtjdXJyZW50Q2FyZC50aGVtZXx8J0NBTE1fQ09OVEVYVCd9YH0gb246dG91Y2hzdGFydD17ZXZlbnQ9PihzdG9yeVRvdWNoU3RhcnQ9ZXZlbnQudG91Y2hlc1swXS5jbGllbnRYKX0gb246dG91Y2hlbmQ9e2V2ZW50PT5lbmRTdG9yeVN3aXBlKGV2ZW50LGNhcmRzLmxlbmd0aCl9PnsjaWYgY3VycmVudENhcmQuZXllYnJvd308cCBjbGFzcz1cInNsaWRlLWV5ZWJyb3dcIj57Y3VycmVudENhcmQuZXllYnJvd308L3A+ey9pZn17I2lmIGN1cnJlbnRDYXJkLmxheW91dD09PSdIRVJPX1NUQVQnJiZjdXJyZW50Q2FyZC5jb21wb25lbnRzPy5bMF19PGRpdiBjbGFzcz1cInN0b3J5LWFtb3VudFwiPjxzcGFuPntjdXJyZW50Q2FyZC5jb21wb25lbnRzWzBdLmxhYmVsfTwvc3Bhbj48c3Ryb25nPntjdXJyZW50Q2FyZC5jb21wb25lbnRzWzBdLmRpc3BsYXlWYWx1ZX08L3N0cm9uZz48L2Rpdj57L2lmfTxoMT57Y3VycmVudENhcmQudGl0bGV9PC9oMT48cD57Y3VycmVudENhcmQuYm9keX08L3A+eyNpZiBjdXJyZW50Q2FyZC5jb21wb25lbnRzPy5sZW5ndGh9PGRpdiBjbGFzcz1cIm9ic2VydmF0aW9uLWNvbXBvbmVudHNcIj57I2VhY2ggY3VycmVudENhcmQuY29tcG9uZW50cyBhcyBjb21wb25lbnR9PGRpdj48c3Bhbj57Y29tcG9uZW50LmxhYmVsfTwvc3Bhbj48c3Ryb25nPntjb21wb25lbnQuZGlzcGxheVZhbHVlfTwvc3Ryb25nPjwvZGl2PnsvZWFjaH08L2Rpdj57L2lmfXsjZWFjaCBjdXJyZW50Q2FyZC5hY3Rpb25zfHxbXSBhcyBhY3Rpb259eyNpZiBhY3Rpb24udHlwZT09PSdPUEVOX0VWSURFTkNFJ308YnV0dG9uIGNsYXNzPVwic3RvcnktYWN0aW9uXCIgZGF0YS10ZXN0aWQ9XCJ2aWV3LWluY2x1ZGVkLWNvbW1pdG1lbnRzXCIgb246Y2xpY2s9e29wZW5Db21taXRtZW50U291cmNlc30+e2FjdGlvbi5sYWJlbH08L2J1dHRvbj57OmVsc2UgaWYgYWN0aW9uLnR5cGU9PT0nT1BFTl9TQUxBUllfT1VUTE9PSyd9PGJ1dHRvbiBjbGFzcz1cInN0b3J5LWFjdGlvblwiIG9uOmNsaWNrPXsoKT0+e29wZW5lZFN0b3J5PW51bGw7b3Blbk1vbmV5KCk7fX0+e2FjdGlvbi5sYWJlbH08L2J1dHRvbj57OmVsc2UgaWYgYWN0aW9uLnR5cGU9PT0nT1BFTl9EVUVfTE9BTid9PGJ1dHRvbiBjbGFzcz1cInN0b3J5LWFjdGlvblwiIGRhdGEtdGVzdGlkPVwicmV2aWV3LWZpbmFsLWVtaVwiIG9uOmNsaWNrPXtvcGVuRHVlTG9hbkZyb21TdG9yeX0+e2FjdGlvbi5sYWJlbH08L2J1dHRvbj57L2lmfXsvZWFjaH08L2FydGljbGU+eyNpZiBjYXJkcy5sZW5ndGg+MX08ZGl2IGNsYXNzPVwic3RvcnktZGVjay1jb250cm9sc1wiPjxidXR0b24gZGlzYWJsZWQ9e3N0b3J5U2xpZGU9PT0wfSBvbjpjbGljaz17KCk9PnN0b3J5U2xpZGUtPTF9PuKGkDwvYnV0dG9uPjxzcGFuPntzdG9yeVNsaWRlKzF9IG9mIHtjYXJkcy5sZW5ndGh9PC9zcGFuPjxidXR0b24gZGlzYWJsZWQ9e3N0b3J5U2xpZGU9PT1jYXJkcy5sZW5ndGgtMX0gb246Y2xpY2s9eygpPT5zdG9yeVNsaWRlKz0xfT5OZXh0IOKGkjwvYnV0dG9uPjwvZGl2PnsvaWZ9PC9kaXY+ey9pZn08L3NlY3Rpb24+PC9kaXY+ey9pZn1cbjwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5X2NsaWNrX2V2ZW50c19oYXZlX2tleV9ldmVudHMgLS0+XG57I2lmIHNob3dDb21taXRtZW50UmV2aWV3fTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PnNob3dDb21taXRtZW50UmV2aWV3PWZhbHNlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5NT05USExZIENPTU1JVE1FTlQ8L3A+PGgyPkhlbHAgbWF0Y2ggdGhpcyBwYXltZW50PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPllvdXIgZXhwZW5zZSB3YXMgc2F2ZWQgbm9ybWFsbHkuIExpbmsgaXQgb25seSBpZiBpdCBiZWxvbmdzIHRvIG9uZSBvZiB5b3VyIGNvbW1pdG1lbnRzLjwvcD57I2lmIGNvbW1pdG1lbnRSZXZpZXdTdGF0dXM9PT0nbG9hZGluZyd9PHA+TG9hZGluZyBwYXltZW50IGNob2ljZXPigKY8L3A+ezplbHNlIGlmIGNvbW1pdG1lbnRSZXZpZXdTdGF0dXM9PT0nZXJyb3InfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntjb21taXRtZW50RXJyb3J9PC9wPns6ZWxzZX17I2VhY2ggY29tbWl0bWVudFJldmlldyBhcyBjYW5kaWRhdGV9PGRpdiBjbGFzcz1cInNvdXJjZS1ub3RlXCI+PHN0cm9uZz57bW9uZXkoY2FuZGlkYXRlLmFtb3VudCl9IMK3IHtjYW5kaWRhdGUuY2F0ZWdvcnl9IC8ge2NhbmRpZGF0ZS5zdWJjYXRlZ29yeX08L3N0cm9uZz48c3Bhbj57ZGF0ZUxhYmVsKGNhbmRpZGF0ZS50cmFuc2FjdGlvbkRhdGUpfTwvc3Bhbj48L2Rpdj48cD5XaGljaCBjb21taXRtZW50IGlzIHRoaXMgZm9yPzwvcD57I2VhY2ggY2FuZGlkYXRlLmNob2ljZXMgYXMgY2hvaWNlfTxidXR0b24gY2xhc3M9XCJzdG9yeS1hY3Rpb25cIiBvbjpjbGljaz17KCk9PnJlc29sdmVDYW5kaWRhdGUoY2FuZGlkYXRlLnRyYW5zYWN0aW9uSWQsY2hvaWNlLmlkKX0gZGlzYWJsZWQ9e3Jlc29sdmluZ0NhbmRpZGF0ZT09PWNhbmRpZGF0ZS50cmFuc2FjdGlvbklkfT57Y2hvaWNlLmxhYmVsfTwvYnV0dG9uPnsvZWFjaH08YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5yZXNvbHZlQ2FuZGlkYXRlKGNhbmRpZGF0ZS50cmFuc2FjdGlvbklkLG51bGwpfSBkaXNhYmxlZD17cmVzb2x2aW5nQ2FuZGlkYXRlPT09Y2FuZGlkYXRlLnRyYW5zYWN0aW9uSWR9PlRoaXMgaXMgbm90IGEgY29tbWl0bWVudDwvYnV0dG9uPnsvZWFjaH17I2lmICFjb21taXRtZW50UmV2aWV3Lmxlbmd0aH08cD5FdmVyeXRoaW5nIGlzIHJldmlld2VkIGZvciB0aGlzIG1vbnRoLjwvcD57L2lmfXsvaWZ9PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIHNob3dTdG9yeUV2aWRlbmNlfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcFwiIG9uOmNsaWNrPXsoKT0+c2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2V9IG9uOmtleWRvd249eyhldmVudCk9PmV2ZW50LmtleT09PSdFc2NhcGUnJiYoc2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2UpfSByb2xlPVwicHJlc2VudGF0aW9uXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbFwiIG9uOmNsaWNrfHN0b3BQcm9wYWdhdGlvbiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zaG93U3RvcnlFdmlkZW5jZT1mYWxzZX0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+SU5DTFVERUQgQ09NTUlUTUVOVFM8L3A+PGgyPntpc0NvbW1pdG1lbnQob3BlbmVkU3RvcnkpPydXaGF0IG1ha2VzIHVwIHRoaXMgbW9udGgnOidTdXBwb3J0aW5nIGV2aWRlbmNlJ308L2gyPnsjaWYgZXZpZGVuY2VJdGVtcy5sZW5ndGh9PHAgY2xhc3M9XCJldmlkZW5jZS10b3RhbFwiPntldmlkZW5jZUl0ZW1zLmxlbmd0aH0gaW5jbHVkZWQge2V2aWRlbmNlSXRlbXMubGVuZ3RoPT09MT8nY29tbWl0bWVudCc6J2NvbW1pdG1lbnRzJ308L3A+PGRpdiBjbGFzcz1cImV2aWRlbmNlLWxpc3RcIj57I2VhY2ggZXZpZGVuY2VJdGVtcyBhcyBpdGVtfXtAY29uc3QgbG9hbkl0ZW09L2xvYW4vaS50ZXN0KGl0ZW0uY2F0ZWdvcnkpfXtAY29uc3QgZnVuZEl0ZW09aXRlbS5zb3VyY2VUeXBlPT09J211dHVhbF9mdW5kX3NpcCd9e0Bjb25zdCBzdG9ja0l0ZW09aXRlbS5zb3VyY2VUeXBlPT09J3N0b2NrX21vbnRobHlfcGxhbid9e0Bjb25zdCByZWN1cnJpbmdJdGVtPWl0ZW0uc291cmNlVHlwZT09PSdyZWN1cnJpbmdfY29tbWl0bWVudCd9e0Bjb25zdCByZWN1cnJpbmdTdGF0dXM9cmVjdXJyaW5nT2NjdXJyZW5jZShpdGVtLnNvdXJjZUlkKT8uc3RhdHVzfTxkaXYgY2xhc3M6ZHVlLWNvbW1pdG1lbnQ9eyhsb2FuSXRlbSYmY3VycmVudENvbW1pdG1lbnRJc0R1ZSgpKXx8KGZ1bmRJdGVtJiZzaXBJc0R1ZShpdGVtKSl8fChzdG9ja0l0ZW0mJnN0b2Nrcy5maW5kKHN0b2NrPT5TdHJpbmcoc3RvY2suaWQpPT09U3RyaW5nKGl0ZW0uc291cmNlSWQpKT8uY3VycmVudE1vbnRobHlQbGFuPy5zdGF0dXM9PT0nRFVFJyl8fChyZWN1cnJpbmdJdGVtJiZyZWN1cnJpbmdTdGF0dXM9PT0nRFVFJyl9IGNsYXNzOmNvbmZpcm1lZC1jb21taXRtZW50PXsoZnVuZEl0ZW0mJnNpcElzQ29uZmlybWVkKGl0ZW0pKXx8KHJlY3VycmluZ0l0ZW0mJnJlY3VycmluZ1N0YXR1cz09PSdDT01QTEVURUQnKX0gY2xhc3M9XCJldmlkZW5jZS1yb3dcIj48ZGl2PjxzdHJvbmc+e2l0ZW0ubWVyY2hhbnR9PC9zdHJvbmc+PHNwYW4+e2l0ZW0uZGF0ZX17aXRlbS5kYXRlJiZpdGVtLmNhdGVnb3J5PycgwrcgJzonJ317aXRlbS5jYXRlZ29yeX08L3NwYW4+PC9kaXY+PGI+e2l0ZW0uYW1vdW50fTwvYj57I2lmIGxvYW5JdGVtfTxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBkYXRhLXRlc3RpZD1cImluY2x1ZGVkLWxvYW4tY29tbWl0bWVudFwiIG9uOmNsaWNrPXtvcGVuSW5jbHVkZWRMb2FufT5SZXZpZXc8L2J1dHRvbj57OmVsc2UgaWYgZnVuZEl0ZW19PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIGRhdGEtdGVzdGlkPXtgaW5jbHVkZWQtbXV0dWFsLWZ1bmQtY29tbWl0bWVudC0ke2l0ZW0uc291cmNlSWR9YH0gb246Y2xpY2s9eygpPT5vcGVuSW5jbHVkZWRNdXR1YWxGdW5kKGl0ZW0pfT5SZXZpZXc8L2J1dHRvbj57OmVsc2UgaWYgc3RvY2tJdGVtfTxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBkYXRhLXRlc3RpZD17YGluY2x1ZGVkLXN0b2NrLWNvbW1pdG1lbnQtJHtpdGVtLnNvdXJjZUlkfWB9IG9uOmNsaWNrPXsoKT0+b3BlbkluY2x1ZGVkU3RvY2soaXRlbSl9PlJldmlldzwvYnV0dG9uPns6ZWxzZSBpZiByZWN1cnJpbmdJdGVtfTxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBkYXRhLXRlc3RpZD17YGluY2x1ZGVkLXJlY3VycmluZy1jb21taXRtZW50LSR7aXRlbS5zb3VyY2VJZH1gfSBvbjpjbGljaz17KCk9Pm9wZW5JbmNsdWRlZENvbW1pdG1lbnQoaXRlbSl9PlJldmlldzwvYnV0dG9uPnsvaWZ9PC9kaXY+ey9lYWNofTwvZGl2Pns6ZWxzZX08ZGl2IGNsYXNzPVwiZW1wdHktc3RhdGUgZXZpZGVuY2UtZW1wdHlcIj48c3Bhbj7il4w8L3NwYW4+PGgyPk5vIGNvbW1pdG1lbnRzIGF0dGFjaGVkPC9oMj48cD5UaGlzIHN0b3J5IGRvZXMgbm90IGluY2x1ZGUgc291cmNlcyB0byBkaXNwbGF5LjwvcD48L2Rpdj57L2lmfTwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBlZGl0aW5nfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5lZGl0aW5nPW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkFJLUNBUFRVUkVEIEVYUEVOU0U8L3A+PGgyPkVkaXQgdHJhbnNhY3Rpb248L2gyPjxkaXYgY2xhc3M9XCJzb3VyY2Utbm90ZVwiPjxzdHJvbmc+Q2FwdHVyZWQgZnJvbSB5b3VyIG1lc3NhZ2U8L3N0cm9uZz48c3Bhbj5SZXZpZXcgdGhlIGRldGFpbHMgYmVsb3cgYmVmb3JlIHNhdmluZy48L3NwYW4+PC9kaXY+PGxhYmVsPkFtb3VudDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjAuMDFcIiBzdGVwPVwiMC4wMVwiIGJpbmQ6dmFsdWU9e2VkaXRBbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5UcmFuc2FjdGlvbiBkYXRlPGlucHV0IHR5cGU9XCJkYXRlXCIgbWF4PXtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwxMCl9IGJpbmQ6dmFsdWU9e2VkaXREYXRlfS8+PC9sYWJlbD57I2lmIG9wdGlvbnNTdGF0dXM9PT0nbG9hZGluZyd9PHAgY2xhc3M9XCJlZGl0LW9wdGlvbnMtc3RhdHVzXCI+TG9hZGluZyBjYXRlZ29yaWVzLCBtZXJjaGFudHMsIGFuZCBhY2NvdW50c+KApjwvcD57OmVsc2UgaWYgb3B0aW9uc1N0YXR1cz09PSdlcnJvcid9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e29wdGlvbnNFcnJvcn08L3A+ezplbHNlfTxsYWJlbD5DYXRlZ29yeTxzZWxlY3QgdmFsdWU9e2VkaXRDYXRlZ29yeX0gb246Y2hhbmdlPXtjaGFuZ2VFZGl0Q2F0ZWdvcnl9PjxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5TZWxlY3QgYSBjYXRlZ29yeTwvb3B0aW9uPnsjZWFjaCBlZGl0T3B0aW9ucy5jYXRlZ29yaWVzIGFzIG9wdGlvbn08b3B0aW9uIHZhbHVlPXtvcHRpb24ubmFtZX0+e29wdGlvbi5uYW1lfTwvb3B0aW9uPnsvZWFjaH08L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5TdWJjYXRlZ29yeTxzZWxlY3QgYmluZDp2YWx1ZT17ZWRpdFN1YmNhdGVnb3J5fSBkaXNhYmxlZD17IWVkaXRDYXRlZ29yeX0+PG9wdGlvbiB2YWx1ZT1cIlwiIGRpc2FibGVkPlNlbGVjdCBhIHN1YmNhdGVnb3J5PC9vcHRpb24+eyNlYWNoIGVkaXRTdWJjYXRlZ29yaWVzIGFzIG9wdGlvbn08b3B0aW9uIHZhbHVlPXtvcHRpb259PntvcHRpb259PC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPk1lcmNoYW50PHNlbGVjdCBiaW5kOnZhbHVlPXtlZGl0TWVyY2hhbnRJZH0+PG9wdGlvbiB2YWx1ZT1cIlwiIGRpc2FibGVkPlNlbGVjdCBhIG1lcmNoYW50PC9vcHRpb24+eyNlYWNoIGVkaXRPcHRpb25zLm1lcmNoYW50cyBhcyBvcHRpb259PG9wdGlvbiB2YWx1ZT17U3RyaW5nKG9wdGlvbi5pZCl9PntvcHRpb24ubmFtZX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+U291cmNlIGFjY291bnQ8c2VsZWN0IGJpbmQ6dmFsdWU9e2VkaXRBY2NvdW50SWR9PjxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5TZWxlY3QgYW4gYWNjb3VudDwvb3B0aW9uPnsjZWFjaCBlZGl0T3B0aW9ucy5hY2NvdW50cyBhcyBvcHRpb259PG9wdGlvbiB2YWx1ZT17U3RyaW5nKG9wdGlvbi5pZCl9PntvcHRpb24ubmFtZX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD57L2lmfXsjaWYgYWN0aW9uRXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e2FjdGlvbkVycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+ZWRpdGluZz1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlRWRpdH0gZGlzYWJsZWQ9e3NhdmluZ3x8b3B0aW9uc1N0YXR1cyE9PSdyZWFkeSd9PntzYXZpbmc/J1NhdmluZ+KApic6J1NhdmUgY2hhbmdlcyd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIGRlbGV0aW5nfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWxcIiByb2xlPVwiYWxlcnRkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIHRhYmluZGV4PVwiLTFcIj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+REVMRVRFIFRSQU5TQUNUSU9OPC9wPjxoMj5EZWxldGUge21lcmNoYW50KGRlbGV0aW5nKX0/PC9oMj48cD5UaGlzIHVwZGF0ZXMgdGhlIGNhbGVuZGFyIGFuZCBtb250aGx5IHRvdGFscy48L3A+PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5kZWxldGluZz1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeSBkZWxldGUtY29uZmlybVwiIG9uOmNsaWNrPXtjb25maXJtRGVsZXRlfT5EZWxldGU8L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgaGFuZG9mZn08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIHdoYXRzYXBwLWhhbmRvZmZcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5oYW5kb2ZmPW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPldIQVRTQVBQIFJFQURZPC9wPjxoMj5Db250aW51ZSBpbiBXaGF0c0FwcDwvaDI+PHA+U2VuZCB0aGUgbWlzc2luZyB0cmFuc2FjdGlvbiBmb3Ige2RhdGVMYWJlbChgJHtoYW5kb2ZmLmRhdGV9VDEyOjAwOjAwYCl9LjwvcD57I2lmIGhhbmRvZmYud2hhdHNhcHBVcmx9PGEgY2xhc3M9XCJjZW50ZXItYWN0aW9uIHdoYXRzYXBwLWFjdGlvblwiIGhyZWY9e2hhbmRvZmYud2hhdHNhcHBVcmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+T3BlbiBXaGF0c0FwcDwvYT57L2lmfTxidXR0b24gY2xhc3M9XCJhdXRoLXNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+aGFuZG9mZj1udWxsfT5Eb25lPC9idXR0b24+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG4iXSwiZmlsZSI6Ii9Vc2Vycy9kZWVuYS9Eb2N1bWVudHMvR2l0SHViL3BlcnNvbmFsLWFpL2Zyb250ZW5kL3NyYy9Ib21lLnN2ZWx0ZSJ9