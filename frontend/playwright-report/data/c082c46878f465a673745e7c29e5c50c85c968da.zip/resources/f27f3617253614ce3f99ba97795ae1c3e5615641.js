import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ViewDetailsLink.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

ViewDetailsLink[$.FILENAME] = 'src/components/ViewDetailsLink.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root = $.add_locations($.from_html(`<span class="view-details-link s-i-mRO75Kegit" role="button" tabindex="0">View details <span aria-hidden="true" class="s-i-mRO75Kegit">→</span></span>`), ViewDetailsLink[$.FILENAME], [[14, 0, [[21, 14]]]]);

function ViewDetailsLink($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, ViewDetailsLink);

	let onAction = $.prop($$props, 'onAction', 8, () => {});
	let label = $.prop($$props, 'label', 8, 'View details');

	function handleKeydown(event) {
		if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
			event.preventDefault();
			event.stopPropagation();
			onAction()();
		}
	}

	var $$exports = { ...$.legacy_api() };

	$.init();

	var span = root();

	$.template_effect(() => $.set_attribute(span, 'aria-label', label()));

	$.event('click', span, $.stopPropagation(function (...$$args) {
		$.apply(onAction, this, $$args, ViewDetailsLink, [19, 28]);
	}));

	$.event('keydown', span, handleKeydown);
	$.append($$anchor, span);

	return $.pop($$exports);
}

if (import.meta.hot) {
	ViewDetailsLink = $.hmr(ViewDetailsLink, () => ViewDetailsLink[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		$.cleanup_styles('s-i-mRO75Kegit');
		module.default[$.HMR].source = ViewDetailsLink[$.HMR].source;
		$.set(ViewDetailsLink[$.HMR].source, module.default[$.HMR].original);
	});
}

export default ViewDetailsLink;
import "/src/components/ViewDetailsLink.svelte?svelte&type=style&lang.css";

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OzRDQUFBLENBQUM7Ozs7S0FDWSxRQUFRLHdDQUFTLENBQUMsQ0FBQztLQUNuQixLQUFLLCtCQUFHLGNBQWM7O1VBRXhCLGFBQWEsQ0FBQyxLQUFLLEVBQUU7c0JBQ3hCLEtBQUssQ0FBQyxHQUFHLEVBQUssT0FBTyxxQkFBSSxLQUFLLENBQUMsR0FBRyxFQUFLLEdBQUcsR0FBRTtHQUM5QyxLQUFLLENBQUMsY0FBYztHQUNwQixLQUFLLENBQUMsZUFBZTtHQUNyQixRQUFRO0VBQ1Y7Q0FDRjs7Ozs7O0tBR0Q7O3lDQUFBLG9CQUlhLEtBQUs7O2tCQUpsQjtVQUsyQixRQUFROzs7b0JBTG5DLE1BTWEsYUFBYTtvQkFOMUI7OztDQUZEIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWaWV3RGV0YWlsc0xpbmsuc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQ+XG4gIGV4cG9ydCBsZXQgb25BY3Rpb24gPSAoKSA9PiB7fTtcbiAgZXhwb3J0IGxldCBsYWJlbCA9ICdWaWV3IGRldGFpbHMnO1xuXG4gIGZ1bmN0aW9uIGhhbmRsZUtleWRvd24oZXZlbnQpIHtcbiAgICBpZiAoZXZlbnQua2V5ID09PSAnRW50ZXInIHx8IGV2ZW50LmtleSA9PT0gJyAnKSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICBvbkFjdGlvbigpO1xuICAgIH1cbiAgfVxuPC9zY3JpcHQ+XG5cbjxzcGFuXG4gIGNsYXNzPVwidmlldy1kZXRhaWxzLWxpbmtcIlxuICByb2xlPVwiYnV0dG9uXCJcbiAgdGFiaW5kZXg9XCIwXCJcbiAgYXJpYS1sYWJlbD17bGFiZWx9XG4gIG9uOmNsaWNrfHN0b3BQcm9wYWdhdGlvbj17b25BY3Rpb259XG4gIG9uOmtleWRvd249e2hhbmRsZUtleWRvd259XG4+VmlldyBkZXRhaWxzIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKGkjwvc3Bhbj48L3NwYW4+XG5cbjxzdHlsZT5cbiAgLnZpZXctZGV0YWlscy1saW5rIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGdhcDogM3B4O1xuICAgIG1hcmdpbjogMDtcbiAgICBwYWRkaW5nOiAwO1xuICAgIGJvcmRlcjogMDtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgICBjb2xvcjogdmFyKC0tZ3JlZW4pO1xuICAgIGZvbnQ6IDgwMCAxMHB4LzEuMiAnRE0gU2FucycsIHNhbnMtc2VyaWY7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cblxuICAudmlldy1kZXRhaWxzLWxpbms6aG92ZXIgeyB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgdGV4dC11bmRlcmxpbmUtb2Zmc2V0OiAzcHg7IH1cbiAgLnZpZXctZGV0YWlscy1saW5rOmZvY3VzLXZpc2libGUgeyBvdXRsaW5lOiAycHggc29saWQgIzRlOWQ4ZDsgb3V0bGluZS1vZmZzZXQ6IDNweDsgYm9yZGVyLXJhZGl1czogNHB4OyB9XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvVXNlcnMvZGVlbmEvRG9jdW1lbnRzL0dpdEh1Yi9wZXJzb25hbC1haS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9WaWV3RGV0YWlsc0xpbmsuc3ZlbHRlIn0=