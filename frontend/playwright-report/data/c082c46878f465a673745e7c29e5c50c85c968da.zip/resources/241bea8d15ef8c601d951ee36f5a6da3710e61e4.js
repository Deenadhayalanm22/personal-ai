import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/profile/ProfileSettings.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

ProfileSettings[$.FILENAME] = 'src/features/profile/ProfileSettings.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root_1 = $.add_locations($.from_html(`<label><span> </span><input type="checkbox"/></label>`), ProfileSettings[$.FILENAME], [[16, 224, [[16, 231], [16, 256]]]]);
var root_2 = $.add_locations($.from_html(`<p class="form-error"> </p>`), ProfileSettings[$.FILENAME], [[17, 345]]);
var root_3 = $.add_locations($.from_html(`<p class="form-error"> </p>`), ProfileSettings[$.FILENAME], [[18, 284]]);

var root = $.add_locations($.from_html(`<section class="workspace-heading"><div><p class="micro-label">YOUR DATA, YOUR CHOICE</p><h1>You</h1><p>Control the information that informs your stories.</p></div></section> <section class="settings-card"><p class="micro-label">YOUR DATA</p><button><span>▤</span><div><strong>Expense capture</strong><small>AI-captured expenses and cleanup</small></div><b>On ›</b></button><button><span>↗</span><div><strong>Optional money modules</strong><small>Goals, investing, safety and budgets</small></div><b>Manage ›</b></button></section> <section class="settings-card"><p class="micro-label">STORY CONTROLS</p><!></section> <section class="settings-card"><p class="micro-label">PRESENTATION</p><label class="demo-mode-toggle"><span><strong>Demo mode</strong><small>Use a separate profile while presenting. Your real data stays hidden.</small></span><input type="checkbox"/></label><!></section> <section class="settings-card"><p class="micro-label">ACCOUNT</p><button><span>↪</span><div><strong> </strong><small>End your secure session on this device</small></div><b>›</b></button><!></section>`, 1), ProfileSettings[$.FILENAME], [
	[14, 0, [[14, 35, [[14, 40], [14, 89], [14, 101]]]]],

	[
		15,
		0,

		[
			[15, 31],

			[
				15,
				67,
				[[15, 119], [15, 133, [[15, 138], [15, 170]]], [15, 223]]
			],

			[
				15,
				243,
				[[15, 274], [15, 288, [[15, 293], [15, 332]]], [15, 389]]
			]
		]
	],

	[16, 0, [[16, 31]]],

	[
		17,
		0,

		[
			[17, 31],
			[17, 70, [[17, 102, [[17, 108], [17, 134]]], [17, 225]]]
		]
	],

	[
		18,
		0,

		[
			[18, 31],

			[
				18,
				65,
				[[18, 116], [18, 130, [[18, 135], [18, 190]]], [18, 249]]
			]
		]
	]
]);

function ProfileSettings($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, ProfileSettings);

	var $$ownership_validator = $.create_ownership_validator($$props);
	let demoMode = $.prop($$props, 'demoMode', 8);
	let demoSwitching = $.prop($$props, 'demoSwitching', 8);
	let demoError = $.prop($$props, 'demoError', 8);
	let loggingOut = $.prop($$props, 'loggingOut', 8);
	let signOutError = $.prop($$props, 'signOutError', 8);
	let storyControls = $.prop($$props, 'storyControls', 12);
	let onNavigate = $.prop($$props, 'onNavigate', 8);
	let onOpenMoney = $.prop($$props, 'onOpenMoney', 8);
	let onDemoModeChange = $.prop($$props, 'onDemoModeChange', 8);
	let onSignOut = $.prop($$props, 'onSignOut', 8);
	var $$exports = { ...$.legacy_api() };

	$.init();

	var fragment = root();
	var section = $.sibling($.first_child(fragment), 2);
	var button = $.sibling($.child(section));
	var button_1 = $.sibling(button);

	$.reset(section);

	var section_1 = $.sibling(section, 2);
	var node = $.sibling($.child(section_1));

	$.add_svelte_meta(
		() => $.each(
			node,
			0,
			() => [
				['spending', 'Use spending in stories'],
				['investments', 'Use investments in stories'],
				['planning', 'Use goals and budgets in stories']
			],
			$.index,
			($$anchor, control) => {
				var label = root_1();
				var span = $.child(label);
				var text = $.child(span, true);

				$.reset(span);

				var input = $.sibling(span);

				$.remove_input_defaults(input);
				$.reset(label);
				$.template_effect(() => $.set_text(text, (control, $.untrack(() => control[1]))));

				$.bind_checked(
					input,
					function get() {
						return storyControls()[control[0]];
					},
					function set($$value) {
						storyControls(storyControls()[control[0]] = $$value, true);
					}
				);

				$.append($$anchor, label);
			}
		),
		'each',
		ProfileSettings,
		16,
		72
	);

	$.reset(section_1);

	var section_2 = $.sibling(section_1, 2);
	var label_1 = $.sibling($.child(section_2));
	var input_1 = $.sibling($.child(label_1));

	$.remove_input_defaults(input_1);
	$.reset(label_1);

	var node_1 = $.sibling(label_1);

	{
		var consequent = ($$anchor) => {
			var p = root_2();
			var text_1 = $.child(p, true);

			$.reset(p);
			$.template_effect(() => $.set_text(text_1, demoError()));
			$.append($$anchor, p);
		};

		$.add_svelte_meta(
			() => $.if(node_1, ($$render) => {
				if (demoError()) $$render(consequent);
			}),
			'if',
			ProfileSettings,
			17,
			330
		);
	}

	$.reset(section_2);

	var section_3 = $.sibling(section_2, 2);
	var button_2 = $.sibling($.child(section_3));
	var div = $.sibling($.child(button_2));
	var strong = $.child(div);
	var text_2 = $.child(strong, true);

	$.reset(strong);
	$.next();
	$.reset(div);
	$.next();
	$.reset(button_2);

	var node_2 = $.sibling(button_2);

	{
		var consequent_1 = ($$anchor) => {
			var p_1 = root_3();
			var text_3 = $.child(p_1, true);

			$.reset(p_1);
			$.template_effect(() => $.set_text(text_3, signOutError()));
			$.append($$anchor, p_1);
		};

		$.add_svelte_meta(
			() => $.if(node_2, ($$render) => {
				if (signOutError()) $$render(consequent_1);
			}),
			'if',
			ProfileSettings,
			18,
			266
		);
	}

	$.reset(section_3);

	$.template_effect(() => {
		$.set_checked(input_1, demoMode());
		input_1.disabled = demoSwitching();
		button_2.disabled = loggingOut();
		$.set_text(text_2, loggingOut() ? 'Signing out…' : 'Sign out');
	});

	$.event('click', button, () => onNavigate()('transactions'));

	$.event('click', button_1, function (...$$args) {
		$.apply(onOpenMoney, this, $$args, ProfileSettings, [15, 261]);
	});

	$.event('change', input_1, function (...$$args) {
		$.apply(onDemoModeChange, this, $$args, ProfileSettings, [17, 303]);
	});

	$.event('click', button_2, function (...$$args) {
		$.apply(onSignOut, this, $$args, ProfileSettings, [18, 83]);
	});

	$.append($$anchor, fragment);

	return $.pop($$exports);
}

if (import.meta.hot) {
	ProfileSettings = $.hmr(ProfileSettings, () => ProfileSettings[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = ProfileSettings[$.HMR].source;
		$.set(ProfileSettings[$.HMR].source, module.default[$.HMR].original);
	});
}

export default ProfileSettings;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUFBLENBQUM7Ozs7O0tBQ1ksUUFBUTtLQUNSLGFBQWE7S0FDYixTQUFTO0tBQ1QsVUFBVTtLQUNWLFlBQVk7S0FDWixhQUFhO0tBQ2IsVUFBVTtLQUNWLFdBQVc7S0FDWCxnQkFBZ0I7S0FDaEIsU0FBUzs7Ozs7O0tBSXJCLE9BQU87S0FBNEQsTUFBTSxxQkFBekUsT0FBTztLQUE0TyxRQUFNLGFBQXRMLE1BQU07O1NBQXpFLE9BQU87O0tBQ1AsU0FBTyxhQURQLE9BQU87OEJBQ1AsU0FBTzs7Ozs7OztLQUF5RSxVQUFVLEVBQUMseUJBQXlCO0tBQUcsYUFBYSxFQUFDLDRCQUE0QjtLQUFHLFVBQVUsRUFBQyxrQ0FBa0M7OztjQUFNLE9BQU87UUFBRSxLQUFLO1FBQUUsSUFBSSxXQUFYLEtBQUs7dUJBQUUsSUFBSTs7WUFBSixJQUFJOztRQUFxQixLQUFLLGFBQTlCLElBQUk7OzRCQUFxQixLQUFLO1lBQXJDLEtBQUs7OENBQWQsT0FBTyxrQkFBZSxPQUFPLENBQUMsQ0FBQzs7O0tBQVUsS0FBSztjQUFpQixHQUFZO2FBQUUsYUFBYSxHQUFDLE9BQU8sQ0FBQyxDQUFDOztjQUFyQyxHQUFZO01BQUUsYUFBYSxDQUFiLGFBQWEsR0FBQyxPQUFPLENBQUMsQ0FBQzs7Ozt1QkFBM0YsS0FBSzs7Ozs7Ozs7O1NBQXJPLFNBQU87O0tBQ1AsU0FBTyxhQURQLFNBQU87S0FDK0QsT0FBSyxxQkFBM0UsU0FBTztLQUEwTixPQUFLLHFCQUFoSyxPQUFLOzt5QkFBc0osT0FBSztTQUFoSyxPQUFLOzt3QkFBTCxPQUFLOzs7O09BQThRLENBQUM7d0JBQUQsQ0FBQzs7V0FBRCxDQUFDOzhDQUFxQixTQUFTO3NCQUEvQixDQUFDOzs7OztRQUFaLFNBQVM7Ozs7Ozs7OztTQUF2VixTQUFPOztLQUNQLFNBQU8sYUFEUCxTQUFPO0tBQzBELFFBQU0scUJBQXZFLFNBQU87S0FBMkgsR0FBRyxxQkFBcEUsUUFBTTtLQUFnRSxNQUFNLFdBQVgsR0FBRztzQkFBRSxNQUFNOztTQUFOLE1BQU07O1NBQVgsR0FBRzs7U0FBcEUsUUFBTTs7d0JBQU4sUUFBTTs7OztPQUFxTixHQUFDO3dCQUFELEdBQUM7O1dBQUQsR0FBQzs4Q0FBcUIsWUFBWTtzQkFBbEMsR0FBQzs7Ozs7UUFBZixZQUFZOzs7Ozs7Ozs7U0FBMVIsU0FBTzs7O2dCQUQwTixPQUFLLEVBQTBCLFFBQVE7RUFBdkMsT0FBSyxZQUE4QyxhQUFhO0VBQ2hPLFFBQU0sWUFBZ0MsVUFBVTtxQkFBOEIsVUFBVSxLQUFDLGNBQWMsR0FBQyxVQUFVOzs7a0JBSGhILE1BQU0sUUFBaUIsVUFBVSxHQUFDLGNBQWM7O2tCQUFnSSxRQUFNO1VBQVcsV0FBVzs7O21CQUU5QyxPQUFLO1VBQXdFLGdCQUFnQjs7O2tCQUM3UCxRQUFNO1VBQVcsU0FBUzs7Ozs7O0NBTjVGIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9maWxlU2V0dGluZ3Muc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQ+XG4gIGV4cG9ydCBsZXQgZGVtb01vZGU7XG4gIGV4cG9ydCBsZXQgZGVtb1N3aXRjaGluZztcbiAgZXhwb3J0IGxldCBkZW1vRXJyb3I7XG4gIGV4cG9ydCBsZXQgbG9nZ2luZ091dDtcbiAgZXhwb3J0IGxldCBzaWduT3V0RXJyb3I7XG4gIGV4cG9ydCBsZXQgc3RvcnlDb250cm9scztcbiAgZXhwb3J0IGxldCBvbk5hdmlnYXRlO1xuICBleHBvcnQgbGV0IG9uT3Blbk1vbmV5O1xuICBleHBvcnQgbGV0IG9uRGVtb01vZGVDaGFuZ2U7XG4gIGV4cG9ydCBsZXQgb25TaWduT3V0O1xuPC9zY3JpcHQ+XG5cbjxzZWN0aW9uIGNsYXNzPVwid29ya3NwYWNlLWhlYWRpbmdcIj48ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5ZT1VSIERBVEEsIFlPVVIgQ0hPSUNFPC9wPjxoMT5Zb3U8L2gxPjxwPkNvbnRyb2wgdGhlIGluZm9ybWF0aW9uIHRoYXQgaW5mb3JtcyB5b3VyIHN0b3JpZXMuPC9wPjwvZGl2Pjwvc2VjdGlvbj5cbjxzZWN0aW9uIGNsYXNzPVwic2V0dGluZ3MtY2FyZFwiPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5ZT1VSIERBVEE8L3A+PGJ1dHRvbiBvbjpjbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgndHJhbnNhY3Rpb25zJyl9PjxzcGFuPuKWpDwvc3Bhbj48ZGl2PjxzdHJvbmc+RXhwZW5zZSBjYXB0dXJlPC9zdHJvbmc+PHNtYWxsPkFJLWNhcHR1cmVkIGV4cGVuc2VzIGFuZCBjbGVhbnVwPC9zbWFsbD48L2Rpdj48Yj5PbiDigLo8L2I+PC9idXR0b24+PGJ1dHRvbiBvbjpjbGljaz17b25PcGVuTW9uZXl9PjxzcGFuPuKGlzwvc3Bhbj48ZGl2PjxzdHJvbmc+T3B0aW9uYWwgbW9uZXkgbW9kdWxlczwvc3Ryb25nPjxzbWFsbD5Hb2FscywgaW52ZXN0aW5nLCBzYWZldHkgYW5kIGJ1ZGdldHM8L3NtYWxsPjwvZGl2PjxiPk1hbmFnZSDigLo8L2I+PC9idXR0b24+PC9zZWN0aW9uPlxuPHNlY3Rpb24gY2xhc3M9XCJzZXR0aW5ncy1jYXJkXCI+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPlNUT1JZIENPTlRST0xTPC9wPnsjZWFjaCBbWydzcGVuZGluZycsJ1VzZSBzcGVuZGluZyBpbiBzdG9yaWVzJ10sWydpbnZlc3RtZW50cycsJ1VzZSBpbnZlc3RtZW50cyBpbiBzdG9yaWVzJ10sWydwbGFubmluZycsJ1VzZSBnb2FscyBhbmQgYnVkZ2V0cyBpbiBzdG9yaWVzJ11dIGFzIGNvbnRyb2x9PGxhYmVsPjxzcGFuPntjb250cm9sWzFdfTwvc3Bhbj48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgYmluZDpjaGVja2VkPXtzdG9yeUNvbnRyb2xzW2NvbnRyb2xbMF1dfS8+PC9sYWJlbD57L2VhY2h9PC9zZWN0aW9uPlxuPHNlY3Rpb24gY2xhc3M9XCJzZXR0aW5ncy1jYXJkXCI+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPlBSRVNFTlRBVElPTjwvcD48bGFiZWwgY2xhc3M9XCJkZW1vLW1vZGUtdG9nZ2xlXCI+PHNwYW4+PHN0cm9uZz5EZW1vIG1vZGU8L3N0cm9uZz48c21hbGw+VXNlIGEgc2VwYXJhdGUgcHJvZmlsZSB3aGlsZSBwcmVzZW50aW5nLiBZb3VyIHJlYWwgZGF0YSBzdGF5cyBoaWRkZW4uPC9zbWFsbD48L3NwYW4+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e2RlbW9Nb2RlfSBkaXNhYmxlZD17ZGVtb1N3aXRjaGluZ30gb246Y2hhbmdlPXtvbkRlbW9Nb2RlQ2hhbmdlfS8+PC9sYWJlbD57I2lmIGRlbW9FcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57ZGVtb0Vycm9yfTwvcD57L2lmfTwvc2VjdGlvbj5cbjxzZWN0aW9uIGNsYXNzPVwic2V0dGluZ3MtY2FyZFwiPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5BQ0NPVU5UPC9wPjxidXR0b24gb246Y2xpY2s9e29uU2lnbk91dH0gZGlzYWJsZWQ9e2xvZ2dpbmdPdXR9PjxzcGFuPuKGqjwvc3Bhbj48ZGl2PjxzdHJvbmc+e2xvZ2dpbmdPdXQ/J1NpZ25pbmcgb3V04oCmJzonU2lnbiBvdXQnfTwvc3Ryb25nPjxzbWFsbD5FbmQgeW91ciBzZWN1cmUgc2Vzc2lvbiBvbiB0aGlzIGRldmljZTwvc21hbGw+PC9kaXY+PGI+4oC6PC9iPjwvYnV0dG9uPnsjaWYgc2lnbk91dEVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntzaWduT3V0RXJyb3J9PC9wPnsvaWZ9PC9zZWN0aW9uPlxuIl0sImZpbGUiOiIvVXNlcnMvZGVlbmEvRG9jdW1lbnRzL0dpdEh1Yi9wZXJzb25hbC1haS9mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHJvZmlsZS9Qcm9maWxlU2V0dGluZ3Muc3ZlbHRlIn0=