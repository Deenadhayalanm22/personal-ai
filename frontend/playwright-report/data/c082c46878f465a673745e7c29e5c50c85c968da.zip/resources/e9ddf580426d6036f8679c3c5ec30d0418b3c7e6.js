import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PrivacyPolicy.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

PrivacyPolicy[$.FILENAME] = 'src/PrivacyPolicy.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root = $.add_locations($.from_html(`<div class="privacy-container s-S0Q9gWttrt5O"><h1 class="s-S0Q9gWttrt5O">Privacy Policy</h1> <p class="updated s-S0Q9gWttrt5O">Last updated: December 29, 2025</p> <p class="s-S0Q9gWttrt5O">This Privacy Policy describes how this application ("the App") collects, uses, and protects user information during a limited pilot and testing phase.</p> <h2 class="s-S0Q9gWttrt5O">1. About This Application</h2> <p class="s-S0Q9gWttrt5O">This App is currently in an early-stage testing and pilot phase. It is being shared with a limited number of real users for functional testing, feedback, and behavior analysis before any public or commercial rollout.</p> <p class="s-S0Q9gWttrt5O">At this stage:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">The App is not a fully launched product</li> <li class="s-S0Q9gWttrt5O">The business entity and commercial model are not finalized</li> <li class="s-S0Q9gWttrt5O">Usage is limited and controlled</li></ul> <h2 class="s-S0Q9gWttrt5O">2. Information We Collect</h2> <p class="s-S0Q9gWttrt5O">During usage of the App, we may collect the following information:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">Phone number (required to communicate via WhatsApp)</li> <li class="s-S0Q9gWttrt5O">Message content sent by the user during interaction</li> <li class="s-S0Q9gWttrt5O">Basic metadata related to message delivery (timestamps, status)</li></ul> <p class="s-S0Q9gWttrt5O">We do not collect:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">Financial information</li> <li class="s-S0Q9gWttrt5O">Sensitive personal identifiers</li> <li class="s-S0Q9gWttrt5O">Location data</li> <li class="s-S0Q9gWttrt5O">Contacts or device data</li></ul> <h2 class="s-S0Q9gWttrt5O">3. How We Use the Information</h2> <p class="s-S0Q9gWttrt5O">Collected information is used only for:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">Sending and receiving WhatsApp messages</li> <li class="s-S0Q9gWttrt5O">Providing responses or notifications requested by the user</li> <li class="s-S0Q9gWttrt5O">Testing application behavior and performance</li> <li class="s-S0Q9gWttrt5O">Debugging and improving system reliability</li></ul> <p class="s-S0Q9gWttrt5O">The data is not used for marketing, advertising, or profiling.</p> <h2 class="s-S0Q9gWttrt5O">4. WhatsApp and Meta Platform Usage</h2> <p class="s-S0Q9gWttrt5O">This App uses the WhatsApp Business Platform APIs provided by Meta.</p> <p class="s-S0Q9gWttrt5O">Messages exchanged through WhatsApp are processed in accordance with:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">WhatsApp Business Platform policies</li> <li class="s-S0Q9gWttrt5O">Meta's data handling and security standards</li></ul> <p class="s-S0Q9gWttrt5O">We do not have access to any user data beyond what is explicitly shared during conversations.</p> <h2 class="s-S0Q9gWttrt5O">5. Data Sharing</h2> <p class="s-S0Q9gWttrt5O">We do not sell, rent, or trade user data.</p> <p class="s-S0Q9gWttrt5O">User data is not shared with third parties, except:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">As required to operate messaging via WhatsApp (Meta platforms)</li> <li class="s-S0Q9gWttrt5O">When required by law or legal process</li></ul> <h2 class="s-S0Q9gWttrt5O">6. Data Retention</h2> <p class="s-S0Q9gWttrt5O">User data is retained only for as long as necessary to:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">Support the pilot testing phase</li> <li class="s-S0Q9gWttrt5O">Resolve issues or analyze failures</li></ul> <p class="s-S0Q9gWttrt5O">Data may be deleted periodically as part of cleanup or when testing concludes.</p> <h2 class="s-S0Q9gWttrt5O">7. User Rights</h2> <p class="s-S0Q9gWttrt5O">Users may:</p> <ul class="s-S0Q9gWttrt5O"><li class="s-S0Q9gWttrt5O">Request deletion of their conversation data</li> <li class="s-S0Q9gWttrt5O">Stop using the App at any time</li></ul> <p class="s-S0Q9gWttrt5O">Requests can be made via the contact information below.</p> <h2 class="s-S0Q9gWttrt5O">8. Security</h2> <p class="s-S0Q9gWttrt5O">Reasonable technical and organizational measures are taken to protect user data against unauthorized access, misuse, or loss. However, as this is a testing-phase application, users acknowledge and accept inherent risks.</p> <h2 class="s-S0Q9gWttrt5O">9. Changes to This Policy</h2> <p class="s-S0Q9gWttrt5O">This Privacy Policy may be updated as the App evolves from pilot to a full product. Any changes will be reflected on this page.</p> <h2 class="s-S0Q9gWttrt5O">10. Contact Information</h2> <p class="s-S0Q9gWttrt5O">For any questions, concerns, or data deletion requests, please contact:</p> <p class="s-S0Q9gWttrt5O"><strong class="s-S0Q9gWttrt5O">Email:</strong> <a href="mailto:your-email@example.com" class="s-S0Q9gWttrt5O">deenadhayalan.m22@gmail.com</a></p></div>`), PrivacyPolicy[$.FILENAME], [
	[
		73,
		0,

		[
			[74, 2],
			[75, 2],
			[77, 2],
			[79, 2],
			[80, 2],
			[82, 2],
			[83, 2, [[84, 4], [85, 4], [86, 4]]],
			[89, 2],
			[90, 2],
			[91, 2, [[92, 4], [93, 4], [94, 4]]],
			[97, 2],
			[98, 2, [[99, 4], [100, 4], [101, 4], [102, 4]]],
			[105, 2],
			[106, 2],
			[107, 2, [[108, 4], [109, 4], [110, 4], [111, 4]]],
			[113, 2],
			[115, 2],
			[116, 2],
			[117, 2],
			[118, 2, [[119, 4], [120, 4]]],
			[122, 2],
			[124, 2],
			[125, 2],
			[126, 2],
			[127, 2, [[128, 4], [129, 4]]],
			[132, 2],
			[133, 2],
			[134, 2, [[135, 4], [136, 4]]],
			[138, 2],
			[140, 2],
			[141, 2],
			[142, 2, [[143, 4], [144, 4]]],
			[146, 2],
			[148, 2],
			[149, 2],
			[151, 2],
			[152, 2],
			[154, 2],
			[155, 2],
			[156, 2, [[156, 5], [156, 29]]]
		]
	]
]);

function PrivacyPolicy($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, PrivacyPolicy);

	var $$exports = { ...$.legacy_api() };

	var // Simple privacy policy component
	div = root();

	$.append($$anchor, div);

	return $.pop($$exports);
}

if (import.meta.hot) {
	PrivacyPolicy = $.hmr(PrivacyPolicy, () => PrivacyPolicy[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		$.cleanup_styles('s-S0Q9gWttrt5O');
		module.default[$.HMR].source = PrivacyPolicy[$.HMR].source;
		$.set(PrivacyPolicy[$.HMR].source, module.default[$.HMR].original);
	});
}

export default PrivacyPolicy;
import "/src/PrivacyPolicy.svelte?svelte&type=style&lang.css";

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQUFBLENBQUM7Ozs7Ozs7Q0F3RUEsR0FBRzs7b0JBQUgsR0FBRzs7O0NBdEVKIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcml2YWN5UG9saWN5LnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0PlxuICAvLyBTaW1wbGUgcHJpdmFjeSBwb2xpY3kgY29tcG9uZW50XG48L3NjcmlwdD5cblxuPHN0eWxlPlxuICAucHJpdmFjeS1jb250YWluZXIge1xuICAgIG1heC13aWR0aDogODAwcHg7XG4gICAgbWFyZ2luOiAycmVtIGF1dG87XG4gICAgcGFkZGluZzogMnJlbTtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwyNTUsMjU1LDAuMDMpO1xuICAgIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gICAgbGluZS1oZWlnaHQ6IDEuNztcbiAgfVxuXG4gIGgxIHtcbiAgICBmb250LXNpemU6IDJyZW07XG4gICAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xuICAgIGNvbG9yOiAjZWVmMmZmO1xuICB9XG5cbiAgaDIge1xuICAgIGZvbnQtc2l6ZTogMS40cmVtO1xuICAgIG1hcmdpbi10b3A6IDJyZW07XG4gICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbiAgICBjb2xvcjogI2M3ZDJmZTtcbiAgfVxuXG4gIHAsIGxpIHtcbiAgICBjb2xvcjogIzlhYTNkNjtcbiAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuICB9XG5cbiAgdWwge1xuICAgIG1hcmdpbi1sZWZ0OiAxLjVyZW07XG4gICAgbWFyZ2luLWJvdHRvbTogMS41cmVtO1xuICB9XG5cbiAgbGkge1xuICAgIG1hcmdpbi1ib3R0b206IDAuNXJlbTtcbiAgfVxuXG4gIC51cGRhdGVkIHtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgY29sb3I6ICM4YjkyYjg7XG4gICAgbWFyZ2luLWJvdHRvbTogMnJlbTtcbiAgfVxuXG4gIGEge1xuICAgIGNvbG9yOiAjNjY3ZWVhO1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgfVxuXG4gIGE6aG92ZXIge1xuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICB9XG5cbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XG4gICAgLnByaXZhY3ktY29udGFpbmVyIHtcbiAgICAgIHBhZGRpbmc6IDEuNXJlbTtcbiAgICAgIG1hcmdpbjogMXJlbTtcbiAgICB9XG5cbiAgICBoMSB7XG4gICAgICBmb250LXNpemU6IDEuNXJlbTtcbiAgICB9XG5cbiAgICBoMiB7XG4gICAgICBmb250LXNpemU6IDEuMnJlbTtcbiAgICB9XG4gIH1cbjwvc3R5bGU+XG5cbjxkaXYgY2xhc3M9XCJwcml2YWN5LWNvbnRhaW5lclwiPlxuICA8aDE+UHJpdmFjeSBQb2xpY3k8L2gxPlxuICA8cCBjbGFzcz1cInVwZGF0ZWRcIj5MYXN0IHVwZGF0ZWQ6IERlY2VtYmVyIDI5LCAyMDI1PC9wPlxuXG4gIDxwPlRoaXMgUHJpdmFjeSBQb2xpY3kgZGVzY3JpYmVzIGhvdyB0aGlzIGFwcGxpY2F0aW9uIChcInRoZSBBcHBcIikgY29sbGVjdHMsIHVzZXMsIGFuZCBwcm90ZWN0cyB1c2VyIGluZm9ybWF0aW9uIGR1cmluZyBhIGxpbWl0ZWQgcGlsb3QgYW5kIHRlc3RpbmcgcGhhc2UuPC9wPlxuXG4gIDxoMj4xLiBBYm91dCBUaGlzIEFwcGxpY2F0aW9uPC9oMj5cbiAgPHA+VGhpcyBBcHAgaXMgY3VycmVudGx5IGluIGFuIGVhcmx5LXN0YWdlIHRlc3RpbmcgYW5kIHBpbG90IHBoYXNlLiBJdCBpcyBiZWluZyBzaGFyZWQgd2l0aCBhIGxpbWl0ZWQgbnVtYmVyIG9mIHJlYWwgdXNlcnMgZm9yIGZ1bmN0aW9uYWwgdGVzdGluZywgZmVlZGJhY2ssIGFuZCBiZWhhdmlvciBhbmFseXNpcyBiZWZvcmUgYW55IHB1YmxpYyBvciBjb21tZXJjaWFsIHJvbGxvdXQuPC9wPlxuICBcbiAgPHA+QXQgdGhpcyBzdGFnZTo8L3A+XG4gIDx1bD5cbiAgICA8bGk+VGhlIEFwcCBpcyBub3QgYSBmdWxseSBsYXVuY2hlZCBwcm9kdWN0PC9saT5cbiAgICA8bGk+VGhlIGJ1c2luZXNzIGVudGl0eSBhbmQgY29tbWVyY2lhbCBtb2RlbCBhcmUgbm90IGZpbmFsaXplZDwvbGk+XG4gICAgPGxpPlVzYWdlIGlzIGxpbWl0ZWQgYW5kIGNvbnRyb2xsZWQ8L2xpPlxuICA8L3VsPlxuXG4gIDxoMj4yLiBJbmZvcm1hdGlvbiBXZSBDb2xsZWN0PC9oMj5cbiAgPHA+RHVyaW5nIHVzYWdlIG9mIHRoZSBBcHAsIHdlIG1heSBjb2xsZWN0IHRoZSBmb2xsb3dpbmcgaW5mb3JtYXRpb246PC9wPlxuICA8dWw+XG4gICAgPGxpPlBob25lIG51bWJlciAocmVxdWlyZWQgdG8gY29tbXVuaWNhdGUgdmlhIFdoYXRzQXBwKTwvbGk+XG4gICAgPGxpPk1lc3NhZ2UgY29udGVudCBzZW50IGJ5IHRoZSB1c2VyIGR1cmluZyBpbnRlcmFjdGlvbjwvbGk+XG4gICAgPGxpPkJhc2ljIG1ldGFkYXRhIHJlbGF0ZWQgdG8gbWVzc2FnZSBkZWxpdmVyeSAodGltZXN0YW1wcywgc3RhdHVzKTwvbGk+XG4gIDwvdWw+XG5cbiAgPHA+V2UgZG8gbm90IGNvbGxlY3Q6PC9wPlxuICA8dWw+XG4gICAgPGxpPkZpbmFuY2lhbCBpbmZvcm1hdGlvbjwvbGk+XG4gICAgPGxpPlNlbnNpdGl2ZSBwZXJzb25hbCBpZGVudGlmaWVyczwvbGk+XG4gICAgPGxpPkxvY2F0aW9uIGRhdGE8L2xpPlxuICAgIDxsaT5Db250YWN0cyBvciBkZXZpY2UgZGF0YTwvbGk+XG4gIDwvdWw+XG5cbiAgPGgyPjMuIEhvdyBXZSBVc2UgdGhlIEluZm9ybWF0aW9uPC9oMj5cbiAgPHA+Q29sbGVjdGVkIGluZm9ybWF0aW9uIGlzIHVzZWQgb25seSBmb3I6PC9wPlxuICA8dWw+XG4gICAgPGxpPlNlbmRpbmcgYW5kIHJlY2VpdmluZyBXaGF0c0FwcCBtZXNzYWdlczwvbGk+XG4gICAgPGxpPlByb3ZpZGluZyByZXNwb25zZXMgb3Igbm90aWZpY2F0aW9ucyByZXF1ZXN0ZWQgYnkgdGhlIHVzZXI8L2xpPlxuICAgIDxsaT5UZXN0aW5nIGFwcGxpY2F0aW9uIGJlaGF2aW9yIGFuZCBwZXJmb3JtYW5jZTwvbGk+XG4gICAgPGxpPkRlYnVnZ2luZyBhbmQgaW1wcm92aW5nIHN5c3RlbSByZWxpYWJpbGl0eTwvbGk+XG4gIDwvdWw+XG4gIDxwPlRoZSBkYXRhIGlzIG5vdCB1c2VkIGZvciBtYXJrZXRpbmcsIGFkdmVydGlzaW5nLCBvciBwcm9maWxpbmcuPC9wPlxuXG4gIDxoMj40LiBXaGF0c0FwcCBhbmQgTWV0YSBQbGF0Zm9ybSBVc2FnZTwvaDI+XG4gIDxwPlRoaXMgQXBwIHVzZXMgdGhlIFdoYXRzQXBwIEJ1c2luZXNzIFBsYXRmb3JtIEFQSXMgcHJvdmlkZWQgYnkgTWV0YS48L3A+XG4gIDxwPk1lc3NhZ2VzIGV4Y2hhbmdlZCB0aHJvdWdoIFdoYXRzQXBwIGFyZSBwcm9jZXNzZWQgaW4gYWNjb3JkYW5jZSB3aXRoOjwvcD5cbiAgPHVsPlxuICAgIDxsaT5XaGF0c0FwcCBCdXNpbmVzcyBQbGF0Zm9ybSBwb2xpY2llczwvbGk+XG4gICAgPGxpPk1ldGEncyBkYXRhIGhhbmRsaW5nIGFuZCBzZWN1cml0eSBzdGFuZGFyZHM8L2xpPlxuICA8L3VsPlxuICA8cD5XZSBkbyBub3QgaGF2ZSBhY2Nlc3MgdG8gYW55IHVzZXIgZGF0YSBiZXlvbmQgd2hhdCBpcyBleHBsaWNpdGx5IHNoYXJlZCBkdXJpbmcgY29udmVyc2F0aW9ucy48L3A+XG5cbiAgPGgyPjUuIERhdGEgU2hhcmluZzwvaDI+XG4gIDxwPldlIGRvIG5vdCBzZWxsLCByZW50LCBvciB0cmFkZSB1c2VyIGRhdGEuPC9wPlxuICA8cD5Vc2VyIGRhdGEgaXMgbm90IHNoYXJlZCB3aXRoIHRoaXJkIHBhcnRpZXMsIGV4Y2VwdDo8L3A+XG4gIDx1bD5cbiAgICA8bGk+QXMgcmVxdWlyZWQgdG8gb3BlcmF0ZSBtZXNzYWdpbmcgdmlhIFdoYXRzQXBwIChNZXRhIHBsYXRmb3Jtcyk8L2xpPlxuICAgIDxsaT5XaGVuIHJlcXVpcmVkIGJ5IGxhdyBvciBsZWdhbCBwcm9jZXNzPC9saT5cbiAgPC91bD5cblxuICA8aDI+Ni4gRGF0YSBSZXRlbnRpb248L2gyPlxuICA8cD5Vc2VyIGRhdGEgaXMgcmV0YWluZWQgb25seSBmb3IgYXMgbG9uZyBhcyBuZWNlc3NhcnkgdG86PC9wPlxuICA8dWw+XG4gICAgPGxpPlN1cHBvcnQgdGhlIHBpbG90IHRlc3RpbmcgcGhhc2U8L2xpPlxuICAgIDxsaT5SZXNvbHZlIGlzc3VlcyBvciBhbmFseXplIGZhaWx1cmVzPC9saT5cbiAgPC91bD5cbiAgPHA+RGF0YSBtYXkgYmUgZGVsZXRlZCBwZXJpb2RpY2FsbHkgYXMgcGFydCBvZiBjbGVhbnVwIG9yIHdoZW4gdGVzdGluZyBjb25jbHVkZXMuPC9wPlxuXG4gIDxoMj43LiBVc2VyIFJpZ2h0czwvaDI+XG4gIDxwPlVzZXJzIG1heTo8L3A+XG4gIDx1bD5cbiAgICA8bGk+UmVxdWVzdCBkZWxldGlvbiBvZiB0aGVpciBjb252ZXJzYXRpb24gZGF0YTwvbGk+XG4gICAgPGxpPlN0b3AgdXNpbmcgdGhlIEFwcCBhdCBhbnkgdGltZTwvbGk+XG4gIDwvdWw+XG4gIDxwPlJlcXVlc3RzIGNhbiBiZSBtYWRlIHZpYSB0aGUgY29udGFjdCBpbmZvcm1hdGlvbiBiZWxvdy48L3A+XG5cbiAgPGgyPjguIFNlY3VyaXR5PC9oMj5cbiAgPHA+UmVhc29uYWJsZSB0ZWNobmljYWwgYW5kIG9yZ2FuaXphdGlvbmFsIG1lYXN1cmVzIGFyZSB0YWtlbiB0byBwcm90ZWN0IHVzZXIgZGF0YSBhZ2FpbnN0IHVuYXV0aG9yaXplZCBhY2Nlc3MsIG1pc3VzZSwgb3IgbG9zcy4gSG93ZXZlciwgYXMgdGhpcyBpcyBhIHRlc3RpbmctcGhhc2UgYXBwbGljYXRpb24sIHVzZXJzIGFja25vd2xlZGdlIGFuZCBhY2NlcHQgaW5oZXJlbnQgcmlza3MuPC9wPlxuXG4gIDxoMj45LiBDaGFuZ2VzIHRvIFRoaXMgUG9saWN5PC9oMj5cbiAgPHA+VGhpcyBQcml2YWN5IFBvbGljeSBtYXkgYmUgdXBkYXRlZCBhcyB0aGUgQXBwIGV2b2x2ZXMgZnJvbSBwaWxvdCB0byBhIGZ1bGwgcHJvZHVjdC4gQW55IGNoYW5nZXMgd2lsbCBiZSByZWZsZWN0ZWQgb24gdGhpcyBwYWdlLjwvcD5cblxuICA8aDI+MTAuIENvbnRhY3QgSW5mb3JtYXRpb248L2gyPlxuICA8cD5Gb3IgYW55IHF1ZXN0aW9ucywgY29uY2VybnMsIG9yIGRhdGEgZGVsZXRpb24gcmVxdWVzdHMsIHBsZWFzZSBjb250YWN0OjwvcD5cbiAgPHA+PHN0cm9uZz5FbWFpbDo8L3N0cm9uZz4gPGEgaHJlZj1cIm1haWx0bzp5b3VyLWVtYWlsQGV4YW1wbGUuY29tXCI+ZGVlbmFkaGF5YWxhbi5tMjJAZ21haWwuY29tPC9hPjwvcD5cbjwvZGl2PlxuIl0sImZpbGUiOiIvVXNlcnMvZGVlbmEvRG9jdW1lbnRzL0dpdEh1Yi9wZXJzb25hbC1haS9mcm9udGVuZC9zcmMvUHJpdmFjeVBvbGljeS5zdmVsdGUifQ==