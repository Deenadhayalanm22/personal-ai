import {
  enable_legacy_mode_flag
} from "/node_modules/.vite/deps/chunk-OHYQYV5R.js?v=e89ac925";

// node_modules/svelte/src/internal/flags/legacy.js
enable_legacy_mode_flag();
//# sourceMappingURL=svelte_internal_flags_legacy.js.map
