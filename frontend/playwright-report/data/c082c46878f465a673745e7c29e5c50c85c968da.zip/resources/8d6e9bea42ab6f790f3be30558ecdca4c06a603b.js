import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppHeader.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

AppHeader[$.FILENAME] = 'src/components/AppHeader.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root = $.add_locations($.from_html(`<header class="portal-topbar"><button class="wordmark"><span>₹</span>Money Stories</button> <div class="topbar-actions"><button><i></i> </button> <button class="profile-button" aria-label="Open your profile">D</button></div></header>`), AppHeader[$.FILENAME], [
	[
		9,
		0,

		[
			[10, 2, [[10, 45]]],
			[11, 2, [[12, 4, [[12, 212]]], [13, 4]]]
		]
	]
]);

function AppHeader($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, AppHeader);

	let connectionStatus = $.prop($$props, 'connectionStatus', 8);
	let connectionLabel = $.prop($$props, 'connectionLabel', 8);
	let onRetry = $.prop($$props, 'onRetry', 8);
	let onHome = $.prop($$props, 'onHome', 8);
	let onProfile = $.prop($$props, 'onProfile', 8);
	var $$exports = { ...$.legacy_api() };
	var header = root();
	var button = $.child(header);
	var div = $.sibling(button, 2);
	var button_1 = $.child(div);
	let classes;
	var text = $.sibling($.child(button_1), 1, true);

	$.reset(button_1);

	var button_2 = $.sibling(button_1, 2);

	$.reset(div);
	$.reset(header);

	$.template_effect(() => {
		classes = $.set_class(button_1, 1, 'connection-status', null, classes, {
			online: $.strict_equals(connectionStatus(), 'online'),
			offline: $.strict_equals(connectionStatus(), 'offline')
		});

		$.set_attribute(button_1, 'aria-label', `Connection status: ${connectionLabel()}. Check again.`);
		$.set_text(text, connectionLabel());
	});

	$.event('click', button, function (...$$args) {
		$.apply(onHome, this, $$args, AppHeader, [10, 37]);
	});

	$.event('click', button_1, function (...$$args) {
		$.apply(onRetry, this, $$args, AppHeader, [12, 136]);
	});

	$.event('click', button_2, function (...$$args) {
		$.apply(onProfile, this, $$args, AppHeader, [13, 45]);
	});

	$.append($$anchor, header);

	return $.pop($$exports);
}

if (import.meta.hot) {
	AppHeader = $.hmr(AppHeader, () => AppHeader[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = AppHeader[$.HMR].source;
		$.set(AppHeader[$.HMR].source, module.default[$.HMR].original);
	});
}

export default AppHeader;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztzQ0FBQSxDQUFDOzs7O0tBQ1ksZ0JBQWdCO0tBQ2hCLGVBQWU7S0FDZixPQUFPO0tBQ1AsTUFBTTtLQUNOLFNBQVM7O0tBR3JCLE1BQU07S0FDSixNQUFNLFdBRFIsTUFBTTtLQUVKLEdBQUcsYUFESCxNQUFNO0tBRUosUUFBTSxXQURSLEdBQUc7OzhCQUNELFFBQU07O1NBQU4sUUFBTTs7S0FDTixRQUFNLGFBRE4sUUFBTTs7U0FEUixHQUFHO1NBRkwsTUFBTTs7O3dCQUdGLFFBQU07MkJBQWUsZ0JBQWdCLElBQUcsUUFBUTs0QkFBaUIsZ0JBQWdCLElBQUcsU0FBUzs7O2tCQUE3RixRQUFNLHNDQUF3SyxlQUFlO21CQUEwQixlQUFlOzs7a0JBRnhPLE1BQU07VUFBNEIsTUFBTTs7O2tCQUV0QyxRQUFNO1VBQTZILE9BQU87OztrQkFDMUksUUFBTTtVQUFrQyxTQUFTOzs7b0JBSnJELE1BQU07OztDQUZQIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBIZWFkZXIuc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQ+XG4gIGV4cG9ydCBsZXQgY29ubmVjdGlvblN0YXR1cztcbiAgZXhwb3J0IGxldCBjb25uZWN0aW9uTGFiZWw7XG4gIGV4cG9ydCBsZXQgb25SZXRyeTtcbiAgZXhwb3J0IGxldCBvbkhvbWU7XG4gIGV4cG9ydCBsZXQgb25Qcm9maWxlO1xuPC9zY3JpcHQ+XG5cbjxoZWFkZXIgY2xhc3M9XCJwb3J0YWwtdG9wYmFyXCI+XG4gIDxidXR0b24gY2xhc3M9XCJ3b3JkbWFya1wiIG9uOmNsaWNrPXtvbkhvbWV9PjxzcGFuPuKCuTwvc3Bhbj5Nb25leSBTdG9yaWVzPC9idXR0b24+XG4gIDxkaXYgY2xhc3M9XCJ0b3BiYXItYWN0aW9uc1wiPlxuICAgIDxidXR0b24gY2xhc3M6b25saW5lPXtjb25uZWN0aW9uU3RhdHVzPT09J29ubGluZSd9IGNsYXNzOm9mZmxpbmU9e2Nvbm5lY3Rpb25TdGF0dXM9PT0nb2ZmbGluZSd9IGNsYXNzPVwiY29ubmVjdGlvbi1zdGF0dXNcIiBvbjpjbGljaz17b25SZXRyeX0gYXJpYS1sYWJlbD17YENvbm5lY3Rpb24gc3RhdHVzOiAke2Nvbm5lY3Rpb25MYWJlbH0uIENoZWNrIGFnYWluLmB9PjxpPjwvaT57Y29ubmVjdGlvbkxhYmVsfTwvYnV0dG9uPlxuICAgIDxidXR0b24gY2xhc3M9XCJwcm9maWxlLWJ1dHRvblwiIG9uOmNsaWNrPXtvblByb2ZpbGV9IGFyaWEtbGFiZWw9XCJPcGVuIHlvdXIgcHJvZmlsZVwiPkQ8L2J1dHRvbj5cbiAgPC9kaXY+XG48L2hlYWRlcj5cbiJdLCJmaWxlIjoiL1VzZXJzL2RlZW5hL0RvY3VtZW50cy9HaXRIdWIvcGVyc29uYWwtYWkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQXBwSGVhZGVyLnN2ZWx0ZSJ9