import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BottomNav.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

BottomNav[$.FILENAME] = 'src/components/BottomNav.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";

var root_1 = $.add_locations($.from_html(`<button><span> </span> </button>`), BottomNav[$.FILENAME], [[8, 23, [[8, 98]]]]);
var root = $.add_locations($.from_html(`<nav class="bottom-nav" aria-label="Main navigation"></nav>`), BottomNav[$.FILENAME], [[7, 0]]);

function BottomNav($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, BottomNav);

	let view = $.prop($$props, 'view', 8);
	let onNavigate = $.prop($$props, 'onNavigate', 8);

	const items = [
		['home', '⌂', 'Home'],
		['transactions', '▤', 'Transactions'],
		['stories', '▱', 'Stories'],
		['you', '♙', 'You']
	];

	var $$exports = { ...$.legacy_api() };

	$.init();

	var nav = root();

	$.add_svelte_meta(
		() => $.each(nav, 5, () => items, $.index, ($$anchor, item) => {
			var button = root_1();
			let classes;
			var span = $.child(button);
			var text = $.child(span, true);

			$.reset(span);

			var text_1 = $.sibling(span, 1, true);

			$.reset(button);

			$.template_effect(() => {
				classes = $.set_class(button, 1, '', null, classes, { active: $.strict_equals(view(), $.get(item)[0]) });
				$.set_text(text, ($.get(item), $.untrack(() => $.get(item)[1])));
				$.set_text(text_1, ($.get(item), $.untrack(() => $.get(item)[2])));
			});

			$.event('click', button, () => onNavigate()($.get(item)[0]));
			$.append($$anchor, button);
		}),
		'each',
		BottomNav,
		8,
		2
	);

	$.reset(nav);
	$.append($$anchor, nav);

	return $.pop($$exports);
}

if (import.meta.hot) {
	BottomNav = $.hmr(BottomNav, () => BottomNav[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = BottomNav[$.HMR].source;
		$.set(BottomNav[$.HMR].source, module.default[$.HMR].original);
	});
}

export default BottomNav;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztzQ0FBQSxDQUFDOzs7O0tBQ1ksSUFBSTtLQUNKLFVBQVU7O09BQ2YsS0FBSztHQUFLLE1BQU0sRUFBQyxHQUFHLEVBQUMsTUFBTTtHQUFHLGNBQWMsRUFBQyxHQUFHLEVBQUMsY0FBYztHQUFHLFNBQVMsRUFBQyxHQUFHLEVBQUMsU0FBUztHQUFHLEtBQUssRUFBQyxHQUFHLEVBQUMsS0FBSzs7Ozs7OztLQUdsSCxHQUFHOzs7ZUFBSCxHQUFHLFdBQ0ssS0FBSyxzQkFBSSxJQUFJO09BQUUsTUFBTTs7T0FBcUUsSUFBSSxXQUEvRSxNQUFNO3NCQUFxRSxJQUFJOztXQUFKLElBQUk7OzBCQUFKLElBQUk7O1dBQS9FLE1BQU07OzswQkFBTixNQUFNLGtEQUFlLElBQUksVUFBRyxJQUFJLEVBQUMsQ0FBQzs0QkFBeEMsSUFBSSx5QkFBbUYsSUFBSSxFQUFDLENBQUM7OEJBQTdGLElBQUkseUJBQW1HLElBQUksRUFBQyxDQUFDOzs7b0JBQXZHLE1BQU0sUUFBK0MsVUFBVSxTQUFDLElBQUksRUFBQyxDQUFDO3NCQUF0RSxNQUFNOzs7Ozs7OztTQUQ3QixHQUFHO29CQUFILEdBQUc7OztDQUZKIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCb3R0b21OYXYuc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQ+XG4gIGV4cG9ydCBsZXQgdmlldztcbiAgZXhwb3J0IGxldCBvbk5hdmlnYXRlO1xuICBjb25zdCBpdGVtcyA9IFtbJ2hvbWUnLCfijIInLCdIb21lJ10sWyd0cmFuc2FjdGlvbnMnLCfilqQnLCdUcmFuc2FjdGlvbnMnXSxbJ3N0b3JpZXMnLCfilrEnLCdTdG9yaWVzJ10sWyd5b3UnLCfimZknLCdZb3UnXV07XG48L3NjcmlwdD5cblxuPG5hdiBjbGFzcz1cImJvdHRvbS1uYXZcIiBhcmlhLWxhYmVsPVwiTWFpbiBuYXZpZ2F0aW9uXCI+XG4gIHsjZWFjaCBpdGVtcyBhcyBpdGVtfTxidXR0b24gY2xhc3M6YWN0aXZlPXt2aWV3PT09aXRlbVswXX0gb246Y2xpY2s9eygpID0+IG9uTmF2aWdhdGUoaXRlbVswXSl9PjxzcGFuPntpdGVtWzFdfTwvc3Bhbj57aXRlbVsyXX08L2J1dHRvbj57L2VhY2h9XG48L25hdj5cbiJdLCJmaWxlIjoiL1VzZXJzL2RlZW5hL0RvY3VtZW50cy9HaXRIdWIvcGVyc29uYWwtYWkvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQm90dG9tTmF2LnN2ZWx0ZSJ9