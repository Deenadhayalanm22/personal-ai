import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

App[$.FILENAME] = 'src/App.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";
import { onMount } from "/node_modules/.vite/deps/svelte.js?v=e89ac925";
import Home from "/src/Home.svelte";
import Auth from "/src/Auth.svelte";
import PrivacyPolicy from "/src/PrivacyPolicy.svelte";

import {
	ApiError,
	clearProfileCaches,
	exchangeMagicLink,
	getDemoMode,
	getExpenseCalendar,
	getHealth,
	getMoneyStories,
	getRecentExpenses,
	setDemoMode
} from "/src/lib/api.js";

var root_7 = $.add_locations($.from_html(`<main class="center-page expired" role="alert"><span class="brand-orb">!</span><h1>This sign-in link is invalid, expired, or has already been used.</h1><a class="center-action" href="/portal">Request a new link</a></main>`), App[$.FILENAME], [[75, 34, [[75, 81], [75, 113], [75, 186]]]]);
var root_9 = $.add_locations($.from_html(`<main class="center-page expired" role="alert"><span class="brand-orb">↻</span><h1> </h1><button class="center-action">Try again</button></main>`), App[$.FILENAME], [[76, 61, [[76, 108], [76, 140], [76, 244]]]]);
var root_10 = $.add_locations($.from_html(`<main class="center-page" aria-live="polite"><span class="brand-orb">₹</span><span class="spinner"></span><h1>Signing you in securely…</h1></main>`), App[$.FILENAME], [[77, 7, [[77, 52], [77, 84], [77, 113]]]]);

function App($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, App);

	const CACHE_KEY = 'money-stories.dashboard-cache.v1';
	const initialPath = location.pathname.replace(/\/$/, '') || '/';
	const isPrivacyPage = $.strict_equals(initialPath, '/privacy-policy');
	const now = new Date();
	const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

	let // Do not mount Home until the session/profile request has succeeded. Home loads
	// protected data on mount, including the actions queue.
	view = $.mutable_source(isPrivacyPage ? 'privacy' : 'initializing');

	let selectedMonth = $.mutable_source(monthFromUrl());
	let calendarSection = $.mutable_source(state());
	let recentSection = $.mutable_source(state());
	let storiesSection = $.mutable_source(state());
	let connectionStatus = $.mutable_source('checking');
	let cacheUpdatedAt = $.mutable_source(null);
	let connectionRequest = 0;
	let demoMode = $.mutable_source(false);

	function state(data = null) {
		return { status: data ? 'ready' : 'loading', data, error: '' };
	}

	function monthFromUrl() {
		const value = new URLSearchParams(location.search).get('month');

		return (/^\d{4}-\d{2}$/).test(value || '') ? value : currentMonth;
	}

	function unavailableSection(data = null) {
		return { status: 'ready', data, error: '' };
	}

	function cacheKey() {
		return `${CACHE_KEY}.${$.get(demoMode) ? 'demo' : 'real'}`;
	}

	function readCache() {
		try {
			const cache = JSON.parse(localStorage.getItem(cacheKey()) || 'null');

			if (!cache?.sections || $.strict_equals(cache.month, $.get(selectedMonth), false)) return false;

			$.set(calendarSection, cache.sections.calendar ? state(cache.sections.calendar) : unavailableSection());
			$.set(recentSection, cache.sections.recent ? state(cache.sections.recent) : unavailableSection());
			$.set(storiesSection, cache.sections.stories ? state(cache.sections.stories) : unavailableSection());
			$.set(cacheUpdatedAt, cache.updatedAt || null);

			return true;
		} catch {
			return false;
		}
	}

	function saveCache() {
		try {
			localStorage.setItem(cacheKey(), JSON.stringify({
				version: 1,
				month: $.get(selectedMonth /* Storage can be unavailable in private browsing. The live app still works. */),
				updatedAt: new Date().toISOString(),

				sections: {
					calendar: $.get(calendarSection).data,
					recent: $.get(recentSection).data,
					stories: $.get(storiesSection).data
				}
			}));

			$.set(cacheUpdatedAt, new Date().toISOString());
		} catch {
			/* Storage can be unavailable in private browsing. The live app still works. */
		}
	}

	function emptyFirstRun() {
		$.set(calendarSection, unavailableSection());
		$.set(recentSection, unavailableSection());
		$.set(storiesSection, unavailableSection());
	}

	function unauthorized() {
		location.replace(`/portal?next=${encodeURIComponent(location.pathname + location.search)}`);
	}

	async function loadCalendar() {
		$.set(calendarSection, {
			...$.get(calendarSection),
			status: $.get(calendarSection).data ? 'refreshing' : 'loading',
			error: ''
		});

		try {
			$.set(calendarSection, {
				status: 'ready',
				data: (await $.track_reactivity_loss(getExpenseCalendar($.get(selectedMonth))))(),
				error: ''
			});

			saveCache();
		} catch(cause) {
			if (!(cause instanceof ApiError && $.strict_equals(cause.status, 401))) $.set(calendarSection, $.get(calendarSection).data
				? { ...$.get(calendarSection), status: 'ready', error: '' }
				: unavailableSection());
		}
	}

	async function loadRecent() {
		$.set(recentSection, {
			...$.get(recentSection),
			status: $.get(recentSection).data ? 'refreshing' : 'loading',
			error: ''
		});

		try {
			$.set(recentSection, {
				status: 'ready',
				data: (await $.track_reactivity_loss(getRecentExpenses($.get(selectedMonth), 5)))(),
				error: ''
			});

			saveCache();
		} catch(cause) {
			if (!(cause instanceof ApiError && $.strict_equals(cause.status, 401))) $.set(recentSection, $.get(recentSection).data
				? { ...$.get(recentSection), status: 'ready', error: '' }
				: unavailableSection());
		}
	}

	async function loadStories() {
		$.set(storiesSection, {
			...$.get(storiesSection),
			status: $.get(storiesSection).data ? 'refreshing' : 'loading',
			error: ''
		});

		try {
			$.set(storiesSection, {
				status: 'ready',
				data: (await $.track_reactivity_loss(getMoneyStories($.get(selectedMonth))))(),
				error: ''
			});

			saveCache();
		} catch(cause) {
			if (!(cause instanceof ApiError && $.strict_equals(cause.status, 401))) $.set(storiesSection, $.get(storiesSection).data
				? { ...$.get(storiesSection), status: 'ready', error: '' }
				: unavailableSection());
		}
	}

	async function refreshWhenOnline() {
		const requestId = ++connectionRequest;

		$.set(connectionStatus, navigator.onLine ? 'checking' : 'offline');

		if (!navigator.onLine) {
			if (!$.get(calendarSection).data && !$.get(recentSection).data && !$.get(storiesSection).data) emptyFirstRun();

			return;
		}

		try {
			(await $.track_reactivity_loss(getHealth()))();

			if ($.strict_equals(requestId, connectionRequest, false)) return;

			$.set(connectionStatus, 'online');
			(await $.track_reactivity_loss(Promise.allSettled([loadCalendar(), loadRecent(), loadStories()])))();
		} catch {
			if ($.strict_equals(requestId, connectionRequest, false)) return;

			$.set(connectionStatus, 'offline');

			if (!$.get(calendarSection).data && !$.get(recentSection).data && !$.get(storiesSection).data) emptyFirstRun();
		}
	}

	function changeMonth(month, updateHistory = true) {
		$.set(selectedMonth, month);

		if (updateHistory) history.pushState({}, '', `/dashboard?month=${encodeURIComponent(month)}`);

		if ($.strict_equals($.get(connectionStatus), 'online')) {
			loadCalendar();
			loadRecent();
			loadStories();
		} else {
			emptyFirstRun();
		}
	}

	async function changeDemoMode(enabled) {
		const result = (await $.track_reactivity_loss(setDemoMode(enabled)))();

		$.set(demoMode, result.demoMode);
		clearProfileCaches();
		emptyFirstRun();
		$.set(cacheUpdatedAt, null);

		if ($.strict_equals($.get(connectionStatus), 'online')) (await $.track_reactivity_loss(refreshWhenOnline()))();
	}

	async function initialize() {
		if (isPrivacyPage) return;

		if ($.strict_equals(initialPath, '/access')) {
			const token = new URLSearchParams(location.search).get('token');

			if (!token) {
				$.set(view, 'invalid-link');

				return;
			}

			$.set(view, 'magic-loading');

			try {
				(await $.track_reactivity_loss(exchangeMagicLink(token)))();

				const next = sessionStorage.getItem('portal-next') || '/dashboard';

				sessionStorage.removeItem('portal-next');
				location.replace(next);
			} catch(cause) {
				$.set(view, cause instanceof ApiError && $.strict_equals(cause.status, 401)
					? 'invalid-link'
					: !navigator.onLine ? 'magic-offline' : 'magic-error');
			}

			return;
		}

		if ($.strict_equals(initialPath, '/portal')) {
			const next = new URLSearchParams(location.search).get('next');

			if (next?.startsWith('/')) sessionStorage.setItem('portal-next', next);

			$.set(view, 'login');

			return;
		}

		// Resolve the active profile before reading a cache so presentation mode can never expose real cached data.
		try {
			$.set(demoMode, (await $.track_reactivity_loss(getDemoMode()))().demoMode);
		} catch(cause) {
			// request() has already notified the app and started the sign-in redirect.
			// Keeping the loading view here prevents Home from issuing protected calls
			// while the browser changes pages.
			if (cause instanceof ApiError && $.strict_equals(cause.status, 401)) return;
		}

		$.set(view, 'dashboard');

		if (!readCache()) emptyFirstRun();

		(await $.track_reactivity_loss(refreshWhenOnline()))();
	}

	onMount(() => {
		const auth = () => unauthorized(),
			pop = () => changeMonth(monthFromUrl(), false),
			online = () => refreshWhenOnline(),
			offline = () => {
				connectionRequest += 1;
				$.set(connectionStatus, 'offline');
			};

		addEventListener('app:unauthorized', auth);
		addEventListener('popstate', pop);
		addEventListener('online', online);
		addEventListener('offline', offline);
		initialize();

		return () => {
			removeEventListener('app:unauthorized', auth);
			removeEventListener('popstate', pop);
			removeEventListener('online', online);
			removeEventListener('offline', offline);
		};
	});

	var $$exports = { ...$.legacy_api() };

	$.init();

	var fragment = $.comment();
	var node = $.first_child(fragment);

	{
		var consequent = ($$anchor) => {
			var fragment_1 = $.comment();
			var node_1 = $.first_child(fragment_1);

			$.add_svelte_meta(() => PrivacyPolicy(node_1, {}), 'component', App, 72, 24, { componentTag: 'PrivacyPolicy' });
			$.append($$anchor, fragment_1);
		};

		var alternate_4 = ($$anchor) => {
			var fragment_2 = $.comment();
			var node_2 = $.first_child(fragment_2);

			{
				var consequent_1 = ($$anchor) => {
					var fragment_3 = $.comment();
					var node_3 = $.first_child(fragment_3);

					$.add_svelte_meta(() => Auth(node_3, {}), 'component', App, 73, 27, { componentTag: 'Auth' });
					$.append($$anchor, fragment_3);
				};

				var alternate_3 = ($$anchor) => {
					var fragment_4 = $.comment();
					var node_4 = $.first_child(fragment_4);

					{
						var consequent_2 = ($$anchor) => {
							var fragment_5 = $.comment();
							var node_5 = $.first_child(fragment_5);

							$.add_svelte_meta(
								() => Home(node_5, {
									get calendarSection() {
										return $.get(calendarSection);
									},

									get recentSection() {
										return $.get(recentSection);
									},

									get storiesSection() {
										return $.get(storiesSection);
									},

									get selectedMonth() {
										return $.get(selectedMonth);
									},

									get connectionStatus() {
										return $.get(connectionStatus);
									},

									get cacheUpdatedAt() {
										return $.get(cacheUpdatedAt);
									},

									get demoMode() {
										return $.get(demoMode);
									},

									onDemoModeChange: changeDemoMode,
									onMonthChange: changeMonth,
									refreshCalendar: loadCalendar,
									refreshRecent: loadRecent,
									refreshStories: loadStories,
									onRetryConnection: refreshWhenOnline,

									onLogout: () => {
										try {
											localStorage.removeItem(`${CACHE_KEY}.real`);
											localStorage.removeItem(`${CACHE_KEY}.demo`);
										} catch {}

										location.replace('/portal?message=' + encodeURIComponent('You’ve been signed out.'));
									}
								}),
								'component',
								App,
								74,
								31,
								{ componentTag: 'Home' }
							);

							$.append($$anchor, fragment_5);
						};

						var alternate_2 = ($$anchor) => {
							var fragment_6 = $.comment();
							var node_6 = $.first_child(fragment_6);

							{
								var consequent_3 = ($$anchor) => {
									var main = root_7();

									$.append($$anchor, main);
								};

								var alternate_1 = ($$anchor) => {
									var fragment_7 = $.comment();
									var node_7 = $.first_child(fragment_7);

									{
										var consequent_4 = ($$anchor) => {
											var main_1 = root_9();
											var h1 = $.sibling($.child(main_1));
											var text = $.child(h1, true);

											$.reset(h1);

											var button = $.sibling(h1);

											$.reset(main_1);

											$.template_effect(() => $.set_text(text, $.strict_equals($.get(view), 'magic-offline')
												? 'You appear to be offline.'
												: 'We couldn’t sign you in right now.'));

											$.event('click', button, initialize);
											$.append($$anchor, main_1);
										};

										var alternate = ($$anchor) => {
											var main_2 = root_10();

											$.append($$anchor, main_2);
										};

										$.add_svelte_meta(
											() => $.if(
												node_7,
												($$render) => {
													if ($.strict_equals($.get(view), 'magic-offline') || $.strict_equals($.get(view), 'magic-error')) $$render(consequent_4); else $$render(alternate, false);
												},
												true
											),
											'if',
											App,
											76,
											0
										);
									}

									$.append($$anchor, fragment_7);
								};

								$.add_svelte_meta(
									() => $.if(
										node_6,
										($$render) => {
											if ($.strict_equals($.get(view), 'invalid-link')) $$render(consequent_3); else $$render(alternate_1, false);
										},
										true
									),
									'if',
									App,
									75,
									0
								);
							}

							$.append($$anchor, fragment_6);
						};

						$.add_svelte_meta(
							() => $.if(
								node_4,
								($$render) => {
									if ($.strict_equals($.get(view), 'dashboard')) $$render(consequent_2); else $$render(alternate_2, false);
								},
								true
							),
							'if',
							App,
							74,
							0
						);
					}

					$.append($$anchor, fragment_4);
				};

				$.add_svelte_meta(
					() => $.if(
						node_2,
						($$render) => {
							if ($.strict_equals($.get(view), 'login')) $$render(consequent_1); else $$render(alternate_3, false);
						},
						true
					),
					'if',
					App,
					73,
					0
				);
			}

			$.append($$anchor, fragment_2);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if ($.strict_equals($.get(view), 'privacy')) $$render(consequent); else $$render(alternate_4, false);
			}),
			'if',
			App,
			72,
			0
		);
	}

	$.append($$anchor, fragment);

	return $.pop($$exports);
}

if (import.meta.hot) {
	App = $.hmr(App, () => App[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = App[$.HMR].source;
		$.set(App[$.HMR].source, module.default[$.HMR].original);
	});
}

export default App;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7O1NBRVcsT0FBTyxRQUFRLFFBQVE7T0FDekIsSUFBSSxNQUFNLGVBQWU7T0FBUyxJQUFJLE1BQU0sZUFBZTtPQUFTLGFBQWEsTUFBTSx3QkFBd0I7OztDQUM3RyxRQUFRO0NBQUUsa0JBQWtCO0NBQUUsaUJBQWlCO0NBQUUsV0FBVztDQUFFLGtCQUFrQjtDQUFFLFNBQVM7Q0FBRSxlQUFlO0NBQUUsaUJBQWlCO0NBQUUsV0FBVztPQUFRLGNBQWM7Ozs7OztnQ0FKN0ssQ0FBQzs7OztPQU1PLFNBQVMsR0FBRyxrQ0FBa0M7T0FDOUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLEtBQUssR0FBRztPQUFFLGFBQWEsbUJBQUcsV0FBVyxFQUFLLGlCQUFpQjtPQUM1RyxHQUFHLE9BQU8sSUFBSTtPQUFJLFlBQVksTUFBTSxHQUFHLENBQUMsV0FBVyxNQUFNLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxLQUFLLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUc7Ozs7Q0FHckcsSUFBSSxvQkFBRyxhQUFhLEdBQUcsU0FBUyxHQUFHLGNBQWM7O0tBQUUsYUFBYSxvQkFBRyxZQUFZO0tBQy9FLGVBQWUsb0JBQUcsS0FBSztLQUFJLGFBQWEsb0JBQUcsS0FBSztLQUFJLGNBQWMsb0JBQUcsS0FBSztLQUFJLGdCQUFnQixvQkFBRyxVQUFVO0tBQUUsY0FBYyxvQkFBRyxJQUFJO0tBQ2xJLGlCQUFpQixHQUFHLENBQUM7S0FDckIsUUFBUSxvQkFBRyxLQUFLOztVQUVYLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUM7V0FBVSxNQUFNLEVBQUUsSUFBSSxHQUFHLE9BQU8sR0FBRyxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO0NBQUk7O1VBQ3JGLFlBQVksR0FBRyxDQUFDO1FBQU8sS0FBSyxPQUFPLGVBQWUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxPQUFPOztVQUFVLGVBQWUsRUFBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLEdBQUcsWUFBWTtDQUFFOztVQUNuSixrQkFBa0IsQ0FBQyxJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUM7V0FBVSxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtDQUFJOztVQUMvRSxRQUFRLEdBQUcsQ0FBQztZQUFXLFNBQVMsVUFBSSxRQUFRLElBQUcsTUFBTSxHQUFHLE1BQU07Q0FBSTs7VUFDbEUsU0FBUyxHQUFHO01BQ2YsQ0FBQztTQUFPLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxPQUFPLE1BQU07O1FBQVEsS0FBSyxFQUFFLFFBQVEsb0JBQUksS0FBSyxDQUFDLEtBQUssUUFBSyxhQUFhLGtCQUFTLEtBQUs7O1NBQUUsZUFBZSxFQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsSUFBSSxrQkFBa0I7U0FBSSxhQUFhLEVBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLGtCQUFrQjtTQUFJLGNBQWMsRUFBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLElBQUksa0JBQWtCO1NBQUksY0FBYyxFQUFHLEtBQUssQ0FBQyxTQUFTLElBQUksSUFBSTs7VUFBUyxJQUFJO0VBQUUsQ0FBQyxPQUFPLENBQUM7VUFBUSxLQUFLO0VBQUU7Q0FDbGdCOztVQUNTLFNBQVMsR0FBRztNQUNmLENBQUM7R0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsU0FBUztJQUFHLE9BQU8sRUFBRSxDQUFDO0lBQUUsS0FBSyxRQUFFLGFBQWE7SUFBRSxTQUFTLE1BQU0sSUFBSSxHQUFHLFdBQVc7O0lBQUksUUFBUTtLQUFJLFFBQVEsUUFBRSxlQUFlLEVBQUMsSUFBSTtLQUFFLE1BQU0sUUFBRSxhQUFhLEVBQUMsSUFBSTtLQUFFLE9BQU8sUUFBRSxjQUFjLEVBQUMsSUFBSTs7OztTQUFRLGNBQWMsTUFBTyxJQUFJLEdBQUcsV0FBVztFQUFJLENBQUMsT0FBTyxDQUFDOztFQUFpRjtDQUNsWDs7VUFDUyxhQUFhLEdBQUcsQ0FBQztRQUFDLGVBQWUsRUFBRyxrQkFBa0I7UUFBSSxhQUFhLEVBQUcsa0JBQWtCO1FBQUksY0FBYyxFQUFHLGtCQUFrQjtDQUFJOztVQUN2SSxZQUFZLEdBQUcsQ0FBQztFQUFDLFFBQVEsQ0FBQyxPQUFPLGlCQUFpQixrQkFBa0IsQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxNQUFNO0NBQU07O2dCQUN4RyxZQUFZLEdBQUcsQ0FBQztRQUFDLGVBQWU7WUFBUSxlQUFlO0dBQUUsTUFBTSxRQUFFLGVBQWUsRUFBQyxJQUFJLEdBQUcsWUFBWSxHQUFHLFNBQVM7R0FBRSxLQUFLLEVBQUUsRUFBRTs7O01BQVEsQ0FBQztTQUFDLGVBQWU7SUFBSyxNQUFNLEVBQUUsT0FBTztJQUFFLElBQUksaUNBQVEsa0JBQWtCLE9BQUMsYUFBYTtJQUFHLEtBQUssRUFBRSxFQUFFOzs7R0FBSSxTQUFTO0VBQUksQ0FBQyxPQUFRLEtBQUssRUFBRSxDQUFDO1NBQU8sS0FBSyxZQUFZLFFBQVEsb0JBQUksS0FBSyxDQUFDLE1BQU0sRUFBSyxHQUFHLFVBQUcsZUFBZSxRQUFHLGVBQWUsRUFBQyxJQUFJO2lCQUFRLGVBQWUsR0FBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxFQUFFO01BQUssa0JBQWtCO0VBQUksQ0FBQztDQUFDOztnQkFDcmIsVUFBVSxHQUFHLENBQUM7UUFBQyxhQUFhO1lBQVEsYUFBYTtHQUFFLE1BQU0sUUFBRSxhQUFhLEVBQUMsSUFBSSxHQUFHLFlBQVksR0FBRyxTQUFTO0dBQUUsS0FBSyxFQUFFLEVBQUU7OztNQUFRLENBQUM7U0FBQyxhQUFhO0lBQUssTUFBTSxFQUFFLE9BQU87SUFBRSxJQUFJLGlDQUFRLGlCQUFpQixPQUFDLGFBQWEsR0FBRSxDQUFDO0lBQUcsS0FBSyxFQUFFLEVBQUU7OztHQUFJLFNBQVM7RUFBSSxDQUFDLE9BQVEsS0FBSyxFQUFFLENBQUM7U0FBTyxLQUFLLFlBQVksUUFBUSxvQkFBSSxLQUFLLENBQUMsTUFBTSxFQUFLLEdBQUcsVUFBRyxhQUFhLFFBQUcsYUFBYSxFQUFDLElBQUk7aUJBQVEsYUFBYSxHQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEVBQUU7TUFBSyxrQkFBa0I7RUFBSSxDQUFDO0NBQUM7O2dCQUN2YSxXQUFXLEdBQUcsQ0FBQztRQUFDLGNBQWM7WUFBUSxjQUFjO0dBQUUsTUFBTSxRQUFFLGNBQWMsRUFBQyxJQUFJLEdBQUcsWUFBWSxHQUFHLFNBQVM7R0FBRSxLQUFLLEVBQUUsRUFBRTs7O01BQVEsQ0FBQztTQUFDLGNBQWM7SUFBSyxNQUFNLEVBQUUsT0FBTztJQUFFLElBQUksaUNBQVEsZUFBZSxPQUFDLGFBQWE7SUFBRyxLQUFLLEVBQUUsRUFBRTs7O0dBQUksU0FBUztFQUFJLENBQUMsT0FBUSxLQUFLLEVBQUUsQ0FBQztTQUFPLEtBQUssWUFBWSxRQUFRLG9CQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUssR0FBRyxVQUFHLGNBQWMsUUFBRyxjQUFjLEVBQUMsSUFBSTtpQkFBUSxjQUFjLEdBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsRUFBRTtNQUFLLGtCQUFrQjtFQUFJLENBQUM7Q0FBQzs7Z0JBQzFhLGlCQUFpQixHQUFHO1FBQzNCLFNBQVMsS0FBSyxpQkFBaUI7O1FBQ3JDLGdCQUFnQixFQUFHLFNBQVMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxHQUFHLFNBQVM7O09BQ3ZELFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztjQUFNLGVBQWUsRUFBQyxJQUFJLFdBQUssYUFBYSxFQUFDLElBQUksV0FBSyxjQUFjLEVBQUMsSUFBSSxFQUFFLGFBQWE7OztFQUFZOztNQUN4SDtrQ0FDSSxTQUFTOzt1QkFDWCxTQUFTLEVBQUssaUJBQWlCOztTQUNuQyxnQkFBZ0IsRUFBRyxRQUFRO2tDQUNyQixPQUFPLENBQUMsVUFBVSxFQUFFLFlBQVksSUFBSSxVQUFVLElBQUksV0FBVztFQUNyRSxDQUFDLE9BQU87dUJBQ0YsU0FBUyxFQUFLLGlCQUFpQjs7U0FDbkMsZ0JBQWdCLEVBQUcsU0FBUzs7Y0FDdkIsZUFBZSxFQUFDLElBQUksV0FBSyxhQUFhLEVBQUMsSUFBSSxXQUFLLGNBQWMsRUFBQyxJQUFJLEVBQUUsYUFBYTtFQUN6RjtDQUNGOztVQUNTLFdBQVcsQ0FBQyxLQUFLLEVBQUUsYUFBYSxHQUFHLElBQUksRUFBRSxDQUFDO1FBQUMsYUFBYSxFQUFHLEtBQUs7O01BQU0sYUFBYSxFQUFFLE9BQU8sQ0FBQyxTQUFTLEtBQUssRUFBRSxzQkFBc0Isa0JBQWtCLENBQUMsS0FBSzs7NEJBQVUsZ0JBQWdCLEdBQUssUUFBUSxHQUFFLENBQUM7R0FBQyxZQUFZO0dBQUksVUFBVTtHQUFJLFdBQVc7RUFBSSxDQUFDLE1BQU0sQ0FBQztHQUFDLGFBQWE7RUFBSSxDQUFDO0NBQUM7O2dCQUN6USxjQUFjLENBQUMsT0FBTyxFQUFFO1FBQy9CLE1BQU0sa0NBQVMsV0FBVyxDQUFDLE9BQU87O1FBQ3hDLFFBQVEsRUFBRyxNQUFNLENBQUMsUUFBUTtFQUMxQixrQkFBa0I7RUFDbEIsYUFBYTtRQUNiLGNBQWMsRUFBRyxJQUFJOzs0QkFDakIsZ0JBQWdCLEdBQUssUUFBUSxrQ0FBUSxpQkFBaUI7Q0FDNUQ7O2dCQUNlLFVBQVUsR0FBRztNQUN0QixhQUFhOztzQkFDYixXQUFXLEVBQUssU0FBUyxHQUFFLENBQUM7U0FBTyxLQUFLLE9BQU8sZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLE9BQU87O1FBQVEsS0FBSyxFQUFFLENBQUM7VUFBQyxJQUFJLEVBQUcsY0FBYzs7O0dBQVUsQ0FBQzs7U0FBQyxJQUFJLEVBQUcsZUFBZTs7T0FBTSxDQUFDO21DQUFPLGlCQUFpQixDQUFDLEtBQUs7O1VBQVMsSUFBSSxHQUFHLGNBQWMsQ0FBQyxPQUFPLENBQUMsYUFBYSxLQUFLLFlBQVk7O0lBQUUsY0FBYyxDQUFDLFVBQVUsQ0FBQyxhQUFhO0lBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJO0dBQUcsQ0FBQyxPQUFRLEtBQUssRUFBRSxDQUFDO1VBQUMsSUFBSSxFQUFHLEtBQUssWUFBWSxRQUFRLG9CQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUssR0FBRztPQUFHLGNBQWM7UUFBSyxTQUFTLENBQUMsTUFBTSxHQUFHLGVBQWUsR0FBRyxhQUFhO0dBQUcsQ0FBQzs7O0VBQVM7O3NCQUNoZixXQUFXLEVBQUssU0FBUyxHQUFFLENBQUM7U0FBTyxJQUFJLE9BQU8sZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU07O09BQU8sSUFBSSxFQUFFLFVBQVUsQ0FBQyxHQUFHLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsSUFBSTs7U0FBRyxJQUFJLEVBQUcsT0FBTzs7O0VBQVU7OztNQUU1TCxDQUFDO1NBQUMsUUFBUSxpQ0FBVSxXQUFXLE9BQUksUUFBUTtFQUFFLENBQUMsT0FBUSxLQUFLLEVBQUU7Ozs7T0FJM0QsS0FBSyxZQUFZLFFBQVEsb0JBQUksS0FBSyxDQUFDLE1BQU0sRUFBSyxHQUFHO0VBQ3ZEOztRQUNBLElBQUksRUFBRyxXQUFXOztPQUNiLFNBQVMsSUFBSSxhQUFhOztpQ0FBVSxpQkFBaUI7Q0FDNUQ7O0NBQ0EsT0FBTyxPQUFPLENBQUM7UUFBTyxJQUFJLFNBQVMsWUFBWTtHQUFJLEdBQUcsU0FBUyxXQUFXLENBQUMsWUFBWSxJQUFJLEtBQUs7R0FBRyxNQUFNLFNBQVMsaUJBQWlCO0dBQUksT0FBTyxTQUFTLENBQUM7SUFBQyxpQkFBaUIsSUFBSSxDQUFDO1VBQUUsZ0JBQWdCLEVBQUcsU0FBUztHQUFFLENBQUM7O0VBQUUsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUUsSUFBSTtFQUFHLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxHQUFHO0VBQUcsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLE1BQU07RUFBRyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsT0FBTztFQUFHLFVBQVU7O2VBQWlCLENBQUM7R0FBQyxtQkFBbUIsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJO0dBQUcsbUJBQW1CLENBQUMsVUFBVSxFQUFFLEdBQUc7R0FBRyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsTUFBTTtHQUFHLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxPQUFPO0VBQUcsQ0FBQztDQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7OzJCQUUxaEIsYUFBYTs7Ozs7Ozs7Ozs7Ozs2QkFDVixJQUFJOzs7Ozs7Ozs7Ozs7OztjQUNBLElBQUk7O3VCQUFFLGVBQWU7Ozs7dUJBQUcsYUFBYTs7Ozt1QkFBRyxjQUFjOzs7O3VCQUFHLGFBQWE7Ozs7dUJBQUcsZ0JBQWdCOzs7O3VCQUFHLGNBQWM7Ozs7dUJBQUcsUUFBUTs7OzJCQUFvQixjQUFjO3dCQUFpQixXQUFXOzBCQUFtQixZQUFZO3dCQUFpQixVQUFVO3lCQUFrQixXQUFXOzRCQUFxQixpQkFBaUI7O3lCQUFrQixDQUFDO2NBQUssQ0FBQztXQUFDLFlBQVksQ0FBQyxVQUFVLElBQUksU0FBUztXQUFVLFlBQVksQ0FBQyxVQUFVLElBQUksU0FBUztVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7O1VBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FBQyx5QkFBeUI7U0FBSSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFDcmdCLElBQUk7OzRCQUFKLElBQUk7Ozs7Ozs7OztlQUN1QixNQUFJO2VBQTJFLEVBQUUscUJBQWpGLE1BQUk7OEJBQTJFLEVBQUU7O21CQUFGLEVBQUU7O2VBQXNHLE1BQU0sYUFBOUcsRUFBRTs7bUJBQWpGLE1BQUk7OzBFQUErRSxJQUFJLEdBQUssZUFBZTtjQUFHLDJCQUEyQjtjQUFHLG9DQUFvQzs7NEJBQU8sTUFBTSxFQUFpQyxVQUFVOzhCQUF4TyxNQUFJOzs7O2VBQzFELE1BQUk7OzhCQUFKLE1BQUk7Ozs7Ozs7dUNBREYsSUFBSSxHQUFLLGVBQWUsMkJBQUksSUFBSSxHQUFLLGFBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQ0FEbEQsSUFBSSxHQUFLLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0FEdkIsSUFBSSxHQUFLLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0FEcEIsSUFBSSxHQUFLLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7OEJBRHJCLElBQUksR0FBSyxTQUFTOzs7Ozs7Ozs7Ozs7Q0FEdkIiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPCEtLSBGSU4tRVBJQy0wMDMgYW5kIEZJTi1FUElDLTAwNDogZG9jcy9qaXJhL3BlcnNvbmFsLWV4cGVuc2UvRklOLUVQSUMtMDAzLWluc2lnaHRzLm1kIGFuZCBGSU4tRVBJQy0wMDQtcG9ydGFsLWFuZC1yZWZlcmVuY2VzLm1kIC0tPlxuPHNjcmlwdD5cbiAgaW1wb3J0IHsgb25Nb3VudCB9IGZyb20gJ3N2ZWx0ZSc7XG4gIGltcG9ydCBIb21lIGZyb20gJy4vSG9tZS5zdmVsdGUnOyBpbXBvcnQgQXV0aCBmcm9tICcuL0F1dGguc3ZlbHRlJzsgaW1wb3J0IFByaXZhY3lQb2xpY3kgZnJvbSAnLi9Qcml2YWN5UG9saWN5LnN2ZWx0ZSc7XG4gIGltcG9ydCB7IEFwaUVycm9yLCBjbGVhclByb2ZpbGVDYWNoZXMsIGV4Y2hhbmdlTWFnaWNMaW5rLCBnZXREZW1vTW9kZSwgZ2V0RXhwZW5zZUNhbGVuZGFyLCBnZXRIZWFsdGgsIGdldE1vbmV5U3RvcmllcywgZ2V0UmVjZW50RXhwZW5zZXMsIHNldERlbW9Nb2RlIH0gZnJvbSAnLi9saWIvYXBpLmpzJztcblxuICBjb25zdCBDQUNIRV9LRVkgPSAnbW9uZXktc3Rvcmllcy5kYXNoYm9hcmQtY2FjaGUudjEnO1xuICBjb25zdCBpbml0aWFsUGF0aCA9IGxvY2F0aW9uLnBhdGhuYW1lLnJlcGxhY2UoL1xcLyQvLCAnJykgfHwgJy8nLCBpc1ByaXZhY3lQYWdlID0gaW5pdGlhbFBhdGggPT09ICcvcHJpdmFjeS1wb2xpY3knO1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLCBjdXJyZW50TW9udGggPSBgJHtub3cuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcobm93LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpfWA7XG4gIC8vIERvIG5vdCBtb3VudCBIb21lIHVudGlsIHRoZSBzZXNzaW9uL3Byb2ZpbGUgcmVxdWVzdCBoYXMgc3VjY2VlZGVkLiBIb21lIGxvYWRzXG4gIC8vIHByb3RlY3RlZCBkYXRhIG9uIG1vdW50LCBpbmNsdWRpbmcgdGhlIGFjdGlvbnMgcXVldWUuXG4gIGxldCB2aWV3ID0gaXNQcml2YWN5UGFnZSA/ICdwcml2YWN5JyA6ICdpbml0aWFsaXppbmcnLCBzZWxlY3RlZE1vbnRoID0gbW9udGhGcm9tVXJsKCk7XG4gIGxldCBjYWxlbmRhclNlY3Rpb24gPSBzdGF0ZSgpLCByZWNlbnRTZWN0aW9uID0gc3RhdGUoKSwgc3Rvcmllc1NlY3Rpb24gPSBzdGF0ZSgpLCBjb25uZWN0aW9uU3RhdHVzID0gJ2NoZWNraW5nJywgY2FjaGVVcGRhdGVkQXQgPSBudWxsO1xuICBsZXQgY29ubmVjdGlvblJlcXVlc3QgPSAwO1xuICBsZXQgZGVtb01vZGUgPSBmYWxzZTtcblxuICBmdW5jdGlvbiBzdGF0ZShkYXRhID0gbnVsbCkgeyByZXR1cm4geyBzdGF0dXM6IGRhdGEgPyAncmVhZHknIDogJ2xvYWRpbmcnLCBkYXRhLCBlcnJvcjogJycgfTsgfVxuICBmdW5jdGlvbiBtb250aEZyb21VcmwoKSB7IGNvbnN0IHZhbHVlID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldCgnbW9udGgnKTsgcmV0dXJuIC9eXFxkezR9LVxcZHsyfSQvLnRlc3QodmFsdWUgfHwgJycpID8gdmFsdWUgOiBjdXJyZW50TW9udGg7IH1cbiAgZnVuY3Rpb24gdW5hdmFpbGFibGVTZWN0aW9uKGRhdGEgPSBudWxsKSB7IHJldHVybiB7IHN0YXR1czogJ3JlYWR5JywgZGF0YSwgZXJyb3I6ICcnIH07IH1cbiAgZnVuY3Rpb24gY2FjaGVLZXkoKSB7IHJldHVybiBgJHtDQUNIRV9LRVl9LiR7ZGVtb01vZGUgPyAnZGVtbycgOiAncmVhbCd9YDsgfVxuICBmdW5jdGlvbiByZWFkQ2FjaGUoKSB7XG4gICAgdHJ5IHsgY29uc3QgY2FjaGUgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKGNhY2hlS2V5KCkpIHx8ICdudWxsJyk7IGlmICghY2FjaGU/LnNlY3Rpb25zIHx8IGNhY2hlLm1vbnRoICE9PSBzZWxlY3RlZE1vbnRoKSByZXR1cm4gZmFsc2U7IGNhbGVuZGFyU2VjdGlvbiA9IGNhY2hlLnNlY3Rpb25zLmNhbGVuZGFyID8gc3RhdGUoY2FjaGUuc2VjdGlvbnMuY2FsZW5kYXIpIDogdW5hdmFpbGFibGVTZWN0aW9uKCk7IHJlY2VudFNlY3Rpb24gPSBjYWNoZS5zZWN0aW9ucy5yZWNlbnQgPyBzdGF0ZShjYWNoZS5zZWN0aW9ucy5yZWNlbnQpIDogdW5hdmFpbGFibGVTZWN0aW9uKCk7IHN0b3JpZXNTZWN0aW9uID0gY2FjaGUuc2VjdGlvbnMuc3RvcmllcyA/IHN0YXRlKGNhY2hlLnNlY3Rpb25zLnN0b3JpZXMpIDogdW5hdmFpbGFibGVTZWN0aW9uKCk7IGNhY2hlVXBkYXRlZEF0ID0gY2FjaGUudXBkYXRlZEF0IHx8IG51bGw7IHJldHVybiB0cnVlOyB9IGNhdGNoIHsgcmV0dXJuIGZhbHNlOyB9XG4gIH1cbiAgZnVuY3Rpb24gc2F2ZUNhY2hlKCkge1xuICAgIHRyeSB7IGxvY2FsU3RvcmFnZS5zZXRJdGVtKGNhY2hlS2V5KCksIEpTT04uc3RyaW5naWZ5KHsgdmVyc2lvbjogMSwgbW9udGg6IHNlbGVjdGVkTW9udGgsIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLCBzZWN0aW9uczogeyBjYWxlbmRhcjogY2FsZW5kYXJTZWN0aW9uLmRhdGEsIHJlY2VudDogcmVjZW50U2VjdGlvbi5kYXRhLCBzdG9yaWVzOiBzdG9yaWVzU2VjdGlvbi5kYXRhIH0gfSkpOyBjYWNoZVVwZGF0ZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTsgfSBjYXRjaCB7IC8qIFN0b3JhZ2UgY2FuIGJlIHVuYXZhaWxhYmxlIGluIHByaXZhdGUgYnJvd3NpbmcuIFRoZSBsaXZlIGFwcCBzdGlsbCB3b3Jrcy4gKi8gfVxuICB9XG4gIGZ1bmN0aW9uIGVtcHR5Rmlyc3RSdW4oKSB7IGNhbGVuZGFyU2VjdGlvbiA9IHVuYXZhaWxhYmxlU2VjdGlvbigpOyByZWNlbnRTZWN0aW9uID0gdW5hdmFpbGFibGVTZWN0aW9uKCk7IHN0b3JpZXNTZWN0aW9uID0gdW5hdmFpbGFibGVTZWN0aW9uKCk7IH1cbiAgZnVuY3Rpb24gdW5hdXRob3JpemVkKCkgeyBsb2NhdGlvbi5yZXBsYWNlKGAvcG9ydGFsP25leHQ9JHtlbmNvZGVVUklDb21wb25lbnQobG9jYXRpb24ucGF0aG5hbWUgKyBsb2NhdGlvbi5zZWFyY2gpfWApOyB9XG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRDYWxlbmRhcigpIHsgY2FsZW5kYXJTZWN0aW9uID0geyAuLi5jYWxlbmRhclNlY3Rpb24sIHN0YXR1czogY2FsZW5kYXJTZWN0aW9uLmRhdGEgPyAncmVmcmVzaGluZycgOiAnbG9hZGluZycsIGVycm9yOiAnJyB9OyB0cnkgeyBjYWxlbmRhclNlY3Rpb24gPSB7IHN0YXR1czogJ3JlYWR5JywgZGF0YTogYXdhaXQgZ2V0RXhwZW5zZUNhbGVuZGFyKHNlbGVjdGVkTW9udGgpLCBlcnJvcjogJycgfTsgc2F2ZUNhY2hlKCk7IH0gY2F0Y2ggKGNhdXNlKSB7IGlmICghKGNhdXNlIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgY2F1c2Uuc3RhdHVzID09PSA0MDEpKSBjYWxlbmRhclNlY3Rpb24gPSBjYWxlbmRhclNlY3Rpb24uZGF0YSA/IHsgLi4uY2FsZW5kYXJTZWN0aW9uLCBzdGF0dXM6ICdyZWFkeScsIGVycm9yOiAnJyB9IDogdW5hdmFpbGFibGVTZWN0aW9uKCk7IH0gfVxuICBhc3luYyBmdW5jdGlvbiBsb2FkUmVjZW50KCkgeyByZWNlbnRTZWN0aW9uID0geyAuLi5yZWNlbnRTZWN0aW9uLCBzdGF0dXM6IHJlY2VudFNlY3Rpb24uZGF0YSA/ICdyZWZyZXNoaW5nJyA6ICdsb2FkaW5nJywgZXJyb3I6ICcnIH07IHRyeSB7IHJlY2VudFNlY3Rpb24gPSB7IHN0YXR1czogJ3JlYWR5JywgZGF0YTogYXdhaXQgZ2V0UmVjZW50RXhwZW5zZXMoc2VsZWN0ZWRNb250aCwgNSksIGVycm9yOiAnJyB9OyBzYXZlQ2FjaGUoKTsgfSBjYXRjaCAoY2F1c2UpIHsgaWYgKCEoY2F1c2UgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBjYXVzZS5zdGF0dXMgPT09IDQwMSkpIHJlY2VudFNlY3Rpb24gPSByZWNlbnRTZWN0aW9uLmRhdGEgPyB7IC4uLnJlY2VudFNlY3Rpb24sIHN0YXR1czogJ3JlYWR5JywgZXJyb3I6ICcnIH0gOiB1bmF2YWlsYWJsZVNlY3Rpb24oKTsgfSB9XG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRTdG9yaWVzKCkgeyBzdG9yaWVzU2VjdGlvbiA9IHsgLi4uc3Rvcmllc1NlY3Rpb24sIHN0YXR1czogc3Rvcmllc1NlY3Rpb24uZGF0YSA/ICdyZWZyZXNoaW5nJyA6ICdsb2FkaW5nJywgZXJyb3I6ICcnIH07IHRyeSB7IHN0b3JpZXNTZWN0aW9uID0geyBzdGF0dXM6ICdyZWFkeScsIGRhdGE6IGF3YWl0IGdldE1vbmV5U3RvcmllcyhzZWxlY3RlZE1vbnRoKSwgZXJyb3I6ICcnIH07IHNhdmVDYWNoZSgpOyB9IGNhdGNoIChjYXVzZSkgeyBpZiAoIShjYXVzZSBpbnN0YW5jZW9mIEFwaUVycm9yICYmIGNhdXNlLnN0YXR1cyA9PT0gNDAxKSkgc3Rvcmllc1NlY3Rpb24gPSBzdG9yaWVzU2VjdGlvbi5kYXRhID8geyAuLi5zdG9yaWVzU2VjdGlvbiwgc3RhdHVzOiAncmVhZHknLCBlcnJvcjogJycgfSA6IHVuYXZhaWxhYmxlU2VjdGlvbigpOyB9IH1cbiAgYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFdoZW5PbmxpbmUoKSB7XG4gICAgY29uc3QgcmVxdWVzdElkID0gKytjb25uZWN0aW9uUmVxdWVzdDtcbiAgICBjb25uZWN0aW9uU3RhdHVzID0gbmF2aWdhdG9yLm9uTGluZSA/ICdjaGVja2luZycgOiAnb2ZmbGluZSc7XG4gICAgaWYgKCFuYXZpZ2F0b3Iub25MaW5lKSB7IGlmICghY2FsZW5kYXJTZWN0aW9uLmRhdGEgJiYgIXJlY2VudFNlY3Rpb24uZGF0YSAmJiAhc3Rvcmllc1NlY3Rpb24uZGF0YSkgZW1wdHlGaXJzdFJ1bigpOyByZXR1cm47IH1cbiAgICB0cnkge1xuICAgICAgYXdhaXQgZ2V0SGVhbHRoKCk7XG4gICAgICBpZiAocmVxdWVzdElkICE9PSBjb25uZWN0aW9uUmVxdWVzdCkgcmV0dXJuO1xuICAgICAgY29ubmVjdGlvblN0YXR1cyA9ICdvbmxpbmUnO1xuICAgICAgYXdhaXQgUHJvbWlzZS5hbGxTZXR0bGVkKFtsb2FkQ2FsZW5kYXIoKSwgbG9hZFJlY2VudCgpLCBsb2FkU3RvcmllcygpXSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBpZiAocmVxdWVzdElkICE9PSBjb25uZWN0aW9uUmVxdWVzdCkgcmV0dXJuO1xuICAgICAgY29ubmVjdGlvblN0YXR1cyA9ICdvZmZsaW5lJztcbiAgICAgIGlmICghY2FsZW5kYXJTZWN0aW9uLmRhdGEgJiYgIXJlY2VudFNlY3Rpb24uZGF0YSAmJiAhc3Rvcmllc1NlY3Rpb24uZGF0YSkgZW1wdHlGaXJzdFJ1bigpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBjaGFuZ2VNb250aChtb250aCwgdXBkYXRlSGlzdG9yeSA9IHRydWUpIHsgc2VsZWN0ZWRNb250aCA9IG1vbnRoOyBpZiAodXBkYXRlSGlzdG9yeSkgaGlzdG9yeS5wdXNoU3RhdGUoe30sICcnLCBgL2Rhc2hib2FyZD9tb250aD0ke2VuY29kZVVSSUNvbXBvbmVudChtb250aCl9YCk7IGlmIChjb25uZWN0aW9uU3RhdHVzID09PSAnb25saW5lJykgeyBsb2FkQ2FsZW5kYXIoKTsgbG9hZFJlY2VudCgpOyBsb2FkU3RvcmllcygpOyB9IGVsc2UgeyBlbXB0eUZpcnN0UnVuKCk7IH0gfVxuICBhc3luYyBmdW5jdGlvbiBjaGFuZ2VEZW1vTW9kZShlbmFibGVkKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc2V0RGVtb01vZGUoZW5hYmxlZCk7XG4gICAgZGVtb01vZGUgPSByZXN1bHQuZGVtb01vZGU7XG4gICAgY2xlYXJQcm9maWxlQ2FjaGVzKCk7XG4gICAgZW1wdHlGaXJzdFJ1bigpO1xuICAgIGNhY2hlVXBkYXRlZEF0ID0gbnVsbDtcbiAgICBpZiAoY29ubmVjdGlvblN0YXR1cyA9PT0gJ29ubGluZScpIGF3YWl0IHJlZnJlc2hXaGVuT25saW5lKCk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gaW5pdGlhbGl6ZSgpIHtcbiAgICBpZiAoaXNQcml2YWN5UGFnZSkgcmV0dXJuO1xuICAgIGlmIChpbml0aWFsUGF0aCA9PT0gJy9hY2Nlc3MnKSB7IGNvbnN0IHRva2VuID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldCgndG9rZW4nKTsgaWYgKCF0b2tlbikgeyB2aWV3ID0gJ2ludmFsaWQtbGluayc7IHJldHVybjsgfSB2aWV3ID0gJ21hZ2ljLWxvYWRpbmcnOyB0cnkgeyBhd2FpdCBleGNoYW5nZU1hZ2ljTGluayh0b2tlbik7IGNvbnN0IG5leHQgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdwb3J0YWwtbmV4dCcpIHx8ICcvZGFzaGJvYXJkJzsgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbSgncG9ydGFsLW5leHQnKTsgbG9jYXRpb24ucmVwbGFjZShuZXh0KTsgfSBjYXRjaCAoY2F1c2UpIHsgdmlldyA9IGNhdXNlIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgY2F1c2Uuc3RhdHVzID09PSA0MDEgPyAnaW52YWxpZC1saW5rJyA6ICghbmF2aWdhdG9yLm9uTGluZSA/ICdtYWdpYy1vZmZsaW5lJyA6ICdtYWdpYy1lcnJvcicpOyB9IHJldHVybjsgfVxuICAgIGlmIChpbml0aWFsUGF0aCA9PT0gJy9wb3J0YWwnKSB7IGNvbnN0IG5leHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCkuZ2V0KCduZXh0Jyk7IGlmIChuZXh0Py5zdGFydHNXaXRoKCcvJykpIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ3BvcnRhbC1uZXh0JywgbmV4dCk7IHZpZXcgPSAnbG9naW4nOyByZXR1cm47IH1cbiAgICAvLyBSZXNvbHZlIHRoZSBhY3RpdmUgcHJvZmlsZSBiZWZvcmUgcmVhZGluZyBhIGNhY2hlIHNvIHByZXNlbnRhdGlvbiBtb2RlIGNhbiBuZXZlciBleHBvc2UgcmVhbCBjYWNoZWQgZGF0YS5cbiAgICB0cnkgeyBkZW1vTW9kZSA9IChhd2FpdCBnZXREZW1vTW9kZSgpKS5kZW1vTW9kZTsgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIC8vIHJlcXVlc3QoKSBoYXMgYWxyZWFkeSBub3RpZmllZCB0aGUgYXBwIGFuZCBzdGFydGVkIHRoZSBzaWduLWluIHJlZGlyZWN0LlxuICAgICAgLy8gS2VlcGluZyB0aGUgbG9hZGluZyB2aWV3IGhlcmUgcHJldmVudHMgSG9tZSBmcm9tIGlzc3VpbmcgcHJvdGVjdGVkIGNhbGxzXG4gICAgICAvLyB3aGlsZSB0aGUgYnJvd3NlciBjaGFuZ2VzIHBhZ2VzLlxuICAgICAgaWYgKGNhdXNlIGluc3RhbmNlb2YgQXBpRXJyb3IgJiYgY2F1c2Uuc3RhdHVzID09PSA0MDEpIHJldHVybjtcbiAgICB9XG4gICAgdmlldyA9ICdkYXNoYm9hcmQnO1xuICAgIGlmICghcmVhZENhY2hlKCkpIGVtcHR5Rmlyc3RSdW4oKTsgYXdhaXQgcmVmcmVzaFdoZW5PbmxpbmUoKTtcbiAgfVxuICBvbk1vdW50KCgpID0+IHsgY29uc3QgYXV0aCA9ICgpID0+IHVuYXV0aG9yaXplZCgpLCBwb3AgPSAoKSA9PiBjaGFuZ2VNb250aChtb250aEZyb21VcmwoKSwgZmFsc2UpLCBvbmxpbmUgPSAoKSA9PiByZWZyZXNoV2hlbk9ubGluZSgpLCBvZmZsaW5lID0gKCkgPT4geyBjb25uZWN0aW9uUmVxdWVzdCArPSAxOyBjb25uZWN0aW9uU3RhdHVzID0gJ29mZmxpbmUnOyB9OyBhZGRFdmVudExpc3RlbmVyKCdhcHA6dW5hdXRob3JpemVkJywgYXV0aCk7IGFkZEV2ZW50TGlzdGVuZXIoJ3BvcHN0YXRlJywgcG9wKTsgYWRkRXZlbnRMaXN0ZW5lcignb25saW5lJywgb25saW5lKTsgYWRkRXZlbnRMaXN0ZW5lcignb2ZmbGluZScsIG9mZmxpbmUpOyBpbml0aWFsaXplKCk7IHJldHVybiAoKSA9PiB7IHJlbW92ZUV2ZW50TGlzdGVuZXIoJ2FwcDp1bmF1dGhvcml6ZWQnLCBhdXRoKTsgcmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9wc3RhdGUnLCBwb3ApOyByZW1vdmVFdmVudExpc3RlbmVyKCdvbmxpbmUnLCBvbmxpbmUpOyByZW1vdmVFdmVudExpc3RlbmVyKCdvZmZsaW5lJywgb2ZmbGluZSk7IH07IH0pO1xuPC9zY3JpcHQ+XG57I2lmIHZpZXcgPT09ICdwcml2YWN5J308UHJpdmFjeVBvbGljeSAvPlxuezplbHNlIGlmIHZpZXcgPT09ICdsb2dpbid9PEF1dGggLz5cbns6ZWxzZSBpZiB2aWV3ID09PSAnZGFzaGJvYXJkJ308SG9tZSB7Y2FsZW5kYXJTZWN0aW9ufSB7cmVjZW50U2VjdGlvbn0ge3N0b3JpZXNTZWN0aW9ufSB7c2VsZWN0ZWRNb250aH0ge2Nvbm5lY3Rpb25TdGF0dXN9IHtjYWNoZVVwZGF0ZWRBdH0ge2RlbW9Nb2RlfSBvbkRlbW9Nb2RlQ2hhbmdlPXtjaGFuZ2VEZW1vTW9kZX0gb25Nb250aENoYW5nZT17Y2hhbmdlTW9udGh9IHJlZnJlc2hDYWxlbmRhcj17bG9hZENhbGVuZGFyfSByZWZyZXNoUmVjZW50PXtsb2FkUmVjZW50fSByZWZyZXNoU3Rvcmllcz17bG9hZFN0b3JpZXN9IG9uUmV0cnlDb25uZWN0aW9uPXtyZWZyZXNoV2hlbk9ubGluZX0gb25Mb2dvdXQ9eygpID0+IHsgdHJ5IHsgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oYCR7Q0FDSEVfS0VZfS5yZWFsYCk7IGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGAke0NBQ0hFX0tFWX0uZGVtb2ApOyB9IGNhdGNoIHt9IGxvY2F0aW9uLnJlcGxhY2UoJy9wb3J0YWw/bWVzc2FnZT0nICsgZW5jb2RlVVJJQ29tcG9uZW50KCdZb3XigJl2ZSBiZWVuIHNpZ25lZCBvdXQuJykpOyB9fSAvPlxuezplbHNlIGlmIHZpZXcgPT09ICdpbnZhbGlkLWxpbmsnfTxtYWluIGNsYXNzPVwiY2VudGVyLXBhZ2UgZXhwaXJlZFwiIHJvbGU9XCJhbGVydFwiPjxzcGFuIGNsYXNzPVwiYnJhbmQtb3JiXCI+ITwvc3Bhbj48aDE+VGhpcyBzaWduLWluIGxpbmsgaXMgaW52YWxpZCwgZXhwaXJlZCwgb3IgaGFzIGFscmVhZHkgYmVlbiB1c2VkLjwvaDE+PGEgY2xhc3M9XCJjZW50ZXItYWN0aW9uXCIgaHJlZj1cIi9wb3J0YWxcIj5SZXF1ZXN0IGEgbmV3IGxpbms8L2E+PC9tYWluPlxuezplbHNlIGlmIHZpZXcgPT09ICdtYWdpYy1vZmZsaW5lJyB8fCB2aWV3ID09PSAnbWFnaWMtZXJyb3InfTxtYWluIGNsYXNzPVwiY2VudGVyLXBhZ2UgZXhwaXJlZFwiIHJvbGU9XCJhbGVydFwiPjxzcGFuIGNsYXNzPVwiYnJhbmQtb3JiXCI+4oa7PC9zcGFuPjxoMT57dmlldyA9PT0gJ21hZ2ljLW9mZmxpbmUnID8gJ1lvdSBhcHBlYXIgdG8gYmUgb2ZmbGluZS4nIDogJ1dlIGNvdWxkbuKAmXQgc2lnbiB5b3UgaW4gcmlnaHQgbm93Lid9PC9oMT48YnV0dG9uIGNsYXNzPVwiY2VudGVyLWFjdGlvblwiIG9uOmNsaWNrPXtpbml0aWFsaXplfT5UcnkgYWdhaW48L2J1dHRvbj48L21haW4+XG57OmVsc2V9PG1haW4gY2xhc3M9XCJjZW50ZXItcGFnZVwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPjxzcGFuIGNsYXNzPVwiYnJhbmQtb3JiXCI+4oK5PC9zcGFuPjxzcGFuIGNsYXNzPVwic3Bpbm5lclwiPjwvc3Bhbj48aDE+U2lnbmluZyB5b3UgaW4gc2VjdXJlbHnigKY8L2gxPjwvbWFpbj57L2lmfVxuIl0sImZpbGUiOiIvVXNlcnMvZGVlbmEvRG9jdW1lbnRzL0dpdEh1Yi9wZXJzb25hbC1haS9mcm9udGVuZC9zcmMvQXBwLnN2ZWx0ZSJ9