import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Auth.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

Auth[$.FILENAME] = 'src/Auth.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";
import { onDestroy } from "/node_modules/.vite/deps/svelte.js?v=e89ac925";
import { ApiError, requestLoginLink } from "/src/lib/api.js";

var root_1 = $.add_locations($.from_html(`<p class="signed-out-notice" role="status"> </p>`), Auth[$.FILENAME], [[42, 46]]);
var root_3 = $.add_locations($.from_html(`<p class="auth-error" role="alert"> </p>`), Auth[$.FILENAME], [[50, 17]]);

var root_2 = $.add_locations($.from_html(`<div class="auth-icon sent-icon" aria-hidden="true">✓</div> <p class="eyebrow">Link sent</p> <h1>Check your WhatsApp</h1> <p>If this number is registered, we sent a secure sign-in link. Open it on this device to continue.</p> <p class="generic-message" role="status"> </p> <div class="security-note"><span aria-hidden="true">↗</span><p>Links expire shortly and can only be used once.</p></div> <!> <button class="auth-primary"> </button> <button class="auth-secondary">Use another number</button>`, 1), Auth[$.FILENAME], [
	[44, 6],
	[45, 6],
	[46, 6],
	[47, 6],
	[48, 6],
	[49, 6, [[49, 33], [49, 66]]],
	[51, 6],
	[52, 6]
]);

var root_5 = $.add_locations($.from_html(`<p id="phone-error" class="auth-error" role="alert"> </p>`), Auth[$.FILENAME], [[62, 19]]);

var root_4 = $.add_locations($.from_html(`<div class="auth-icon" aria-hidden="true">↗</div> <p class="eyebrow">Private access</p> <h1>Sign in to your portal</h1> <p>Enter the phone number connected to your WhatsApp account. We’ll send you a secure sign-in link.</p> <form novalidate=""><label for="phone">Phone number</label> <div><input id="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+91 98765 43210" aria-describedby="phone-hint phone-error"/></div> <small id="phone-hint">Include your country code, for example +91.</small> <!> <button class="auth-primary" type="submit"> </button></form> <p class="privacy-copy">We’ll only use this number to securely find your account. We never reveal whether a number is registered.</p>`, 1), Auth[$.FILENAME], [
	[54, 6],
	[55, 6],
	[56, 6],
	[57, 6],
	[58, 6, [[59, 8], [60, 8, [[60, 59]]], [61, 8], [63, 8]]],
	[65, 6]
]);

var root = $.add_locations($.from_html(`<main class="auth-page"><a class="auth-brand" href="/portal" aria-label="Expense AI portal"><span>₹</span>Expense AI</a> <section class="auth-card" aria-live="polite"><!> <!></section> <p class="auth-footer"><span></span>Protected with secure, cookie-based access</p></main>`), Auth[$.FILENAME], [[39, 0, [[40, 2, [[40, 70]]], [41, 2], [68, 2, [[68, 25]]]]]]);

function Auth($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, Auth);

	let phoneNumber = $.mutable_source('');
	let state = $.mutable_source('form');
	let error = $.mutable_source('');
	let genericMessage = $.mutable_source('');
	let seconds = $.mutable_source(0);
	let timer;
	let resending = $.mutable_source(false);
	const signedOutMessage = new URLSearchParams(location.search).get('message');
	const validPhone = (value) => (/^\+[1-9]\d{7,14}$/).test(value.replace(/[\s()-]/g, ''));

	function startCountdown() {
		clearInterval(timer);
		$.set(seconds, 60);

		timer = setInterval(
			() => {
				$.set(seconds, $.get(seconds) - 1);

				if ($.get(seconds) <= 0) clearInterval(timer);
			},
			1000
		);
	}

	async function submit() {
		$.set(error, '');

		if (!$.get(phoneNumber).trim()) {
			$.set(error, 'Enter your phone number, including the country code.');

			return;
		}

		if (!validPhone($.get(phoneNumber))) {
			$.set(error, 'Enter a valid international number, such as +91 98765 43210.');

			return;
		}

		$.set(state, 'submitting');

		try {
			const result = (await $.track_reactivity_loss(requestLoginLink($.get(phoneNumber).trim())))();

			$.set(genericMessage, result?.message || 'If this number is registered, we sent a login link to its WhatsApp account.');
			$.set(state, 'sent');
			startCountdown();
		} catch(cause) {
			$.set(state, 'form');

			$.set(error, !navigator.onLine
				? 'You appear to be offline. Check your connection and try again.'
				: 'We couldn’t send the link right now. Please try again shortly.');
		}
	}

	function reset() {
		clearInterval(timer);
		$.set(phoneNumber, '');
		$.set(error, '');
		$.set(genericMessage, '');
		$.set(state, 'form');
	}

	async function resend() {
		if ($.get(seconds) > 0 || $.get(resending)) return;

		$.set(resending, true);

		try {
			const result = (await $.track_reactivity_loss(requestLoginLink($.get(phoneNumber).trim())))();

			$.set(genericMessage, result?.message || $.get(genericMessage));
			startCountdown();
		} catch(cause) {
			$.set(error, !navigator.onLine
				? 'You appear to be offline. Check your connection and try again.'
				: 'We couldn’t resend the link right now. Please try again shortly.');
		} finally {
			$.set(resending, false);
		}
	}

	onDestroy(() => clearInterval(timer));

	var $$exports = { ...$.legacy_api() };

	$.init();

	var main = root();
	var section = $.sibling($.child(main), 2);
	var node = $.child(section);

	{
		var consequent = ($$anchor) => {
			var p = root_1();
			var text = $.child(p);

			$.reset(p);
			$.template_effect(() => $.set_text(text, `✓ ${signedOutMessage ?? ''}`));
			$.append($$anchor, p);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if (signedOutMessage && $.strict_equals($.get(state), 'form')) $$render(consequent);
			}),
			'if',
			Auth,
			42,
			4
		);
	}

	var node_1 = $.sibling(node, 2);

	{
		var consequent_2 = ($$anchor) => {
			var fragment = root_2();
			var p_1 = $.sibling($.first_child(fragment), 8);
			var text_1 = $.child(p_1, true);

			$.reset(p_1);

			var node_2 = $.sibling(p_1, 4);

			{
				var consequent_1 = ($$anchor) => {
					var p_2 = root_3();
					var text_2 = $.child(p_2, true);

					$.reset(p_2);
					$.template_effect(() => $.set_text(text_2, $.get(error)));
					$.append($$anchor, p_2);
				};

				$.add_svelte_meta(
					() => $.if(node_2, ($$render) => {
						if ($.get(error)) $$render(consequent_1);
					}),
					'if',
					Auth,
					50,
					6
				);
			}

			var button = $.sibling(node_2, 2);
			var text_3 = $.child(button, true);

			$.reset(button);

			var button_1 = $.sibling(button, 2);

			$.template_effect(() => {
				$.set_text(text_1, $.get(genericMessage));
				button.disabled = $.get(seconds) > 0 || $.get(resending);

				$.set_text(text_3, $.get(resending)
					? 'Resending…'
					: $.get(seconds) > 0 ? `Resend link in ${$.get(seconds)}s` : 'Resend link');
			});

			$.event('click', button, resend);
			$.event('click', button_1, reset);
			$.append($$anchor, fragment);
		};

		var alternate = ($$anchor) => {
			var fragment_1 = root_4();
			var form = $.sibling($.first_child(fragment_1), 8);
			var div = $.sibling($.child(form), 2);
			let classes;
			var input = $.child(div);

			$.remove_input_defaults(input);
			$.reset(div);

			var node_3 = $.sibling(div, 4);

			{
				var consequent_3 = ($$anchor) => {
					var p_3 = root_5();
					var text_4 = $.child(p_3, true);

					$.reset(p_3);
					$.template_effect(() => $.set_text(text_4, $.get(error)));
					$.append($$anchor, p_3);
				};

				$.add_svelte_meta(
					() => $.if(node_3, ($$render) => {
						if ($.get(error)) $$render(consequent_3);
					}),
					'if',
					Auth,
					62,
					8
				);
			}

			var button_2 = $.sibling(node_3, 2);
			var text_5 = $.child(button_2, true);

			$.reset(button_2);
			$.reset(form);
			$.next(2);

			$.template_effect(
				($0) => {
					classes = $.set_class(div, 1, 'phone-field', null, classes, { 'error-field': $.get(error) });
					$.set_attribute(input, 'aria-invalid', $0);
					button_2.disabled = $.strict_equals($.get(state), 'submitting');
					$.set_text(text_5, $.strict_equals($.get(state), 'submitting') ? 'Sending securely…' : 'Send link on WhatsApp');
				},
				[() => Boolean($.get(error))]
			);

			$.bind_value(
				input,
				function get() {
					return $.get(phoneNumber);
				},
				function set($$value) {
					$.set(phoneNumber, $$value);
				}
			);

			$.event('input', input, () => $.set(error, ''));
			$.event('submit', form, $.preventDefault(submit));
			$.append($$anchor, fragment_1);
		};

		$.add_svelte_meta(
			() => $.if(node_1, ($$render) => {
				if ($.strict_equals($.get(state), 'sent')) $$render(consequent_2); else $$render(alternate, false);
			}),
			'if',
			Auth,
			43,
			4
		);
	}

	$.reset(section);
	$.next(2);
	$.reset(main);
	$.append($$anchor, main);

	return $.pop($$exports);
}

if (import.meta.hot) {
	Auth = $.hmr(Auth, () => Auth[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = Auth[$.HMR].source;
		$.set(Auth[$.HMR].source, module.default[$.HMR].original);
	});
}

export default Auth;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7O1NBRVcsU0FBUyxRQUFRLFFBQVE7U0FDekIsUUFBUSxFQUFFLGdCQUFnQixRQUFRLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQUgzRCxDQUFDOzs7O0tBS0ssV0FBVyxvQkFBRyxFQUFFO0tBQ2hCLEtBQUssb0JBQUcsTUFBTTtLQUNkLEtBQUssb0JBQUcsRUFBRTtLQUNWLGNBQWMsb0JBQUcsRUFBRTtLQUNuQixPQUFPLG9CQUFHLENBQUM7S0FDWCxLQUFLO0tBQ0wsU0FBUyxvQkFBRyxLQUFLO09BQ2YsZ0JBQWdCLE9BQU8sZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLFNBQVM7T0FFckUsVUFBVSxJQUFJLEtBQUssTUFBSyxtQkFBbUIsRUFBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRTs7VUFDMUUsY0FBYyxHQUFHO0VBQ3hCLGFBQWEsQ0FBQyxLQUFLO1FBQUcsT0FBTyxFQUFHLEVBQUU7O0VBQ2xDLEtBQUssR0FBRyxXQUFXO1NBQU8sQ0FBQztVQUFDLE9BQU8sUUFBUCxPQUFPLElBQUksQ0FBQzs7Y0FBTSxPQUFPLEtBQUksQ0FBQyxFQUFFLGFBQWEsQ0FBQyxLQUFLO0dBQUcsQ0FBQztHQUFFLElBQUk7O0NBQzNGOztnQkFDZSxNQUFNLEdBQUc7UUFDdEIsS0FBSyxFQUFHLEVBQUU7O2FBQ0wsV0FBVyxFQUFDLElBQUksSUFBSSxDQUFDO1NBQUMsS0FBSyxFQUFHLHNEQUFzRDs7O0VBQVU7O09BQzlGLFVBQVUsT0FBQyxXQUFXLElBQUcsQ0FBQztTQUFDLEtBQUssRUFBRyw4REFBOEQ7OztFQUFVOztRQUNoSCxLQUFLLEVBQUcsWUFBWTs7TUFDaEI7U0FDSSxNQUFNLGtDQUFTLGdCQUFnQixPQUFDLFdBQVcsRUFBQyxJQUFJOztTQUN0RCxjQUFjLEVBQUcsTUFBTSxFQUFFLE9BQU8sSUFBSSw2RUFBNkU7U0FDakgsS0FBSyxFQUFHLE1BQU07R0FBRSxjQUFjO0VBQ2hDLENBQUMsT0FBUSxLQUFLLEVBQUU7U0FDZCxLQUFLLEVBQUcsTUFBTTs7U0FDZCxLQUFLLEdBQUksU0FBUyxDQUFDLE1BQU07TUFBRyxnRUFBZ0U7TUFBRyxnRUFBZ0U7RUFDaks7Q0FDRjs7VUFDUyxLQUFLLEdBQUcsQ0FBQztFQUFDLGFBQWEsQ0FBQyxLQUFLO1FBQUcsV0FBVyxFQUFHLEVBQUU7UUFBRSxLQUFLLEVBQUcsRUFBRTtRQUFFLGNBQWMsRUFBRyxFQUFFO1FBQUUsS0FBSyxFQUFHLE1BQU07Q0FBRTs7Z0JBQzdGLE1BQU0sR0FBRyxDQUFDO1lBQUssT0FBTyxJQUFHLENBQUMsVUFBSSxTQUFTOztRQUFVLFNBQVMsRUFBRyxJQUFJOztNQUFNLENBQUM7U0FBTyxNQUFNLGtDQUFTLGdCQUFnQixPQUFDLFdBQVcsRUFBQyxJQUFJOztTQUFLLGNBQWMsRUFBRyxNQUFNLEVBQUUsT0FBTyxVQUFJLGNBQWM7R0FBRSxjQUFjO0VBQUksQ0FBQyxPQUFRLEtBQUssRUFBRSxDQUFDO1NBQUMsS0FBSyxHQUFJLFNBQVMsQ0FBQyxNQUFNO01BQUcsZ0VBQWdFO01BQUcsa0VBQWtFO0VBQUUsQ0FBQyxTQUFTLENBQUM7U0FBQyxTQUFTLEVBQUcsS0FBSztFQUFFLENBQUM7Q0FBQzs7Q0FDL2EsU0FBUyxPQUFPLGFBQWEsQ0FBQyxLQUFLOzs7Ozs7S0FHcEMsSUFBSTtLQUVGLE9BQU8scUJBRlQsSUFBSTtvQkFFRixPQUFPOzs7O09BQ3FDLENBQUM7c0JBQUQsQ0FBQzs7V0FBRCxDQUFDO2lEQUE0QyxnQkFBZ0I7c0JBQTdELENBQUM7Ozs7O1FBQXZDLGdCQUFnQiwwQkFBSSxLQUFLLEdBQUssTUFBTTs7Ozs7Ozs7Ozs7Ozs7T0FNdEMsR0FBQzt3QkFBRCxHQUFDOztXQUFELEdBQUM7OzBCQUFELEdBQUM7Ozs7U0FFVSxHQUFDOzBCQUFELEdBQUM7O2FBQUQsR0FBQztzREFBa0MsS0FBSzt3QkFBeEMsR0FBQzs7Ozs7Z0JBQVIsS0FBSzs7Ozs7Ozs7O09BQ1QsTUFBTTt3QkFBTixNQUFNOztXQUFOLE1BQU07O09BQ04sUUFBTSxhQUROLE1BQU07Ozs2QkFIbUMsY0FBYztJQUd2RCxNQUFNLGtCQUFrRCxPQUFPLElBQUcsQ0FBQyxVQUFJLFNBQVM7OzZCQUFHLFNBQVM7T0FBRyxZQUFZO2FBQUcsT0FBTyxJQUFHLENBQUMsMkJBQXFCLE9BQU8sT0FBTSxhQUFhOzs7b0JBQXhLLE1BQU0sRUFBZ0MsTUFBTTtvQkFDNUMsUUFBTSxFQUFrQyxLQUFLOzs7Ozs7T0FNN0MsSUFBSTtPQUVGLEdBQUcscUJBRkwsSUFBSTs7T0FFaUQsS0FBSyxXQUF4RCxHQUFHOzsyQkFBZ0QsS0FBSztXQUF4RCxHQUFHOzswQkFBSCxHQUFHOzs7O1NBRVEsR0FBQzswQkFBRCxHQUFDOzthQUFELEdBQUM7c0RBQW1ELEtBQUs7d0JBQXpELEdBQUM7Ozs7O2dCQUFSLEtBQUs7Ozs7Ozs7OztPQUNULFFBQU07d0JBQU4sUUFBTTs7V0FBTixRQUFNO1dBTFIsSUFBSTs7Ozs7MkJBRUYsR0FBRywwREFBb0IsS0FBSztxQkFBdUIsS0FBSztLQUd4RCxRQUFNLGtDQUE4QyxLQUFLLEdBQUssWUFBWTs4Q0FBRyxLQUFLLEdBQUssWUFBWSxJQUFHLG1CQUFtQixHQUFHLHVCQUF1Qjs7V0FIOEUsT0FBTyxPQUFDLEtBQUs7Ozs7SUFBM0wsS0FBSzthQUEwRCxHQUFVO2tCQUFFLFdBQVc7O2FBQXZCLEdBQVU7V0FBRSxXQUFXOzs7O29CQUF0RixLQUFLLGNBQXlNLEtBQUssRUFBRyxFQUFFO3FCQUY3USxJQUFJLG1CQUEyQixNQUFNOzs7Ozs7OEJBZm5DLEtBQUssR0FBSyxNQUFNOzs7Ozs7Ozs7U0FGdEIsT0FBTzs7U0FGVCxJQUFJO29CQUFKLElBQUk7OztDQUZMIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8IS0tIEZJTi1FUElDLTAwNDogZG9jcy9qaXJhL3BlcnNvbmFsLWV4cGVuc2UvRklOLUVQSUMtMDA0LXBvcnRhbC1hbmQtcmVmZXJlbmNlcy5tZCAtLT5cbjxzY3JpcHQ+XG4gIGltcG9ydCB7IG9uRGVzdHJveSB9IGZyb20gJ3N2ZWx0ZSc7XG4gIGltcG9ydCB7IEFwaUVycm9yLCByZXF1ZXN0TG9naW5MaW5rIH0gZnJvbSAnLi9saWIvYXBpLmpzJztcblxuICBsZXQgcGhvbmVOdW1iZXIgPSAnJztcbiAgbGV0IHN0YXRlID0gJ2Zvcm0nO1xuICBsZXQgZXJyb3IgPSAnJztcbiAgbGV0IGdlbmVyaWNNZXNzYWdlID0gJyc7XG4gIGxldCBzZWNvbmRzID0gMDtcbiAgbGV0IHRpbWVyO1xuICBsZXQgcmVzZW5kaW5nID0gZmFsc2U7XG4gIGNvbnN0IHNpZ25lZE91dE1lc3NhZ2UgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCkuZ2V0KCdtZXNzYWdlJyk7XG5cbiAgY29uc3QgdmFsaWRQaG9uZSA9ICh2YWx1ZSkgPT4gL15cXCtbMS05XVxcZHs3LDE0fSQvLnRlc3QodmFsdWUucmVwbGFjZSgvW1xccygpLV0vZywgJycpKTtcbiAgZnVuY3Rpb24gc3RhcnRDb3VudGRvd24oKSB7XG4gICAgY2xlYXJJbnRlcnZhbCh0aW1lcik7IHNlY29uZHMgPSA2MDtcbiAgICB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHsgc2Vjb25kcyAtPSAxOyBpZiAoc2Vjb25kcyA8PSAwKSBjbGVhckludGVydmFsKHRpbWVyKTsgfSwgMTAwMCk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gc3VibWl0KCkge1xuICAgIGVycm9yID0gJyc7XG4gICAgaWYgKCFwaG9uZU51bWJlci50cmltKCkpIHsgZXJyb3IgPSAnRW50ZXIgeW91ciBwaG9uZSBudW1iZXIsIGluY2x1ZGluZyB0aGUgY291bnRyeSBjb2RlLic7IHJldHVybjsgfVxuICAgIGlmICghdmFsaWRQaG9uZShwaG9uZU51bWJlcikpIHsgZXJyb3IgPSAnRW50ZXIgYSB2YWxpZCBpbnRlcm5hdGlvbmFsIG51bWJlciwgc3VjaCBhcyArOTEgOTg3NjUgNDMyMTAuJzsgcmV0dXJuOyB9XG4gICAgc3RhdGUgPSAnc3VibWl0dGluZyc7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlcXVlc3RMb2dpbkxpbmsocGhvbmVOdW1iZXIudHJpbSgpKTtcbiAgICAgIGdlbmVyaWNNZXNzYWdlID0gcmVzdWx0Py5tZXNzYWdlIHx8ICdJZiB0aGlzIG51bWJlciBpcyByZWdpc3RlcmVkLCB3ZSBzZW50IGEgbG9naW4gbGluayB0byBpdHMgV2hhdHNBcHAgYWNjb3VudC4nO1xuICAgICAgc3RhdGUgPSAnc2VudCc7IHN0YXJ0Q291bnRkb3duKCk7XG4gICAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIHN0YXRlID0gJ2Zvcm0nO1xuICAgICAgZXJyb3IgPSAhbmF2aWdhdG9yLm9uTGluZSA/ICdZb3UgYXBwZWFyIHRvIGJlIG9mZmxpbmUuIENoZWNrIHlvdXIgY29ubmVjdGlvbiBhbmQgdHJ5IGFnYWluLicgOiAnV2UgY291bGRu4oCZdCBzZW5kIHRoZSBsaW5rIHJpZ2h0IG5vdy4gUGxlYXNlIHRyeSBhZ2FpbiBzaG9ydGx5Lic7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHJlc2V0KCkgeyBjbGVhckludGVydmFsKHRpbWVyKTsgcGhvbmVOdW1iZXIgPSAnJzsgZXJyb3IgPSAnJzsgZ2VuZXJpY01lc3NhZ2UgPSAnJzsgc3RhdGUgPSAnZm9ybSc7IH1cbiAgYXN5bmMgZnVuY3Rpb24gcmVzZW5kKCkgeyBpZiAoc2Vjb25kcyA+IDAgfHwgcmVzZW5kaW5nKSByZXR1cm47IHJlc2VuZGluZyA9IHRydWU7IHRyeSB7IGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlcXVlc3RMb2dpbkxpbmsocGhvbmVOdW1iZXIudHJpbSgpKTsgZ2VuZXJpY01lc3NhZ2UgPSByZXN1bHQ/Lm1lc3NhZ2UgfHwgZ2VuZXJpY01lc3NhZ2U7IHN0YXJ0Q291bnRkb3duKCk7IH0gY2F0Y2ggKGNhdXNlKSB7IGVycm9yID0gIW5hdmlnYXRvci5vbkxpbmUgPyAnWW91IGFwcGVhciB0byBiZSBvZmZsaW5lLiBDaGVjayB5b3VyIGNvbm5lY3Rpb24gYW5kIHRyeSBhZ2Fpbi4nIDogJ1dlIGNvdWxkbuKAmXQgcmVzZW5kIHRoZSBsaW5rIHJpZ2h0IG5vdy4gUGxlYXNlIHRyeSBhZ2FpbiBzaG9ydGx5Lic7IH0gZmluYWxseSB7IHJlc2VuZGluZyA9IGZhbHNlOyB9IH1cbiAgb25EZXN0cm95KCgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpKTtcbjwvc2NyaXB0PlxuXG48bWFpbiBjbGFzcz1cImF1dGgtcGFnZVwiPlxuICA8YSBjbGFzcz1cImF1dGgtYnJhbmRcIiBocmVmPVwiL3BvcnRhbFwiIGFyaWEtbGFiZWw9XCJFeHBlbnNlIEFJIHBvcnRhbFwiPjxzcGFuPuKCuTwvc3Bhbj5FeHBlbnNlIEFJPC9hPlxuICA8c2VjdGlvbiBjbGFzcz1cImF1dGgtY2FyZFwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgIHsjaWYgc2lnbmVkT3V0TWVzc2FnZSAmJiBzdGF0ZSA9PT0gJ2Zvcm0nfTxwIGNsYXNzPVwic2lnbmVkLW91dC1ub3RpY2VcIiByb2xlPVwic3RhdHVzXCI+4pyTIHtzaWduZWRPdXRNZXNzYWdlfTwvcD57L2lmfVxuICAgIHsjaWYgc3RhdGUgPT09ICdzZW50J31cbiAgICAgIDxkaXYgY2xhc3M9XCJhdXRoLWljb24gc2VudC1pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+4pyTPC9kaXY+XG4gICAgICA8cCBjbGFzcz1cImV5ZWJyb3dcIj5MaW5rIHNlbnQ8L3A+XG4gICAgICA8aDE+Q2hlY2sgeW91ciBXaGF0c0FwcDwvaDE+XG4gICAgICA8cD5JZiB0aGlzIG51bWJlciBpcyByZWdpc3RlcmVkLCB3ZSBzZW50IGEgc2VjdXJlIHNpZ24taW4gbGluay4gT3BlbiBpdCBvbiB0aGlzIGRldmljZSB0byBjb250aW51ZS48L3A+XG4gICAgICA8cCBjbGFzcz1cImdlbmVyaWMtbWVzc2FnZVwiIHJvbGU9XCJzdGF0dXNcIj57Z2VuZXJpY01lc3NhZ2V9PC9wPlxuICAgICAgPGRpdiBjbGFzcz1cInNlY3VyaXR5LW5vdGVcIj48c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7ihpc8L3NwYW4+PHA+TGlua3MgZXhwaXJlIHNob3J0bHkgYW5kIGNhbiBvbmx5IGJlIHVzZWQgb25jZS48L3A+PC9kaXY+XG4gICAgICB7I2lmIGVycm9yfTxwIGNsYXNzPVwiYXV0aC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L3A+ey9pZn1cbiAgICAgIDxidXR0b24gY2xhc3M9XCJhdXRoLXByaW1hcnlcIiBvbjpjbGljaz17cmVzZW5kfSBkaXNhYmxlZD17c2Vjb25kcyA+IDAgfHwgcmVzZW5kaW5nfT57cmVzZW5kaW5nID8gJ1Jlc2VuZGluZ+KApicgOiBzZWNvbmRzID4gMCA/IGBSZXNlbmQgbGluayBpbiAke3NlY29uZHN9c2AgOiAnUmVzZW5kIGxpbmsnfTwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImF1dGgtc2Vjb25kYXJ5XCIgb246Y2xpY2s9e3Jlc2V0fT5Vc2UgYW5vdGhlciBudW1iZXI8L2J1dHRvbj5cbiAgICB7OmVsc2V9XG4gICAgICA8ZGl2IGNsYXNzPVwiYXV0aC1pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+4oaXPC9kaXY+XG4gICAgICA8cCBjbGFzcz1cImV5ZWJyb3dcIj5Qcml2YXRlIGFjY2VzczwvcD5cbiAgICAgIDxoMT5TaWduIGluIHRvIHlvdXIgcG9ydGFsPC9oMT5cbiAgICAgIDxwPkVudGVyIHRoZSBwaG9uZSBudW1iZXIgY29ubmVjdGVkIHRvIHlvdXIgV2hhdHNBcHAgYWNjb3VudC4gV2XigJlsbCBzZW5kIHlvdSBhIHNlY3VyZSBzaWduLWluIGxpbmsuPC9wPlxuICAgICAgPGZvcm0gb246c3VibWl0fHByZXZlbnREZWZhdWx0PXtzdWJtaXR9IG5vdmFsaWRhdGU+XG4gICAgICAgIDxsYWJlbCBmb3I9XCJwaG9uZVwiPlBob25lIG51bWJlcjwvbGFiZWw+XG4gICAgICAgIDxkaXYgY2xhc3M6ZXJyb3ItZmllbGQ9e2Vycm9yfSBjbGFzcz1cInBob25lLWZpZWxkXCI+PGlucHV0IGlkPVwicGhvbmVcIiB0eXBlPVwidGVsXCIgaW5wdXRtb2RlPVwidGVsXCIgYXV0b2NvbXBsZXRlPVwidGVsXCIgYmluZDp2YWx1ZT17cGhvbmVOdW1iZXJ9IHBsYWNlaG9sZGVyPVwiKzkxIDk4NzY1IDQzMjEwXCIgYXJpYS1kZXNjcmliZWRieT1cInBob25lLWhpbnQgcGhvbmUtZXJyb3JcIiBhcmlhLWludmFsaWQ9e0Jvb2xlYW4oZXJyb3IpfSBvbjppbnB1dD17KCkgPT4gZXJyb3IgPSAnJ30gLz48L2Rpdj5cbiAgICAgICAgPHNtYWxsIGlkPVwicGhvbmUtaGludFwiPkluY2x1ZGUgeW91ciBjb3VudHJ5IGNvZGUsIGZvciBleGFtcGxlICs5MS48L3NtYWxsPlxuICAgICAgICB7I2lmIGVycm9yfTxwIGlkPVwicGhvbmUtZXJyb3JcIiBjbGFzcz1cImF1dGgtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj57ZXJyb3J9PC9wPnsvaWZ9XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJhdXRoLXByaW1hcnlcIiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e3N0YXRlID09PSAnc3VibWl0dGluZyd9PntzdGF0ZSA9PT0gJ3N1Ym1pdHRpbmcnID8gJ1NlbmRpbmcgc2VjdXJlbHnigKYnIDogJ1NlbmQgbGluayBvbiBXaGF0c0FwcCd9PC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgICA8cCBjbGFzcz1cInByaXZhY3ktY29weVwiPldl4oCZbGwgb25seSB1c2UgdGhpcyBudW1iZXIgdG8gc2VjdXJlbHkgZmluZCB5b3VyIGFjY291bnQuIFdlIG5ldmVyIHJldmVhbCB3aGV0aGVyIGEgbnVtYmVyIGlzIHJlZ2lzdGVyZWQuPC9wPlxuICAgIHsvaWZ9XG4gIDwvc2VjdGlvbj5cbiAgPHAgY2xhc3M9XCJhdXRoLWZvb3RlclwiPjxzcGFuPjwvc3Bhbj5Qcm90ZWN0ZWQgd2l0aCBzZWN1cmUsIGNvb2tpZS1iYXNlZCBhY2Nlc3M8L3A+XG48L21haW4+XG4iXSwiZmlsZSI6Ii9Vc2Vycy9kZWVuYS9Eb2N1bWVudHMvR2l0SHViL3BlcnNvbmFsLWFpL2Zyb250ZW5kL3NyYy9BdXRoLnN2ZWx0ZSJ9