import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Home.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=e89ac925";
import "/node_modules/.vite/deps/svelte_internal_flags_legacy.js?v=e89ac925";

Home[$.FILENAME] = 'src/Home.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=e89ac925";
import "/src/commitment.css";
import "/src/components/detail-sheet.css";
import { onMount, tick } from "/node_modules/.vite/deps/svelte.js?v=e89ac925";

import {
	ApiError,
	completeAction,
	completeRecurringCommitment,
	confirmSipOccurrence,
	confirmStockMonthlyPlan,
	createCreditCard,
	createLoan,
	createMissingDateContext,
	createMutualFund,
	createMutualFundLumpSum,
	createMutualFundSip,
	createStock,
	createStockMonthlyPlan,
	createRecurringCommitment,
	deleteExpense,
	deleteLoan,
	deleteMutualFund,
	deleteRecurringCommitment,
	deleteStock,
	getActions,
	getCommitmentReview,
	getCreditCards,
	getExpenseOptions,
	getExpensesForDate,
	getIncomeOutlook,
	getLoanHistory,
	getLoans,
	getMutualFund,
	getMutualFunds,
	getRecurringCommitmentHistory,
	getRecurringCommitments,
	getStock,
	getStocks,
	logout,
	markLoanEmiPaid,
	recordRecurringCommitmentCompletion,
	resolveCommitmentReview,
	saveIncomeProfile,
	searchMutualFunds,
	searchStocks,
	updateCreditCard,
	updateExpense,
	updateLoan,
	updateRecurringCommitment,
	updateSipOccurrence,
	updateMutualFundTransaction
} from "/src/lib/api.js";

import SectionState from "/src/SectionState.svelte";
import Normalization from "/src/Normalization.svelte";
import AppHeader from "/src/components/AppHeader.svelte";
import BottomNav from "/src/components/BottomNav.svelte";
import DueReminder from "/src/components/DueReminder.svelte";
import ViewDetailsLink from "/src/components/ViewDetailsLink.svelte";
import ClosedLoanRow from "/src/components/ClosedLoanRow.svelte";
import ProfileSettings from "/src/features/profile/ProfileSettings.svelte";

var root_2 = $.add_locations($.from_html(`<p>Loading payment history…</p>`), Home[$.FILENAME], [[171, 300]]);
var root_4 = $.add_locations($.from_html(`<p> </p>`), Home[$.FILENAME], [[171, 369]]);
var root_8 = $.add_locations($.from_html(`<div class="loan-history-action"><!></div>`), Home[$.FILENAME], [[171, 929]]);

var root_7 = $.add_locations($.from_html(`<div><span> </span><strong> </strong><span class="history-amount"><b> </b></span><small> </small><!></div>`), Home[$.FILENAME], [
	[
		171,
		527,
		[[171, 596], [171, 635], [171, 681, [[171, 710]]], [171, 770]]
	]
]);

var root_9 = $.add_locations($.from_html(`<p>No payments recorded yet.</p>`), Home[$.FILENAME], [[171, 1155]]);
var root_5 = $.add_locations($.from_html(`<section class="investment-history"><h3>EMI timeline</h3><!></section>`), Home[$.FILENAME], [[171, 401, [[171, 437]]]]);
var root_1 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">LOAN DETAILS</p><h2> </h2><!></section></div>`), Home[$.FILENAME], [[171, 17, [[171, 64, [[171, 131], [171, 195], [171, 234]]]]]]);
var root_11 = $.add_locations($.from_html(`<p>Loading payment history…</p>`), Home[$.FILENAME], [[172, 327]]);
var root_13 = $.add_locations($.from_html(`<p> </p>`), Home[$.FILENAME], [[172, 402]]);

var root_16 = $.add_locations($.from_html(`<div class="investment-history-row"><span> </span><strong> </strong><span class="history-amount"><b> </b></span><small> </small></div>`), Home[$.FILENAME], [
	[
		172,
		581,
		[[172, 617], [172, 656], [172, 706, [[172, 735]]], [172, 810]]
	]
]);

var root_17 = $.add_locations($.from_html(`<p>No payments recorded yet.</p>`), Home[$.FILENAME], [[172, 883]]);
var root_14 = $.add_locations($.from_html(`<section class="investment-history"><h3>Payment history</h3><!></section>`), Home[$.FILENAME], [[172, 440, [[172, 476]]]]);
var root_10 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">COMMITMENT DETAILS</p><h2> </h2><!></section></div>`), Home[$.FILENAME], [[172, 23, [[172, 70, [[172, 137], [172, 207], [172, 252]]]]]]);

var root_18 = $.add_locations($.from_html(`<section class="offline-notice"><span>◌</span><div><strong> </strong><p> </p></div><button>Retry</button></section>`), Home[$.FILENAME], [
	[
		176,
		34,
		[[176, 66], [176, 80, [[176, 85], [176, 166]]], [176, 323]]
	]
]);

var root_20 = $.add_locations($.from_html(`<button class="spending-hero"><span>MONTHLY SPENDING</span><strong> <small>spent</small></strong><b> </b></button>`), Home[$.FILENAME], [
	[179, 92, [[179, 162], [179, 191, [[179, 224]]], [179, 253]]]
]);

var root_23 = $.add_locations($.from_html(`<button></button>`), Home[$.FILENAME], [[180, 475]]);

var root_24 = $.add_locations($.from_html(`<button><span class="story-source"> </span><strong> </strong><b> </b><i>›</i></button>`), Home[$.FILENAME], [
	[
		180,
		1088,
		[[180, 1217], [180, 1271], [180, 1318], [180, 1360]]
	]
]);

var root_22 = $.add_locations($.from_html(`<div class="story-carousel" aria-label="Your stories"><div class="story-dots" aria-label="Choose a story"><!><span> </span></div><div class="story-carousel-viewport"><div class="story-carousel-track"></div></div></div>`), Home[$.FILENAME], [
	[
		180,
		335,
		[[180, 389, [[180, 723]]], [180, 783, [[180, 957]]]]
	]
]);

var root_25 = $.add_locations($.from_html(`<div class="story-rail-empty">Your stories will appear here as you add expenses.</div>`), Home[$.FILENAME], [[180, 1409]]);

var root_26 = $.add_locations($.from_html(`<button class="row-main"><div><strong> </strong><span> </span></div><b> </b></button>`), Home[$.FILENAME], [
	[181, 293, [[181, 377, [[181, 382], [181, 415]]], [181, 487]]]
]);

var root_27 = $.add_locations($.from_html(`<p class="empty-copy">No expenses recorded yet.</p>`), Home[$.FILENAME], [[181, 532]]);

var root_19 = $.add_locations($.from_html(`<section class="app-heading"><div><p class="micro-label"> </p><h1> </h1><p>Here’s how your month is unfolding.</p></div></section> <!> <section class="home-section"><div class="section-title"><div><p class="micro-label">YOUR STORIES</p><h2>Small signals, clearly told</h2></div><button class="text-link">See all</button></div><!></section> <section class="home-section"><div class="section-title"><div><p class="micro-label">RECENT ACTIVITY</p><h2>Your latest expenses</h2></div><button class="text-link">See all</button></div><div class="compact-list"></div></section> <button class="your-money-card"><span>◒</span><div><strong>Your money</strong><small>See your incoming and outgoing plan, only when you’re ready.</small></div><b>Explore ›</b></button>`, 1), Home[$.FILENAME], [
	[178, 2, [[178, 31, [[178, 36], [178, 104], [178, 125]]]]],

	[
		180,
		2,
		[[180, 32, [[180, 59, [[180, 64], [180, 103]]], [180, 145]]]]
	],

	[
		181,
		2,

		[
			[181, 32, [[181, 59, [[181, 64], [181, 106]]], [181, 141]]],
			[181, 229]
		]
	],

	[
		182,
		2,
		[[182, 55], [182, 69, [[182, 74], [182, 101]]], [182, 182]]
	]
]);

var root_31 = $.add_locations($.from_html(`<span> </span>`), Home[$.FILENAME], [[185, 467]]);
var root_32 = $.add_locations($.from_html(`<span></span>`), Home[$.FILENAME], [[185, 554]]);
var root_33 = $.add_locations($.from_html(`<button> </button>`), Home[$.FILENAME], [[185, 600]]);
var root_34 = $.add_locations($.from_html(`<i></i>`), Home[$.FILENAME], [[185, 851]]);

var root_30 = $.add_locations($.from_html(`<section class="month-card"><div class="month-summary"><div><span>Total recorded</span><strong> </strong></div><div><span>Transactions</span><strong> </strong></div><div><span>Highest day</span><strong> </strong></div></div><div class="weekdays"></div><div class="calendar"><!><!></div><div class="legend"><span>Lower spend</span><div></div><span>Higher spend</span></div></section>`), Home[$.FILENAME], [
	[
		185,
		92,

		[
			[
				185,
				120,

				[
					[185, 147, [[185, 152], [185, 179]]],
					[185, 226, [[185, 231], [185, 256]]],
					[185, 305, [[185, 310], [185, 334]]]
				]
			],

			[185, 389],
			[185, 496],
			[185, 778, [[185, 798], [185, 822], [185, 892]]]
		]
	]
]);

var root_35 = $.add_locations($.from_html(`<div class="activity-loading">Loading transactions…</div>`), Home[$.FILENAME], [[186, 368]]);
var root_37 = $.add_locations($.from_html(`<div class="section-error"><p>Could not load this date.</p><button>Try again</button></div>`), Home[$.FILENAME], [[186, 476, [[186, 503], [186, 535]]]]);
var root_40 = $.add_locations($.from_html(`<div class="row-actions"><button>Edit transaction</button><button class="danger">Delete</button></div>`), Home[$.FILENAME], [[186, 1441, [[186, 1466], [186, 1530]]]]);

var root_39 = $.add_locations($.from_html(`<article><button class="row-main"><div><strong> </strong><span> </span></div><div class="row-value"><b> </b><span>⌄</span></div></button><!></article>`), Home[$.FILENAME], [
	[
		186,
		1018,

		[
			[
				186,
				1085,

				[
					[186, 1170, [[186, 1175], [186, 1208]]],
					[186, 1280, [[186, 1303], [186, 1332]]]
				]
			]
		]
	]
]);

var root_41 = $.add_locations($.from_html(`<p class="empty-copy">No transactions for this view.</p>`), Home[$.FILENAME], [[186, 1625]]);
var root_42 = $.add_locations($.from_html(`<button class="view-all"> </button>`), Home[$.FILENAME], [[186, 1720]]);
var root_38 = $.add_locations($.from_html(`<div class="activity-summary"><p class="micro-label"> </p><h2> </h2></div><div class="compact-list"></div><!>`, 1), Home[$.FILENAME], [[186, 593, [[186, 623], [186, 764]]], [186, 964]]);

var root_29 = $.add_locations($.from_html(`<section class="workspace-heading"><div><p class="micro-label">EXPENSE WORKSPACE</p><h1>Transactions</h1><p>AI-captured expenses, ready for your review.</p></div><label class="month-switcher"><button type="button">←</button><input type="month"/><button type="button">→</button></label></section> <!> <section class="activity-panel adaptive-activity"><div class="activity-tabs"><button>Recent</button><button> </button></div><!></section> <button class="wide-button"> </button><button class="cleanup-card"><span>✦</span><div><strong>Expense cleanup</strong><small>Fix merchant and account names captured by AI.</small></div><b>Open ›</b></button>`, 1), Home[$.FILENAME], [
	[
		184,
		2,

		[
			[184, 37, [[184, 42], [184, 86], [184, 107]]],
			[184, 164, [[184, 194], [184, 257], [184, 378]]]
		]
	],

	[186, 2, [[186, 52, [[186, 79], [186, 176]]]]],
	[187, 2],

	[
		187,
		205,
		[[187, 272], [187, 286, [[187, 291], [187, 323]]], [187, 390]]
	]
]);

var root_45 = $.add_locations($.from_html(`<button> </button>`), Home[$.FILENAME], [[189, 267]]);
var root_48 = $.add_locations($.from_html(`<button></button>`), Home[$.FILENAME], [[189, 969]]);
var root_50 = $.add_locations($.from_html(`<span class="commitment-icon"> </span>`), Home[$.FILENAME], [[189, 1924]]);

var root_49 = $.add_locations($.from_html(`<button><span class="story-source"> </span><!><strong> </strong><b> </b><i>›</i></button>`), Home[$.FILENAME], [
	[
		189,
		1608,
		[[189, 1848], [189, 1984], [189, 2022], [189, 2064]]
	]
]);

var root_47 = $.add_locations($.from_html(`<div class="story-carousel story-carousel-full"><div class="story-dots" aria-label="Choose a story"><!><span> </span></div><div class="story-carousel-viewport"><div class="story-carousel-track"></div></div></div>`), Home[$.FILENAME], [
	[
		189,
		793,
		[[189, 879, [[189, 1227]]], [189, 1293, [[189, 1471]]]]
	]
]);

var root_51 = $.add_locations($.from_html(`<div class="empty-state"><span>✦</span><h2> </h2><p>As you choose to add more information, relevant stories will appear here.</p></div>`), Home[$.FILENAME], [[189, 2113, [[189, 2138], [189, 2152], [189, 2203]]]]);

var root_44 = $.add_locations($.from_html(`<section class="workspace-heading"><div><p class="micro-label">YOUR MONEY, EXPLAINED</p><h1>Stories</h1><p>Insights across the information you choose to share.</p></div></section><div class="story-filters"></div><div class="commitment-style-control"><span>Commitment style</span><button>Calm</button><button>Playful ✨</button></div><!>`, 1), Home[$.FILENAME], [
	[189, 2, [[189, 37, [[189, 42], [189, 90], [189, 106]]]]],
	[189, 181],
	[189, 397, [[189, 435], [189, 464], [189, 567]]]
]);

var root_54 = $.add_locations($.from_html(`<p>Loading your private outlook…</p>`), Home[$.FILENAME], [[203, 256]]);
var root_56 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[203, 325, [[203, 355], [203, 381]]]]);
var root_58 = $.add_locations($.from_html(`<div class="income-summary masked"><span>Salary saved</span><strong> </strong><button class="income-edit" aria-label="Update salary outlook" title="Update salary outlook">🔧</button><small>Masked before it reaches this screen.</small></div>`), Home[$.FILENAME], [[203, 473, [[203, 508], [203, 533], [203, 584], [203, 714]]]]);
var root_59 = $.add_locations($.from_html(`<div class="income-summary"><strong>Start with a range</strong><small>Only you decide whether to share a range or an exact amount.</small></div><button class="add-fund-row">Set up salary outlook</button>`, 1), Home[$.FILENAME], [[203, 779, [[203, 807], [203, 842]]], [203, 923]]);
var root_60 = $.add_locations($.from_html(`<p class="loan-state">Loading commitments…</p>`), Home[$.FILENAME], [[204, 258]]);
var root_62 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[204, 341, [[204, 371], [204, 401]]]]);
var root_66 = $.add_locations($.from_html(`<small> </small>`), Home[$.FILENAME], [[204, 1381]]);

var root_65 = $.add_locations($.from_html(`<article><span>↻</span><div><strong class="loan-name"> <button class="loan-edit">🔧</button><button class="loan-delete"> </button></strong><small> </small><small> </small><!></div><div><b> </b></div><!><button class="text-link">Mark completed</button></article>`), Home[$.FILENAME], [
	[
		204,
		522,

		[
			[204, 659],

			[
				204,
				673,

				[
					[204, 678, [[204, 722], [204, 845]]],
					[204, 1063],
					[204, 1199]
				]
			],

			[204, 1466, [[204, 1471]]],
			[204, 1585]
		]
	]
]);

var root_67 = $.add_locations($.from_html(`<p class="loan-state">No commitments yet.</p>`), Home[$.FILENAME], [[204, 1700]]);
var root_68 = $.add_locations($.from_html(`<p class="loan-state">Loading credit cards…</p>`), Home[$.FILENAME], [[205, 214]]);
var root_70 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[205, 298, [[205, 328], [205, 358]]]]);

var root_73 = $.add_locations($.from_html(`<article class="loan-row"><span>▣</span><div><strong class="loan-name"> <button class="loan-edit" title="Edit credit card">🔧</button></strong><small> </small></div><div><b> </b><small> </small></div></article>`), Home[$.FILENAME], [
	[
		205,
		473,

		[
			[205, 499],
			[205, 513, [[205, 518, [[205, 559]]], [205, 707]]],
			[205, 778, [[205, 783], [205, 807]]]
		]
	]
]);

var root_74 = $.add_locations($.from_html(`<p class="loan-state">Add a card once it appears as an account in your captured expenses.</p>`), Home[$.FILENAME], [[205, 881]]);

var root_75 = $.add_locations($.from_html(`<button class="module-row"><span> </span><div><strong> </strong><small> </small></div><b>Coming soon</b></button>`), Home[$.FILENAME], [
	[
		207,
		8,
		[[207, 57], [207, 81, [[207, 86], [207, 114]]], [207, 146]]
	]
]);

var root_76 = $.add_locations($.from_html(`<p>Loading your funds…</p>`), Home[$.FILENAME], [[209, 255]]);
var root_78 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[209, 318, [[209, 348], [209, 378]]]]);
var root_81 = $.add_locations($.from_html(`<strong> </strong><small> </small>`, 1), Home[$.FILENAME], [[209, 569], [209, 618]]);
var root_82 = $.add_locations($.from_html(`<strong> </strong><small>Current valuation is temporarily unavailable</small>`, 1), Home[$.FILENAME], [[209, 810], [209, 860]]);
var root_85 = $.add_locations($.from_html(`<span class="stock-recurring-bell" role="button" tabindex="0" title="Set SIP">🔔</span>`), Home[$.FILENAME], [[209, 2225]]);

var root_84 = $.add_locations($.from_html(`<div class="fund-card-values"><div><span>P&amp;L</span><b> </b><small> </small></div><div><span>Invested</span><b> </b></div><div><span>Current</span><b> </b></div></div><p class="fund-card-nav"> <!></p>`, 1), Home[$.FILENAME], [
	[
		209,
		1658,

		[
			[209, 1688, [[209, 1784], [209, 1804], [209, 1881]]],
			[209, 1992, [[209, 1997], [209, 2018]]],
			[209, 2060, [[209, 2065], [209, 2085]]]
		]
	],

	[209, 2137]
]);

var root_86 = $.add_locations($.from_html(`<p class="fund-valuation-unavailable"> </p>`), Home[$.FILENAME], [[209, 2555]]);

var root_83 = $.add_locations($.from_html(`<button><span class="fund-card-orb"></span><div class="fund-card-title"><strong> </strong><span class="fund-delete" role="button" tabindex="0" title="Delete mutual fund"> </span><small> </small></div><!><footer><span class="fund-sip-summary"> </span><span class="fund-actions"><span>View details →</span><span class="fund-lump-sum" role="button" tabindex="0">＋ Lump sum</span></span></footer><!></button>`), Home[$.FILENAME], [
	[
		209,
		989,

		[
			[209, 1126],
			[209, 1161, [[209, 1190], [209, 1224], [209, 1576]]],

			[
				209,
				2695,
				[[209, 2703], [209, 2957, [[209, 2984], [209, 3011]]]]
			]
		]
	]
]);

var root_80 = $.add_locations($.from_html(`<section class="portfolio-total"><span>Total portfolio value</span><!></section><div class="fund-card-list"></div>`, 1), Home[$.FILENAME], [[209, 466, [[209, 499]]], [209, 934]]);
var root_88 = $.add_locations($.from_html(`<p>Choose one verified scheme, then add its existing holding, an SIP, or occasional lump sums whenever you need.</p>`), Home[$.FILENAME], [[209, 3415]]);
var root_89 = $.add_locations($.from_html(`<p>Loading your stocks…</p>`), Home[$.FILENAME], [[212, 37]]);
var root_91 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[213, 40, [[213, 70], [213, 95]]]]);
var root_94 = $.add_locations($.from_html(`<strong> </strong><small> </small>`, 1), Home[$.FILENAME], [[215, 108], [215, 156]]);
var root_95 = $.add_locations($.from_html(`<strong> </strong><small>Current valuation is temporarily unavailable</small>`, 1), Home[$.FILENAME], [[215, 328], [215, 377]]);

var root_97 = $.add_locations($.from_html(`<div class="fund-card-values"><div><span>P&amp;L</span><b> </b><small> </small></div><div><span>Invested</span><b> </b></div><div><span>Current</span><b> </b></div></div><p class="fund-card-nav"> <button class="stock-recurring-bell" title="Set monthly recurring plan">🔔</button></p>`, 1), Home[$.FILENAME], [
	[
		218,
		43,

		[
			[218, 73, [[218, 171], [218, 191], [218, 270]]],
			[218, 383, [[218, 388], [218, 409]]],
			[218, 452, [[218, 457], [218, 477]]]
		]
	],

	[218, 530, [[218, 647]]]
]);

var root_98 = $.add_locations($.from_html(`<p class="fund-valuation-unavailable"> </p>`), Home[$.FILENAME], [[218, 837]]);

var root_96 = $.add_locations($.from_html(`<article><span class="fund-card-orb"></span><div class="fund-card-title"><strong> </strong><span class="fund-delete" role="button" tabindex="0" title="Delete stock"> </span><small> </small></div> <!> <footer><span class="fund-sip-summary"> </span><!></footer> <!></article>`), Home[$.FILENAME], [
	[
		216,
		61,

		[
			[217, 12],
			[217, 47, [[217, 76], [217, 105], [217, 402]]],
			[219, 12, [[219, 20]]]
		]
	]
]);

var root_93 = $.add_locations($.from_html(`<section class="portfolio-total"><span>Total stock value</span><!></section> <div class="fund-card-list"></div>`, 1), Home[$.FILENAME], [[215, 10, [[215, 43]]], [216, 10]]);
var root_100 = $.add_locations($.from_html(`<p>Search a listed stock, then add the shares and amount you already invested.</p>`), Home[$.FILENAME], [[222, 15]]);
var root_101 = $.add_locations($.from_html(`<div class="loan-total"><span>Total monthly EMI</span><b> </b></div>`), Home[$.FILENAME], [[225, 203, [[225, 227], [225, 257]]]]);
var root_102 = $.add_locations($.from_html(`<p class="loan-state">Loading your loans…</p>`), Home[$.FILENAME], [[226, 36]]);
var root_104 = $.add_locations($.from_html(`<div class="loan-state error"><span> </span><button>Try again</button></div>`), Home[$.FILENAME], [[226, 112, [[226, 142], [226, 166]]]]);
var root_108 = $.add_locations($.from_html(`<div class="loan-progress"><div><span> </span></div><i></i></div>`), Home[$.FILENAME], [[226, 1075, [[226, 1102, [[226, 1107]]], [226, 1193]]]]);
var root_109 = $.add_locations($.from_html(`<div class="loan-due-action"><strong>Final EMI due</strong><p>Confirm you paid the final EMI before closing this loan.</p><button class="primary" data-testid="mark-final-emi-paid"> </button></div>`), Home[$.FILENAME], [[226, 1330, [[226, 1359], [226, 1389], [226, 1452]]]]);

var root_107 = $.add_locations($.from_html(`<article><span>₹</span><div><strong class="loan-name"> <button class="loan-edit" title="Edit loan">🔧</button><button class="loan-delete" title="Delete loan"> </button></strong><small> </small></div><div><b> </b><small> </small></div><!><!><!></article>`), Home[$.FILENAME], [
	[
		226,
		311,

		[
			[226, 398],
			[226, 412, [[226, 417, [[226, 458], [226, 584]]], [226, 789]]],
			[226, 899, [[226, 904], [226, 944]]]
		]
	]
]);

var root_110 = $.add_locations($.from_html(`<p class="loan-state">No active loans.</p>`), Home[$.FILENAME], [[226, 1740]]);
var root_112 = $.add_locations($.from_html(`<div class="closed-loans-list"></div>`), Home[$.FILENAME], [[227, 285]]);
var root_111 = $.add_locations($.from_html(`<button class="closed-loans-toggle" data-testid="closed-loans-toggle"> <span> </span></button><!>`, 1), Home[$.FILENAME], [[227, 32, [[227, 217]]]]);

var root_53 = $.add_locations($.from_html(`<div class="modal-backdrop" role="presentation"><section class="modal money-modal" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button> <p class="micro-label">OPTIONAL, PRIVATE, YOURS</p><h2>Build your complete money picture</h2> <p class="module-reassurance">You choose what to add. Nothing is required, and you can remove a module anytime.</p> <section class="income-module"><div class="loans-heading"><div><strong>Salary outlook</strong><small>Private estimate — never treated as your account balance</small></div><span class="verified-pill">Optional</span></div><!></section> <section class="loans-module" data-testid="commitments-section"><div class="loans-heading"><div><strong>Commitments</strong><small>Rent, bills, subscriptions, maintenance, and repeatable obligations</small></div></div><!><button class="add-loan-row">＋ Add a commitment</button></section> <section class="loans-module"><div class="loans-heading"><div><strong>Credit cards</strong><small>Turn captured card spending into the bill due next month</small></div></div><!><button class="add-loan-row">＋ Add a credit card</button></section> <!> <section class="mutual-funds-module"><div class="loans-heading"><div><strong>Mutual funds</strong><small>Portfolio value from the latest available NAV</small></div><span class="verified-pill">Scheme API</span></div><!><button class="add-fund-row">＋ Add a mutual fund</button></section> <section class="mutual-funds-module stocks-module"><div class="loans-heading"><div><strong>Stocks</strong><small>Portfolio value from the latest available market price</small></div><span class="verified-pill">Market data</span></div> <!> <button class="add-fund-row">＋ Add a stock</button></section> <section class="loans-module" data-testid="loans-section"><div class="loans-heading"><div><strong>Loans</strong><small>Track repayments and monthly commitments</small></div><!></div> <!> <!> <button class="add-loan-row">＋ Add another loan</button></section> <p class="module-footnote">These modules use normal forms—not AI cleanup—and only inform stories if you turn that on.</p></section></div>`), Home[$.FILENAME], [
	[
		198,
		2,

		[
			[
				199,
				4,

				[
					[200, 6],
					[201, 6],
					[201, 57],
					[202, 6],

					[
						203,
						6,
						[[203, 37, [[203, 64, [[203, 69], [203, 100]]], [203, 177]]]]
					],

					[
						204,
						6,

						[
							[204, 70, [[204, 97, [[204, 102], [204, 130]]]]],
							[204, 1750]
						]
					],

					[
						205,
						6,
						[[205, 36, [[205, 63, [[205, 68], [205, 97]]]]], [205, 979]]
					],

					[
						209,
						6,

						[
							[209, 43, [[209, 70, [[209, 75], [209, 104]]], [209, 170]]],
							[209, 3536]
						]
					],

					[
						210,
						6,

						[
							[211, 8, [[211, 35, [[211, 40], [211, 63]]], [211, 138]]],
							[223, 8]
						]
					],

					[
						225,
						6,
						[[225, 64, [[225, 91, [[225, 96], [225, 118]]]]], [228, 8]]
					],

					[230, 6]
				]
			]
		]
	]
]);

var root_115 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[234, 735]]);
var root_116 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[234, 1324]]);

var root_114 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal loan-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">COMMITMENT</p><h2> </h2><p class="module-reassurance">A planning estimate, not proof that a bill was paid.</p><label>Name<input maxlength="120"/></label><label>Planning amount<input type="number" inputmode="decimal" min="0.01"/></label><label>Frequency<select aria-label="Frequency"></select></label><label>Every<input aria-label="Every" type="number" min="1"/></label><label>Next expected date<input type="date"/></label><label><input type="checkbox"/> Flexible reminder</label><label>Amount basis<select><option>Fixed amount</option><option>My estimate</option></select></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		234,
		24,

		[
			[
				234,
				52,

				[
					[234, 117],
					[234, 189],
					[234, 226],
					[234, 311],
					[234, 397, [[234, 408]]],
					[234, 474, [[234, 496]]],
					[234, 600, [[234, 616]]],
					[234, 809, [[234, 821]]],
					[234, 925, [[234, 950]]],
					[234, 1023, [[234, 1030]]],
					[234, 1127, [[234, 1146, [[234, 1193], [234, 1236]]]]],
					[234, 1372, [[234, 1399], [234, 1480]]]
				]
			]
		]
	]
]);

var root_117 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal loan-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">COMPLETION</p><h2> </h2><label>Actual amount<input type="number" min="0.01"/></label><label>Completed on<input type="date"/></label><label>Next expected date<input type="date"/></label><button class="text-link"> </button><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary">Save completion</button></div></section></div>`), Home[$.FILENAME], [
	[
		235,
		26,

		[
			[
				235,
				54,

				[
					[235, 119],
					[235, 192],
					[235, 229],
					[235, 281, [[235, 301]]],
					[235, 383, [[235, 402]]],
					[235, 470, [[235, 495]]],
					[235, 568],
					[235, 799, [[235, 826], [235, 908]]]
				]
			]
		]
	]
]);

var root_119 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[236, 625]]);
var root_120 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[236, 1182]]);

var root_118 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal loan-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">CREDIT-CARD BILLING</p><h2> </h2><p class="module-reassurance">We add only expenses captured against this account between statement dates to the bill due in that month.</p><label>Captured account<select><option disabled>Select the card account</option><!></select></label><label>Card name<input placeholder="e.g. Millennia" maxlength="120"/></label><label>Issuer / vendor<input placeholder="e.g. HDFC Bank" maxlength="120"/></label><label>Bill generation day<input type="number" min="1" max="28"/></label><label>Payment due day<input type="number" min="1" max="28"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		236,
		24,

		[
			[
				236,
				52,

				[
					[236, 117],
					[236, 189],
					[236, 235],
					[236, 311],
					[236, 450, [[236, 473, [[236, 528]]]]],
					[236, 707, [[236, 723]]],
					[236, 821, [[236, 843]]],
					[236, 943, [[236, 969]]],
					[236, 1057, [[236, 1079]]],
					[236, 1230, [[236, 1257], [236, 1338]]]
				]
			]
		]
	]
]);

var root_122 = $.add_locations($.from_html(`<button> </button>`), Home[$.FILENAME], [[237, 566]]);
var root_123 = $.add_locations($.from_html(`<label>Monthly take-home salary<input type="number" min="1" inputmode="decimal" placeholder="Optional exact amount"/></label>`), Home[$.FILENAME], [[237, 1088, [[237, 1119]]]]);
var root_124 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[237, 1410]]);
var root_125 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[237, 1531]]);

var root_121 = $.add_locations($.from_html(`<div class="modal-backdrop income-flow-backdrop"><section class="modal income-flow" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">PRIVATE SALARY CONTEXT</p><h2>What range feels comfortable to share?</h2><p class="module-reassurance">A range is enough. This is not a request for a payslip, and it never changes your balance.</p><div class="range-options"></div><button class="text-link income-exact-toggle"> </button><!><label>How often does it arrive?<select></select></label><!><div class="modal-actions"><button class="secondary">Skip for now</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		237,
		20,

		[
			[
				237,
				69,

				[
					[237, 136],
					[237, 204],
					[237, 253],
					[237, 300],
					[237, 424],
					[237, 789],
					[237, 1261, [[237, 1293]]],
					[237, 1575, [[237, 1602], [237, 1742]]]
				]
			]
		]
	]
]);

var root_127 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[239, 651]]);
var root_128 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[239, 1541]]);

var root_126 = $.add_locations($.from_html(`<div class="modal-backdrop loan-form-backdrop" role="presentation"><section class="modal loan-form" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">LOAN DETAILS</p><h2> </h2><p class="module-reassurance">Your loan information is stored securely in your account.</p><label>Loan name<input placeholder="e.g. HDFC Home Loan" maxlength="255"/></label><label>Loan type<select></select></label><label>Original loan principal<input type="number" inputmode="decimal" min="1" placeholder="e.g. 4200000"/></label><label>Monthly EMI amount<input type="number" inputmode="decimal" min="1" placeholder="e.g. 38600"/></label><label>Total tenure in months<input type="number" inputmode="numeric" min="1" placeholder="e.g. 240"/></label><label>First EMI due date<input type="date"/></label><label>Bank / lender<input placeholder="e.g. HDFC Bank" maxlength="255"/></label><label>Notes <span class="optional">Optional</span><input placeholder="e.g. Primary residence"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		239,
		2,

		[
			[
				239,
				69,

				[
					[239, 148],
					[239, 214],
					[239, 253],
					[239, 308],
					[239, 399, [[239, 415]]],
					[239, 513, [[239, 529]]],
					[239, 731, [[239, 761]]],
					[239, 887, [[239, 912]]],
					[239, 1035, [[239, 1064]]],
					[239, 1186, [[239, 1211]]],
					[239, 1278, [[239, 1298]]],
					[239, 1393, [[239, 1406], [239, 1444]]],
					[239, 1583, [[239, 1610], [239, 1685]]]
				]
			]
		]
	]
]);

var root_130 = $.add_locations($.from_html(`<div class="fund-success"><span>✓</span><p class="micro-label"> </p><h2> </h2><p> </p><button class="primary">Done</button></div>`), Home[$.FILENAME], [
	[
		243,
		19,
		[[243, 45], [243, 59], [243, 136], [243, 212], [243, 520]]
	]
]);

var root_133 = $.add_locations($.from_html(`<p>Searching schemes…</p>`), Home[$.FILENAME], [[245, 389]]);
var root_135 = $.add_locations($.from_html(`<p>Type at least 2 characters to search.</p>`), Home[$.FILENAME], [[245, 452]]);
var root_137 = $.add_locations($.from_html(`<button type="button"><strong> </strong><small> </small></button>`), Home[$.FILENAME], [[245, 534, [[245, 611], [245, 647]]]]);
var root_138 = $.add_locations($.from_html(`<p>No matching scheme found.</p>`), Home[$.FILENAME], [[245, 808]]);
var root_132 = $.add_locations($.from_html(`<div class="scheme-menu"><!></div>`), Home[$.FILENAME], [[245, 328]]);

var root_139 = $.add_locations($.from_html(`<div class="scheme-validated"><span>✓</span><div><strong>Verified by scheme master</strong><small> </small></div></div>`), Home[$.FILENAME], [
	[245, 891, [[245, 921], [245, 935, [[245, 940], [245, 982]]]]]
]);

var root_141 = $.add_locations($.from_html(`<option></option>`), Home[$.FILENAME], [[246, 622]]);

var root_140 = $.add_locations($.from_html(`<label>Monthly SIP amount<input type="number" inputmode="decimal" min="1"/></label><div class="fund-field-pair"><label>SIP date<select></select></label><label>Start month<input type="month"/></label></div>`, 1), Home[$.FILENAME], [
	[246, 396, [[246, 421]]],

	[
		246,
		512,
		[[246, 541, [[246, 556]]], [246, 754, [[246, 772]]]]
	]
]);

var root_142 = $.add_locations($.from_html(`<div class="fund-field-pair"><label>Current units<input type="number" inputmode="decimal" min="0.001" step="0.001"/></label><label>Total amount invested<input type="number" inputmode="decimal" min="0.01"/></label></div><p class="fund-disclaimer">Average purchase cost is calculated by the backend after the opening balance is recorded.</p>`, 1), Home[$.FILENAME], [
	[
		247,
		411,
		[[247, 440, [[247, 460]]], [247, 571, [[247, 599]]]]
	],

	[247, 703]
]);

var root_143 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[248, 21]]);

var root_131 = $.add_locations($.from_html(`<p class="micro-label">MUTUAL FUND</p><h2>Add a mutual fund</h2><p class="module-reassurance">Search the official scheme master. A returned name is one verified fund, plan and option.</p> <div class="fund-section"><span class="fund-section-label">1 · FUND</span><label class="scheme-picker">Search and select scheme<input placeholder="Type at least 2 characters" autocomplete="off"/><!></label><!></div> <div class="fund-section"><span class="fund-section-label">2 · SIP <em>OPTIONAL</em></span><fieldset><legend>Do you have an actual SIP for this fund?</legend><label class="choice"><input type="radio"/> Yes</label><label class="choice"><input type="radio"/> No</label></fieldset><!></div> <div class="fund-section"><span class="fund-section-label">3 · EXISTING HOLDING <em>OPTIONAL</em></span><fieldset><legend>Do you already hold this fund?</legend><label class="choice"><input type="radio"/> No</label><label class="choice"><input type="radio"/> Yes</label></fieldset><!></div> <!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div>`, 1), Home[$.FILENAME], [
	[244, 11],
	[244, 49],
	[244, 75],
	[245, 6, [[245, 32], [245, 80, [[245, 133]]]]],

	[
		246,
		6,

		[
			[246, 32, [[246, 73]]],

			[
				246,
				97,

				[
					[246, 107],
					[246, 164, [[246, 186]]],
					[246, 261, [[246, 283]]]
				]
			]
		]
	],

	[
		247,
		6,

		[
			[247, 32, [[247, 86]]],

			[
				247,
				110,

				[
					[247, 120],
					[247, 167, [[247, 189]]],
					[247, 266, [[247, 288]]]
				]
			]
		]
	],

	[248, 63, [[248, 90], [248, 171]]]
]);

var root_129 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop" role="presentation"><section class="modal fund-form" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button> <!></section></div>`), Home[$.FILENAME], [[242, 2, [[242, 69, [[242, 148]]]]]]);
var root_146 = $.add_locations($.from_html(`<p>Searching stock symbols…</p>`), Home[$.FILENAME], [[252, 816]]);
var root_148 = $.add_locations($.from_html(`<p>Could not search stocks.</p>`), Home[$.FILENAME], [[252, 885]]);
var root_150 = $.add_locations($.from_html(`<button type="button"><strong> </strong><small> </small></button>`), Home[$.FILENAME], [[252, 952, [[252, 1027], [252, 1070]]]]);
var root_151 = $.add_locations($.from_html(`<p>No matching listed stock found.</p>`), Home[$.FILENAME], [[252, 1262]]);
var root_145 = $.add_locations($.from_html(`<div class="scheme-menu"><!></div>`), Home[$.FILENAME], [[252, 756]]);

var root_152 = $.add_locations($.from_html(`<div class="scheme-validated"><span>✓</span><div><strong>Verified market symbol</strong><small> </small></div></div>`), Home[$.FILENAME], [
	[
		252,
		1350,
		[[252, 1380], [252, 1394, [[252, 1399], [252, 1438]]]]
	]
]);

var root_153 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[252, 2064]]);

var root_144 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop" role="presentation"><section class="modal fund-form" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">STOCK HOLDING</p><h2>Add a stock</h2><p class="module-reassurance">Search market symbols, then record the shares and total amount you already invested. Editing and selling will follow in a later update.</p><div class="fund-section"><span class="fund-section-label">1 · STOCK</span><label class="scheme-picker">Search and select stock<input placeholder="Type at least 2 characters" autocomplete="off"/><!></label><!></div><div class="fund-section"><span class="fund-section-label">2 · HOLDING</span><div class="fund-field-pair"><label>Shares held<input type="number" inputmode="decimal" min="0.001" step="0.001"/></label><label>Total amount invested<input type="number" inputmode="decimal" min="0.01"/></label></div></div><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		252,
		2,

		[
			[
				252,
				69,

				[
					[252, 148],
					[252, 215],
					[252, 255],
					[252, 275],
					[252, 444, [[252, 470], [252, 519, [[252, 571]]]]],

					[
						252,
						1677,

						[
							[252, 1703],

							[
								252,
								1754,
								[[252, 1783, [[252, 1801]]], [252, 1909, [[252, 1937]]]]
							]
						]
					],

					[252, 2107, [[252, 2134], [252, 2210]]]
				]
			]
		]
	]
]);

var root_155 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[254, 668]]);

var root_154 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY SIP</p><h2> </h2><p class="module-reassurance">This creates a monthly plan. Occasional lump sums remain separate.</p><label>Monthly amount<input type="number" min="0.01"/></label><label>SIP date<input type="number" min="1" max="28"/></label><label>Start month<input type="month"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		254,
		19,

		[
			[
				254,
				66,

				[
					[254, 131],
					[254, 197],
					[254, 235],
					[254, 285],
					[254, 385, [[254, 406]]],
					[254, 479, [[254, 494]]],
					[254, 570, [[254, 588]]],
					[254, 710, [[254, 737], [254, 812]]]
				]
			]
		]
	]
]);

var root_156 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY ETF PLAN</p><h2> </h2><label>Monthly amount<input type="number" min="0.01"/></label><label>Investment day<input type="number" min="1" max="28"/></label><label>Start month<input type="month"/></label><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		255,
		21,

		[
			[
				255,
				68,

				[
					[255, 133],
					[255, 201],
					[255, 244],
					[255, 280, [[255, 301]]],
					[255, 376, [[255, 397]]],
					[255, 475, [[255, 493]]],
					[255, 560, [[255, 587], [255, 664]]]
				]
			]
		]
	]
]);

var root_157 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">CONFIRM ETF INVESTMENT</p><h2>Was this investment processed?</h2><label>Amount invested<input type="number" min="0.01"/></label><label>Executed market price<input type="number" min="0.0001"/></label><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary">Confirm investment</button></div></section></div>`), Home[$.FILENAME], [
	[
		256,
		33,

		[
			[
				256,
				80,

				[
					[256, 145],
					[256, 225],
					[256, 274],
					[256, 313, [[256, 335]]],
					[256, 418, [[256, 446]]],
					[256, 530, [[256, 557], [256, 646]]]
				]
			]
		]
	]
]);

var root_159 = $.add_locations($.from_html(`<h2>Loading stock details…</h2>`), Home[$.FILENAME], [[257, 230]]);
var root_161 = $.add_locations($.from_html(`<h2>Couldn’t load this stock</h2>`), Home[$.FILENAME], [[257, 299]]);

var root_163 = $.add_locations($.from_html(`<div class="investment-history-row"><span> </span><strong> </strong><span class="history-amount"><b> </b></span><small> </small></div>`), Home[$.FILENAME], [
	[
		257,
		700,
		[[257, 736], [257, 783], [257, 861, [[257, 890]]], [257, 925]]
	]
]);

var root_162 = $.add_locations($.from_html(`<p class="micro-label">STOCK DETAILS</p><h2> </h2><div class="detail-grid"><div><span>Invested</span><b> </b></div><div><span>Shares</span><b> </b></div></div><section class="investment-history"><h3>Investment history</h3><!></section>`, 1), Home[$.FILENAME], [
	[257, 339],
	[257, 379],

	[
		257,
		412,

		[
			[257, 437, [[257, 442], [257, 463]]],
			[257, 511, [[257, 516], [257, 535]]]
		]
	],

	[257, 601, [[257, 637]]]
]);

var root_158 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><!></section></div>`), Home[$.FILENAME], [[257, 17, [[257, 64, [[257, 131]]]]]]);
var root_165 = $.add_locations($.from_html(`<p class="micro-label">FUND DETAILS</p><h2>Loading fund details…</h2>`, 1), Home[$.FILENAME], [[259, 227], [259, 266]]);
var root_167 = $.add_locations($.from_html(`<p class="micro-label">FUND DETAILS</p><h2>Couldn’t load this fund</h2><p> </p><button class="primary">Try again</button>`, 1), Home[$.FILENAME], [[259, 333], [259, 372], [259, 404], [259, 428]]);

var root_170 = $.add_locations($.from_html(`<div class="investment-history-row"><span> </span><strong> </strong><span class="history-amount"><b> </b><button class="history-edit" aria-label="Edit this investment" title="Edit this investment">🔧</button></span><small> </small></div>`), Home[$.FILENAME], [
	[
		259,
		1568,

		[
			[259, 1604],
			[259, 1651],
			[259, 1746, [[259, 1775], [259, 1803]]],
			[259, 1965]
		]
	]
]);

var root_169 = $.add_locations($.from_html(`<section class="investment-history"><h3>Investment history</h3><!></section>`), Home[$.FILENAME], [[259, 1470, [[259, 1506]]]]);

var root_168 = $.add_locations($.from_html(`<p class="micro-label">FUND DETAILS</p><h2> </h2><div class="detail-value"><span>Current value</span><strong> </strong></div><div><span>Total P&amp;L</span><strong> </strong><b> </b></div><div class="detail-grid"><div><span>Invested</span><b> </b></div><div><span>Units</span><b> </b></div><div><span>Average NAV</span><b> </b></div><div><span>Current NAV</span><b> </b></div></div><!><p class="fund-disclaimer">Average NAV is based on confirmed investments. Current NAV is the latest available MFAPI value.</p>`, 1), Home[$.FILENAME], [
	[259, 571],
	[259, 610],
	[259, 642, [[259, 668], [259, 694]]],
	[259, 749, [[259, 876], [259, 902], [259, 994]]],

	[
		259,
		1109,

		[
			[259, 1134, [[259, 1139], [259, 1160]]],
			[259, 1201, [[259, 1206], [259, 1224]]],
			[259, 1274, [[259, 1279], [259, 1303]]],
			[259, 1353, [[259, 1358], [259, 1382]]]
		]
	],

	[259, 2078]
]);

var root_164 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-detail" role="dialog" aria-modal="true"><button class="close">×</button><!></section></div>`), Home[$.FILENAME], [[259, 16, [[259, 63, [[259, 130]]]]]]);
var root_172 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[260, 736]]);

var root_171 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">LUMP-SUM INVESTMENT</p><h2> </h2><p class="module-reassurance">This adds confirmed units to this fund only. It does not change the monthly SIP plan.</p><label>Amount invested<input type="number" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><label>NAV<input type="number" min="0.0001" step="0.0001" placeholder="e.g. 87.25"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		260,
		17,

		[
			[
				260,
				64,

				[
					[260, 129],
					[260, 193],
					[260, 239],
					[260, 279],
					[260, 398, [[260, 420]]],
					[260, 505, [[260, 528]]],
					[260, 597, [[260, 607]]],
					[260, 781, [[260, 808], [260, 881]]]
				]
			]
		]
	]
]);

var root_174 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[261, 952]]);

var root_173 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">CONFIRM SIP INVESTMENT</p><h2>Was this SIP processed?</h2><p class="module-reassurance">Units will be estimated from the NAV and marked as an estimate until you correct them from your statement.</p><div class="source-note"><strong> </strong><span> </span></div><label>Amount invested<input type="number" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><label>NAV <span class="optional">Estimated</span><input type="number" min="0.0001" step="0.0001" placeholder="e.g. 87.25"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		261,
		19,

		[
			[
				261,
				66,

				[
					[261, 131],
					[261, 197],
					[261, 246],
					[261, 278],
					[261, 418, [[261, 443], [261, 491]]],
					[261, 562, [[261, 584]]],
					[261, 672, [[261, 695]]],
					[261, 767, [[261, 778], [261, 817]]],
					[261, 1000, [[261, 1027], [261, 1102]]]
				]
			]
		]
	]
]);

var root_176 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[262, 876]]);

var root_175 = $.add_locations($.from_html(`<div class="modal-backdrop fund-form-backdrop"><section class="modal fund-form" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">EDIT INVESTMENT</p><h2> </h2><p class="module-reassurance">Update this recorded investment. Your fund totals will recalculate automatically.</p><label>Amount invested<input type="number" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><label>NAV<input type="number" min="0.0001" step="0.0001"/></label><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		262,
		28,

		[
			[
				262,
				75,

				[
					[262, 140],
					[262, 215],
					[262, 257],
					[262, 416],
					[262, 531, [[262, 553]]],
					[262, 646, [[262, 669]]],
					[262, 746, [[262, 756]]],
					[262, 929, [[262, 956], [262, 1040]]]
				]
			]
		]
	]
]);

var root_177 = $.add_locations($.from_html(`<div class="account-repair-backdrop" role="presentation"><section class="account-repair-dialog" role="dialog" aria-modal="true" tabindex="-1"><header class="account-repair-bar"><div><span class="repair-symbol">✦</span><span><p>EXPENSE DATA ONLY</p><strong>Expense cleanup</strong></span></div><button>×</button></header><div class="account-repair-content"><!></div></section></div>`), Home[$.FILENAME], [
	[
		264,
		23,

		[
			[
				264,
				189,

				[
					[
						264,
						299,

						[
							[264, 334, [[264, 339], [264, 375, [[264, 381], [264, 405]]]]],
							[264, 450]
						]
					],

					[264, 516]
				]
			]
		]
	]
]);

var root_181 = $.add_locations($.from_html(`<i></i>`), Home[$.FILENAME], [[266, 680]]);
var root_180 = $.add_locations($.from_html(`<div class="story-progress"></div>`), Home[$.FILENAME], [[266, 628]]);
var root_182 = $.add_locations($.from_html(`<p class="slide-eyebrow"> </p>`), Home[$.FILENAME], [[266, 964]]);
var root_183 = $.add_locations($.from_html(`<div class="story-amount"><span> </span><strong> </strong></div>`), Home[$.FILENAME], [[266, 1086, [[266, 1112], [266, 1158]]]]);
var root_185 = $.add_locations($.from_html(`<div><span> </span><strong> </strong></div>`), Home[$.FILENAME], [[266, 1394, [[266, 1399], [266, 1429]]]]);
var root_184 = $.add_locations($.from_html(`<div class="observation-components"></div>`), Home[$.FILENAME], [[266, 1315]]);
var root_187 = $.add_locations($.from_html(`<button class="story-action" data-testid="view-included-commitments"> </button>`), Home[$.FILENAME], [[266, 1570]]);
var root_189 = $.add_locations($.from_html(`<button class="story-action"> </button>`), Home[$.FILENAME], [[266, 1741]]);
var root_191 = $.add_locations($.from_html(`<button class="story-action" data-testid="review-final-emi"> </button>`), Home[$.FILENAME], [[266, 1880]]);
var root_192 = $.add_locations($.from_html(`<div class="story-deck-controls"><button>←</button><span> </span><button>Next →</button></div>`), Home[$.FILENAME], [[266, 2037, [[266, 2070], [266, 2143], [266, 2188]]]]);
var root_179 = $.add_locations($.from_html(`<div class="story-deck"><!><article><!><!><h1> </h1><p> </p><!><!></article><!></div>`), Home[$.FILENAME], [[266, 584, [[266, 739, [[266, 1226], [266, 1254]]]]]]);
var root_178 = $.add_locations($.from_html(`<div class="story-reader-backdrop" role="presentation"><section class="story-detail" role="dialog" aria-modal="true" tabindex="-1"><button class="back-button">← Back to stories</button><p class="micro-label"> </p><!></section></div>`), Home[$.FILENAME], [[266, 17, [[266, 167, [[266, 268], [266, 354]]]]]]);
var root_194 = $.add_locations($.from_html(`<p>Loading payment choices…</p>`), Home[$.FILENAME], [[268, 421]]);
var root_196 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[268, 495]]);
var root_199 = $.add_locations($.from_html(`<button class="story-action"> </button>`), Home[$.FILENAME], [[268, 826]]);

var root_198 = $.add_locations($.from_html(`<div class="source-note"><strong> </strong><span> </span></div><p>Which commitment is this for?</p><!><button class="secondary">This is not a commitment</button>`, 1), Home[$.FILENAME], [
	[268, 582, [[268, 607], [268, 698]]],
	[268, 755],
	[268, 1008]
]);

var root_200 = $.add_locations($.from_html(`<p>Everything is reviewed for this month.</p>`), Home[$.FILENAME], [[268, 1222]]);
var root_197 = $.add_locations($.from_html(`<!><!>`, 1), Home[$.FILENAME], []);

var root_193 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true"><button class="close">×</button><p class="micro-label">MONTHLY COMMITMENT</p><h2>Help match this payment</h2><p class="module-reassurance">Your expense was saved normally. Link it only if it belongs to one of your commitments.</p><!></section></div>`), Home[$.FILENAME], [
	[
		268,
		26,
		[[268, 54, [[268, 109], [268, 183], [268, 228], [268, 260]]]]
	]
]);

var root_204 = $.add_locations($.from_html(`<button class="secondary" data-testid="included-loan-commitment">Review</button>`), Home[$.FILENAME], [[269, 1487]]);
var root_206 = $.add_locations($.from_html(`<button class="secondary">Review</button>`), Home[$.FILENAME], [[269, 1614]]);
var root_208 = $.add_locations($.from_html(`<button class="secondary">Review</button>`), Home[$.FILENAME], [[269, 1784]]);
var root_210 = $.add_locations($.from_html(`<button class="secondary">Review</button>`), Home[$.FILENAME], [[269, 1947]]);

var root_203 = $.add_locations($.from_html(`<div><div><strong> </strong><span> </span></div><b> </b><!></div>`), Home[$.FILENAME], [
	[
		269,
		959,
		[[269, 1336, [[269, 1341], [269, 1373]]], [269, 1453]]
	]
]);

var root_202 = $.add_locations($.from_html(`<p class="evidence-total"> </p><div class="evidence-list"></div>`, 1), Home[$.FILENAME], [[269, 503], [269, 618]]);
var root_211 = $.add_locations($.from_html(`<div class="empty-state evidence-empty"><span>◌</span><h2>No commitments attached</h2><p>This story does not include sources to display.</p></div>`), Home[$.FILENAME], [[269, 2126, [[269, 2166], [269, 2180], [269, 2212]]]]);

var root_201 = $.add_locations($.from_html(`<div class="modal-backdrop" role="presentation"><section class="modal" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">INCLUDED COMMITMENTS</p><h2> </h2><!></section></div>`), Home[$.FILENAME], [
	[269, 23, [[269, 180, [[269, 274], [269, 345], [269, 392]]]]]
]);

var root_213 = $.add_locations($.from_html(`<p class="edit-options-status">Loading categories, merchants, and accounts…</p>`), Home[$.FILENAME], [[270, 624]]);
var root_215 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[270, 737]]);
var root_217 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[270, 951]]);
var root_218 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[270, 1195]]);
var root_219 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[270, 1401]]);
var root_220 = $.add_locations($.from_html(`<option> </option>`), Home[$.FILENAME], [[270, 1627]]);

var root_216 = $.add_locations($.from_html(`<label>Category<select><option disabled>Select a category</option><!></select></label><label>Subcategory<select><option disabled>Select a subcategory</option><!></select></label><label>Merchant<select><option disabled>Select a merchant</option><!></select></label><label>Source account<select><option disabled>Select an account</option><!></select></label>`, 1), Home[$.FILENAME], [
	[270, 784, [[270, 799, [[270, 859]]]]],
	[270, 1025, [[270, 1043, [[270, 1105]]]]],
	[270, 1259, [[270, 1274, [[270, 1310]]]]],
	[270, 1481, [[270, 1502, [[270, 1537]]]]]
]);

var root_221 = $.add_locations($.from_html(`<p class="form-error"> </p>`), Home[$.FILENAME], [[270, 1729]]);

var root_212 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">AI-CAPTURED EXPENSE</p><h2>Edit transaction</h2><div class="source-note"><strong>Captured from your message</strong><span>Review the details below before saving.</span></div><label>Amount<input type="number" inputmode="decimal" min="0.01" step="0.01"/></label><label>Transaction date<input type="date"/></label><!><!><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary"> </button></div></section></div>`), Home[$.FILENAME], [
	[
		270,
		13,

		[
			[
				270,
				41,

				[
					[270, 110],
					[270, 170],
					[270, 216],
					[270, 241, [[270, 266], [270, 309]]],
					[270, 367, [[270, 380]]],
					[270, 477, [[270, 500]]],
					[270, 1773, [[270, 1800], [270, 1869]]]
				]
			]
		]
	]
]);

var root_222 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal" role="alertdialog" aria-modal="true" tabindex="-1"><p class="micro-label">DELETE TRANSACTION</p><h2> </h2><p>This updates the calendar and monthly totals.</p><div class="modal-actions"><button class="secondary">Cancel</button><button class="primary delete-confirm">Delete</button></div></section></div>`), Home[$.FILENAME], [
	[
		271,
		14,

		[
			[
				271,
				42,

				[
					[271, 116],
					[271, 161],
					[271, 198],
					[271, 250, [[271, 277], [271, 347]]]
				]
			]
		]
	]
]);

var root_224 = $.add_locations($.from_html(`<a class="center-action whatsapp-action" target="_blank" rel="noopener">Open WhatsApp</a>`), Home[$.FILENAME], [[272, 362]]);

var root_223 = $.add_locations($.from_html(`<div class="modal-backdrop"><section class="modal whatsapp-handoff" role="dialog" aria-modal="true" tabindex="-1"><button class="close">×</button><p class="micro-label">WHATSAPP READY</p><h2>Continue in WhatsApp</h2><p> </p><!><button class="auth-secondary">Done</button></section></div>`), Home[$.FILENAME], [
	[
		272,
		13,

		[
			[
				272,
				41,
				[[272, 127], [272, 187], [272, 228], [272, 257], [272, 483]]
			]
		]
	]
]);

var root = $.add_locations($.from_html(`<!> <!> <!> <main class="app-shell"><!> <!></main> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!> <!>`, 1), Home[$.FILENAME], [[175, 0]]);

function Home($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, false, Home);

	const data = $.mutable_source();
	const currency = $.mutable_source();
	const calendar = $.mutable_source();
	const recentData = $.mutable_source();
	const recentItems = $.mutable_source();
	const storyData = $.mutable_source();
	const stories = $.mutable_source();
	const filteredStories = $.mutable_source();
	const homeStories = $.mutable_source();
	const selected = $.mutable_source();
	const activeItems = $.mutable_source();
	const visibleItems = $.mutable_source();
	const editSubcategories = $.mutable_source();
	const activeLoans = $.mutable_source();
	const closedLoans = $.mutable_source();
	const totalMonthlyEmi = $.mutable_source();
	const mutualPortfolio = $.mutable_source();
	const stockPortfolio = $.mutable_source();
	const visibleActions = $.mutable_source();
	const highlightedLoanAction = $.mutable_source();
	const connectionLabel = $.mutable_source();
	const evidenceItems = $.mutable_source();
	const binding_group = [];
	const binding_group_1 = [];
	let calendarSection = $.prop($$props, 'calendarSection', 8);
	let recentSection = $.prop($$props, 'recentSection', 8);
	let storiesSection = $.prop($$props, 'storiesSection', 8);
	let selectedMonth = $.prop($$props, 'selectedMonth', 8);
	let connectionStatus = $.prop($$props, 'connectionStatus', 8);
	let cacheUpdatedAt = $.prop($$props, 'cacheUpdatedAt', 8);
	let demoMode = $.prop($$props, 'demoMode', 8);
	let onDemoModeChange = $.prop($$props, 'onDemoModeChange', 8);
	let onMonthChange = $.prop($$props, 'onMonthChange', 8);
	let refreshCalendar = $.prop($$props, 'refreshCalendar', 8);
	let refreshRecent = $.prop($$props, 'refreshRecent', 8);
	let refreshStories = $.prop($$props, 'refreshStories', 8);
	let onRetryConnection = $.prop($$props, 'onRetryConnection', 8);
	let onLogout = $.prop($$props, 'onLogout', 8);
	let view = $.mutable_source('home');
	let showMoney = $.mutable_source(false);
	let showNormalization = $.mutable_source(false);
	let selectedDay = $.mutable_source(null);
	let activityTab = $.mutable_source('recent');
	let dayItems = $.mutable_source([]);
	let dayStatus = $.mutable_source('idle');
	let showAll = $.mutable_source(false);
	let expandedId = $.mutable_source(null);
	let openedStory = $.mutable_source(null);
	let handoff = $.mutable_source(null);
	let addingContext = $.mutable_source(false);
	let actionError = $.mutable_source('');
	let loggingOut = $.mutable_source(false);
	let signOutError = $.mutable_source('');
	let demoSwitching = $.mutable_source(false);
	let demoError = $.mutable_source('');
	let storySlide = $.mutable_source(0);
	let storyTouchStart = $.mutable_source(null);
	let showStoryEvidence = $.mutable_source(false);
	let storyFilter = $.mutable_source('All');
	let homeStoryIndex = $.mutable_source(0);
	let storiesRailIndex = $.mutable_source(0);
	let storyRailTouchStart = $.mutable_source(null);
	let commitmentStyle = $.mutable_source('playful');
	let editing = $.mutable_source(null);
	let editAmount = $.mutable_source('');
	let editDate = $.mutable_source('');
	let editCategory = $.mutable_source('');
	let editSubcategory = $.mutable_source('');
	let editMerchantId = $.mutable_source('');
	let editAccountId = $.mutable_source('');
	let saving = $.mutable_source(false);
	let deleting = $.mutable_source(null);
	let editOptions = $.mutable_source({ categories: [], merchants: [], accounts: [] });
	let optionsStatus = $.mutable_source('idle');
	let optionsError = $.mutable_source('');
	let storyControls = { spending: true, investments: true, planning: true };
	let showLoanForm = $.mutable_source(false);
	let loanError = $.mutable_source('');
	let loanStatus = $.mutable_source('idle');
	let loanEditingId = $.mutable_source(null);
	let loanSaving = $.mutable_source(false);
	let loanDeletingId = $.mutable_source(null);
	let showClosedLoans = $.mutable_source(false);

	let loanForm = $.mutable_source({
		loanName: '',
		loanType: 'HOME',
		lenderName: '',
		originalPrincipal: '',
		monthlyEmiAmount: '',
		totalTenureMonths: '',
		firstEmiDueDate: '',
		notes: ''
	});

	let loans = $.mutable_source([]);
	let loanHistory = $.mutable_source(null);
	let loanHistoryStatus = $.mutable_source('idle');
	let loanHistoryError = $.mutable_source('');
	let commitments = $.mutable_source([]);
	let commitmentStatus = $.mutable_source('idle');
	let commitmentError = $.mutable_source('');
	let showCommitmentForm = $.mutable_source(false);
	let commitmentSaving = $.mutable_source(false);
	let commitmentEditingId = $.mutable_source(null);
	let commitmentDeletingId = $.mutable_source(null);
	let completingCommitmentId = null;
	let commitmentHistory = $.mutable_source(null);
	let commitmentHistoryStatus = $.mutable_source('idle');
	let commitmentHistoryError = $.mutable_source('');

	let commitmentForm = $.mutable_source({
		label: '',
		planningAmount: '',
		dueDay: '',
		amountMode: 'FIXED',
		recurrenceUnit: 'MONTH',
		recurrenceInterval: '1',
		flexibleSchedule: false,
		nextExpectedDate: ''
	});

	let completionCommitment = $.mutable_source(null);
	let completionForm = $.mutable_source({ actualAmount: '', completedAt: '', nextExpectedDate: '' });
	let creditCards = $.mutable_source([]);
	let creditCardStatus = $.mutable_source('idle');
	let creditCardError = $.mutable_source('');
	let showCreditCardForm = $.mutable_source(false);
	let creditCardSaving = $.mutable_source(false);
	let creditCardEditingId = $.mutable_source(null);

	let creditCardForm = $.mutable_source({
		accountReferenceId: '',
		cardName: '',
		issuerName: '',
		statementDay: '',
		dueDay: ''
	});

	let showCommitmentReview = $.mutable_source(false);
	let commitmentReview = $.mutable_source([]);
	let commitmentReviewStatus = $.mutable_source('idle');
	let resolvingCandidate = $.mutable_source(null);
	let incomeOutlook = $.mutable_source({ salary: null });
	let incomeStatus = $.mutable_source('idle');
	let incomeError = $.mutable_source('');
	let incomeSaving = $.mutable_source(false);
	let showIncomeFlow = $.mutable_source(false);

	let salaryForm = $.mutable_source({
		salaryVisibility: 'RANGE',
		salaryRange: 'FROM_50000_TO_100000',
		exactMonthlySalary: '',
		salaryFrequency: 'MONTHLY'
	});

	let showMutualFundForm = $.mutable_source(false);
	let schemeQuery = $.mutable_source('');
	let showSchemeMenu = $.mutable_source(false);
	let selectedScheme = $.mutable_source(null);
	let fundError = $.mutable_source('');
	let fundSaved = $.mutable_source(false);
	let fundSaving = $.mutable_source(false);
	let schemeSearchStatus = $.mutable_source('idle');
	let schemeResults = $.mutable_source([]);
	let schemeSearchRequest = 0;
	let mutualFunds = $.mutable_source([]);
	let mutualFundStatus = $.mutable_source('idle');
	let mutualFundError = $.mutable_source('');
	let mutualFundDeletingId = $.mutable_source(null);
	let stocks = $.mutable_source([]);
	let stockStatus = $.mutable_source('idle');
	let stockError = $.mutable_source('');
	let showStockForm = $.mutable_source(false);
	let stockQuery = $.mutable_source('');
	let selectedStock = $.mutable_source(null);
	let stockResults = $.mutable_source([]);
	let stockSearchStatus = $.mutable_source('idle');
	let stockSearchRequest = 0;
	let stockSaving = $.mutable_source(false);
	let stockDeletingId = $.mutable_source(null);
	let stockPlanTarget = $.mutable_source(null);
	let stockPlanForm = $.mutable_source({ amount: '', day: '', startMonth: '' });
	let stockPlanSaving = $.mutable_source(false);
	let stockPlanConfirmationTarget = $.mutable_source(null);
	let stockPlanConfirmation = $.mutable_source({ amount: '', price: '' });
	let stockDetail = $.mutable_source(null);
	let stockDetailStatus = $.mutable_source('idle');
	let highlightedStockId = $.mutable_source(null);
	let stockForm = $.mutable_source({ quantity: '', totalInvested: '' });
	let actions = $.mutable_source([]);
	let actionsStatus = 'idle';
	let actionsError = '';
	let completingActionId = $.mutable_source(null);
	let highlightedLoanId = $.mutable_source(null);
	let highlightedFundId = null;
	let confirmingSip = $.mutable_source(null);
	let sipConfirmError = $.mutable_source('');
	let sipConfirmSaving = $.mutable_source(false);

	let sipConfirmForm = $.mutable_source({
		amount: '',
		transactionDate: new Date().toISOString().slice(0, 10),
		nav: ''
	});

	let fundDetail = $.mutable_source(null);
	let fundDetailStatus = $.mutable_source('idle');
	let fundDetailError = $.mutable_source('');
	let lumpSumFund = $.mutable_source(null);
	let lumpSumSaving = $.mutable_source(false);
	let lumpSumError = $.mutable_source('');
	let lumpSumForm = $.mutable_source({ amount: '', transactionDate: '', nav: '' });
	let editingFundTransaction = $.mutable_source(null);
	let fundTransactionSaving = $.mutable_source(false);
	let fundTransactionError = $.mutable_source('');
	let fundTransactionForm = $.mutable_source({ amount: '', transactionDate: '', nav: '' });
	const MONEY_MODULES_CACHE_KEY = 'money-stories.money-modules-cache.v1';

	let fundForm = $.mutable_source({
		hasSip: 'YES',
		sipAmount: '25000',
		sipDate: '5',
		startMonth: '2026-10',
		hasHolding: 'YES',
		currentUnits: '128.456',
		totalInvested: '10000'
	});

	let fundSipTarget = $.mutable_source(null);
	let fundSipForm = $.mutable_source({ amount: '', day: '', startMonth: '' });
	let fundSipSaving = $.mutable_source(false);

	const money = (value) => new Intl.NumberFormat('en-IN', {
		style: 'currency',
		currency: $.get(currency),
		maximumFractionDigits: 0
	}).format(Number(value || 0));

	const moneyDecimal = (value) => new Intl.NumberFormat('en-IN', {
		style: 'currency',
		currency: $.get(currency),
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(Number(value || 0));

	const compactMoney = (value) => new Intl.NumberFormat('en-IN', {
		style: 'currency',
		currency: $.get(currency),
		notation: 'compact',
		maximumFractionDigits: 2
	}).format(Number(value || 0));

	const fundSubtitle = (name) => (/growth/i).test(name) ? 'Growth · Direct plan' : 'Verified scheme';
	const fundAccent = (id) => ['coral', 'gold', 'violet', 'blue'][Number(id || 0) % 4];
	const merchant = (item) => item.merchant || item.merchantName || item.description || item.originalMessage || 'Expense';
	const category = (item) => item.category?.name || item.category || 'Uncategorised';
	const transactionDate = (item) => item.transactionDate || item.transactionTime || item.date;

	const dateLabel = (value) => value
		? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short' }).format(new Date(value))
		: '';

	const monthLabel = (value) => {
		const [y, m] = value.split('-').map(Number);

		return new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(new Date(y, m - 1));
	};

	const greeting = () => new Date().getHours() < 12
		? 'Good morning'
		: new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';

	const isoDate = (day) => `${selectedMonth()}-${String(day).padStart(2, '0')}`;
	const hasDeck = (story) => Array.isArray(story.cards) && story.cards.length > 0;
	const storyName = (story) => String(story.storyType || story.type || 'Money story').replaceAll('_', ' ');
	const storyTone = (story) => story.cardFace?.theme || 'calm';
	const storyCardFace = (story) => story.cardFace || { heading: 'Money story', displayValue: 'View', theme: 'calm' };
	const storySource = (story) => story.source || story.domain || ($.strict_equals(story.storyType, 'MONTHLY_COMMITMENT') ? 'Planning' : 'Spending');
	const isCommitment = (story) => $.strict_equals(story?.storyType, 'MONTHLY_COMMITMENT');
	const storyIcon = (story) => isCommitment(story) ? '🎬' : '';
	const storyHeading = (story) => storyCardFace(story).heading;

	function setCommitmentStyle(style) {
		$.set(commitmentStyle, style);

		try {
			localStorage.setItem('money-stories.commitment-style', style);
		} catch {}
	}

	function localInputDate(value) {
		if (!value) return '';

		const text = String(value);

		if ((/^\d{4}-\d{2}-\d{2}$/).test(text)) return text;

		const date = new Date(text);

		return Number.isNaN(date.getTime())
			? text.slice(0, 10)
			: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
	}

	function evidenceFor(story, slide = 0) {
		const card = story?.cards?.slice().sort((a, b) => (a.sequence || 0) - (b.sequence || 0))[slide];
		const evidence = story?.evidence?.byCard?.[card?.cardId] || story?.evidence;

		const raw = Array.isArray(evidence)
			? evidence
			: evidence?.transactions || evidence?.items || story?.transactions || [];

		return raw.map((item) => {
			const [idType, id] = String(item.transactionId || item.id || '').split(':');

			return {
				sourceType: idType,
				sourceId: id,
				merchant: item.merchantLabel || item.merchant || item.merchantName || item.description || 'Expense',
				category: item.categoryLabel || item.category?.name || item.category || 'Uncategorised',
				detail: item.subcategoryLabel || item.detail || '',
				date: item.dateLabel || dateLabel(item.transactionDate || item.transactionTime || item.date),
				amount: item.amount?.displayValue || item.displayAmount || money(item.amount)
			};
		});
	}

	function loanSchedule(loan) {
		const first = new Date(`${loan.firstEmiDueDate}T12:00:00`);

		if (Number.isNaN(first.getTime())) return null;

		const tenure = Number(loan.totalTenureMonths) || 0,
			due = Number.isInteger(loan.completedEmiCount) ? loan.completedEmiCount : 0,
			remaining = Number.isInteger(loan.remainingEmiCount) ? loan.remainingEmiCount : Math.max(0, tenure - due),
			finalDue = new Date(first.getFullYear(), first.getMonth() + Math.max(0, tenure - 1), first.getDate());

		return {
			due,
			remaining,
			tenure,
			percent: tenure ? Math.round(due / tenure * 100) : 0,
			endLabel: new Intl.DateTimeFormat(undefined, { month: 'short', year: 'numeric' }).format(finalDue)
		};
	}

	function actionPresentation(action) {
		if ($.strict_equals(action.actionType, 'LOAN_CLOSURE_CONFIRMATION')) {
			const scheduled = action.scheduledCompletionDate
				? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${action.scheduledCompletionDate}T12:00:00`))
				: '';

			const description = (action.description || `EMI was scheduled to finish on ${scheduled}.`).replace(action.scheduledCompletionDate || '', scheduled).replace(/\s*Mark it closed if the final EMI was paid\.?\s*$/i, '');

			return {
				title: 'Loan closure confirmation',
				description,
				cta: 'Review loan'
			};
		}

		return null;
	}

	const moneyModulesCacheKey = () => `${MONEY_MODULES_CACHE_KEY}.${demoMode() ? 'demo' : 'real'}`;

	function readMoneyModulesCache() {
		try {
			const cached = JSON.parse(localStorage.getItem(moneyModulesCacheKey()) || 'null');

			if (!cached) return false;

			if (Array.isArray(cached.loans)) {
				$.set(loans, cached.loans);
				$.set(loanStatus, 'ready');
			}

			if (Array.isArray(cached.mutualFunds)) {
				$.set(mutualFunds, cached.mutualFunds);
				$.set(mutualFundStatus, 'ready');
			}

			if (Array.isArray(cached.stocks)) {
				$.set(stocks, cached.stocks);
				$.set(stockStatus, 'ready');
			}

			return true;
		} catch {
			return false;
		}
	}

	function saveMoneyModulesCache() {
		try {
			localStorage.setItem(moneyModulesCacheKey(), JSON.stringify({
				updatedAt: new Date().toISOString(),
				loans: $.get(loans /* The live modules still work if storage is unavailable. */),
				mutualFunds: $.get(mutualFunds),
				stocks: $.get(stocks)
			}));
		} catch {
			/* The live modules still work if storage is unavailable. */
		}
	}

	async function loadLoans() {
		$.set(loanStatus, $.get(loans).length ? 'refreshing' : 'loading');

		try {
			const result = (await $.track_reactivity_loss(getLoans()))();

			$.set(loans, result.loans || []);
			$.set(loanStatus, 'ready');
			saveMoneyModulesCache();
		} catch(cause) {
			if ($.get(loans).length) {
				$.set(loanStatus, 'ready');

				return;
			}

			$.set(loanStatus, 'error');
			$.set(loanError, cause?.message || 'Could not load loans.');
		}
	}

	async function loadCommitments() {
		$.set(commitmentStatus, 'loading');
		$.set(commitmentError, '');

		try {
			const result = (await $.track_reactivity_loss(getRecurringCommitments()))();

			$.set(commitments, result.items || []);
			$.set(commitmentStatus, 'ready');
		} catch(cause) {
			$.set(commitmentStatus, 'error');
			$.set(commitmentError, cause?.message || 'Could not load commitments.');
		}
	}

	const recurrenceLabel = (item) => {
		const n = Number(item.recurrenceInterval || 1),
			unit = String(item.recurrenceUnit || 'MONTH').toLowerCase();

		const text = `${$.strict_equals(n, 1) ? '' : `${n} `}${unit}${$.strict_equals(n, 1) ? '' : 's'}`;

		return item.flexibleSchedule ? `Usually every ${text}` : `Every ${text}`;
	};

	const expectedLabel = (date) => date
		? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${date}T12:00:00`))
		: '';

	function openCommitmentForm(item = null) {
		const editingExisting = Boolean(item && 'planningAmount' in item);

		$.set(commitmentError, '');
		$.set(commitmentEditingId, editingExisting ? item.id : null);

		$.set(commitmentForm, item
			? {
				label: editingExisting ? item.label : merchant(item),
				planningAmount: String(editingExisting ? item.planningAmount : item.amount || ''),

				dueDay: String(editingExisting
					? item.dueDay ?? ''
					: new Date(transactionDate(item)).getDate() || ''),

				amountMode: editingExisting ? item.amountMode || 'FIXED' : 'FIXED',
				recurrenceUnit: editingExisting ? item.recurrenceUnit || 'MONTH' : 'MONTH',
				recurrenceInterval: String(editingExisting ? item.recurrenceInterval || 1 : 1),
				flexibleSchedule: editingExisting ? Boolean(item.flexibleSchedule) : false,
				nextExpectedDate: editingExisting ? item.nextExpectedDate || '' : selectedMonth() + '-01',
				...editingExisting ? {} : { sourceTransactionId: item.id }
			}
			: {
				label: '',
				planningAmount: '',
				dueDay: '',
				amountMode: 'FIXED',
				recurrenceUnit: 'MONTH',
				recurrenceInterval: '1',
				flexibleSchedule: false,
				nextExpectedDate: selectedMonth() + '-01'
			});

		$.set(showCommitmentForm, true);
	}

	async function saveCommitment() {
		const planningAmount = Number($.get(commitmentForm).planningAmount),
			dueDay = $.get(commitmentForm).dueDay ? Number($.get(commitmentForm).dueDay) : null,
			recurrenceInterval = Number($.get(commitmentForm).recurrenceInterval);

		if (!$.get(commitmentForm).label.trim() || !(planningAmount > 0) || !(recurrenceInterval > 0) || !$.get(commitmentForm).nextExpectedDate || $.strict_equals(dueDay, null, false) && (dueDay < 1 || dueDay > 28)) {
			$.set(commitmentError, 'Add a name, positive planning amount, frequency, and next expected date.');

			return;
		}

		$.set(commitmentSaving, true);

		try {
			const payload = {
				...$.get(commitmentForm),
				label: $.get(commitmentForm).label.trim(),
				planningAmount,
				dueDay,
				recurrenceInterval,
				effectiveMonth: selectedMonth()
			};

			if ($.strict_equals($.get(commitmentEditingId), null, false)) delete payload.sourceTransactionId;

			(await $.track_reactivity_loss($.strict_equals($.get(commitmentEditingId), null)
				? createRecurringCommitment(payload)
				: updateRecurringCommitment($.get(commitmentEditingId), payload)))();

			$.set(showCommitmentForm, false);
			(await $.track_reactivity_loss(Promise.all([loadCommitments(), refreshStories()()])))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not save this commitment.');
		} finally {
			$.set(commitmentSaving, false);
		}
	}

	function openCompletion(commitment) {
		$.set(completionCommitment, commitment);

		const today = new Date().toISOString().slice(0, 10);

		$.set(completionForm, {
			actualAmount: String(commitment.planningAmount),
			completedAt: today,
			nextExpectedDate: commitment.nextExpectedDate || today
		});
	}

	function addMonths(months) {
		const date = new Date(`${$.get(completionForm).completedAt}T12:00:00`);

		date.setMonth(date.getMonth() + months);
		$.mutate(completionForm, $.get(completionForm).nextExpectedDate = date.toISOString().slice(0, 10));
	}

	async function saveCompletion() {
		if (!$.get(completionCommitment)) return;

		try {
			(await $.track_reactivity_loss(recordRecurringCommitmentCompletion($.get(completionCommitment).id, {
				actualAmount: Number($.get(completionForm).actualAmount),
				completedAt: $.get(completionForm).completedAt,
				nextExpectedDate: $.get(completionForm).nextExpectedDate
			})))();

			$.set(completionCommitment, null);
			(await $.track_reactivity_loss(Promise.all([loadCommitments(), refreshStories()()])))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not save completion.');
		}
	}

	async function removeCommitment(commitment) {
		if ($.strict_equals($.get(commitmentDeletingId), null, false)) return;

		$.set(commitmentDeletingId, commitment.id);
		$.set(commitmentError, '');

		try {
			(await $.track_reactivity_loss(deleteRecurringCommitment(commitment.id)))();
			$.set(commitments, $.get(commitments).filter((item) => $.strict_equals(item.id, commitment.id, false)));
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not delete this commitment.');
		} finally {
			$.set(commitmentDeletingId, null);
		}
	}

	async function loadMutualFunds() {
		$.set(mutualFundStatus, $.get(mutualFunds).length ? 'refreshing' : 'loading');
		$.set(mutualFundError, '');

		try {
			const result = (await $.track_reactivity_loss(getMutualFunds()))();

			$.set(mutualFunds, result.mutualFunds || []);
			$.set(mutualFundStatus, 'ready');
			saveMoneyModulesCache();
		} catch(cause) {
			if ($.get(mutualFunds).length) {
				$.set(mutualFundStatus, 'ready');

				return;
			}

			$.set(mutualFundStatus, 'error');
			$.set(mutualFundError, cause?.message || 'Could not load mutual funds.');
		}
	}

	async function loadStocks() {
		$.set(stockStatus, $.get(stocks).length ? 'refreshing' : 'loading');
		$.set(stockError, '');

		try {
			const result = (await $.track_reactivity_loss(getStocks()))();

			$.set(stocks, result.stocks || []);
			$.set(stockStatus, 'ready');
			saveMoneyModulesCache();
		} catch(cause) {
			if ($.get(stocks).length) {
				$.set(stockStatus, 'ready');

				return;
			}

			$.set(stockStatus, 'error');
			$.set(stockError, cause?.message || 'Could not load stocks.');
		}
	}

	async function loadActions() {
		actionsStatus = $.get(actions).length ? 'refreshing' : 'loading';
		actionsError = '';

		try {
			const result = (await $.track_reactivity_loss(getActions()))();

			$.set(actions, result.actions || []);
			actionsStatus = 'ready';
		} catch(cause) {
			actionsStatus = 'error';
			actionsError = cause?.message || 'Could not load actions.';
		}
	}

	async function completeOpenAction(action) {
		if ($.strict_equals($.get(completingActionId), null, false)) return;

		$.set(completingActionId, action.id);
		actionsError = '';

		try {
			(await $.track_reactivity_loss(completeAction(action.id)))();
			$.set(actions, $.get(actions).filter((item) => $.strict_equals(item.id, action.id, false)));
			(await $.track_reactivity_loss(Promise.all([loadLoans(), loadActions()])))();
		} catch(cause) {
			actionsError = cause?.message || 'Could not complete this action.';
		} finally {
			$.set(completingActionId, null);
		}
	}

	function moneyReviewTarget(type, id) {
		if ($.strict_equals(type, 'loan')) {
			const loan = $.get(loans).find((item) => $.strict_equals(String(item.id), String(id)));

			return loan && [
				...document.querySelectorAll('[data-testid="loans-section"] .loan-row')
			].find((row) => row.querySelector('.loan-name')?.textContent.trim().startsWith(loan.loanName));
		}

		if ($.strict_equals(type, 'commitment')) return document.querySelector(`[data-testid="commitment-${id}"]`);
		if ($.strict_equals(type, 'stock')) return document.querySelector(`[data-testid="stock-card-${id}"]`);

		const fund = fundSummary(id);

		return fund && [
			...document.querySelectorAll('.mutual-funds-module:not(.stocks-module) .fund-card')
		].find((card) => $.strict_equals(card.getAttribute('aria-label'), `Open ${fund.schemeName} details`));
	}

	async function focusMoneyTarget(type, id) {
		(await $.track_reactivity_loss(tick()))();
		(await $.track_reactivity_loss(new Promise((resolve) => requestAnimationFrame(resolve))))();

		const target = moneyReviewTarget(type, id);

		if (!target) return;

		target.tabIndex = -1;
		target.scrollIntoView({ behavior: 'smooth', block: 'center' });
		target.focus({ preventScroll: true });
	}

	async function openLoanDueAction(action) {
		$.set(highlightedLoanId, action.referenceId);
		$.set(showMoney, true);
		(await $.track_reactivity_loss(Promise.all([loadLoans(), loadActions()])))();
		(await $.track_reactivity_loss(focusMoneyTarget('loan', action.referenceId)))();
	}

	async function openCommitmentSources() {
		$.set(showStoryEvidence, true);
		(await $.track_reactivity_loss(Promise.all([loadMutualFunds(), loadCommitments()])))();
	}

	async function openIncludedLoan(event) {
		const loanItems = $.get(evidenceItems).filter((item) => (/loan/i).test(item.category));

		const buttons = [
			...document.querySelectorAll('[data-testid="included-loan-commitment"]')
		];

		const item = loanItems[buttons.indexOf(event.currentTarget)];

		if (!item) return;

		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('loan', item.sourceId)))();
	}

	async function openIncludedMutualFund(item) {
		highlightedFundId = item.sourceId;
		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('fund', item.sourceId)))();
	}

	async function openIncludedStock(item) {
		$.set(highlightedStockId, item.sourceId);
		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('stock', item.sourceId)))();
	}

	async function openIncludedCommitment(item) {
		$.set(showStoryEvidence, false);
		$.set(openedStory, null);
		(await $.track_reactivity_loss(openMoney()))();
		(await $.track_reactivity_loss(focusMoneyTarget('commitment', item.sourceId)))();
	}

	const recurringOccurrence = (item) => {
		const id = $.strict_equals(typeof item, 'object') ? item.sourceId : item;
		const match = $.get(commitments).find((value) => $.strict_equals(String(value.id), String(id))) || $.get(commitments).find((value) => $.strict_equals(value.label, item?.merchant));

		return (match || $.strict_equals($.get(commitments).length, 1) && $.get(commitments)[0])?.currentOccurrence;
	};

	async function markCommitmentDone(commitment) {
		if ($.strict_equals(completingCommitmentId, null, false)) return;

		const occurrence = commitment.currentOccurrence;

		if (!occurrence?.month) return;

		completingCommitmentId = commitment.id;
		$.set(commitmentError, '');

		try {
			(await $.track_reactivity_loss(completeRecurringCommitment(commitment.id, occurrence.month)))();
			(await $.track_reactivity_loss(Promise.all([loadCommitments(), refreshStories()()])))();
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not mark this commitment done.');
		} finally {
			completingCommitmentId = null;
		}
	}

	function sipIsDue(item) {
		return $.strict_equals($.get(mutualFunds).find((fund) => $.strict_equals(String(fund.id), String(item.sourceId)))?.currentSip?.status, 'DUE');
	}

	function sipIsConfirmed(item) {
		return $.strict_equals($.get(mutualFunds).find((fund) => $.strict_equals(String(fund.id), String(item.sourceId)))?.currentSip?.status, 'CONFIRMED');
	}

	function currentCommitmentIsDue() {
		const card = $.get(openedStory)?.cards?.slice().sort((a, b) => (a.sequence || 0) - (b.sequence || 0))[$.get(storySlide)];

		return card?.components?.some((component) => $.strict_equals(component.label, 'This month') && component.displayValue?.startsWith('Due'));
	}

	const incomeRangeLabel = (value) => ({
		UNDER_25000: 'Under ₹25k',
		FROM_25000_TO_50000: '₹25k–₹50k',
		FROM_50000_TO_100000: '₹50k–₹1L',
		FROM_100000_TO_200000: '₹1L–₹2L',
		OVER_200000: 'Over ₹2L'
	})[value] || 'Not shared';

	async function loadIncomeOutlook() {
		$.set(incomeStatus, 'loading');
		$.set(incomeError, '');

		try {
			$.set(incomeOutlook, (await $.track_reactivity_loss(getIncomeOutlook()))());
			$.set(incomeStatus, 'ready');
		} catch(cause) {
			$.set(incomeStatus, 'error');
			$.set(incomeError, cause?.message || 'Could not load your income outlook.');
		}
	}

	async function openMoney() {
		$.set(showMoney, true);
		readMoneyModulesCache();

		(await $.track_reactivity_loss(Promise.all([
			loadLoans(),
			loadMutualFunds(),
			loadStocks(),
			loadIncomeOutlook(),
			loadCommitments(),
			loadCreditCards(),
			loadExpenseOptions()
		])))();
	}

	function closeMoney() {
		$.set(showMoney, false);
		$.set(highlightedLoanId, null);
		highlightedFundId = null;
	}

	const fundSummary = (id) => $.get(mutualFunds).find((fund) => $.strict_equals(String(fund.id), String(id)));

	async function loadCreditCards() {
		$.set(creditCardStatus, 'loading');
		$.set(creditCardError, '');

		try {
			const result = (await $.track_reactivity_loss(getCreditCards()))();

			$.set(creditCards, result.cards || []);
			$.set(creditCardStatus, 'ready');
		} catch(cause) {
			$.set(creditCardStatus, 'error');
			$.set(creditCardError, cause?.message || 'Could not load credit cards.');
		}
	}

	async function loadExpenseOptions() {
		if ($.strict_equals($.get(optionsStatus), 'loading')) return;

		try {
			const result = (await $.track_reactivity_loss(getExpenseOptions()))();

			$.set(editOptions, {
				categories: result.categories || [],
				merchants: result.merchants || [],
				accounts: result.accounts || []
			});

			$.set(optionsStatus, 'ready');
		} catch(cause) {
			$.set(optionsStatus, 'error');
			$.set(optionsError, cause?.message || 'Could not load accounts.');
		}
	}

	function openCreditCardForm(card = null) {
		$.set(creditCardError, '');
		$.set(creditCardEditingId, card?.id ?? null);

		$.set(creditCardForm, card
			? {
				accountReferenceId: String(card.accountReferenceId),
				cardName: card.cardName,
				issuerName: card.issuerName,
				statementDay: String(card.statementDay),
				dueDay: String(card.dueDay)
			}
			: {
				accountReferenceId: '',
				cardName: '',
				issuerName: '',
				statementDay: '',
				dueDay: ''
			});

		$.set(showCreditCardForm, true);
	}

	async function saveCreditCard() {
		const statementDay = Number($.get(creditCardForm).statementDay),
			dueDay = Number($.get(creditCardForm).dueDay);

		if (!$.get(creditCardForm).accountReferenceId || !$.get(creditCardForm).cardName.trim() || !$.get(creditCardForm).issuerName.trim() || statementDay < 1 || statementDay > 28 || dueDay < 1 || dueDay > 28) {
			$.set(creditCardError, 'Choose the captured card account and enter days from 1 to 28.');

			return;
		}

		$.set(creditCardSaving, true);
		$.set(creditCardError, '');

		const payload = {
			accountReferenceId: Number($.get(creditCardForm).accountReferenceId),
			cardName: $.get(creditCardForm).cardName.trim(),
			issuerName: $.get(creditCardForm).issuerName.trim(),
			statementDay,
			dueDay
		};

		try {
			const saved = $.strict_equals($.get(creditCardEditingId), null)
				? (await $.track_reactivity_loss(createCreditCard(payload)))()
				: (await $.track_reactivity_loss(updateCreditCard($.get(creditCardEditingId), payload)))();

			$.set(creditCards, $.strict_equals($.get(creditCardEditingId), null)
				? [saved, ...$.get(creditCards)]
				: $.get(creditCards).map((card) => $.strict_equals(card.id, saved.id) ? saved : card));

			$.set(creditCardStatus, 'ready');
			$.set(showCreditCardForm, false);
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(creditCardError, cause?.message || 'Could not save this credit card.');
		} finally {
			$.set(creditCardSaving, false);
		}
	}

	function openIncomeFlow() {
		$.set(incomeError, '');

		$.set(salaryForm, {
			salaryVisibility: 'RANGE',
			salaryRange: 'FROM_50000_TO_100000',
			exactMonthlySalary: '',
			salaryFrequency: 'MONTHLY'
		});

		$.set(showIncomeFlow, true);
	}

	async function saveSalary() {
		$.set(incomeSaving, true);
		$.set(incomeError, '');

		try {
			(await $.track_reactivity_loss(saveIncomeProfile({
				...$.get(salaryForm),
				exactMonthlySalary: $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT') ? Number($.get(salaryForm).exactMonthlySalary) : null
			})))();

			(await $.track_reactivity_loss(loadIncomeOutlook()))();
			$.set(showIncomeFlow, false);
		} catch(cause) {
			$.set(incomeError, cause?.message || 'Could not save this preference.');
		} finally {
			$.set(incomeSaving, false);
		}
	}

	function openLoanForm(loan = null) {
		$.set(loanError, '');
		$.set(loanEditingId, loan?.id ?? null);

		$.set(loanForm, loan
			? {
				loanName: loan.loanName || '',
				loanType: loan.loanType || 'HOME',
				lenderName: loan.lenderName || '',
				originalPrincipal: String(loan.originalPrincipal ?? ''),
				monthlyEmiAmount: String(loan.monthlyEmiAmount ?? ''),
				totalTenureMonths: String(loan.totalTenureMonths ?? ''),
				firstEmiDueDate: localInputDate(loan.firstEmiDueDate),
				notes: loan.notes || ''
			}
			: {
				loanName: '',
				loanType: 'HOME',
				lenderName: '',
				originalPrincipal: '',
				monthlyEmiAmount: '',
				totalTenureMonths: '',
				firstEmiDueDate: '',
				notes: ''
			});

		$.set(showLoanForm, true);
	}

	async function saveLoan() {
		const originalPrincipal = Number($.get(loanForm).originalPrincipal),
			monthlyEmiAmount = Number($.get(loanForm).monthlyEmiAmount),
			totalTenureMonths = Number($.get(loanForm).totalTenureMonths);

		if (!$.get(loanForm).loanName.trim() || !$.get(loanForm).lenderName.trim() || !$.get(loanForm).firstEmiDueDate || originalPrincipal <= 0 || monthlyEmiAmount <= 0 || !Number.isInteger(totalTenureMonths) || totalTenureMonths <= 0) {
			$.set(loanError, 'Complete every required loan detail with valid positive amounts.');

			return;
		}

		const payload = {
			loanName: $.get(loanForm).loanName.trim(),
			loanType: $.get(loanForm).loanType,
			lenderName: $.get(loanForm).lenderName.trim(),
			originalPrincipal,
			monthlyEmiAmount,
			totalTenureMonths,
			firstEmiDueDate: $.get(loanForm).firstEmiDueDate,
			notes: $.get(loanForm).notes
		};

		$.set(loanSaving, true);
		$.set(loanError, '');

		try {
			const saved = $.equals($.get(loanEditingId), null)
				? (await $.track_reactivity_loss(createLoan(payload)))()
				: (await $.track_reactivity_loss(updateLoan($.get(loanEditingId), payload)))();

			$.set(loans, $.equals($.get(loanEditingId), null)
				? [...$.get(loans), saved]
				: $.get(loans).map((loan) => $.strict_equals(loan.id, saved.id) ? saved : loan));

			$.set(showLoanForm, false);
			$.set(loanStatus, 'ready');
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(loanError, cause?.message || 'Could not save this loan.');
		} finally {
			$.set(loanSaving, false);
		}
	}

	async function removeLoan(loan) {
		if ($.strict_equals($.get(loanDeletingId), null, false)) return;

		$.set(loanDeletingId, loan.id);
		$.set(loanError, '');

		try {
			(await $.track_reactivity_loss(deleteLoan(loan.id)))();
			$.set(loans, $.get(loans).filter((item) => $.strict_equals(item.id, loan.id, false)));
			saveMoneyModulesCache();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(loanError, cause?.message || 'Could not delete this loan.');
		} finally {
			$.set(loanDeletingId, null);
		}
	}

	async function payLoanEmi(loan, occurrence) {
		try {
			(await $.track_reactivity_loss(markLoanEmiPaid(loan.id, occurrence.month)))();
			(await $.track_reactivity_loss(Promise.all([loadLoans(), refreshStories()()])))();
		} catch(cause) {
			$.set(loanError, cause?.message || 'Could not mark this EMI paid.');
		}
	}

	async function openLoanHistory(loan) {
		$.set(loanHistory, { loanName: loan.loanName });
		$.set(loanHistoryStatus, 'loading');
		$.set(loanHistoryError, '');

		try {
			$.set(loanHistory, (await $.track_reactivity_loss(getLoanHistory(loan.id)))());
			$.set(loanHistoryStatus, 'ready');
		} catch(cause) {
			$.set(loanHistoryStatus, 'error');
			$.set(loanHistoryError, cause?.message || 'Could not load payment history.');
		}
	}

	async function payLoanHistoryEmi(occurrence) {
		if (!$.get(loanHistory)) return;

		try {
			(await $.track_reactivity_loss(markLoanEmiPaid($.get(loanHistory).id, occurrence.month)))();

			(await $.track_reactivity_loss(Promise.all([
				loadLoans(),
				openLoanHistory($.get(loanHistory)),
				refreshStories()()
			])))();
		} catch(cause) {
			$.set(loanHistoryError, cause?.message || 'Could not mark this EMI paid.');
		}
	}

	async function openCommitmentHistory(commitment) {
		$.set(commitmentHistory, { label: commitment.label });
		$.set(commitmentHistoryStatus, 'loading');
		$.set(commitmentHistoryError, '');

		try {
			$.set(commitmentHistory, (await $.track_reactivity_loss(getRecurringCommitmentHistory(commitment.id)))());
			$.set(commitmentHistoryStatus, 'ready');
		} catch(cause) {
			$.set(commitmentHistoryStatus, 'error');
			$.set(commitmentHistoryError, cause?.message || 'Could not load payment history.');
		}
	}

	function openMutualFundForm() {
		$.set(fundError, '');
		$.set(fundSaved, false);
		$.set(schemeQuery, '');
		$.set(selectedScheme, null);
		$.set(showSchemeMenu, false);

		$.set(fundForm, {
			hasSip: 'YES',
			sipAmount: '25000',
			sipDate: '5',
			startMonth: '2026-10',
			hasHolding: 'YES',
			currentUnits: '128.456',
			totalInvested: '10000'
		});

		$.set(showMutualFundForm, true);
	}

	async function searchSchemes(value) {
		$.set(schemeQuery, value);
		$.set(selectedScheme, null);
		$.set(showSchemeMenu, true);
		$.set(fundError, '');

		if (value.trim().length < 2) {
			$.set(schemeResults, []);
			$.set(schemeSearchStatus, 'idle');

			return;
		}

		const requestId = ++schemeSearchRequest;

		$.set(schemeSearchStatus, 'loading');

		try {
			const result = (await $.track_reactivity_loss(searchMutualFunds(value.trim())))();

			if ($.strict_equals(requestId, schemeSearchRequest, false)) return;

			$.set(schemeResults, Array.isArray(result) ? result : result.schemes || []);
			$.set(schemeSearchStatus, 'ready');
		} catch(cause) {
			if ($.strict_equals(requestId, schemeSearchRequest, false)) return;

			$.set(schemeResults, []);
			$.set(schemeSearchStatus, 'error');
			$.set(fundError, cause?.message || 'Could not search the scheme master.');
		}
	}

	function selectScheme(scheme) {
		$.set(selectedScheme, scheme);
		$.set(schemeQuery, scheme.schemeName);
		$.set(showSchemeMenu, false);
		$.set(fundError, '');
	}

	async function saveMutualFund() {
		const sipAmount = Number($.get(fundForm).sipAmount),
			units = Number($.get(fundForm).currentUnits),
			invested = Number($.get(fundForm).totalInvested);

		if (!$.get(selectedScheme)) {
			$.set(fundError, 'Choose a scheme from the verified scheme master.');

			return;
		}

		if ($.strict_equals($.get(fundForm).hasSip, 'YES') && (sipAmount <= 0 || !$.get(fundForm).sipDate || !$.get(fundForm).startMonth)) {
			$.set(fundError, 'Add a valid monthly amount, SIP date, and start month.');

			return;
		}

		if ($.strict_equals($.get(fundForm).hasHolding, 'YES') && (!(units > 0) || !(invested > 0))) {
			$.set(fundError, 'Enter current units and invested amount greater than zero.');

			return;
		}

		const payload = {
			schemeCode: $.get(selectedScheme).schemeCode,
			schemeName: $.get(selectedScheme).schemeName,

			...$.strict_equals($.get(fundForm).hasSip, 'YES')
				? {
					monthlySipAmount: sipAmount,
					sipDay: Number($.get(fundForm).sipDate),
					startMonth: $.get(fundForm).startMonth
				}
				: {},

			...$.get(selectedScheme).isin ? { isin: $.get(selectedScheme).isin } : {},

			...$.strict_equals($.get(fundForm).hasHolding, 'YES')
				? {
					existingHolding: { currentUnits: units, totalInvestedAmount: invested }
				}
				: {}
		};

		$.set(fundSaving, true);
		$.set(fundError, '');

		try {
			(await $.track_reactivity_loss(createMutualFund(payload)))();
			$.set(fundSaved, true);
			(await $.track_reactivity_loss(loadMutualFunds()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(fundError, cause?.message || 'Could not create this mutual fund.');
		} finally {
			$.set(fundSaving, false);
		}
	}

	async function removeMutualFund(fund) {
		if ($.strict_equals($.get(mutualFundDeletingId), null, false)) return;

		$.set(mutualFundDeletingId, fund.id);
		$.set(mutualFundError, '');

		try {
			(await $.track_reactivity_loss(deleteMutualFund(fund.id)))();
			$.set(mutualFunds, $.get(mutualFunds).filter((item) => $.strict_equals(item.id, fund.id, false)));
			saveMoneyModulesCache();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(mutualFundError, cause?.message || 'Could not delete this mutual fund.');
		} finally {
			$.set(mutualFundDeletingId, null);
		}
	}

	function openFundSipPlan(fund) {
		$.set(fundSipTarget, fund);

		$.set(fundSipForm, {
			amount: '',
			day: '',
			startMonth: new Date().toISOString().slice(0, 7)
		});

		$.set(fundError, '');
	}

	async function saveFundSipPlan() {
		const amount = Number($.get(fundSipForm).amount),
			day = Number($.get(fundSipForm).day);

		if (!(amount > 0) || !(day >= 1 && day <= 28) || !$.get(fundSipForm).startMonth) {
			$.set(fundError, 'Enter a positive monthly amount, a day from 1 to 28, and a start month.');

			return;
		}

		$.set(fundSipSaving, true);

		try {
			(await $.track_reactivity_loss(createMutualFundSip($.get(fundSipTarget).id, { amount, day, startMonth: $.get(fundSipForm).startMonth })))();
			$.set(fundSipTarget, null);
			(await $.track_reactivity_loss(loadMutualFunds()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(fundError, cause?.message || 'Could not save this SIP.');
		} finally {
			$.set(fundSipSaving, false);
		}
	}

	function openStockForm() {
		$.set(stockError, '');
		$.set(stockQuery, '');
		$.set(selectedStock, null);
		$.set(stockResults, []);
		$.set(stockForm, { quantity: '', totalInvested: '' });
		$.set(showStockForm, true);
	}

	async function findStocks(value) {
		$.set(stockQuery, value);
		$.set(selectedStock, null);
		$.set(stockError, '');

		if (value.trim().length < 2) {
			$.set(stockResults, []);
			$.set(stockSearchStatus, 'idle');

			return;
		}

		const requestId = ++stockSearchRequest;

		$.set(stockSearchStatus, 'loading');

		try {
			const result = (await $.track_reactivity_loss(searchStocks(value.trim())))();

			if ($.strict_equals(requestId, stockSearchRequest, false)) return;

			$.set(stockResults, Array.isArray(result) ? result : []);
			$.set(stockSearchStatus, 'ready');
		} catch(cause) {
			if ($.strict_equals(requestId, stockSearchRequest, false)) return;

			$.set(stockResults, []);
			$.set(stockSearchStatus, 'error');
			$.set(stockError, cause?.message || 'Could not search stock symbols.');
		}
	}

	function selectStock(stock) {
		$.set(selectedStock, stock);
		$.set(stockQuery, `${stock.name} (${stock.symbol})`);
		$.set(stockResults, []);
		$.set(stockError, '');
	}

	async function saveStock() {
		const quantity = Number($.get(stockForm).quantity),
			totalInvestedAmount = Number($.get(stockForm).totalInvested);

		if (!$.get(selectedStock)) {
			$.set(stockError, 'Choose a stock from the search results.');

			return;
		}

		if (!(quantity > 0) || !(totalInvestedAmount > 0)) {
			$.set(stockError, 'Enter valid positive quantity and total invested amount.');

			return;
		}

		$.set(stockSaving, true);
		$.set(stockError, '');

		try {
			(await $.track_reactivity_loss(createStock({
				symbol: $.get(selectedStock).symbol,
				name: $.get(selectedStock).name,
				exchange: $.get(selectedStock).exchange,
				quantity,
				totalInvestedAmount
			})))();

			$.set(showStockForm, false);
			(await $.track_reactivity_loss(loadStocks()))();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not add this stock.');
		} finally {
			$.set(stockSaving, false);
		}
	}

	async function removeStock(stock) {
		if ($.strict_equals($.get(stockDeletingId), null, false)) return;

		$.set(stockDeletingId, stock.id);
		$.set(stockError, '');

		try {
			(await $.track_reactivity_loss(deleteStock(stock.id)))();
			$.set(stocks, $.get(stocks).filter((item) => $.strict_equals(item.id, stock.id, false)));
			saveMoneyModulesCache();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not delete this stock.');
		} finally {
			$.set(stockDeletingId, null);
		}
	}

	function openStockPlan(stock) {
		$.set(stockPlanTarget, stock);

		$.set(stockPlanForm, {
			amount: stock.activeMonthlyPlan?.amount || '',
			day: stock.activeMonthlyPlan?.day || '',
			startMonth: stock.activeMonthlyPlan?.startMonth || new Date().toISOString().slice(0, 7)
		});

		$.set(stockError, '');
	}

	async function saveStockPlan() {
		const amount = Number($.get(stockPlanForm).amount),
			day = Number($.get(stockPlanForm).day);

		if (!(amount > 0) || !(day >= 1 && day <= 28) || !$.get(stockPlanForm).startMonth) {
			$.set(stockError, 'Enter a positive amount, a day from 1 to 28, and a start month.');

			return;
		}

		$.set(stockPlanSaving, true);

		try {
			(await $.track_reactivity_loss(createStockMonthlyPlan($.get(stockPlanTarget).id, { amount, day, startMonth: $.get(stockPlanForm).startMonth })))();
			$.set(stockPlanTarget, null);
			(await $.track_reactivity_loss(loadStocks()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not save this monthly plan.');
		} finally {
			$.set(stockPlanSaving, false);
		}
	}

	async function confirmStockPlan() {
		const amount = Number($.get(stockPlanConfirmation).amount),
			executionPrice = Number($.get(stockPlanConfirmation).price);

		if (!(amount > 0) || !(executionPrice > 0)) return;

		try {
			(await $.track_reactivity_loss(confirmStockMonthlyPlan($.get(stockPlanConfirmationTarget).id, $.get(stockPlanConfirmationTarget).currentMonthlyPlan.month, {
				amount,
				executionPrice,
				transactionDate: new Date().toISOString().slice(0, 10)
			})))();

			$.set(stockPlanConfirmationTarget, null);
			(await $.track_reactivity_loss(loadStocks()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(stockError, cause?.message || 'Could not confirm this ETF investment.');
		}
	}

	async function openStockDetail(id) {
		$.set(stockDetail, { id });
		$.set(stockDetailStatus, 'loading');

		try {
			$.set(stockDetail, (await $.track_reactivity_loss(getStock(id)))());
			$.set(stockDetailStatus, 'ready');
		} catch(cause) {
			$.set(stockDetailStatus, 'error');
			$.set(stockError, cause?.message || 'Could not load this stock.');
		}
	}

	function openSipConfirmation(fund, occurrence) {
		$.set(confirmingSip, { fund, occurrence });
		$.set(sipConfirmError, '');

		$.set(sipConfirmForm, {
			amount: String(occurrence.amount || fund.monthlySipAmount || ''),
			transactionDate: occurrence.transactionDate || new Date().toISOString().slice(0, 10),
			nav: $.equals(occurrence.nav, null) ? '' : String(occurrence.nav)
		});
	}

	async function saveSipConfirmation() {
		const amount = Number($.get(sipConfirmForm).amount),
			nav = Number($.get(sipConfirmForm).nav);

		if (!(amount > 0) || !$.get(sipConfirmForm).transactionDate || !(nav > 0)) {
			$.set(sipConfirmError, 'Enter a valid amount, transaction date, and NAV.');

			return;
		}

		$.set(sipConfirmSaving, true);
		$.set(sipConfirmError, '');

		try {
			const payload = {
				amount,
				transactionDate: $.get(sipConfirmForm).transactionDate,
				nav,
				calculationSource: 'NAV_ESTIMATED'
			};

			if ($.strict_equals($.get(confirmingSip).occurrence.status, 'CONFIRMED')) (await $.track_reactivity_loss(updateSipOccurrence($.get(confirmingSip).fund.id, $.get(confirmingSip).occurrence.scheduledMonth, payload)))(); else (await $.track_reactivity_loss(confirmSipOccurrence($.get(confirmingSip).fund.id, $.get(confirmingSip).occurrence.scheduledMonth, payload)))();

			$.set(confirmingSip, null);
			(await $.track_reactivity_loss(loadMutualFunds()))();
			(await $.track_reactivity_loss(refreshStories()()))();
		} catch(cause) {
			$.set(sipConfirmError, cause?.message || 'Could not save this SIP allocation.');
		} finally {
			$.set(sipConfirmSaving, false);
		}
	}

	async function openFundDetail(id) {
		$.set(fundDetail, { id });
		$.set(fundDetailStatus, 'loading');
		$.set(fundDetailError, '');

		try {
			$.set(fundDetail, (await $.track_reactivity_loss(getMutualFund(id)))());
			$.set(fundDetailStatus, 'ready');
		} catch(cause) {
			$.set(fundDetailStatus, 'error');
			$.set(fundDetailError, cause?.message || 'Could not load this fund.');
		}
	}

	function openLumpSum(fund) {
		$.set(lumpSumFund, fund);
		$.set(lumpSumError, '');

		$.set(lumpSumForm, {
			amount: '',
			transactionDate: new Date().toISOString().slice(0, 10),
			nav: ''
		});
	}

	function openHistoryEdit(fund, entry) {
		$.set(editingFundTransaction, { fund, entry });
		$.set(fundTransactionError, '');

		$.set(fundTransactionForm, {
			amount: String(entry.amount || ''),
			transactionDate: entry.transactionDate || '',
			nav: $.equals(entry.nav, null) ? '' : String(entry.nav)
		});
	}

	async function saveFundTransaction() {
		const amount = Number($.get(fundTransactionForm).amount),
			nav = Number($.get(fundTransactionForm).nav);

		if (!(amount > 0) || !$.get(fundTransactionForm).transactionDate || !(nav > 0)) {
			$.set(fundTransactionError, 'Enter a valid amount, transaction date, and NAV.');

			return;
		}

		$.set(fundTransactionSaving, true);
		$.set(fundTransactionError, '');

		try {
			(await $.track_reactivity_loss(updateMutualFundTransaction($.get(editingFundTransaction).fund.id, $.get(editingFundTransaction).entry.id, {
				amount,
				transactionDate: $.get(fundTransactionForm).transactionDate,
				nav,
				calculationSource: 'USER_ENTERED'
			})))();

			const id = $.get(editingFundTransaction).fund.id;

			$.set(editingFundTransaction, null);
			(await $.track_reactivity_loss(Promise.all([loadMutualFunds(), openFundDetail(id), refreshStories()()])))();
		} catch(cause) {
			$.set(fundTransactionError, cause?.message || 'Could not update this investment.');
		} finally {
			$.set(fundTransactionSaving, false);
		}
	}

	async function saveLumpSum() {
		const amount = Number($.get(lumpSumForm).amount),
			nav = Number($.get(lumpSumForm).nav);

		if (!(amount > 0) || !$.get(lumpSumForm).transactionDate || !(nav > 0)) {
			$.set(lumpSumError, 'Enter a positive amount, transaction date, and NAV.');

			return;
		}

		$.set(lumpSumSaving, true);

		try {
			(await $.track_reactivity_loss(createMutualFundLumpSum($.get(lumpSumFund).id, {
				amount,
				transactionDate: $.get(lumpSumForm).transactionDate,
				nav,
				calculationSource: 'NAV_ESTIMATED'
			})))();

			$.set(lumpSumFund, null);
			(await $.track_reactivity_loss(Promise.all([loadMutualFunds(), refreshStories()()])))();
		} catch(cause) {
			$.set(lumpSumError, cause?.message || 'Could not add this lump sum.');
		} finally {
			$.set(lumpSumSaving, false);
		}
	}

	function navigate(next) {
		$.set(view, next);

		if ($.strict_equals(next, 'transactions', false)) {
			$.set(selectedDay, null);
			$.set(activityTab, 'recent');
		}

		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

	function currentLocalMonth() {
		const now = new Date();

		return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
	}

	function changeMonth(offset) {
		const [y, m] = selectedMonth().split('-').map(Number),
			next = new Date(Date.UTC(y, m - 1 + offset, 1)).toISOString().slice(0, 7);

		if (next <= currentLocalMonth()) {
			$.set(selectedDay, null);
			$.set(dayItems, []);
			$.set(activityTab, 'recent');
			onMonthChange()(next);
		}
	}

	function buildCalendar(monthValue, apiDays) {
		const [y, m] = monthValue.split('-').map(Number),
			count = new Date(y, m, 0).getDate(),
			leading = (new Date(y, m - 1, 1).getDay() + 6) % 7,
			values = new Map(apiDays.map((x) => [Number(String(x.date).slice(-2)), x])),
			today = new Date(),
			current = $.strict_equals(today.getFullYear(), y) && $.strict_equals(today.getMonth() + 1, m);

		return {
			leading,

			days: Array.from({ length: count }, (_, i) => {
				const day = i + 1, v = values.get(day) || {};

				return {
					day,
					totalSpend: Number(v.totalSpend || 0),
					transactionCount: Number(v.transactionCount || 0),
					intensity: Math.max(0, Math.min(4, Number(v.intensity || 0))),
					future: current && day > today.getDate()
				};
			})
		};
	}

	async function selectDate(day) {
		if (!day || day.future) return;

		$.set(selectedDay, day.day);
		$.set(activityTab, 'day');
		$.set(showAll, false);
		$.set(expandedId, null);
		(await $.track_reactivity_loss(loadDay()))();
	}

	async function loadDay() {
		if ($.equals($.get(selectedDay), null)) return;

		$.set(dayStatus, 'loading');

		try {
			const page = (await $.track_reactivity_loss(getExpensesForDate(selectedMonth(), isoDate($.get(selectedDay)), 50)))();

			$.set(dayItems, page.items || page.expenses || []);
			$.set(dayStatus, 'ready');
		} catch {
			$.set(dayStatus, 'error');
		}
	}

	async function openStory(story) {
		$.set(openedStory, story);
		$.set(storySlide, 0);
		$.set(showStoryEvidence, false);

		const hasReview = (story.cards || []).some((card) => (card.actions || []).some((action) => $.strict_equals(action.type, 'OPEN_COMMITMENT_REVIEW')));

		if (hasReview) {
			$.set(commitmentReviewStatus, 'loading');
			$.set(showCommitmentReview, true);

			try {
				const result = (await $.track_reactivity_loss(getCommitmentReview(selectedMonth())))();

				$.set(commitmentReview, result.items || []);
				$.set(commitmentReviewStatus, 'ready');
			} catch(cause) {
				$.set(commitmentReviewStatus, 'error');
				$.set(commitmentError, cause?.message || 'Could not load payments needing review.');
			}
		}
	}

	function storyHasLoan(story) {
		return isCommitment(story) && evidenceFor(story, $.get(storySlide)).some((item) => (/loan/i).test(item.category));
	}

	async function resolveCandidate(transactionId, commitmentId) {
		$.set(resolvingCandidate, transactionId);

		try {
			(await $.track_reactivity_loss(resolveCommitmentReview(transactionId, commitmentId)))();
			$.set(commitmentReview, $.get(commitmentReview).filter((item) => $.strict_equals(item.transactionId, transactionId, false)));
			(await $.track_reactivity_loss(refreshStories()()))();

			if (!$.get(commitmentReview).length) $.set(showCommitmentReview, false);
		} catch(cause) {
			$.set(commitmentError, cause?.message || 'Could not save this review.');
		} finally {
			$.set(resolvingCandidate, null);
		}
	}

	function endStorySwipe(event, length) {
		if ($.strict_equals($.get(storyTouchStart), null)) return;

		const distance = event.changedTouches[0].clientX - $.get(storyTouchStart);

		if (Math.abs(distance) > 45) $.set(storySlide, Math.max(0, Math.min(length - 1, $.get(storySlide) + (distance < 0 ? 1 : -1))));

		$.set(storyTouchStart, null);
	}

	function endRailSwipe(event, length, rail) {
		if ($.strict_equals($.get(storyRailTouchStart), null)) return;

		const distance = event.changedTouches[0].clientX - $.get(storyRailTouchStart);

		if (Math.abs(distance) > 45) {
			const next = Math.max(0, Math.min(length - 1, ($.strict_equals(rail, 'home') ? $.get(homeStoryIndex) : $.get(storiesRailIndex)) + (distance < 0 ? 1 : -1)));

			if ($.strict_equals(rail, 'home')) $.set(homeStoryIndex, next); else $.set(storiesRailIndex, next);
		}

		$.set(storyRailTouchStart, null);
	}

	async function startEdit(item) {
		$.set(editing, item);
		$.set(editAmount, String(item.amount ?? ''));
		$.set(editDate, localInputDate(transactionDate(item)));
		$.set(editCategory, $.strict_equals(category(item), 'Uncategorised') ? '' : category(item));
		$.set(editSubcategory, item.subcategory?.name || item.subcategory || '');
		$.set(editMerchantId, String(item.merchantId ?? item.merchant?.id ?? ''));
		$.set(editAccountId, String(item.accountId ?? item.account?.id ?? item.sourceAccountId ?? ''));
		$.set(actionError, '');
		$.set(optionsError, '');

		if ($.strict_equals($.get(optionsStatus), 'ready')) {
			selectCurrentReferences(item);

			return;
		}

		$.set(optionsStatus, 'loading');

		try {
			const result = (await $.track_reactivity_loss(getExpenseOptions()))();

			$.set(editOptions, {
				categories: result.categories || [],
				merchants: result.merchants || [],
				accounts: result.accounts || []
			});

			$.set(optionsStatus, 'ready');
			selectCurrentReferences(item);
		} catch(cause) {
			$.set(optionsStatus, 'error');
			$.set(optionsError, cause?.message || 'Could not load expense options.');
		}
	}

	function selectCurrentReferences(item) {
		if (!$.get(editMerchantId)) {
			const match = $.get(editOptions).merchants.find((option) => $.strict_equals(option.name?.toLowerCase(), merchant(item).toLowerCase()));

			if (match) $.set(editMerchantId, String(match.id));
		}

		if (!$.get(editAccountId)) {
			const current = String(item.account?.name ?? item.sourceAccount?.name ?? item.accountName ?? '').toLowerCase(),
				match = $.get(editOptions).accounts.find((option) => $.strict_equals(option.name?.toLowerCase(), current));

			if (match) $.set(editAccountId, String(match.id));
		}
	}

	function changeEditCategory(event) {
		$.set(editCategory, event.currentTarget.value);

		if (!$.get(editSubcategories).includes($.get(editSubcategory))) $.set(editSubcategory, '');
	}

	async function saveEdit() {
		const amount = Number($.get(editAmount)),
			merchantId = Number($.get(editMerchantId)),
			accountId = Number($.get(editAccountId));

		if (!$.get(editing) || $.get(saving) || $.strict_equals($.get(optionsStatus), 'ready', false) || !Number.isFinite(amount) || amount <= 0 || !$.get(editDate) || !$.get(editCategory) || !$.get(editSubcategory) || !Number.isFinite(merchantId) || !Number.isFinite(accountId)) return;

		$.set(saving, true);
		$.set(actionError, '');

		try {
			(await $.track_reactivity_loss(updateExpense($.get(editing).id, {
				amount,
				transactionDate: $.get(editDate),
				category: $.get(editCategory),
				subcategory: $.get(editSubcategory),
				merchantId,
				accountId
			})))();

			$.set(editing, null);

			(await $.track_reactivity_loss(Promise.all([
				loadDay(),
				refreshRecent()(),
				refreshCalendar()(),
				refreshStories()()
			])))();
		} catch(cause) {
			$.set(actionError, cause?.message || 'Could not update the transaction.');
		} finally {
			$.set(saving, false);
		}
	}

	async function confirmDelete() {
		if (!$.get(deleting)) return;

		try {
			(await $.track_reactivity_loss(deleteExpense($.get(deleting).id)))();
			$.set(deleting, null);

			(await $.track_reactivity_loss(Promise.all([
				loadDay(),
				refreshRecent()(),
				refreshCalendar()(),
				refreshStories()()
			])))();
		} catch(cause) {
			$.set(actionError, cause?.message || 'Could not delete the transaction.');
			$.set(deleting, null);
		}
	}

	async function addMissingDate() {
		if (!$.get(selected) || $.get(addingContext)) return;

		$.set(addingContext, true);

		try {
			const result = (await $.track_reactivity_loss(createMissingDateContext(isoDate($.get(selected).day), $.get(data).timezone || Intl.DateTimeFormat().resolvedOptions().timeZone)))();

			$.set(handoff, { ...result, date: isoDate($.get(selected).day) });
		} catch(cause) {
			$.set(actionError, cause instanceof ApiError
				? cause.message
				: 'Could not prepare WhatsApp recording.');
		} finally {
			$.set(addingContext, false);
		}
	}

	async function signOut() {
		$.set(loggingOut, true);

		try {
			(await $.track_reactivity_loss(logout()))();

			try {
				localStorage.removeItem(`${MONEY_MODULES_CACHE_KEY}.real`);
				localStorage.removeItem(`${MONEY_MODULES_CACHE_KEY}.demo`);
			} catch {}

			onLogout()();
		} catch {
			$.set(loggingOut, false);
			$.set(signOutError, 'Could not sign out.');
		}
	}

	async function switchDemoMode() {
		if ($.get(demoSwitching)) return;

		$.set(demoSwitching, true);
		$.set(demoError, '');

		try {
			(await $.track_reactivity_loss(onDemoModeChange()(!demoMode())))();
			$.set(loans, []);
			$.set(mutualFunds, []);
			$.set(stocks, []);
			$.set(actions, []);
			$.set(loanStatus, 'idle');
			$.set(mutualFundStatus, 'idle');
			$.set(stockStatus, 'idle');
			actionsStatus = 'idle';
			$.set(fundDetail, null);
			$.set(dayItems, []);
			$.set(selectedDay, null);
			$.set(editOptions, { categories: [], merchants: [], accounts: [] });
			$.set(optionsStatus, 'idle');
			$.set(showMoney, false);
			(await $.track_reactivity_loss(loadActions()))();
		} catch(cause) {
			$.set(demoError, cause?.message || 'Could not switch profiles.');
		} finally {
			$.set(demoSwitching, false);
		}
	}

	onMount(() => {
		try {
			$.set(commitmentStyle, localStorage.getItem('money-stories.commitment-style') || 'playful');
		} catch {}

		loadActions();
	});

	$.legacy_pre_effect(() => ($.deep_read_state(calendarSection())), () => {
		$.set(data, calendarSection().data || {});
	});

	$.legacy_pre_effect(() => ($.get(data)), () => {
		$.set(currency, $.get(data).currency || 'INR');
	});

	$.legacy_pre_effect(() => ($.deep_read_state(selectedMonth()), $.get(data)), () => {
		$.set(calendar, buildCalendar(selectedMonth(), $.get(data).days || []));
	});

	$.legacy_pre_effect(() => ($.deep_read_state(recentSection())), () => {
		$.set(recentData, recentSection().data || {});
	});

	$.legacy_pre_effect(() => ($.get(recentData)), () => {
		$.set(recentItems, ($.get(recentData).items || $.get(recentData).expenses || []).slice(0, 5));
	});

	$.legacy_pre_effect(() => ($.deep_read_state(storiesSection())), () => {
		$.set(storyData, storiesSection().data || {});
	});

	$.legacy_pre_effect(() => ($.get(storyData)), () => {
		$.set(stories, $.get(storyData).stories || $.get(storyData).moneyStories || $.get(storyData).storyCards || []);
	});

	$.legacy_pre_effect(() => ($.get(storyFilter), $.get(stories)), () => {
		$.set(filteredStories, $.strict_equals($.get(storyFilter), 'All')
			? $.get(stories)
			: $.get(stories).filter((story) => $.strict_equals(storySource(story).toLowerCase(), $.get(storyFilter).toLowerCase())));
	});

	$.legacy_pre_effect(() => ($.get(stories)), () => {
		$.set(homeStories, $.get(stories).slice(0, 3));
	});

	$.legacy_pre_effect(() => ($.get(homeStoryIndex), $.get(homeStories)), () => {
		if ($.get(homeStoryIndex) >= $.get(homeStories).length) $.set(homeStoryIndex, 0);
	});

	$.legacy_pre_effect(() => ($.get(storiesRailIndex), $.get(filteredStories)), () => {
		if ($.get(storiesRailIndex) >= $.get(filteredStories).length) $.set(storiesRailIndex, 0);
	});

	$.legacy_pre_effect(() => ($.get(selectedDay), $.get(calendar)), () => {
		$.set(selected, $.equals($.get(selectedDay), null)
			? null
			: $.get(calendar).days.find((day) => $.strict_equals(day.day, $.get(selectedDay))));
	});

	$.legacy_pre_effect(() => ($.get(activityTab), $.get(recentItems), $.get(dayItems)), () => {
		$.set(activeItems, $.strict_equals($.get(activityTab), 'recent') ? $.get(recentItems) : $.get(dayItems));
	});

	$.legacy_pre_effect(() => ($.get(showAll), $.get(activeItems)), () => {
		$.set(visibleItems, $.get(showAll) ? $.get(activeItems) : $.get(activeItems).slice(0, 5));
	});

	$.legacy_pre_effect(() => ($.get(editOptions), $.get(editCategory)), () => {
		$.set(editSubcategories, $.get(editOptions).categories.find((option) => $.strict_equals(option.name, $.get(editCategory)))?.subcategories || []);
	});

	$.legacy_pre_effect(() => ($.get(loans)), () => {
		$.set(activeLoans, $.get(loans).filter((loan) => $.strict_equals(loan.status, 'ACTIVE')));
	});

	$.legacy_pre_effect(() => ($.get(loans)), () => {
		$.set(closedLoans, $.get(loans).filter((loan) => $.strict_equals(loan.status, 'CLOSED')));
	});

	$.legacy_pre_effect(() => ($.get(activeLoans)), () => {
		$.set(totalMonthlyEmi, $.get(activeLoans).reduce((total, loan) => total + Number(loan.monthlyEmiAmount || 0), 0));
	});

	$.legacy_pre_effect(() => ($.get(mutualFunds)), () => {
		$.set(mutualPortfolio, {
			invested: $.get(mutualFunds).reduce((total, fund) => total + Number(fund.invested || 0), 0),

			current: $.get(mutualFunds).some((fund) => $.strict_equals(fund.currentValue, null, false))
				? $.get(mutualFunds).reduce((total, fund) => total + Number(fund.currentValue || 0), 0)
				: null,

			pnl: $.get(mutualFunds).some((fund) => $.strict_equals(fund.profitOrLoss, null, false))
				? $.get(mutualFunds).reduce((total, fund) => total + Number(fund.profitOrLoss || 0), 0)
				: null
		});
	});

	$.legacy_pre_effect(() => ($.get(stocks)), () => {
		$.set(stockPortfolio, {
			invested: $.get(stocks).reduce((total, stock) => total + Number(stock.invested || 0), 0),

			current: $.get(stocks).some((stock) => $.strict_equals(stock.currentValue, null, false))
				? $.get(stocks).reduce((total, stock) => total + Number(stock.currentValue || 0), 0)
				: null,

			pnl: $.get(stocks).some((stock) => $.strict_equals(stock.profitOrLoss, null, false))
				? $.get(stocks).reduce((total, stock) => total + Number(stock.profitOrLoss || 0), 0)
				: null
		});
	});

	$.legacy_pre_effect(() => ($.get(actions)), () => {
		$.set(visibleActions, $.get(actions).map((action) => ({ action, presentation: actionPresentation(action) })).filter((item) => item.presentation));
	});

	$.legacy_pre_effect(() => ($.get(actions), $.get(highlightedLoanId)), () => {
		$.set(highlightedLoanAction, $.get(actions).find((action) => $.strict_equals(String(action.referenceId), String($.get(highlightedLoanId))) && $.strict_equals(action.actionType, 'LOAN_CLOSURE_CONFIRMATION')));
	});

	$.legacy_pre_effect(() => ($.deep_read_state(connectionStatus())), () => {
		$.set(connectionLabel, $.strict_equals(connectionStatus(), 'online')
			? 'Online'
			: $.strict_equals(connectionStatus(), 'offline') ? 'Offline' : 'Checking');
	});

	$.legacy_pre_effect(() => ($.get(commitments), $.get(openedStory), $.get(storySlide)), () => {
		$.set(evidenceItems, (
			$.get(commitments),
			evidenceFor($.get(openedStory), $.get(storySlide))
		));
	});

	$.legacy_pre_effect_reset();

	var $$exports = { ...$.legacy_api() };

	$.init();

	var fragment = root();
	var node = $.first_child(fragment);

	{
		var consequent_4 = ($$anchor) => {
			var div = root_1();
			var section = $.child(div);
			var button = $.child(section);
			var h2 = $.sibling(button, 2);
			var text_1 = $.child(h2, true);

			$.reset(h2);

			var node_1 = $.sibling(h2);

			{
				var consequent = ($$anchor) => {
					var p = root_2();

					$.append($$anchor, p);
				};

				var alternate_2 = ($$anchor) => {
					var fragment_1 = $.comment();
					var node_2 = $.first_child(fragment_1);

					{
						var consequent_1 = ($$anchor) => {
							var p_1 = root_4();
							var text_2 = $.child(p_1, true);

							$.reset(p_1);
							$.template_effect(() => $.set_text(text_2, $.get(loanHistoryError)));
							$.append($$anchor, p_1);
						};

						var alternate_1 = ($$anchor) => {
							var section_1 = root_5();
							var node_3 = $.sibling($.child(section_1));

							{
								var consequent_3 = ($$anchor) => {
									var fragment_2 = $.comment();
									var node_4 = $.first_child(fragment_2);

									$.add_svelte_meta(
										() => $.each(
											node_4,
											1,
											() => (
												$.get(loanHistory),
												$.untrack(() => $.get(loanHistory).history)
											),
											$.index,
											($$anchor, entry) => {
												var div_1 = root_7();
												let classes;
												var span = $.child(div_1);
												var text_3 = $.child(span, true);

												$.reset(span);

												var strong = $.sibling(span);
												var text_4 = $.child(strong);

												$.reset(strong);

												var span_1 = $.sibling(strong);
												var b_1 = $.child(span_1);
												var text_5 = $.child(b_1, true);

												$.reset(b_1);
												$.reset(span_1);

												var small = $.sibling(span_1);
												var text_6 = $.child(small, true);

												$.reset(small);

												var node_5 = $.sibling(small);

												{
													var consequent_2 = ($$anchor) => {
														var div_2 = root_8();
														var node_6 = $.child(div_2);

														{
															let $0 = $.derived_safe_equal(() => (
																$.get(entry),
																$.untrack(() => `Due now · ${money($.get(entry).plannedAmount)}`)
															));

															let $1 = $.derived_safe_equal(() => (
																$.get(entry),
																$.untrack(() => `Mark ${monthLabel($.get(entry).month)} EMI paid`)
															));

															$.add_svelte_meta(
																() => DueReminder(node_6, {
																	get detail() {
																		return $.get($0);
																	},

																	get actionLabel() {
																		return $.get($1);
																	},

																	onAction: () => payLoanHistoryEmi($.get(entry))
																}),
																'component',
																Home,
																171,
																962,
																{ componentTag: 'DueReminder' }
															);
														}

														$.reset(div_2);
														$.append($$anchor, div_2);
													};

													$.add_svelte_meta(
														() => $.if(node_5, ($$render) => {
															if ((
																$.get(entry),
																$.untrack(() => $.strict_equals($.get(entry).status, 'DUE'))
															)) $$render(consequent_2);
														}),
														'if',
														Home,
														171,
														903
													);
												}

												$.reset(div_1);

												$.template_effect(
													($0, $1, $2, $3) => {
														classes = $.set_class(div_1, 1, 'investment-history-row', null, classes, { due: $.strict_equals($.get(entry).status, 'DUE') });
														$.set_text(text_3, $0);
														$.set_text(text_4, `${$1 ?? ''} EMI`);
														$.set_text(text_5, $2);
														$.set_text(text_6, $3);
													},
													[
														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).dueDate))
														),

														() => (
															$.get(entry),
															$.untrack(() => monthLabel($.get(entry).month))
														),

														() => (
															$.get(entry),
															$.untrack(() => money($.get(entry).paidAmount || $.get(entry).plannedAmount))
														),

														() => (
															$.get(entry),

															$.untrack(() => $.strict_equals($.get(entry).status, 'PAID')
																? `Paid on ${dateLabel($.get(entry).paidAt)}`
																: $.strict_equals($.get(entry).status, 'DUE') ? 'Due now' : $.get(entry).status.toLowerCase())
														)
													]
												);

												$.append($$anchor, div_1);
											}
										),
										'each',
										Home,
										171,
										491
									);

									$.append($$anchor, fragment_2);
								};

								var alternate = ($$anchor) => {
									var p_2 = root_9();

									$.append($$anchor, p_2);
								};

								$.add_svelte_meta(
									() => $.if(node_3, ($$render) => {
										if ((
											$.get(loanHistory),
											$.untrack(() => $.get(loanHistory).history?.length)
										)) $$render(consequent_3); else $$render(alternate, false);
									}),
									'if',
									Home,
									171,
									458
								);
							}

							$.reset(section_1);
							$.append($$anchor, section_1);
						};

						$.add_svelte_meta(
							() => $.if(
								node_2,
								($$render) => {
									if ($.strict_equals($.get(loanHistoryStatus), 'error')) $$render(consequent_1); else $$render(alternate_1, false);
								},
								true
							),
							'if',
							Home,
							171,
							331
						);
					}

					$.append($$anchor, fragment_1);
				};

				$.add_svelte_meta(
					() => $.if(node_1, ($$render) => {
						if ($.strict_equals($.get(loanHistoryStatus), 'loading')) $$render(consequent); else $$render(alternate_2, false);
					}),
					'if',
					Home,
					171,
					265
				);
			}

			$.reset(section);
			$.reset(div);

			$.template_effect(() => $.set_text(text_1, (
				$.get(loanHistory),
				$.untrack(() => $.get(loanHistory).loanName)
			)));

			$.event('click', button, () => $.set(loanHistory, null));
			$.append($$anchor, div);
		};

		$.add_svelte_meta(
			() => $.if(node, ($$render) => {
				if ($.get(loanHistory)) $$render(consequent_4);
			}),
			'if',
			Home,
			171,
			0
		);
	}

	var node_7 = $.sibling(node, 2);

	{
		var consequent_8 = ($$anchor) => {
			var div_3 = root_10();
			var section_2 = $.child(div_3);
			var button_1 = $.child(section_2);
			var h2_1 = $.sibling(button_1, 2);
			var text_7 = $.child(h2_1, true);

			$.reset(h2_1);

			var node_8 = $.sibling(h2_1);

			{
				var consequent_5 = ($$anchor) => {
					var p_3 = root_11();

					$.append($$anchor, p_3);
				};

				var alternate_5 = ($$anchor) => {
					var fragment_3 = $.comment();
					var node_9 = $.first_child(fragment_3);

					{
						var consequent_6 = ($$anchor) => {
							var p_4 = root_13();
							var text_8 = $.child(p_4, true);

							$.reset(p_4);
							$.template_effect(() => $.set_text(text_8, $.get(commitmentHistoryError)));
							$.append($$anchor, p_4);
						};

						var alternate_4 = ($$anchor) => {
							var section_3 = root_14();
							var node_10 = $.sibling($.child(section_3));

							{
								var consequent_7 = ($$anchor) => {
									var fragment_4 = $.comment();
									var node_11 = $.first_child(fragment_4);

									$.add_svelte_meta(
										() => $.each(
											node_11,
											1,
											() => (
												$.get(commitmentHistory),
												$.untrack(() => $.get(commitmentHistory).history)
											),
											$.index,
											($$anchor, entry) => {
												var div_4 = root_16();
												var span_2 = $.child(div_4);
												var text_9 = $.child(span_2, true);

												$.reset(span_2);

												var strong_1 = $.sibling(span_2);
												var text_10 = $.child(strong_1);

												$.reset(strong_1);

												var span_3 = $.sibling(strong_1);
												var b_2 = $.child(span_3);
												var text_11 = $.child(b_2, true);

												$.reset(b_2);
												$.reset(span_3);

												var small_1 = $.sibling(span_3);
												var text_12 = $.child(small_1);

												$.reset(small_1);
												$.reset(div_4);

												$.template_effect(
													($0, $1, $2, $3) => {
														$.set_text(text_9, $0);
														$.set_text(text_10, `${$1 ?? ''} payment`);
														$.set_text(text_11, $2);
														$.set_text(text_12, `Done on ${$3 ?? ''}`);
													},
													[
														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).dueDate))
														),

														() => (
															$.get(entry),
															$.untrack(() => monthLabel($.get(entry).month))
														),

														() => (
															$.get(entry),
															$.get(commitmentHistory),
															$.untrack(() => money($.get(entry).actualAmount || $.get(commitmentHistory).planningAmount))
														),

														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).completedAt))
														)
													]
												);

												$.append($$anchor, div_4);
											}
										),
										'each',
										Home,
										172,
										539
									);

									$.append($$anchor, fragment_4);
								};

								var alternate_3 = ($$anchor) => {
									var p_5 = root_17();

									$.append($$anchor, p_5);
								};

								$.add_svelte_meta(
									() => $.if(node_10, ($$render) => {
										if ((
											$.get(commitmentHistory),
											$.untrack(() => $.get(commitmentHistory).history?.length)
										)) $$render(consequent_7); else $$render(alternate_3, false);
									}),
									'if',
									Home,
									172,
									500
								);
							}

							$.reset(section_3);
							$.append($$anchor, section_3);
						};

						$.add_svelte_meta(
							() => $.if(
								node_9,
								($$render) => {
									if ($.strict_equals($.get(commitmentHistoryStatus), 'error')) $$render(consequent_6); else $$render(alternate_4, false);
								},
								true
							),
							'if',
							Home,
							172,
							358
						);
					}

					$.append($$anchor, fragment_3);
				};

				$.add_svelte_meta(
					() => $.if(node_8, ($$render) => {
						if ($.strict_equals($.get(commitmentHistoryStatus), 'loading')) $$render(consequent_5); else $$render(alternate_5, false);
					}),
					'if',
					Home,
					172,
					286
				);
			}

			$.reset(section_2);
			$.reset(div_3);

			$.template_effect(() => $.set_text(text_7, (
				$.get(commitmentHistory),
				$.untrack(() => $.get(commitmentHistory).label)
			)));

			$.event('click', button_1, () => $.set(commitmentHistory, null));
			$.append($$anchor, div_3);
		};

		$.add_svelte_meta(
			() => $.if(node_7, ($$render) => {
				if ($.get(commitmentHistory)) $$render(consequent_8);
			}),
			'if',
			Home,
			172,
			0
		);
	}

	var node_12 = $.sibling(node_7, 2);

	$.add_svelte_meta(
		() => AppHeader(node_12, {
			get connectionStatus() {
				return connectionStatus();
			},

			get connectionLabel() {
				return $.get(connectionLabel);
			},

			get onRetry() {
				return onRetryConnection();
			},

			onHome: () => navigate('home'),
			onProfile: () => navigate('you')
		}),
		'component',
		Home,
		174,
		0,
		{ componentTag: 'AppHeader' }
	);

	var main = $.sibling(node_12, 2);
	var node_13 = $.child(main);

	{
		var consequent_9 = ($$anchor) => {
			var section_4 = root_18();
			var div_5 = $.sibling($.child(section_4));
			var strong_2 = $.child(div_5);
			var text_13 = $.child(strong_2, true);

			$.reset(strong_2);

			var p_6 = $.sibling(strong_2);
			var text_14 = $.child(p_6, true);

			$.reset(p_6);
			$.reset(div_5);

			var button_2 = $.sibling(div_5);

			$.reset(section_4);

			$.template_effect(() => {
				$.set_text(text_13, cacheUpdatedAt() ? 'Showing your last saved view' : 'You’re offline');

				$.set_text(text_14, cacheUpdatedAt()
					? 'We’ll refresh automatically when the service is back.'
					: 'Your layout is ready. Connect once to load your expenses and stories.');
			});

			$.event('click', button_2, function (...$$args) {
				$.apply(onRetryConnection, this, $$args, Home, [176, 341]);
			});

			$.append($$anchor, section_4);
		};

		$.add_svelte_meta(
			() => $.if(node_13, ($$render) => {
				if ($.strict_equals(connectionStatus(), 'offline')) $$render(consequent_9);
			}),
			'if',
			Home,
			176,
			0
		);
	}

	var node_14 = $.sibling(node_13, 2);

	{
		var consequent_11 = ($$anchor) => {
			var fragment_5 = root_19();
			var section_5 = $.first_child(fragment_5);
			var div_6 = $.child(section_5);
			var p_7 = $.child(div_6);
			var text_15 = $.child(p_7, true);

			$.reset(p_7);

			var h1 = $.sibling(p_7);
			var text_16 = $.child(h1, true);

			$.reset(h1);
			$.next();
			$.reset(div_6);
			$.reset(section_5);

			var node_15 = $.sibling(section_5, 2);

			$.add_svelte_meta(
				() => SectionState(node_15, {
					get section() {
						return calendarSection();
					},

					title: 'Spending overview',

					get retry() {
						return refreshCalendar();
					},

					children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
						var button_3 = root_20();
						var strong_3 = $.sibling($.child(button_3));
						var text_17 = $.child(strong_3);

						$.next();
						$.reset(strong_3);

						var b_3 = $.sibling(strong_3);
						var text_18 = $.child(b_3);

						$.reset(b_3);
						$.reset(button_3);

						$.template_effect(
							($0) => {
								$.set_text(text_17, `${$0 ?? ''} `);

								$.set_text(text_18, `${(
									$.get(data),
									$.untrack(() => $.get(data).transactionCount || 0)
								) ?? ''} transactions · View transactions →`);
							},
							[
								() => ($.get(data), $.untrack(() => money($.get(data).totalSpend)))
							]
						);

						$.event('click', button_3, () => navigate('transactions'));
						$.append($$anchor, button_3);
					}),

					$$slots: { default: true }
				}),
				'component',
				Home,
				179,
				2,
				{ componentTag: 'SectionState' }
			);

			var section_6 = $.sibling(node_15, 2);
			var div_7 = $.child(section_6);
			var button_4 = $.sibling($.child(div_7));

			$.reset(div_7);

			var node_16 = $.sibling(div_7);

			$.add_svelte_meta(
				() => SectionState(node_16, {
					get section() {
						return storiesSection();
					},

					title: 'Your stories',

					get retry() {
						return refreshStories();
					},

					children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
						var fragment_6 = $.comment();
						var node_17 = $.first_child(fragment_6);

						{
							var consequent_10 = ($$anchor) => {
								var div_8 = root_22();
								var div_9 = $.child(div_8);
								var node_18 = $.child(div_9);

								$.add_svelte_meta(
									() => $.each(node_18, 1, () => $.get(homeStories), $.index, ($$anchor, story, index) => {
										var button_5 = root_23();
										let classes_1;

										$.template_effect(
											($0) => {
												$.set_attribute(button_5, 'aria-label', $0);
												$.set_attribute(button_5, 'aria-current', $.strict_equals(index, $.get(homeStoryIndex)) ? 'true' : undefined);
												classes_1 = $.set_class(button_5, 1, '', null, classes_1, { active: $.strict_equals(index, $.get(homeStoryIndex)) });
											},
											[
												() => (
													index,
													$.get(homeStories),
													$.get(story),
													$.untrack(() => `Show story ${index + 1} of ${$.get(homeStories).length}: ${storyCardFace($.get(story)).heading}`)
												)
											]
										);

										$.event('click', button_5, () => $.set(homeStoryIndex, index));
										$.append($$anchor, button_5);
									}),
									'each',
									Home,
									180,
									441
								);

								var span_4 = $.sibling(node_18);
								var text_19 = $.child(span_4);

								$.reset(span_4);
								$.reset(div_9);

								var div_10 = $.sibling(div_9);
								var div_11 = $.child(div_10);

								$.add_svelte_meta(
									() => $.each(div_11, 5, () => $.get(homeStories), $.index, ($$anchor, story, index) => {
										var button_6 = root_24();
										let classes_2;
										var span_5 = $.child(button_6);
										var text_20 = $.child(span_5, true);

										$.reset(span_5);

										var strong_4 = $.sibling(span_5);
										var text_21 = $.child(strong_4, true);

										$.reset(strong_4);

										var b_4 = $.sibling(strong_4);
										var text_22 = $.child(b_4, true);

										$.reset(b_4);
										$.next();
										$.reset(button_6);

										$.template_effect(
											($0, $1, $2, $3) => {
												classes_2 = $.set_class(button_6, 1, $0, null, classes_2, { current: $.strict_equals(index, $.get(homeStoryIndex)) });
												$.set_text(text_20, $1);
												$.set_text(text_21, $2);
												$.set_text(text_22, $3);
											},
											[
												() => (
													$.get(story),
													$.untrack(() => `story-carousel-card ${storyTone($.get(story))}`)
												),

												() => ($.get(story), $.untrack(() => storySource($.get(story)))),

												() => (
													$.get(story),
													$.untrack(() => storyCardFace($.get(story)).heading)
												),

												() => (
													$.get(story),
													$.untrack(() => storyCardFace($.get(story)).displayValue)
												)
											]
										);

										$.event('click', button_6, () => openStory($.get(story)));
										$.append($$anchor, button_6);
									}),
									'each',
									Home,
									180,
									1054
								);

								$.reset(div_11);
								$.reset(div_10);
								$.reset(div_8);

								$.template_effect(() => {
									$.set_text(text_19, `${$.get(homeStoryIndex) + 1} / ${(
										$.get(homeStories),
										$.untrack(() => $.get(homeStories).length)
									) ?? ''}`);

									$.set_style(div_11, `transform:translateX(calc(${$.get(homeStoryIndex)} * -92%))`);
								});

								$.event('touchstart', div_10, (event) => $.set(storyRailTouchStart, event.touches[0].clientX));
								$.event('touchend', div_10, (event) => endRailSwipe(event, $.get(homeStories).length, 'home'));
								$.append($$anchor, div_8);
							};

							var alternate_6 = ($$anchor) => {
								var div_12 = root_25();

								$.append($$anchor, div_12);
							};

							$.add_svelte_meta(
								() => $.if(node_17, ($$render) => {
									if ((
										$.get(homeStories),
										$.untrack(() => $.get(homeStories).length)
									)) $$render(consequent_10); else $$render(alternate_6, false);
								}),
								'if',
								Home,
								180,
								311
							);
						}

						$.append($$anchor, fragment_6);
					}),

					$$slots: { default: true }
				}),
				'component',
				Home,
				180,
				228,
				{ componentTag: 'SectionState' }
			);

			$.reset(section_6);

			var section_7 = $.sibling(section_6, 2);
			var div_13 = $.child(section_7);
			var button_7 = $.sibling($.child(div_13));

			$.reset(div_13);

			var div_14 = $.sibling(div_13);

			$.add_svelte_meta(
				() => $.each(
					div_14,
					5,
					() => (
						$.get(recentItems),
						$.untrack(() => $.get(recentItems).slice(0, 3))
					),
					$.index,
					($$anchor, item) => {
						var button_8 = root_26();
						var div_15 = $.child(button_8);
						var strong_5 = $.child(div_15);
						var text_23 = $.child(strong_5, true);

						$.reset(strong_5);

						var span_6 = $.sibling(strong_5);
						var text_24 = $.child(span_6);

						$.reset(span_6);
						$.reset(div_15);

						var b_5 = $.sibling(div_15);
						var text_25 = $.child(b_5);

						$.reset(b_5);
						$.reset(button_8);

						$.template_effect(
							($0, $1, $2, $3) => {
								$.set_text(text_23, $0);
								$.set_text(text_24, `${$1 ?? ''} · ${$2 ?? ''}`);
								$.set_text(text_25, `− ${$3 ?? ''}`);
							},
							[
								() => ($.get(item), $.untrack(() => merchant($.get(item)))),
								() => ($.get(item), $.untrack(() => category($.get(item)))),

								() => (
									$.get(item),
									$.untrack(() => dateLabel(transactionDate($.get(item))))
								),

								() => ($.get(item), $.untrack(() => money($.get(item).amount)))
							]
						);

						$.event('click', button_8, () => {
							navigate('transactions');
							startEdit($.get(item));
						});

						$.append($$anchor, button_8);
					},
					($$anchor) => {
						var p_8 = root_27();

						$.append($$anchor, p_8);
					}
				),
				'each',
				Home,
				181,
				255
			);

			$.reset(div_14);
			$.reset(section_7);

			var button_9 = $.sibling(section_7, 2);

			$.template_effect(
				($0, $1) => {
					$.set_text(text_15, $0);
					$.set_text(text_16, $1);
				},
				[
					() => (
						$.deep_read_state(selectedMonth()),
						$.untrack(() => monthLabel(selectedMonth()).toUpperCase())
					),

					() => ($.untrack(greeting))
				]
			);

			$.event('click', button_4, () => navigate('stories'));
			$.event('click', button_7, () => navigate('transactions'));
			$.event('click', button_9, openMoney);
			$.append($$anchor, fragment_5);
		};

		var alternate_12 = ($$anchor) => {
			var fragment_7 = $.comment();
			var node_19 = $.first_child(fragment_7);

			{
				var consequent_16 = ($$anchor) => {
					var fragment_8 = root_29();
					var section_8 = $.first_child(fragment_8);
					var label = $.sibling($.child(section_8));
					var button_10 = $.child(label);
					var input = $.sibling(button_10);

					$.remove_input_defaults(input);

					var button_11 = $.sibling(input);

					$.reset(label);
					$.reset(section_8);

					var node_20 = $.sibling(section_8, 2);

					$.add_svelte_meta(
						() => SectionState(node_20, {
							get section() {
								return calendarSection();
							},

							title: 'Spending calendar',

							get retry() {
								return refreshCalendar();
							},

							children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
								var section_9 = root_30();
								var div_16 = $.child(section_9);
								var div_17 = $.child(div_16);
								var strong_6 = $.sibling($.child(div_17));
								var text_26 = $.child(strong_6, true);

								$.reset(strong_6);
								$.reset(div_17);

								var div_18 = $.sibling(div_17);
								var strong_7 = $.sibling($.child(div_18));
								var text_27 = $.child(strong_7, true);

								$.reset(strong_7);
								$.reset(div_18);

								var div_19 = $.sibling(div_18);
								var strong_8 = $.sibling($.child(div_19));
								var text_28 = $.child(strong_8, true);

								$.reset(strong_8);
								$.reset(div_19);
								$.reset(div_16);

								var div_20 = $.sibling(div_16);

								$.add_svelte_meta(
									() => $.each(div_20, 4, () => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], $.index, ($$anchor, d) => {
										var span_7 = root_31();
										var text_29 = $.child(span_7, true);

										$.reset(span_7);
										$.template_effect(() => $.set_text(text_29, d));
										$.append($$anchor, span_7);
									}),
									'each',
									Home,
									185,
									411
								);

								$.reset(div_20);

								var div_21 = $.sibling(div_20);
								var node_21 = $.child(div_21);

								$.add_svelte_meta(
									() => $.each(
										node_21,
										1,
										() => (
											$.get(calendar),
											$.untrack(() => Array($.get(calendar).leading))
										),
										$.index,
										($$anchor, _) => {
											var span_8 = root_32();

											$.append($$anchor, span_8);
										}
									),
									'each',
									Home,
									185,
									518
								);

								var node_22 = $.sibling(node_21);

								$.add_svelte_meta(
									() => $.each(node_22, 1, () => ($.get(calendar), $.untrack(() => $.get(calendar).days)), $.index, ($$anchor, d) => {
										var button_12 = root_33();
										let classes_3;
										var text_30 = $.child(button_12, true);

										$.reset(button_12);

										$.template_effect(() => {
											classes_3 = $.set_class(button_12, 1, ($.get(d), $.untrack(() => `level-${$.get(d).intensity}`)), null, classes_3, {
												future: $.get(d).future,
												selected: $.strict_equals($.get(selectedDay), $.get(d).day)
											});

											button_12.disabled = ($.get(d), $.untrack(() => $.get(d).future));
											$.set_text(text_30, ($.get(d), $.untrack(() => $.get(d).day)));
										});

										$.event('click', button_12, () => selectDate($.get(d)));
										$.append($$anchor, button_12);
									}),
									'each',
									Home,
									185,
									574
								);

								$.reset(div_21);

								var div_22 = $.sibling(div_21);
								var div_23 = $.sibling($.child(div_22));

								$.add_svelte_meta(
									() => $.each(div_23, 4, () => [0, 1, 2, 3, 4], $.index, ($$anchor, l) => {
										var i_1 = root_34();

										$.template_effect(() => $.set_class(i_1, 1, `level-${l}`));
										$.append($$anchor, i_1);
									}),
									'each',
									Home,
									185,
									827
								);

								$.reset(div_23);
								$.next();
								$.reset(div_22);
								$.reset(section_9);

								$.template_effect(
									($0, $1) => {
										$.set_text(text_26, $0);

										$.set_text(text_27, (
											$.get(data),
											$.untrack(() => $.get(data).transactionCount || 0)
										));

										$.set_text(text_28, $1);
									},
									[
										() => ($.get(data), $.untrack(() => money($.get(data).totalSpend))),

										() => (
											$.get(data),
											$.untrack(() => money($.get(data).highestSpend))
										)
									]
								);

								$.append($$anchor, section_9);
							}),

							$$slots: { default: true }
						}),
						'component',
						Home,
						185,
						2,
						{ componentTag: 'SectionState' }
					);

					var section_10 = $.sibling(node_20, 2);
					var div_24 = $.child(section_10);
					var button_13 = $.child(div_24);
					let classes_4;
					var button_14 = $.sibling(button_13);
					let classes_5;
					var text_31 = $.child(button_14, true);

					$.reset(button_14);
					$.reset(div_24);

					var node_23 = $.sibling(div_24);

					{
						var consequent_12 = ($$anchor) => {
							var div_25 = root_35();

							$.append($$anchor, div_25);
						};

						var alternate_8 = ($$anchor) => {
							var fragment_9 = $.comment();
							var node_24 = $.first_child(fragment_9);

							{
								var consequent_13 = ($$anchor) => {
									var div_26 = root_37();
									var button_15 = $.sibling($.child(div_26));

									$.reset(div_26);
									$.event('click', button_15, loadDay);
									$.append($$anchor, div_26);
								};

								var alternate_7 = ($$anchor) => {
									var fragment_10 = root_38();
									var div_27 = $.first_child(fragment_10);
									var p_9 = $.child(div_27);
									var text_32 = $.child(p_9, true);

									$.reset(p_9);

									var h2_2 = $.sibling(p_9);
									var text_33 = $.child(h2_2, true);

									$.reset(h2_2);
									$.reset(div_27);

									var div_28 = $.sibling(div_27);

									$.add_svelte_meta(
										() => $.each(
											div_28,
											5,
											() => $.get(visibleItems),
											$.index,
											($$anchor, item) => {
												var article = root_39();
												let classes_6;
												var button_16 = $.child(article);
												var div_29 = $.child(button_16);
												var strong_9 = $.child(div_29);
												var text_34 = $.child(strong_9, true);

												$.reset(strong_9);

												var span_9 = $.sibling(strong_9);
												var text_35 = $.child(span_9);

												$.reset(span_9);
												$.reset(div_29);

												var div_30 = $.sibling(div_29);
												var b_6 = $.child(div_30);
												var text_36 = $.child(b_6);

												$.reset(b_6);

												var span_10 = $.sibling(b_6);
												let classes_7;

												$.reset(div_30);
												$.reset(button_16);

												var node_25 = $.sibling(button_16);

												{
													var consequent_14 = ($$anchor) => {
														var div_31 = root_40();
														var button_17 = $.child(div_31);
														var button_18 = $.sibling(button_17);

														$.reset(div_31);
														$.event('click', button_17, () => startEdit($.get(item)));
														$.event('click', button_18, () => $.set(deleting, $.get(item)));
														$.append($$anchor, div_31);
													};

													$.add_svelte_meta(
														() => $.if(node_25, ($$render) => {
															if ((
																$.get(expandedId),
																$.get(item),
																$.untrack(() => $.strict_equals($.get(expandedId), $.get(item).id))
															)) $$render(consequent_14);
														}),
														'if',
														Home,
														186,
														1415
													);
												}

												$.reset(article);

												$.template_effect(
													($0, $1, $2, $3) => {
														classes_6 = $.set_class(article, 1, 'compact-row', null, classes_6, { expanded: $.strict_equals($.get(expandedId), $.get(item).id) });
														$.set_text(text_34, $0);
														$.set_text(text_35, `${$1 ?? ''} · ${$2 ?? ''}`);
														$.set_text(text_36, `− ${$3 ?? ''}`);
														classes_7 = $.set_class(span_10, 1, 'row-chevron', null, classes_7, { open: $.strict_equals($.get(expandedId), $.get(item).id) });
													},
													[
														() => ($.get(item), $.untrack(() => merchant($.get(item)))),
														() => ($.get(item), $.untrack(() => category($.get(item)))),

														() => (
															$.get(item),
															$.untrack(() => dateLabel(transactionDate($.get(item))))
														),

														() => ($.get(item), $.untrack(() => money($.get(item).amount)))
													]
												);

												$.event('click', button_16, () => $.set(expandedId, $.strict_equals($.get(expandedId), $.get(item).id) ? null : $.get(item).id));
												$.append($$anchor, article);
											},
											($$anchor) => {
												var p_10 = root_41();

												$.append($$anchor, p_10);
											}
										),
										'each',
										Home,
										186,
										990
									);

									$.reset(div_28);

									var node_26 = $.sibling(div_28);

									{
										var consequent_15 = ($$anchor) => {
											var button_19 = root_42();
											var text_37 = $.child(button_19, true);

											$.reset(button_19);

											$.template_effect(() => $.set_text(text_37, (
												$.get(showAll),
												$.get(activeItems),

												$.untrack(() => $.get(showAll)
													? 'Show fewer ↑'
													: `View all ${$.get(activeItems).length} transactions ↓`)
											)));

											$.event('click', button_19, () => $.set(showAll, !$.get(showAll)));
											$.append($$anchor, button_19);
										};

										$.add_svelte_meta(
											() => $.if(node_26, ($$render) => {
												if ((
													$.get(activeItems),
													$.untrack(() => $.get(activeItems).length > 5)
												)) $$render(consequent_15);
											}),
											'if',
											Home,
											186,
											1694
										);
									}

									$.template_effect(
										($0, $1) => {
											$.set_text(text_32, $0);
											$.set_text(text_33, $1);
										},
										[
											() => (
												$.get(activityTab),
												$.get(selected),
												$.deep_read_state(selectedMonth()),

												$.untrack(() => $.strict_equals($.get(activityTab), 'recent')
													? 'RECENT EXPENSES'
													: $.get(selected)
														? `${$.get(selected).day} ${monthLabel(selectedMonth())}`
														: 'SELECT A DATE')
											),

											() => (
												$.get(activityTab),
												$.get(recentItems),
												$.get(selected),

												$.untrack(() => $.strict_equals($.get(activityTab), 'recent')
													? `${$.get(recentItems).length} recent transactions`
													: $.get(selected)
														? `${$.get(selected).transactionCount} transactions · ${money($.get(selected).totalSpend)}`
														: 'Choose a date in the calendar')
											)
										]
									);

									$.append($$anchor, fragment_10);
								};

								$.add_svelte_meta(
									() => $.if(
										node_24,
										($$render) => {
											if ($.strict_equals($.get(activityTab), 'day') && $.strict_equals($.get(dayStatus), 'error')) $$render(consequent_13); else $$render(alternate_7, false);
										},
										true
									),
									'if',
									Home,
									186,
									425
								);
							}

							$.append($$anchor, fragment_9);
						};

						$.add_svelte_meta(
							() => $.if(node_23, ($$render) => {
								if ($.strict_equals($.get(activityTab), 'day') && $.strict_equals($.get(dayStatus), 'loading')) $$render(consequent_12); else $$render(alternate_8, false);
							}),
							'if',
							Home,
							186,
							320
						);
					}

					$.reset(section_10);

					var button_20 = $.sibling(section_10, 2);
					var text_38 = $.child(button_20, true);

					$.reset(button_20);

					var button_21 = $.sibling(button_20);

					$.template_effect(
						($0) => {
							$.set_value(input, selectedMonth());
							$.set_attribute(input, 'max', $0);
							classes_4 = $.set_class(button_13, 1, '', null, classes_4, { active: $.strict_equals($.get(activityTab), 'recent') });
							classes_5 = $.set_class(button_14, 1, '', null, classes_5, { active: $.strict_equals($.get(activityTab), 'day') });

							$.set_text(text_31, (
								$.get(selected),
								$.untrack(() => $.get(selected) ? `${$.get(selected).day} selected` : 'Select a date')
							));

							button_20.disabled = !$.get(selected) || $.get(addingContext);

							$.set_text(text_38, $.get(addingContext)
								? 'Preparing WhatsApp…'
								: $.get(selected)
									? '+ Add missing expense'
									: 'Select a date to add an expense');
						},
						[() => ($.untrack(currentLocalMonth))]
					);

					$.event('click', button_10, () => changeMonth(-1));
					$.event('change', input, (e) => onMonthChange()(e.currentTarget.value));
					$.event('click', button_11, () => changeMonth(1));
					$.event('click', button_13, () => $.set(activityTab, 'recent'));
					$.event('click', button_14, () => $.set(activityTab, 'day'));
					$.event('click', button_20, addMissingDate);
					$.event('click', button_21, () => $.set(showNormalization, true));
					$.append($$anchor, fragment_8);
				};

				var alternate_11 = ($$anchor) => {
					var fragment_11 = $.comment();
					var node_27 = $.first_child(fragment_11);

					{
						var consequent_19 = ($$anchor) => {
							var fragment_12 = root_44();
							var div_32 = $.sibling($.first_child(fragment_12));

							$.add_svelte_meta(
								() => $.each(div_32, 4, () => ['All', 'Spending', 'Investing', 'Planning'], $.index, ($$anchor, filter) => {
									var button_22 = root_45();
									let classes_8;
									var text_39 = $.child(button_22, true);

									$.reset(button_22);

									$.template_effect(() => {
										classes_8 = $.set_class(button_22, 1, '', null, classes_8, { active: $.strict_equals($.get(storyFilter), filter) });
										$.set_text(text_39, filter);
									});

									$.event('click', button_22, () => {
										$.set(storyFilter, filter);
										$.set(storiesRailIndex, 0);
									});

									$.append($$anchor, button_22);
								}),
								'each',
								Home,
								189,
								208
							);

							$.reset(div_32);

							var div_33 = $.sibling(div_32);
							var button_23 = $.sibling($.child(div_33));
							let classes_9;
							var button_24 = $.sibling(button_23);
							let classes_10;

							$.reset(div_33);

							var node_28 = $.sibling(div_33);

							$.add_svelte_meta(
								() => SectionState(node_28, {
									get section() {
										return storiesSection();
									},

									title: 'Stories',

									get retry() {
										return refreshStories();
									},

									children: $.wrap_snippet(Home, ($$anchor, $$slotProps) => {
										var fragment_13 = $.comment();
										var node_29 = $.first_child(fragment_13);

										{
											var consequent_18 = ($$anchor) => {
												var div_34 = root_47();
												var div_35 = $.child(div_34);
												var node_30 = $.child(div_35);

												$.add_svelte_meta(
													() => $.each(node_30, 1, () => $.get(filteredStories), $.index, ($$anchor, story, index) => {
														var button_25 = root_48();
														let classes_11;

														$.template_effect(
															($0) => {
																$.set_attribute(button_25, 'aria-label', $0);
																$.set_attribute(button_25, 'aria-current', $.strict_equals(index, $.get(storiesRailIndex)) ? 'true' : undefined);
																classes_11 = $.set_class(button_25, 1, '', null, classes_11, { active: $.strict_equals(index, $.get(storiesRailIndex)) });
															},
															[
																() => (
																	index,
																	$.get(filteredStories),
																	$.get(story),
																	$.untrack(() => `Show story ${index + 1} of ${$.get(filteredStories).length}: ${storyCardFace($.get(story)).heading}`)
																)
															]
														);

														$.event('click', button_25, () => $.set(storiesRailIndex, index));
														$.append($$anchor, button_25);
													}),
													'each',
													Home,
													189,
													931
												);

												var span_11 = $.sibling(node_30);
												var text_40 = $.child(span_11);

												$.reset(span_11);
												$.reset(div_35);

												var div_36 = $.sibling(div_35);
												var div_37 = $.child(div_36);

												$.add_svelte_meta(
													() => $.each(div_37, 5, () => $.get(filteredStories), $.index, ($$anchor, story, index) => {
														var button_26 = root_49();
														let classes_12;
														var span_12 = $.child(button_26);
														var text_41 = $.child(span_12, true);

														$.reset(span_12);

														var node_31 = $.sibling(span_12);

														{
															var consequent_17 = ($$anchor) => {
																var span_13 = root_50();
																var text_42 = $.child(span_13, true);

																$.reset(span_13);

																$.template_effect(($0) => $.set_text(text_42, $0), [
																	() => ($.get(story), $.untrack(() => storyIcon($.get(story))))
																]);

																$.append($$anchor, span_13);
															};

															$.add_svelte_meta(
																() => $.if(node_31, ($$render) => {
																	if (($.get(story), $.untrack(() => storyIcon($.get(story))))) $$render(consequent_17);
																}),
																'if',
																Home,
																189,
																1902
															);
														}

														var strong_10 = $.sibling(node_31);
														var text_43 = $.child(strong_10, true);

														$.reset(strong_10);

														var b_7 = $.sibling(strong_10);
														var text_44 = $.child(b_7, true);

														$.reset(b_7);
														$.next();
														$.reset(button_26);

														$.template_effect(
															($0, $1, $2, $3, $4) => {
																classes_12 = $.set_class(button_26, 1, $0, null, classes_12, $1);
																$.set_text(text_41, $2);
																$.set_text(text_43, $3);
																$.set_text(text_44, $4);
															},
															[
																() => (
																	$.get(story),
																	$.untrack(() => `story-carousel-card ${storyTone($.get(story))}`)
																),

																() => ({
																	'commitment-card': isCommitment($.get(story)),
																	playful: isCommitment($.get(story)) && $.strict_equals($.get(commitmentStyle), 'playful'),
																	current: $.strict_equals(index, $.get(storiesRailIndex))
																}),

																() => ($.get(story), $.untrack(() => storySource($.get(story)))),
																() => ($.get(story), $.untrack(() => storyHeading($.get(story)))),

																() => (
																	$.get(story),
																	$.untrack(() => storyCardFace($.get(story)).displayValue)
																)
															]
														);

														$.event('click', button_26, () => openStory($.get(story)));
														$.append($$anchor, button_26);
													}),
													'each',
													Home,
													189,
													1570
												);

												$.reset(div_37);
												$.reset(div_36);
												$.reset(div_34);

												$.template_effect(() => {
													$.set_attribute(div_34, 'aria-label', `${$.get(storyFilter)} stories`);

													$.set_text(text_40, `${$.get(storiesRailIndex) + 1} / ${(
														$.get(filteredStories),
														$.untrack(() => $.get(filteredStories).length)
													) ?? ''}`);

													$.set_style(div_37, `transform:translateX(calc(${$.get(storiesRailIndex)} * -92%))`);
												});

												$.event('touchstart', div_36, (event) => $.set(storyRailTouchStart, event.touches[0].clientX));
												$.event('touchend', div_36, (event) => endRailSwipe(event, $.get(filteredStories).length, 'full'));
												$.append($$anchor, div_34);
											};

											var alternate_9 = ($$anchor) => {
												var div_38 = root_51();
												var h2_3 = $.sibling($.child(div_38));
												var text_45 = $.child(h2_3);

												$.reset(h2_3);
												$.next();
												$.reset(div_38);

												$.template_effect(($0) => $.set_text(text_45, `No ${$0 ?? ''} stories yet`), [
													() => (
														$.get(storyFilter),
														$.untrack(() => $.get(storyFilter).toLowerCase())
													)
												]);

												$.append($$anchor, div_38);
											};

											$.add_svelte_meta(
												() => $.if(node_29, ($$render) => {
													if ((
														$.get(filteredStories),
														$.untrack(() => $.get(filteredStories).length)
													)) $$render(consequent_18); else $$render(alternate_9, false);
												}),
												'if',
												Home,
												189,
												765
											);
										}

										$.append($$anchor, fragment_13);
									}),

									$$slots: { default: true }
								}),
								'component',
								Home,
								189,
								687,
								{ componentTag: 'SectionState' }
							);

							$.template_effect(() => {
								classes_9 = $.set_class(button_23, 1, '', null, classes_9, { active: $.strict_equals($.get(commitmentStyle), 'calm') });
								classes_10 = $.set_class(button_24, 1, '', null, classes_10, { active: $.strict_equals($.get(commitmentStyle), 'playful') });
							});

							$.event('click', button_23, () => setCommitmentStyle('calm'));
							$.event('click', button_24, () => setCommitmentStyle('playful'));
							$.append($$anchor, fragment_12);
						};

						var alternate_10 = ($$anchor) => {
							var fragment_14 = $.comment();
							var node_32 = $.first_child(fragment_14);

							$.add_svelte_meta(
								() => ProfileSettings(node_32, {
									get demoMode() {
										return demoMode();
									},

									get demoSwitching() {
										return $.get(demoSwitching);
									},

									get demoError() {
										return $.get(demoError);
									},

									get loggingOut() {
										return $.get(loggingOut);
									},

									get signOutError() {
										return $.get(signOutError);
									},

									get storyControls() {
										return storyControls;
									},

									onNavigate: navigate,
									onOpenMoney: openMoney,
									onDemoModeChange: switchDemoMode,
									onSignOut: signOut
								}),
								'component',
								Home,
								191,
								2,
								{ componentTag: 'ProfileSettings' }
							);

							$.append($$anchor, fragment_14);
						};

						$.add_svelte_meta(
							() => $.if(
								node_27,
								($$render) => {
									if ($.strict_equals($.get(view), 'stories')) $$render(consequent_19); else $$render(alternate_10, false);
								},
								true
							),
							'if',
							Home,
							188,
							0
						);
					}

					$.append($$anchor, fragment_11);
				};

				$.add_svelte_meta(
					() => $.if(
						node_19,
						($$render) => {
							if ($.strict_equals($.get(view), 'transactions')) $$render(consequent_16); else $$render(alternate_11, false);
						},
						true
					),
					'if',
					Home,
					183,
					0
				);
			}

			$.append($$anchor, fragment_7);
		};

		$.add_svelte_meta(
			() => $.if(node_14, ($$render) => {
				if ($.strict_equals($.get(view), 'home')) $$render(consequent_11); else $$render(alternate_12, false);
			}),
			'if',
			Home,
			177,
			0
		);
	}

	$.reset(main);

	var node_33 = $.sibling(main, 2);

	$.add_svelte_meta(
		() => BottomNav(node_33, {
			get view() {
				return $.get(view);
			},

			onNavigate: navigate
		}),
		'component',
		Home,
		194,
		0,
		{ componentTag: 'BottomNav' }
	);

	var node_34 = $.sibling(node_33, 2);

	{
		var consequent_51 = ($$anchor) => {
			var div_39 = root_53();
			var section_11 = $.child(div_39);
			var button_27 = $.child(section_11);
			var section_12 = $.sibling(button_27, 7);
			var node_35 = $.sibling($.child(section_12));

			{
				var consequent_20 = ($$anchor) => {
					var p_11 = root_54();

					$.append($$anchor, p_11);
				};

				var alternate_15 = ($$anchor) => {
					var fragment_15 = $.comment();
					var node_36 = $.first_child(fragment_15);

					{
						var consequent_21 = ($$anchor) => {
							var div_40 = root_56();
							var span_14 = $.child(div_40);
							var text_46 = $.child(span_14, true);

							$.reset(span_14);

							var button_28 = $.sibling(span_14);

							$.reset(div_40);
							$.template_effect(() => $.set_text(text_46, $.get(incomeError)));
							$.event('click', button_28, loadIncomeOutlook);
							$.append($$anchor, div_40);
						};

						var alternate_14 = ($$anchor) => {
							var fragment_16 = $.comment();
							var node_37 = $.first_child(fragment_16);

							{
								var consequent_22 = ($$anchor) => {
									var div_41 = root_58();
									var strong_11 = $.sibling($.child(div_41));
									var text_47 = $.child(strong_11, true);

									$.reset(strong_11);

									var button_29 = $.sibling(strong_11);

									$.next();
									$.reset(div_41);

									$.template_effect(() => $.set_text(text_47, (
										$.get(incomeOutlook),
										$.untrack(() => $.get(incomeOutlook).salary.maskedValue)
									)));

									$.event('click', button_29, openIncomeFlow);
									$.append($$anchor, div_41);
								};

								var alternate_13 = ($$anchor) => {
									var fragment_17 = root_59();
									var button_30 = $.sibling($.first_child(fragment_17));

									$.event('click', button_30, openIncomeFlow);
									$.append($$anchor, fragment_17);
								};

								$.add_svelte_meta(
									() => $.if(
										node_37,
										($$render) => {
											if ((
												$.get(incomeOutlook),
												$.untrack(() => $.get(incomeOutlook).salary)
											)) $$render(consequent_22); else $$render(alternate_13, false);
										},
										true
									),
									'if',
									Home,
									203,
									442
								);
							}

							$.append($$anchor, fragment_16);
						};

						$.add_svelte_meta(
							() => $.if(
								node_36,
								($$render) => {
									if ($.strict_equals($.get(incomeStatus), 'error')) $$render(consequent_21); else $$render(alternate_14, false);
								},
								true
							),
							'if',
							Home,
							203,
							292
						);
					}

					$.append($$anchor, fragment_15);
				};

				$.add_svelte_meta(
					() => $.if(node_35, ($$render) => {
						if ($.strict_equals($.get(incomeStatus), 'loading')) $$render(consequent_20); else $$render(alternate_15, false);
					}),
					'if',
					Home,
					203,
					226
				);
			}

			$.reset(section_12);

			var section_13 = $.sibling(section_12, 2);
			var node_38 = $.sibling($.child(section_13));

			{
				var consequent_23 = ($$anchor) => {
					var p_12 = root_60();

					$.append($$anchor, p_12);
				};

				var alternate_18 = ($$anchor) => {
					var fragment_18 = $.comment();
					var node_39 = $.first_child(fragment_18);

					{
						var consequent_24 = ($$anchor) => {
							var div_42 = root_62();
							var span_15 = $.child(div_42);
							var text_48 = $.child(span_15, true);

							$.reset(span_15);

							var button_31 = $.sibling(span_15);

							$.reset(div_42);
							$.template_effect(() => $.set_text(text_48, $.get(commitmentError)));
							$.event('click', button_31, loadCommitments);
							$.append($$anchor, div_42);
						};

						var alternate_17 = ($$anchor) => {
							var fragment_19 = $.comment();
							var node_40 = $.first_child(fragment_19);

							{
								var consequent_26 = ($$anchor) => {
									var fragment_20 = $.comment();
									var node_41 = $.first_child(fragment_20);

									$.add_svelte_meta(
										() => $.each(node_41, 1, () => $.get(commitments), $.index, ($$anchor, commitment) => {
											var article_1 = root_65();
											let classes_13;
											var div_43 = $.sibling($.child(article_1));
											var strong_12 = $.child(div_43);
											var text_49 = $.child(strong_12, true);
											var button_32 = $.sibling(text_49);
											var button_33 = $.sibling(button_32);
											var text_50 = $.child(button_33, true);

											$.reset(button_33);
											$.reset(strong_12);

											var small_2 = $.sibling(strong_12);
											var text_51 = $.child(small_2);

											$.reset(small_2);

											var small_3 = $.sibling(small_2);
											var text_52 = $.child(small_3, true);

											$.reset(small_3);

											var node_42 = $.sibling(small_3);

											{
												var consequent_25 = ($$anchor) => {
													var small_4 = root_66();
													var text_53 = $.child(small_4);

													$.reset(small_4);

													$.template_effect(($0) => $.set_text(text_53, `Next expected: ${$0 ?? ''}`), [
														() => (
															$.get(commitment),
															$.untrack(() => expectedLabel($.get(commitment).nextExpectedDate))
														)
													]);

													$.append($$anchor, small_4);
												};

												$.add_svelte_meta(
													() => $.if(node_42, ($$render) => {
														if ((
															$.get(commitment),
															$.untrack(() => $.get(commitment).nextExpectedDate)
														)) $$render(consequent_25);
													}),
													'if',
													Home,
													204,
													1348
												);
											}

											$.reset(div_43);

											var div_44 = $.sibling(div_43);
											var b_8 = $.child(div_44);
											var text_54 = $.child(b_8, true);

											$.reset(b_8);
											$.reset(div_44);

											var node_43 = $.sibling(div_44);

											$.add_svelte_meta(() => ViewDetailsLink(node_43, { onAction: () => openCommitmentHistory($.get(commitment)) }), 'component', Home, 204, 1518, { componentTag: 'ViewDetailsLink' });

											var button_34 = $.sibling(node_43);

											$.reset(article_1);

											$.template_effect(
												($0, $1, $2) => {
													classes_13 = $.set_class(article_1, 1, 'loan-row', null, classes_13, {
														'due-recurring': $.strict_equals($.get(commitment).currentOccurrence?.status, 'DUE')
													});

													$.set_attribute(article_1, 'data-testid', (
														$.get(commitment),
														$.untrack(() => `commitment-${$.get(commitment).id}`)
													));

													$.set_text(text_49, ($.get(commitment), $.untrack(() => $.get(commitment).label)));

													$.set_attribute(button_32, 'aria-label', (
														$.get(commitment),
														$.untrack(() => `Edit ${$.get(commitment).label}`)
													));

													$.set_attribute(button_33, 'aria-label', (
														$.get(commitment),
														$.untrack(() => `Delete ${$.get(commitment).label}`)
													));

													button_33.disabled = $.strict_equals($.get(commitmentDeletingId), null, false);

													$.set_text(text_50, (
														$.get(commitmentDeletingId),
														$.get(commitment),
														$.untrack(() => $.strict_equals($.get(commitmentDeletingId), $.get(commitment).id) ? '…' : '🗑')
													));

													$.set_text(text_51, `${(
														$.get(commitment),
														$.untrack(() => $.strict_equals($.get(commitment).amountMode, 'RECENT_BILL_ESTIMATE') ? 'Recent-bill estimate' : 'Planning amount')
													) ?? ''} · ${$0 ?? ''}`);

													$.set_text(text_52, $1);
													$.set_text(text_54, $2);
												},
												[
													() => (
														$.get(commitment),
														$.untrack(() => recurrenceLabel($.get(commitment)))
													),

													() => (
														$.get(commitment),

														$.untrack(() => $.strict_equals($.get(commitment).currentOccurrence?.status, 'COMPLETED')
															? 'Completed'
															: $.strict_equals($.get(commitment).status, 'ACTIVE') ? 'Active' : $.get(commitment).status.toLowerCase())
													),

													() => (
														$.get(commitment),
														$.untrack(() => money($.get(commitment).planningAmount))
													)
												]
											);

											$.event('click', button_32, () => openCommitmentForm($.get(commitment)));
											$.event('click', button_33, () => removeCommitment($.get(commitment)));
											$.event('click', button_34, () => openCompletion($.get(commitment)));
											$.append($$anchor, article_1);
										}),
										'each',
										Home,
										204,
										489
									);

									$.append($$anchor, fragment_20);
								};

								var alternate_16 = ($$anchor) => {
									var p_13 = root_67();

									$.append($$anchor, p_13);
								};

								$.add_svelte_meta(
									() => $.if(
										node_40,
										($$render) => {
											if ((
												$.get(commitments),
												$.untrack(() => $.get(commitments).length)
											)) $$render(consequent_26); else $$render(alternate_16, false);
										},
										true
									),
									'if',
									Home,
									204,
									460
								);
							}

							$.append($$anchor, fragment_19);
						};

						$.add_svelte_meta(
							() => $.if(
								node_39,
								($$render) => {
									if ($.strict_equals($.get(commitmentStatus), 'error')) $$render(consequent_24); else $$render(alternate_17, false);
								},
								true
							),
							'if',
							Home,
							204,
							304
						);
					}

					$.append($$anchor, fragment_18);
				};

				$.add_svelte_meta(
					() => $.if(node_38, ($$render) => {
						if ($.strict_equals($.get(commitmentStatus), 'loading')) $$render(consequent_23); else $$render(alternate_18, false);
					}),
					'if',
					Home,
					204,
					224
				);
			}

			var button_35 = $.sibling(node_38);

			$.reset(section_13);

			var section_14 = $.sibling(section_13, 2);
			var node_44 = $.sibling($.child(section_14));

			{
				var consequent_27 = ($$anchor) => {
					var p_14 = root_68();

					$.append($$anchor, p_14);
				};

				var alternate_21 = ($$anchor) => {
					var fragment_21 = $.comment();
					var node_45 = $.first_child(fragment_21);

					{
						var consequent_28 = ($$anchor) => {
							var div_45 = root_70();
							var span_16 = $.child(div_45);
							var text_55 = $.child(span_16, true);

							$.reset(span_16);

							var button_36 = $.sibling(span_16);

							$.reset(div_45);
							$.template_effect(() => $.set_text(text_55, $.get(creditCardError)));
							$.event('click', button_36, loadCreditCards);
							$.append($$anchor, div_45);
						};

						var alternate_20 = ($$anchor) => {
							var fragment_22 = $.comment();
							var node_46 = $.first_child(fragment_22);

							{
								var consequent_29 = ($$anchor) => {
									var fragment_23 = $.comment();
									var node_47 = $.first_child(fragment_23);

									$.add_svelte_meta(
										() => $.each(node_47, 1, () => $.get(creditCards), $.index, ($$anchor, card) => {
											var article_2 = root_73();
											var div_46 = $.sibling($.child(article_2));
											var strong_13 = $.child(div_46);
											var text_56 = $.child(strong_13, true);
											var button_37 = $.sibling(text_56);

											$.reset(strong_13);

											var small_5 = $.sibling(strong_13);
											var text_57 = $.child(small_5);

											$.reset(small_5);
											$.reset(div_46);

											var div_47 = $.sibling(div_46);
											var b_9 = $.child(div_47);
											var text_58 = $.child(b_9);

											$.reset(b_9);

											var small_6 = $.sibling(b_9);
											var text_59 = $.child(small_6);

											$.reset(small_6);
											$.reset(div_47);
											$.reset(article_2);

											$.template_effect(() => {
												$.set_text(text_56, ($.get(card), $.untrack(() => $.get(card).cardName)));
												$.set_attribute(button_37, 'aria-label', ($.get(card), $.untrack(() => `Edit ${$.get(card).cardName}`)));
												$.set_text(text_57, `${($.get(card), $.untrack(() => $.get(card).issuerName)) ?? ''} · captured as ${($.get(card), $.untrack(() => $.get(card).accountName)) ?? ''}`);
												$.set_text(text_58, `Due ${($.get(card), $.untrack(() => $.get(card).dueDay)) ?? ''}`);
												$.set_text(text_59, `Statement ${($.get(card), $.untrack(() => $.get(card).statementDay)) ?? ''}`);
											});

											$.event('click', button_37, () => openCreditCardForm($.get(card)));
											$.append($$anchor, article_2);
										}),
										'each',
										Home,
										205,
										446
									);

									$.append($$anchor, fragment_23);
								};

								var alternate_19 = ($$anchor) => {
									var p_15 = root_74();

									$.append($$anchor, p_15);
								};

								$.add_svelte_meta(
									() => $.if(
										node_46,
										($$render) => {
											if ((
												$.get(creditCards),
												$.untrack(() => $.get(creditCards).length)
											)) $$render(consequent_29); else $$render(alternate_19, false);
										},
										true
									),
									'if',
									Home,
									205,
									417
								);
							}

							$.append($$anchor, fragment_22);
						};

						$.add_svelte_meta(
							() => $.if(
								node_45,
								($$render) => {
									if ($.strict_equals($.get(creditCardStatus), 'error')) $$render(consequent_28); else $$render(alternate_20, false);
								},
								true
							),
							'if',
							Home,
							205,
							261
						);
					}

					$.append($$anchor, fragment_21);
				};

				$.add_svelte_meta(
					() => $.if(node_44, ($$render) => {
						if ($.strict_equals($.get(creditCardStatus), 'loading')) $$render(consequent_27); else $$render(alternate_21, false);
					}),
					'if',
					Home,
					205,
					180
				);
			}

			var button_38 = $.sibling(node_44);

			$.reset(section_14);

			var node_48 = $.sibling(section_14, 2);

			$.add_svelte_meta(
				() => $.each(
					node_48,
					0,
					() => [
						['◒', 'Emergency fund', 'Track your safety cushion'],
						['◎', 'Goals', 'Plan for what matters'],
						['▤', 'Budgets', 'Set gentle spending limits']
					],
					$.index,
					($$anchor, module) => {
						var button_39 = root_75();
						var span_17 = $.child(button_39);
						var text_60 = $.child(span_17, true);

						$.reset(span_17);

						var div_48 = $.sibling(span_17);
						var strong_14 = $.child(div_48);
						var text_61 = $.child(strong_14, true);

						$.reset(strong_14);

						var small_7 = $.sibling(strong_14);
						var text_62 = $.child(small_7, true);

						$.reset(small_7);
						$.reset(div_48);
						$.next();
						$.reset(button_39);

						$.template_effect(() => {
							$.set_text(text_60, (module, $.untrack(() => module[0])));
							$.set_text(text_61, (module, $.untrack(() => module[1])));
							$.set_text(text_62, (module, $.untrack(() => module[2])));
						});

						$.event('click', button_39, closeMoney);
						$.append($$anchor, button_39);
					}
				),
				'each',
				Home,
				206,
				6
			);

			var section_15 = $.sibling(node_48, 2);
			var node_49 = $.sibling($.child(section_15));

			{
				var consequent_30 = ($$anchor) => {
					var p_16 = root_76();

					$.append($$anchor, p_16);
				};

				var alternate_26 = ($$anchor) => {
					var fragment_24 = $.comment();
					var node_50 = $.first_child(fragment_24);

					{
						var consequent_31 = ($$anchor) => {
							var div_49 = root_78();
							var span_18 = $.child(div_49);
							var text_63 = $.child(span_18, true);

							$.reset(span_18);

							var button_40 = $.sibling(span_18);

							$.reset(div_49);
							$.template_effect(() => $.set_text(text_63, $.get(mutualFundError)));
							$.event('click', button_40, loadMutualFunds);
							$.append($$anchor, div_49);
						};

						var alternate_25 = ($$anchor) => {
							var fragment_25 = $.comment();
							var node_51 = $.first_child(fragment_25);

							{
								var consequent_36 = ($$anchor) => {
									var fragment_26 = root_80();
									var section_16 = $.first_child(fragment_26);
									var node_52 = $.sibling($.child(section_16));

									{
										var consequent_32 = ($$anchor) => {
											var fragment_27 = root_81();
											var strong_15 = $.first_child(fragment_27);
											var text_64 = $.child(strong_15, true);

											$.reset(strong_15);

											var small_8 = $.sibling(strong_15);
											let classes_14;
											var text_65 = $.child(small_8);

											$.reset(small_8);

											$.template_effect(
												($0, $1, $2) => {
													$.set_text(text_64, $0);
													classes_14 = $.set_class(small_8, 1, '', null, classes_14, $1);

													$.set_text(text_65, `${(
														$.get(mutualPortfolio),
														$.untrack(() => $.get(mutualPortfolio).pnl >= 0 ? '+' : '')
													) ?? ''}${$2 ?? ''} overall P&L`);
												},
												[
													() => (
														$.get(mutualPortfolio),
														$.untrack(() => money($.get(mutualPortfolio).current))
													),

													() => ({
														positive: Number($.get(mutualPortfolio).pnl) >= 0,
														negative: Number($.get(mutualPortfolio).pnl) < 0
													}),

													() => (
														$.get(mutualPortfolio),
														$.untrack(() => money($.get(mutualPortfolio).pnl))
													)
												]
											);

											$.append($$anchor, fragment_27);
										};

										var alternate_22 = ($$anchor) => {
											var fragment_28 = root_82();
											var strong_16 = $.first_child(fragment_28);
											var text_66 = $.child(strong_16, true);

											$.reset(strong_16);
											$.next();

											$.template_effect(($0) => $.set_text(text_66, $0), [
												() => (
													$.get(mutualPortfolio),
													$.untrack(() => money($.get(mutualPortfolio).invested))
												)
											]);

											$.append($$anchor, fragment_28);
										};

										$.add_svelte_meta(
											() => $.if(node_52, ($$render) => {
												if ((
													$.get(mutualPortfolio),
													$.untrack(() => $.strict_equals($.get(mutualPortfolio).current, null, false))
												)) $$render(consequent_32); else $$render(alternate_22, false);
											}),
											'if',
											Home,
											209,
											533
										);
									}

									$.reset(section_16);

									var div_50 = $.sibling(section_16);

									$.add_svelte_meta(
										() => $.each(div_50, 5, () => $.get(mutualFunds), $.index, ($$anchor, fund) => {
											var button_41 = root_83();
											var div_51 = $.sibling($.child(button_41));
											var strong_17 = $.child(div_51);
											var text_67 = $.child(strong_17, true);

											$.reset(strong_17);

											var span_19 = $.sibling(strong_17);
											var text_68 = $.child(span_19, true);

											$.reset(span_19);

											var small_9 = $.sibling(span_19);
											var text_69 = $.child(small_9, true);

											$.reset(small_9);
											$.reset(div_51);

											var node_53 = $.sibling(div_51);

											{
												var consequent_34 = ($$anchor) => {
													var fragment_29 = root_84();
													var div_52 = $.first_child(fragment_29);
													var div_53 = $.child(div_52);
													let classes_15;
													var b_10 = $.sibling($.child(div_53));
													var text_70 = $.child(b_10);

													$.reset(b_10);

													var small_10 = $.sibling(b_10);
													var text_71 = $.child(small_10);

													$.reset(small_10);
													$.reset(div_53);

													var div_54 = $.sibling(div_53);
													var b_11 = $.sibling($.child(div_54));
													var text_72 = $.child(b_11, true);

													$.reset(b_11);
													$.reset(div_54);

													var div_55 = $.sibling(div_54);
													var b_12 = $.sibling($.child(div_55));
													var text_73 = $.child(b_12, true);

													$.reset(b_12);
													$.reset(div_55);
													$.reset(div_52);

													var p_17 = $.sibling(div_52);
													var text_74 = $.child(p_17);
													var node_54 = $.sibling(text_74);

													{
														var consequent_33 = ($$anchor) => {
															var span_20 = root_85();

															$.template_effect(() => $.set_attribute(span_20, 'aria-label', (
																$.get(fund),
																$.untrack(() => `Set SIP for ${$.get(fund).schemeName}`)
															)));

															$.event('click', span_20, $.stopPropagation(() => openFundSipPlan($.get(fund))));

															$.event('keydown', span_20, $.stopPropagation((event) => {
																if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
																	event.preventDefault();
																	openFundSipPlan($.get(fund));
																}
															}));

															$.append($$anchor, span_20);
														};

														$.add_svelte_meta(
															() => $.if(node_54, ($$render) => {
																if (($.get(fund), $.untrack(() => !$.get(fund).activeSip))) $$render(consequent_33);
															}),
															'if',
															Home,
															209,
															2204
														);
													}

													$.reset(p_17);

													$.template_effect(
														($0, $1, $2, $3, $4, $5, $6, $7) => {
															classes_15 = $.set_class(div_53, 1, '', null, classes_15, $0);
															$.set_text(text_70, `${$1 ?? ''}${$2 ?? ''}`);
															$.set_text(text_71, `${$3 ?? ''}${$4 ?? ''}%`);
															$.set_text(text_72, $5);
															$.set_text(text_73, $6);
															$.set_text(text_74, `Latest NAV ${$7 ?? ''} `);
														},
														[
															() => ({
																positive: Number($.get(fund).profitOrLoss) >= 0,
																negative: Number($.get(fund).profitOrLoss) < 0
															}),

															() => (
																$.get(fund),
																$.untrack(() => Number($.get(fund).profitOrLoss) >= 0 ? '+' : '')
															),

															() => (
																$.get(fund),
																$.untrack(() => compactMoney($.get(fund).profitOrLoss))
															),

															() => (
																$.get(fund),
																$.untrack(() => Number($.get(fund).profitOrLossPercent) >= 0 ? '+' : '')
															),

															() => (
																$.get(fund),
																$.untrack(() => Number($.get(fund).profitOrLossPercent).toFixed(2))
															),

															() => (
																$.get(fund),
																$.untrack(() => compactMoney($.get(fund).invested))
															),

															() => (
																$.get(fund),
																$.untrack(() => compactMoney($.get(fund).currentValue))
															),

															() => (
																$.get(fund),
																$.untrack(() => moneyDecimal($.get(fund).latestNav))
															)
														]
													);

													$.append($$anchor, fragment_29);
												};

												var alternate_23 = ($$anchor) => {
													var p_18 = root_86();
													var text_75 = $.child(p_18);

													$.reset(p_18);

													$.template_effect(($0) => $.set_text(text_75, `Current valuation is temporarily unavailable. Your invested amount is ${$0 ?? ''}.`), [
														() => ($.get(fund), $.untrack(() => money($.get(fund).invested)))
													]);

													$.append($$anchor, p_18);
												};

												$.add_svelte_meta(
													() => $.if(node_53, ($$render) => {
														if ((
															$.get(fund),
															$.untrack(() => $.strict_equals($.get(fund).currentValue, null, false))
														)) $$render(consequent_34); else $$render(alternate_23, false);
													}),
													'if',
													Home,
													209,
													1628
												);
											}

											var footer = $.sibling(node_53);
											var span_21 = $.child(footer);
											var text_76 = $.child(span_21, true);

											$.reset(span_21);

											var span_22 = $.sibling(span_21);
											var span_23 = $.sibling($.child(span_22));

											$.reset(span_22);
											$.reset(footer);

											var node_55 = $.sibling(footer);

											{
												var consequent_35 = ($$anchor) => {
													var fragment_30 = $.comment();
													var node_56 = $.first_child(fragment_30);

													{
														let $0 = $.derived_safe_equal(() => (
															$.get(fund),
															$.untrack(() => `mutual-fund-sip-${$.get(fund).id}`)
														));

														let $1 = $.derived_safe_equal(() => (
															$.get(fund),
															$.untrack(() => `Due now · ${money($.get(fund).currentSip.amount)}`)
														));

														$.add_svelte_meta(
															() => DueReminder(node_56, {
																get testId() {
																	return $.get($0);
																},

																get detail() {
																	return $.get($1);
																},

																actionLabel: 'Confirm allocation',
																onAction: () => openSipConfirmation($.get(fund), $.get(fund).currentSip)
															}),
															'component',
															Home,
															209,
															3185,
															{ componentTag: 'DueReminder' }
														);
													}

													$.append($$anchor, fragment_30);
												};

												$.add_svelte_meta(
													() => $.if(node_55, ($$render) => {
														if ((
															$.get(fund),
															$.untrack(() => $.strict_equals($.get(fund).currentSip?.status, "DUE"))
														)) $$render(consequent_35);
													}),
													'if',
													Home,
													209,
													3148
												);
											}

											$.reset(button_41);

											$.template_effect(
												($0, $1, $2) => {
													$.set_class(button_41, 1, $0);

													$.set_attribute(button_41, 'aria-label', (
														$.get(fund),
														$.untrack(() => `Open ${$.get(fund).schemeName} details`)
													));

													$.set_text(text_67, ($.get(fund), $.untrack(() => $.get(fund).schemeName)));

													$.set_attribute(span_19, 'aria-label', (
														$.get(fund),
														$.untrack(() => `Delete ${$.get(fund).schemeName}`)
													));

													$.set_text(text_68, (
														$.get(mutualFundDeletingId),
														$.get(fund),
														$.untrack(() => $.strict_equals($.get(mutualFundDeletingId), $.get(fund).id) ? '…' : '🗑')
													));

													$.set_text(text_69, $1);
													$.set_text(text_76, $2);
												},
												[
													() => (
														$.get(fund),
														$.untrack(() => `fund-card ${fundAccent($.get(fund).id)}`)
													),

													() => (
														$.get(fund),
														$.untrack(() => fundSubtitle($.get(fund).schemeName))
													),

													() => (
														$.get(fund),

														$.untrack(() => $.get(fund).activeSip
															? `1 SIP · ${compactMoney($.get(fund).activeSip.amount)} on the ${$.get(fund).activeSip.day}${$.strict_equals($.get(fund).activeSip.day, 1)
																? 'st'
																: $.strict_equals($.get(fund).activeSip.day, 2)
																	? 'nd'
																	: $.strict_equals($.get(fund).activeSip.day, 3) ? 'rd' : 'th'} of every month`
															: 'No active SIP')
													)
												]
											);

											$.event('click', span_19, $.stopPropagation(() => removeMutualFund($.get(fund))));

											$.event('keydown', span_19, $.stopPropagation((event) => {
												if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
													event.preventDefault();
													removeMutualFund($.get(fund));
												}
											}));

											$.event('click', span_23, $.stopPropagation(() => openLumpSum($.get(fund))));
											$.event('click', button_41, () => openFundDetail($.get(fund).id));
											$.append($$anchor, button_41);
										}),
										'each',
										Home,
										209,
										962
									);

									$.reset(div_50);
									$.append($$anchor, fragment_26);
								};

								var alternate_24 = ($$anchor) => {
									var p_19 = root_88();

									$.append($$anchor, p_19);
								};

								$.add_svelte_meta(
									() => $.if(
										node_51,
										($$render) => {
											if ((
												$.get(mutualFunds),
												$.untrack(() => $.get(mutualFunds).length)
											)) $$render(consequent_36); else $$render(alternate_24, false);
										},
										true
									),
									'if',
									Home,
									209,
									437
								);
							}

							$.append($$anchor, fragment_25);
						};

						$.add_svelte_meta(
							() => $.if(
								node_50,
								($$render) => {
									if ($.strict_equals($.get(mutualFundStatus), 'error')) $$render(consequent_31); else $$render(alternate_25, false);
								},
								true
							),
							'if',
							Home,
							209,
							281
						);
					}

					$.append($$anchor, fragment_24);
				};

				$.add_svelte_meta(
					() => $.if(node_49, ($$render) => {
						if ($.strict_equals($.get(mutualFundStatus), 'loading')) $$render(consequent_30); else $$render(alternate_26, false);
					}),
					'if',
					Home,
					209,
					221
				);
			}

			var button_42 = $.sibling(node_49);

			$.reset(section_15);

			var section_17 = $.sibling(section_15, 2);
			var node_57 = $.sibling($.child(section_17), 2);

			{
				var consequent_37 = ($$anchor) => {
					var p_20 = root_89();

					$.append($$anchor, p_20);
				};

				var alternate_31 = ($$anchor) => {
					var fragment_31 = $.comment();
					var node_58 = $.first_child(fragment_31);

					{
						var consequent_38 = ($$anchor) => {
							var div_56 = root_91();
							var span_24 = $.child(div_56);
							var text_77 = $.child(span_24, true);

							$.reset(span_24);

							var button_43 = $.sibling(span_24);

							$.reset(div_56);
							$.template_effect(() => $.set_text(text_77, $.get(stockError)));
							$.event('click', button_43, loadStocks);
							$.append($$anchor, div_56);
						};

						var alternate_30 = ($$anchor) => {
							var fragment_32 = $.comment();
							var node_59 = $.first_child(fragment_32);

							{
								var consequent_42 = ($$anchor) => {
									var fragment_33 = root_93();
									var section_18 = $.first_child(fragment_33);
									var node_60 = $.sibling($.child(section_18));

									{
										var consequent_39 = ($$anchor) => {
											var fragment_34 = root_94();
											var strong_18 = $.first_child(fragment_34);
											var text_78 = $.child(strong_18, true);

											$.reset(strong_18);

											var small_11 = $.sibling(strong_18);
											let classes_16;
											var text_79 = $.child(small_11);

											$.reset(small_11);

											$.template_effect(
												($0, $1) => {
													$.set_text(text_78, $0);

													classes_16 = $.set_class(small_11, 1, '', null, classes_16, {
														positive: $.get(stockPortfolio).pnl >= 0,
														negative: $.get(stockPortfolio).pnl < 0
													});

													$.set_text(text_79, `${(
														$.get(stockPortfolio),
														$.untrack(() => $.get(stockPortfolio).pnl >= 0 ? '+' : '')
													) ?? ''}${$1 ?? ''} overall P&L`);
												},
												[
													() => (
														$.get(stockPortfolio),
														$.untrack(() => money($.get(stockPortfolio).current))
													),

													() => (
														$.get(stockPortfolio),
														$.untrack(() => money($.get(stockPortfolio).pnl))
													)
												]
											);

											$.append($$anchor, fragment_34);
										};

										var alternate_27 = ($$anchor) => {
											var fragment_35 = root_95();
											var strong_19 = $.first_child(fragment_35);
											var text_80 = $.child(strong_19, true);

											$.reset(strong_19);
											$.next();

											$.template_effect(($0) => $.set_text(text_80, $0), [
												() => (
													$.get(stockPortfolio),
													$.untrack(() => money($.get(stockPortfolio).invested))
												)
											]);

											$.append($$anchor, fragment_35);
										};

										$.add_svelte_meta(
											() => $.if(node_60, ($$render) => {
												if ((
													$.get(stockPortfolio),
													$.untrack(() => $.strict_equals($.get(stockPortfolio).current, null, false))
												)) $$render(consequent_39); else $$render(alternate_27, false);
											}),
											'if',
											Home,
											215,
											73
										);
									}

									$.reset(section_18);

									var div_57 = $.sibling(section_18, 2);

									$.add_svelte_meta(
										() => $.each(div_57, 5, () => $.get(stocks), $.index, ($$anchor, stock) => {
											var article_3 = root_96();
											let classes_17;
											var div_58 = $.sibling($.child(article_3));
											var strong_20 = $.child(div_58);
											var text_81 = $.child(strong_20, true);

											$.reset(strong_20);

											var span_25 = $.sibling(strong_20);
											var text_82 = $.child(span_25, true);

											$.reset(span_25);

											var small_12 = $.sibling(span_25);
											var text_83 = $.child(small_12);

											$.reset(small_12);
											$.reset(div_58);

											var node_61 = $.sibling(div_58, 2);

											{
												var consequent_40 = ($$anchor) => {
													var fragment_36 = root_97();
													var div_59 = $.first_child(fragment_36);
													var div_60 = $.child(div_59);
													let classes_18;
													var b_13 = $.sibling($.child(div_60));
													var text_84 = $.child(b_13);

													$.reset(b_13);

													var small_13 = $.sibling(b_13);
													var text_85 = $.child(small_13);

													$.reset(small_13);
													$.reset(div_60);

													var div_61 = $.sibling(div_60);
													var b_14 = $.sibling($.child(div_61));
													var text_86 = $.child(b_14, true);

													$.reset(b_14);
													$.reset(div_61);

													var div_62 = $.sibling(div_61);
													var b_15 = $.sibling($.child(div_62));
													var text_87 = $.child(b_15, true);

													$.reset(b_15);
													$.reset(div_62);
													$.reset(div_59);

													var p_21 = $.sibling(div_59);
													var text_88 = $.child(p_21);
													var button_44 = $.sibling(text_88);

													$.reset(p_21);

													$.template_effect(
														($0, $1, $2, $3, $4, $5, $6, $7, $8) => {
															classes_18 = $.set_class(div_60, 1, '', null, classes_18, $0);
															$.set_text(text_84, `${$1 ?? ''}${$2 ?? ''}`);
															$.set_text(text_85, `${$3 ?? ''}${$4 ?? ''}%`);
															$.set_text(text_86, $5);
															$.set_text(text_87, $6);
															$.set_text(text_88, `Latest price ${$7 ?? ''} · ${$8 ?? ''} shares `);

															$.set_attribute(button_44, 'aria-label', (
																$.get(stock),
																$.untrack(() => `Set monthly recurring plan for ${$.get(stock).name}`)
															));
														},
														[
															() => ({
																positive: Number($.get(stock).profitOrLoss) >= 0,
																negative: Number($.get(stock).profitOrLoss) < 0
															}),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).profitOrLoss) >= 0 ? '+' : '')
															),

															() => (
																$.get(stock),
																$.untrack(() => compactMoney($.get(stock).profitOrLoss))
															),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).profitOrLossPercent) >= 0 ? '+' : '')
															),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).profitOrLossPercent).toFixed(2))
															),

															() => (
																$.get(stock),
																$.untrack(() => compactMoney($.get(stock).invested))
															),

															() => (
																$.get(stock),
																$.untrack(() => compactMoney($.get(stock).currentValue))
															),

															() => (
																$.get(stock),
																$.untrack(() => moneyDecimal($.get(stock).latestPrice))
															),

															() => (
																$.get(stock),
																$.untrack(() => Number($.get(stock).quantity).toFixed(3))
															)
														]
													);

													$.event('click', button_44, () => openStockPlan($.get(stock)));
													$.append($$anchor, fragment_36);
												};

												var alternate_28 = ($$anchor) => {
													var p_22 = root_98();
													var text_89 = $.child(p_22);

													$.reset(p_22);

													$.template_effect(($0) => $.set_text(text_89, `Current price is temporarily unavailable. Your invested amount is ${$0 ?? ''}.`), [
														() => ($.get(stock), $.untrack(() => money($.get(stock).invested)))
													]);

													$.append($$anchor, p_22);
												};

												$.add_svelte_meta(
													() => $.if(node_61, ($$render) => {
														if ((
															$.get(stock),
															$.untrack(() => $.strict_equals($.get(stock).currentValue, null, false))
														)) $$render(consequent_40); else $$render(alternate_28, false);
													}),
													'if',
													Home,
													218,
													12
												);
											}

											var footer_1 = $.sibling(node_61, 2);
											var span_26 = $.child(footer_1);
											var text_90 = $.child(span_26, true);

											$.reset(span_26);

											var node_62 = $.sibling(span_26);

											$.add_svelte_meta(() => ViewDetailsLink(node_62, { onAction: () => openStockDetail($.get(stock).id) }), 'component', Home, 219, 322, { componentTag: 'ViewDetailsLink' });
											$.reset(footer_1);

											var node_63 = $.sibling(footer_1, 2);

											{
												var consequent_41 = ($$anchor) => {
													var fragment_37 = $.comment();
													var node_64 = $.first_child(fragment_37);

													{
														let $0 = $.derived_safe_equal(() => (
															$.get(stock),
															$.untrack(() => `stock-monthly-plan-${$.get(stock).id}`)
														));

														let $1 = $.derived_safe_equal(() => (
															$.get(stock),
															$.untrack(() => `Due now · ${money($.get(stock).currentMonthlyPlan.amount)}`)
														));

														$.add_svelte_meta(
															() => DueReminder(node_64, {
																get testId() {
																	return $.get($0);
																},

																get detail() {
																	return $.get($1);
																},

																actionLabel: 'Confirm allocation',

																onAction: () => {
																	$.set(stockPlanConfirmationTarget, $.get(stock));

																	$.set(stockPlanConfirmation, {
																		amount: String($.get(stock).currentMonthlyPlan.amount),
																		price: String($.get(stock).latestPrice || '')
																	});
																}
															}),
															'component',
															Home,
															220,
															58,
															{ componentTag: 'DueReminder' }
														);
													}

													$.append($$anchor, fragment_37);
												};

												$.add_svelte_meta(
													() => $.if(node_63, ($$render) => {
														if ((
															$.get(stock),
															$.untrack(() => $.strict_equals($.get(stock).currentMonthlyPlan?.status, 'DUE'))
														)) $$render(consequent_41);
													}),
													'if',
													Home,
													220,
													12
												);
											}

											$.reset(article_3);

											$.template_effect(
												($0, $1, $2) => {
													classes_17 = $.set_class(article_3, 1, $0, null, classes_17, $1);

													$.set_attribute(article_3, 'data-testid', (
														$.get(stock),
														$.untrack(() => `stock-card-${$.get(stock).id}`)
													));

													$.set_text(text_81, ($.get(stock), $.untrack(() => $.get(stock).name)));
													$.set_attribute(span_25, 'aria-label', ($.get(stock), $.untrack(() => `Delete ${$.get(stock).name}`)));

													$.set_text(text_82, (
														$.get(stockDeletingId),
														$.get(stock),
														$.untrack(() => $.strict_equals($.get(stockDeletingId), $.get(stock).id) ? '…' : '🗑')
													));

													$.set_text(text_83, `${($.get(stock), $.untrack(() => $.get(stock).symbol)) ?? ''}${(
														$.get(stock),
														$.untrack(() => $.get(stock).exchange ? ` · ${$.get(stock).exchange}` : '')
													) ?? ''}`);

													$.set_text(text_90, $2);
												},
												[
													() => (
														$.get(stock),
														$.untrack(() => `fund-card ${fundAccent($.get(stock).id)}`)
													),

													() => ({
														'due-stock': $.strict_equals(String($.get(stock).id), String($.get(highlightedStockId)))
													}),

													() => (
														$.get(stock),

														$.untrack(() => $.get(stock).activeMonthlyPlan
															? `Monthly plan · ${compactMoney($.get(stock).activeMonthlyPlan.amount)} on the ${$.get(stock).activeMonthlyPlan.day}${$.strict_equals($.get(stock).activeMonthlyPlan.day, 1)
																? 'st'
																: $.strict_equals($.get(stock).activeMonthlyPlan.day, 2)
																	? 'nd'
																	: $.strict_equals($.get(stock).activeMonthlyPlan.day, 3) ? 'rd' : 'th'}`
															: 'No monthly plan')
													)
												]
											);

											$.event('click', span_25, () => removeStock($.get(stock)));

											$.event('keydown', span_25, (event) => {
												if ($.strict_equals(event.key, 'Enter') || $.strict_equals(event.key, ' ')) {
													event.preventDefault();
													removeStock($.get(stock));
												}
											});

											$.append($$anchor, article_3);
										}),
										'each',
										Home,
										216,
										38
									);

									$.reset(div_57);
									$.append($$anchor, fragment_33);
								};

								var alternate_29 = ($$anchor) => {
									var p_23 = root_100();

									$.append($$anchor, p_23);
								};

								$.add_svelte_meta(
									() => $.if(
										node_59,
										($$render) => {
											if (($.get(stocks), $.untrack(() => $.get(stocks).length))) $$render(consequent_42); else $$render(alternate_29, false);
										},
										true
									),
									'if',
									Home,
									214,
									8
								);
							}

							$.append($$anchor, fragment_32);
						};

						$.add_svelte_meta(
							() => $.if(
								node_58,
								($$render) => {
									if ($.strict_equals($.get(stockStatus), 'error')) $$render(consequent_38); else $$render(alternate_30, false);
								},
								true
							),
							'if',
							Home,
							213,
							8
						);
					}

					$.append($$anchor, fragment_31);
				};

				$.add_svelte_meta(
					() => $.if(node_57, ($$render) => {
						if ($.strict_equals($.get(stockStatus), 'loading')) $$render(consequent_37); else $$render(alternate_31, false);
					}),
					'if',
					Home,
					212,
					8
				);
			}

			var button_45 = $.sibling(node_57, 2);

			$.reset(section_17);

			var section_19 = $.sibling(section_17, 2);
			var div_63 = $.child(section_19);
			var node_65 = $.sibling($.child(div_63));

			{
				var consequent_43 = ($$anchor) => {
					var div_64 = root_101();
					var b_16 = $.sibling($.child(div_64));
					var text_91 = $.child(b_16);

					$.reset(b_16);
					$.reset(div_64);

					$.template_effect(($0) => $.set_text(text_91, `${$0 ?? ''}/mo`), [
						() => (
							$.get(totalMonthlyEmi),
							$.untrack(() => money($.get(totalMonthlyEmi)))
						)
					]);

					$.append($$anchor, div_64);
				};

				$.add_svelte_meta(
					() => $.if(node_65, ($$render) => {
						if ((
							$.get(activeLoans),
							$.untrack(() => $.get(activeLoans).length)
						)) $$render(consequent_43);
					}),
					'if',
					Home,
					225,
					179
				);
			}

			$.reset(div_63);

			var node_66 = $.sibling(div_63, 2);

			{
				var consequent_44 = ($$anchor) => {
					var p_24 = root_102();

					$.append($$anchor, p_24);
				};

				var alternate_34 = ($$anchor) => {
					var fragment_38 = $.comment();
					var node_67 = $.first_child(fragment_38);

					{
						var consequent_45 = ($$anchor) => {
							var div_65 = root_104();
							var span_27 = $.child(div_65);
							var text_92 = $.child(span_27, true);

							$.reset(span_27);

							var button_46 = $.sibling(span_27);

							$.reset(div_65);
							$.template_effect(() => $.set_text(text_92, $.get(loanError)));
							$.event('click', button_46, loadLoans);
							$.append($$anchor, div_65);
						};

						var alternate_33 = ($$anchor) => {
							var fragment_39 = $.comment();
							var node_68 = $.first_child(fragment_39);

							{
								var consequent_48 = ($$anchor) => {
									var fragment_40 = $.comment();
									var node_69 = $.first_child(fragment_40);

									$.add_svelte_meta(
										() => $.each(node_69, 1, () => $.get(activeLoans), $.index, ($$anchor, loan) => {
											const schedule = $.tag($.derived_safe_equal(() => ($.get(loan), $.untrack(() => loanSchedule($.get(loan))))), 'schedule');

											$.get(schedule);

											var article_4 = root_107();
											let classes_19;
											var div_66 = $.sibling($.child(article_4));
											var strong_21 = $.child(div_66);
											var text_93 = $.child(strong_21, true);
											var button_47 = $.sibling(text_93);
											var button_48 = $.sibling(button_47);
											var text_94 = $.child(button_48, true);

											$.reset(button_48);
											$.reset(strong_21);

											var small_14 = $.sibling(strong_21);
											var text_95 = $.child(small_14);

											$.reset(small_14);
											$.reset(div_66);

											var div_67 = $.sibling(div_66);
											var b_17 = $.child(div_67);
											var text_96 = $.child(b_17);

											$.reset(b_17);

											var small_15 = $.sibling(b_17);
											var text_97 = $.child(small_15);

											$.reset(small_15);
											$.reset(div_67);

											var node_70 = $.sibling(div_67);

											$.add_svelte_meta(() => ViewDetailsLink(node_70, { onAction: () => openLoanHistory($.get(loan)) }), 'component', Home, 226, 1006, { componentTag: 'ViewDetailsLink' });

											var node_71 = $.sibling(node_70);

											{
												var consequent_46 = ($$anchor) => {
													var div_68 = root_108();
													var div_69 = $.child(div_68);
													var span_28 = $.child(div_69);
													var text_98 = $.child(span_28);

													$.reset(span_28);
													$.reset(div_69);

													var i_2 = $.sibling(div_69);

													$.reset(div_68);

													$.template_effect(() => {
														$.set_text(text_98, `${(
															$.deep_read_state($.get(schedule)),
															$.untrack(() => $.get(schedule).due)
														) ?? ''} of ${(
															$.deep_read_state($.get(schedule)),
															$.untrack(() => $.get(schedule).tenure)
														) ?? ''} historical EMI months completed`);

														$.set_style(i_2, (
															$.deep_read_state($.get(schedule)),
															$.untrack(() => `--loan-progress:${$.get(schedule).percent}%`)
														));
													});

													$.append($$anchor, div_68);
												};

												$.add_svelte_meta(
													() => $.if(node_71, ($$render) => {
														if ($.get(schedule)) $$render(consequent_46);
													}),
													'if',
													Home,
													226,
													1061
												);
											}

											var node_72 = $.sibling(node_71);

											{
												var consequent_47 = ($$anchor) => {
													var div_70 = root_109();
													var button_49 = $.sibling($.child(div_70), 2);
													var text_99 = $.child(button_49, true);

													$.reset(button_49);
													$.reset(div_70);

													$.template_effect(() => {
														button_49.disabled = $.strict_equals($.get(completingActionId), null, false);

														$.set_text(text_99, (
															$.get(completingActionId),
															$.get(highlightedLoanAction),
															$.untrack(() => $.strict_equals($.get(completingActionId), $.get(highlightedLoanAction).id) ? 'Marking loan closed…' : 'Mark final EMI paid')
														));
													});

													$.event('click', button_49, () => completeOpenAction($.get(highlightedLoanAction)));
													$.append($$anchor, div_70);
												};

												$.add_svelte_meta(
													() => $.if(node_72, ($$render) => {
														if ((
															$.get(loan),
															$.get(highlightedLoanId),
															$.get(highlightedLoanAction),
															$.untrack(() => $.strict_equals(String($.get(loan).id), String($.get(highlightedLoanId))) && $.get(highlightedLoanAction))
														)) $$render(consequent_47);
													}),
													'if',
													Home,
													226,
													1258
												);
											}

											$.reset(article_4);

											$.template_effect(
												($0, $1, $2, $3) => {
													classes_19 = $.set_class(article_4, 1, 'loan-row', null, classes_19, $0);
													$.set_text(text_93, ($.get(loan), $.untrack(() => $.get(loan).loanName)));
													$.set_attribute(button_47, 'aria-label', ($.get(loan), $.untrack(() => `Edit ${$.get(loan).loanName}`)));

													$.set_attribute(button_48, 'aria-label', (
														$.get(loan),
														$.untrack(() => `Delete ${$.get(loan).loanName}`)
													));

													button_48.disabled = $.strict_equals($.get(loanDeletingId), null, false);

													$.set_text(text_94, (
														$.get(loanDeletingId),
														$.get(loan),
														$.untrack(() => $.strict_equals($.get(loanDeletingId), $.get(loan).id) ? '…' : '🗑')
													));

													$.set_text(text_95, `${($.get(loan), $.untrack(() => $.get(loan).lenderName)) ?? ''} · ${$1 ?? ''} · ${($.get(loan), $.untrack(() => $.get(loan).totalTenureMonths)) ?? ''} months`);
													$.set_text(text_96, `${$2 ?? ''}/mo`);
													$.set_text(text_97, `${$3 ?? ''} principal`);
												},
												[
													() => ({
														'due-loan': $.strict_equals(String($.get(loan).id), String($.get(highlightedLoanId)))
													}),

													() => (
														$.get(loan),
														$.untrack(() => $.get(loan).loanType.replaceAll('_', ' '))
													),

													() => (
														$.get(loan),
														$.untrack(() => money($.get(loan).monthlyEmiAmount))
													),

													() => (
														$.get(loan),
														$.untrack(() => money($.get(loan).originalPrincipal))
													)
												]
											);

											$.event('click', button_47, () => openLoanForm($.get(loan)));
											$.event('click', button_48, () => removeLoan($.get(loan)));
											$.append($$anchor, article_4);
										}),
										'each',
										Home,
										226,
										248
									);

									$.append($$anchor, fragment_40);
								};

								var alternate_32 = ($$anchor) => {
									var p_25 = root_110();

									$.append($$anchor, p_25);
								};

								$.add_svelte_meta(
									() => $.if(
										node_68,
										($$render) => {
											if ((
												$.get(activeLoans),
												$.untrack(() => $.get(activeLoans).length)
											)) $$render(consequent_48); else $$render(alternate_32, false);
										},
										true
									),
									'if',
									Home,
									226,
									219
								);
							}

							$.append($$anchor, fragment_39);
						};

						$.add_svelte_meta(
							() => $.if(
								node_67,
								($$render) => {
									if ($.strict_equals($.get(loanStatus), 'error')) $$render(consequent_45); else $$render(alternate_33, false);
								},
								true
							),
							'if',
							Home,
							226,
							81
						);
					}

					$.append($$anchor, fragment_38);
				};

				$.add_svelte_meta(
					() => $.if(node_66, ($$render) => {
						if ($.strict_equals($.get(loanStatus), 'loading')) $$render(consequent_44); else $$render(alternate_34, false);
					}),
					'if',
					Home,
					226,
					8
				);
			}

			var node_73 = $.sibling(node_66, 2);

			{
				var consequent_50 = ($$anchor) => {
					var fragment_41 = root_111();
					var button_50 = $.first_child(fragment_41);
					var text_100 = $.child(button_50);
					var span_29 = $.sibling(text_100);
					var text_101 = $.child(span_29, true);

					$.reset(span_29);
					$.reset(button_50);

					var node_74 = $.sibling(button_50);

					{
						var consequent_49 = ($$anchor) => {
							var div_71 = root_112();

							$.add_svelte_meta(
								() => $.each(div_71, 5, () => $.get(closedLoans), $.index, ($$anchor, loan) => {
									var fragment_42 = $.comment();
									var node_75 = $.first_child(fragment_42);

									$.add_svelte_meta(
										() => ClosedLoanRow(node_75, {
											get loan() {
												return $.get(loan);
											},

											money
										}),
										'component',
										Home,
										227,
										343,
										{ componentTag: 'ClosedLoanRow' }
									);

									$.append($$anchor, fragment_42);
								}),
								'each',
								Home,
								227,
								316
							);

							$.reset(div_71);
							$.append($$anchor, div_71);
						};

						$.add_svelte_meta(
							() => $.if(node_74, ($$render) => {
								if ($.get(showClosedLoans)) $$render(consequent_49);
							}),
							'if',
							Home,
							227,
							264
						);
					}

					$.template_effect(() => {
						$.set_attribute(button_50, 'aria-expanded', $.get(showClosedLoans));

						$.set_text(text_100, `Closed loans · ${(
							$.get(closedLoans),
							$.untrack(() => $.get(closedLoans).length)
						) ?? ''}`);

						$.set_text(text_101, $.get(showClosedLoans) ? '⌃' : '⌄');
					});

					$.event('click', button_50, () => $.set(showClosedLoans, !$.get(showClosedLoans)));
					$.append($$anchor, fragment_41);
				};

				$.add_svelte_meta(
					() => $.if(node_73, ($$render) => {
						if ((
							$.get(closedLoans),
							$.untrack(() => $.get(closedLoans).length)
						)) $$render(consequent_50);
					}),
					'if',
					Home,
					227,
					8
				);
			}

			var button_51 = $.sibling(node_73, 2);

			$.reset(section_19);
			$.next(2);
			$.reset(section_11);
			$.reset(div_39);
			$.event('click', button_27, closeMoney);
			$.event('click', button_35, () => openCommitmentForm());
			$.event('click', button_38, () => openCreditCardForm());
			$.event('click', button_42, openMutualFundForm);
			$.event('click', button_45, openStockForm);
			$.event('click', button_51, () => openLoanForm());

			$.event('click', section_11, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_39, closeMoney);
			$.event('keydown', div_39, (event) => $.strict_equals(event.key, 'Escape') && closeMoney());
			$.append($$anchor, div_39);
		};

		$.add_svelte_meta(
			() => $.if(node_34, ($$render) => {
				if ($.get(showMoney)) $$render(consequent_51);
			}),
			'if',
			Home,
			197,
			0
		);
	}

	var node_76 = $.sibling(node_34, 2);

	{
		var consequent_53 = ($$anchor) => {
			var div_72 = root_114();
			var section_20 = $.child(div_72);
			var button_52 = $.child(section_20);
			var h2_4 = $.sibling(button_52, 2);
			var text_102 = $.child(h2_4, true);

			$.reset(h2_4);

			var label_1 = $.sibling(h2_4, 2);
			var input_1 = $.sibling($.child(label_1));

			$.remove_input_defaults(input_1);
			$.reset(label_1);

			var label_2 = $.sibling(label_1);
			var input_2 = $.sibling($.child(label_2));

			$.remove_input_defaults(input_2);
			$.reset(label_2);

			var label_3 = $.sibling(label_2);
			var select = $.sibling($.child(label_3));

			$.template_effect(() => {
				$.get(commitmentForm);
				$.invalidate_inner_signals(() => {});
			});

			$.add_svelte_meta(
				() => $.each(select, 4, () => ['DAY', 'WEEK', 'MONTH', 'YEAR'], $.index, ($$anchor, unit) => {
					var option_1 = root_115();
					var text_103 = $.child(option_1, true);

					$.reset(option_1);

					var option_1_value = {};

					$.template_effect(
						($0) => {
							$.set_text(text_103, $0);

							if (option_1_value !== (option_1_value = unit)) {
								option_1.value = (option_1.__value = unit) ?? '';
							}
						},
						[() => (unit, $.untrack(() => unit.toLowerCase()))]
					);

					$.append($$anchor, option_1);
				}),
				'each',
				Home,
				234,
				690
			);

			$.reset(select);
			$.reset(label_3);

			var label_4 = $.sibling(label_3);
			var input_3 = $.sibling($.child(label_4));

			$.remove_input_defaults(input_3);
			$.reset(label_4);

			var label_5 = $.sibling(label_4);
			var input_4 = $.sibling($.child(label_5));

			$.remove_input_defaults(input_4);
			$.reset(label_5);

			var label_6 = $.sibling(label_5);
			var input_5 = $.child(label_6);

			$.remove_input_defaults(input_5);
			$.next();
			$.reset(label_6);

			var label_7 = $.sibling(label_6);
			var select_1 = $.sibling($.child(label_7));

			$.template_effect(() => {
				$.get(commitmentForm);
				$.invalidate_inner_signals(() => {});
			});

			var option_2 = $.child(select_1);

			option_2.value = option_2.__value = 'FIXED';

			var option_3 = $.sibling(option_2);

			option_3.value = option_3.__value = 'USER_ESTIMATE';
			$.reset(select_1);
			$.reset(label_7);

			var node_77 = $.sibling(label_7);

			{
				var consequent_52 = ($$anchor) => {
					var p_26 = root_116();
					var text_104 = $.child(p_26, true);

					$.reset(p_26);
					$.template_effect(() => $.set_text(text_104, $.get(commitmentError)));
					$.append($$anchor, p_26);
				};

				$.add_svelte_meta(
					() => $.if(node_77, ($$render) => {
						if ($.get(commitmentError)) $$render(consequent_52);
					}),
					'if',
					Home,
					234,
					1303
				);
			}

			var div_73 = $.sibling(node_77);
			var button_53 = $.child(div_73);
			var button_54 = $.sibling(button_53);
			var text_105 = $.child(button_54, true);

			$.reset(button_54);
			$.reset(div_73);
			$.reset(section_20);
			$.reset(div_72);

			$.template_effect(() => {
				$.set_text(text_102, $.strict_equals($.get(commitmentEditingId), null) ? 'Add a repeatable obligation' : 'Edit commitment');
				button_54.disabled = $.get(commitmentSaving);

				$.set_text(text_105, $.get(commitmentSaving)
					? 'Saving…'
					: $.strict_equals($.get(commitmentEditingId), null) ? 'Add commitment' : 'Save changes');
			});

			$.event('click', button_52, () => $.set(showCommitmentForm, false));

			$.bind_value(
				input_1,
				function get() {
					return $.get(commitmentForm).label;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).label = $$value);
				}
			);

			$.bind_value(
				input_2,
				function get() {
					return $.get(commitmentForm).planningAmount;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).planningAmount = $$value);
				}
			);

			$.bind_select_value(
				select,
				function get() {
					return $.get(commitmentForm).recurrenceUnit;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).recurrenceUnit = $$value);
				}
			);

			$.bind_value(
				input_3,
				function get() {
					return $.get(commitmentForm).recurrenceInterval;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).recurrenceInterval = $$value);
				}
			);

			$.bind_value(
				input_4,
				function get() {
					return $.get(commitmentForm).nextExpectedDate;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).nextExpectedDate = $$value);
				}
			);

			$.bind_checked(
				input_5,
				function get() {
					return $.get(commitmentForm).flexibleSchedule;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).flexibleSchedule = $$value);
				}
			);

			$.bind_select_value(
				select_1,
				function get() {
					return $.get(commitmentForm).amountMode;
				},
				function set($$value) {
					$.mutate(commitmentForm, $.get(commitmentForm).amountMode = $$value);
				}
			);

			$.event('click', button_53, () => $.set(showCommitmentForm, false));
			$.event('click', button_54, saveCommitment);
			$.append($$anchor, div_72);
		};

		$.add_svelte_meta(
			() => $.if(node_76, ($$render) => {
				if ($.get(showCommitmentForm)) $$render(consequent_53);
			}),
			'if',
			Home,
			234,
			0
		);
	}

	var node_78 = $.sibling(node_76, 2);

	{
		var consequent_54 = ($$anchor) => {
			var div_74 = root_117();
			var section_21 = $.child(div_74);
			var button_55 = $.child(section_21);
			var h2_5 = $.sibling(button_55, 2);
			var text_106 = $.child(h2_5);

			$.reset(h2_5);

			var label_8 = $.sibling(h2_5);
			var input_6 = $.sibling($.child(label_8));

			$.remove_input_defaults(input_6);
			$.reset(label_8);

			var label_9 = $.sibling(label_8);
			var input_7 = $.sibling($.child(label_9));

			$.remove_input_defaults(input_7);
			$.reset(label_9);

			var label_10 = $.sibling(label_9);
			var input_8 = $.sibling($.child(label_10));

			$.remove_input_defaults(input_8);
			$.reset(label_10);

			var button_56 = $.sibling(label_10);
			var text_107 = $.child(button_56);

			$.reset(button_56);

			var div_75 = $.sibling(button_56);
			var button_57 = $.child(div_75);
			var button_58 = $.sibling(button_57);

			$.reset(div_75);
			$.reset(section_21);
			$.reset(div_74);

			$.template_effect(
				($0) => {
					$.set_text(text_106, `Mark ${(
						$.get(completionCommitment),
						$.untrack(() => $.get(completionCommitment).label)
					) ?? ''} completed`);

					$.set_text(text_107, `In ${(
						$.get(completionCommitment),
						$.untrack(() => $.get(completionCommitment).recurrenceInterval || 1)
					) ?? ''} ${$0 ?? ''}(s)`);
				},
				[
					() => (
						$.get(completionCommitment),
						$.untrack(() => String($.get(completionCommitment).recurrenceUnit || 'MONTH').toLowerCase())
					)
				]
			);

			$.event('click', button_55, () => $.set(completionCommitment, null));

			$.bind_value(
				input_6,
				function get() {
					return $.get(completionForm).actualAmount;
				},
				function set($$value) {
					$.mutate(completionForm, $.get(completionForm).actualAmount = $$value);
				}
			);

			$.bind_value(
				input_7,
				function get() {
					return $.get(completionForm).completedAt;
				},
				function set($$value) {
					$.mutate(completionForm, $.get(completionForm).completedAt = $$value);
				}
			);

			$.bind_value(
				input_8,
				function get() {
					return $.get(completionForm).nextExpectedDate;
				},
				function set($$value) {
					$.mutate(completionForm, $.get(completionForm).nextExpectedDate = $$value);
				}
			);

			$.event('click', button_56, () => addMonths(Number($.get(completionCommitment).recurrenceInterval || 1)));
			$.event('click', button_57, () => $.set(completionCommitment, null));
			$.event('click', button_58, saveCompletion);
			$.append($$anchor, div_74);
		};

		$.add_svelte_meta(
			() => $.if(node_78, ($$render) => {
				if ($.get(completionCommitment)) $$render(consequent_54);
			}),
			'if',
			Home,
			235,
			0
		);
	}

	var node_79 = $.sibling(node_78, 2);

	{
		var consequent_56 = ($$anchor) => {
			var div_76 = root_118();
			var section_22 = $.child(div_76);
			var button_59 = $.child(section_22);
			var h2_6 = $.sibling(button_59, 2);
			var text_108 = $.child(h2_6, true);

			$.reset(h2_6);

			var label_11 = $.sibling(h2_6, 2);
			var select_2 = $.sibling($.child(label_11));

			$.template_effect(() => {
				$.get(creditCardForm);

				$.invalidate_inner_signals(() => {
					$.get(editOptions);
					String;
				});
			});

			var option_4 = $.child(select_2);

			option_4.value = option_4.__value = '';

			var node_80 = $.sibling(option_4);

			$.add_svelte_meta(
				() => $.each(
					node_80,
					1,
					() => (
						$.get(editOptions),
						$.untrack(() => $.get(editOptions).accounts)
					),
					$.index,
					($$anchor, account) => {
						var option_5 = root_119();
						var text_109 = $.child(option_5, true);

						$.reset(option_5);

						var option_5_value = {};

						$.template_effect(
							($0) => {
								$.set_text(text_109, ($.get(account), $.untrack(() => $.get(account).name)));

								if (option_5_value !== (option_5_value = $0)) {
									option_5.value = (option_5.__value = $0) ?? '';
								}
							},
							[
								() => ($.get(account), $.untrack(() => String($.get(account).id)))
							]
						);

						$.append($$anchor, option_5);
					}
				),
				'each',
				Home,
				236,
				586
			);

			$.reset(select_2);
			$.reset(label_11);

			var label_12 = $.sibling(label_11);
			var input_9 = $.sibling($.child(label_12));

			$.remove_input_defaults(input_9);
			$.reset(label_12);

			var label_13 = $.sibling(label_12);
			var input_10 = $.sibling($.child(label_13));

			$.remove_input_defaults(input_10);
			$.reset(label_13);

			var label_14 = $.sibling(label_13);
			var input_11 = $.sibling($.child(label_14));

			$.remove_input_defaults(input_11);
			$.reset(label_14);

			var label_15 = $.sibling(label_14);
			var input_12 = $.sibling($.child(label_15));

			$.remove_input_defaults(input_12);
			$.reset(label_15);

			var node_81 = $.sibling(label_15);

			{
				var consequent_55 = ($$anchor) => {
					var p_27 = root_120();
					var text_110 = $.child(p_27, true);

					$.reset(p_27);
					$.template_effect(() => $.set_text(text_110, $.get(creditCardError)));
					$.append($$anchor, p_27);
				};

				$.add_svelte_meta(
					() => $.if(node_81, ($$render) => {
						if ($.get(creditCardError)) $$render(consequent_55);
					}),
					'if',
					Home,
					236,
					1161
				);
			}

			var div_77 = $.sibling(node_81);
			var button_60 = $.child(div_77);
			var button_61 = $.sibling(button_60);
			var text_111 = $.child(button_61, true);

			$.reset(button_61);
			$.reset(div_77);
			$.reset(section_22);
			$.reset(div_76);

			$.template_effect(() => {
				$.set_text(text_108, $.strict_equals($.get(creditCardEditingId), null) ? 'Add a credit card' : 'Edit credit card');
				button_61.disabled = $.get(creditCardSaving) || $.strict_equals($.get(optionsStatus), 'ready', false);

				$.set_text(text_111, $.get(creditCardSaving)
					? 'Saving…'
					: $.strict_equals($.get(creditCardEditingId), null) ? 'Add credit card' : 'Save changes');
			});

			$.event('click', button_59, () => $.set(showCreditCardForm, false));

			$.bind_select_value(
				select_2,
				function get() {
					return $.get(creditCardForm).accountReferenceId;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).accountReferenceId = $$value);
				}
			);

			$.bind_value(
				input_9,
				function get() {
					return $.get(creditCardForm).cardName;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).cardName = $$value);
				}
			);

			$.bind_value(
				input_10,
				function get() {
					return $.get(creditCardForm).issuerName;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).issuerName = $$value);
				}
			);

			$.bind_value(
				input_11,
				function get() {
					return $.get(creditCardForm).statementDay;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).statementDay = $$value);
				}
			);

			$.bind_value(
				input_12,
				function get() {
					return $.get(creditCardForm).dueDay;
				},
				function set($$value) {
					$.mutate(creditCardForm, $.get(creditCardForm).dueDay = $$value);
				}
			);

			$.event('click', button_60, () => $.set(showCreditCardForm, false));
			$.event('click', button_61, saveCreditCard);
			$.append($$anchor, div_76);
		};

		$.add_svelte_meta(
			() => $.if(node_79, ($$render) => {
				if ($.get(showCreditCardForm)) $$render(consequent_56);
			}),
			'if',
			Home,
			236,
			0
		);
	}

	var node_82 = $.sibling(node_79, 2);

	{
		var consequent_59 = ($$anchor) => {
			var div_78 = root_121();
			var section_23 = $.child(div_78);
			var button_62 = $.child(section_23);
			var div_79 = $.sibling(button_62, 4);

			$.add_svelte_meta(
				() => $.each(
					div_79,
					4,
					() => [
						'UNDER_25000',
						'FROM_25000_TO_50000',
						'FROM_50000_TO_100000',
						'FROM_100000_TO_200000',
						'OVER_200000'
					],
					$.index,
					($$anchor, range) => {
						var button_63 = root_122();
						let classes_20;
						var text_112 = $.child(button_63, true);

						$.reset(button_63);

						$.template_effect(
							($0) => {
								classes_20 = $.set_class(button_63, 1, '', null, classes_20, {
									active: $.strict_equals($.get(salaryForm).salaryRange, range) && $.strict_equals($.get(salaryForm).salaryVisibility, 'RANGE')
								});

								$.set_text(text_112, $0);
							},
							[() => (range, $.untrack(() => incomeRangeLabel(range)))]
						);

						$.event('click', button_63, () => {
							$.mutate(salaryForm, $.get(salaryForm).salaryVisibility = 'RANGE');
							$.mutate(salaryForm, $.get(salaryForm).salaryRange = range);
						});

						$.append($$anchor, button_63);
					}
				),
				'each',
				Home,
				237,
				451
			);

			$.reset(div_79);

			var button_64 = $.sibling(div_79);
			var text_113 = $.child(button_64, true);

			$.reset(button_64);

			var node_83 = $.sibling(button_64);

			{
				var consequent_57 = ($$anchor) => {
					var label_16 = root_123();
					var input_13 = $.sibling($.child(label_16));

					$.remove_input_defaults(input_13);
					$.reset(label_16);

					$.bind_value(
						input_13,
						function get() {
							return $.get(salaryForm).exactMonthlySalary;
						},
						function set($$value) {
							$.mutate(salaryForm, $.get(salaryForm).exactMonthlySalary = $$value);
						}
					);

					$.append($$anchor, label_16);
				};

				$.add_svelte_meta(
					() => $.if(node_83, ($$render) => {
						if ((
							$.get(salaryForm),
							$.untrack(() => $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT'))
						)) $$render(consequent_57);
					}),
					'if',
					Home,
					237,
					1045
				);
			}

			var label_17 = $.sibling(node_83);
			var select_3 = $.sibling($.child(label_17));

			$.template_effect(() => {
				$.get(salaryForm);
				$.invalidate_inner_signals(() => {});
			});

			$.add_svelte_meta(
				() => $.each(select_3, 4, () => ['MONTHLY', 'TWICE_MONTHLY', 'WEEKLY', 'IRREGULAR'], $.index, ($$anchor, frequency) => {
					var option_6 = root_124();
					var text_114 = $.child(option_6, true);

					$.reset(option_6);

					var option_6_value = {};

					$.template_effect(
						($0) => {
							$.set_text(text_114, $0);

							if (option_6_value !== (option_6_value = frequency)) {
								option_6.value = (option_6.__value = frequency) ?? '';
							}
						},
						[
							() => (
								frequency,
								$.untrack(() => frequency.replaceAll('_', ' ').toLowerCase())
							)
						]
					);

					$.append($$anchor, option_6);
				}),
				'each',
				Home,
				237,
				1341
			);

			$.reset(select_3);
			$.reset(label_17);

			var node_84 = $.sibling(label_17);

			{
				var consequent_58 = ($$anchor) => {
					var p_28 = root_125();
					var text_115 = $.child(p_28, true);

					$.reset(p_28);
					$.template_effect(() => $.set_text(text_115, $.get(incomeError)));
					$.append($$anchor, p_28);
				};

				$.add_svelte_meta(
					() => $.if(node_84, ($$render) => {
						if ($.get(incomeError)) $$render(consequent_58);
					}),
					'if',
					Home,
					237,
					1514
				);
			}

			var div_80 = $.sibling(node_84);
			var button_65 = $.child(div_80);
			var button_66 = $.sibling(button_65);
			var text_116 = $.child(button_66, true);

			$.reset(button_66);
			$.reset(div_80);
			$.reset(section_23);
			$.reset(div_78);

			$.template_effect(() => {
				$.set_text(text_113, (
					$.get(salaryForm),

					$.untrack(() => $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT')
						? 'Use a range instead'
						: 'I’m comfortable sharing the exact amount')
				));

				button_65.disabled = $.get(incomeSaving);
				button_66.disabled = $.get(incomeSaving);
				$.set_text(text_116, $.get(incomeSaving) ? 'Saving…' : 'Save salary outlook');
			});

			$.event('click', button_62, () => $.set(showIncomeFlow, false));
			$.event('click', button_64, () => $.mutate(salaryForm, $.get(salaryForm).salaryVisibility = $.strict_equals($.get(salaryForm).salaryVisibility, 'EXACT') ? 'RANGE' : 'EXACT'));

			$.bind_select_value(
				select_3,
				function get() {
					return $.get(salaryForm).salaryFrequency;
				},
				function set($$value) {
					$.mutate(salaryForm, $.get(salaryForm).salaryFrequency = $$value);
				}
			);

			$.event('click', button_65, () => {
				$.mutate(salaryForm, $.get(salaryForm).salaryVisibility = 'SKIPPED');
				saveSalary();
			});

			$.event('click', button_66, saveSalary);
			$.append($$anchor, div_78);
		};

		$.add_svelte_meta(
			() => $.if(node_82, ($$render) => {
				if ($.get(showIncomeFlow)) $$render(consequent_59);
			}),
			'if',
			Home,
			237,
			0
		);
	}

	var node_85 = $.sibling(node_82, 2);

	{
		var consequent_61 = ($$anchor) => {
			var div_81 = root_126();
			var section_24 = $.child(div_81);
			var button_67 = $.child(section_24);
			var h2_7 = $.sibling(button_67, 2);
			var text_117 = $.child(h2_7, true);

			$.reset(h2_7);

			var label_18 = $.sibling(h2_7, 2);
			var input_14 = $.sibling($.child(label_18));

			$.remove_input_defaults(input_14);
			$.reset(label_18);

			var label_19 = $.sibling(label_18);
			var select_4 = $.sibling($.child(label_19));

			$.template_effect(() => {
				$.get(loanForm);
				$.invalidate_inner_signals(() => {});
			});

			$.add_svelte_meta(
				() => $.each(
					select_4,
					4,
					() => [
						'HOME',
						'VEHICLE',
						'PERSONAL',
						'EDUCATION',
						'CREDIT_CARD_EMI',
						'OTHER'
					],
					$.index,
					($$anchor, type) => {
						var option_7 = root_127();
						var text_118 = $.child(option_7, true);

						$.reset(option_7);

						var option_7_value = {};

						$.template_effect(
							($0) => {
								$.set_text(text_118, $0);

								if (option_7_value !== (option_7_value = type)) {
									option_7.value = (option_7.__value = type) ?? '';
								}
							},
							[() => (type, $.untrack(() => type.replaceAll('_', ' ')))]
						);

						$.append($$anchor, option_7);
					}
				),
				'each',
				Home,
				239,
				568
			);

			$.reset(select_4);
			$.reset(label_19);

			var label_20 = $.sibling(label_19);
			var input_15 = $.sibling($.child(label_20));

			$.remove_input_defaults(input_15);
			$.reset(label_20);

			var label_21 = $.sibling(label_20);
			var input_16 = $.sibling($.child(label_21));

			$.remove_input_defaults(input_16);
			$.reset(label_21);

			var label_22 = $.sibling(label_21);
			var input_17 = $.sibling($.child(label_22));

			$.remove_input_defaults(input_17);
			$.reset(label_22);

			var label_23 = $.sibling(label_22);
			var input_18 = $.sibling($.child(label_23));

			$.remove_input_defaults(input_18);
			$.reset(label_23);

			var label_24 = $.sibling(label_23);
			var input_19 = $.sibling($.child(label_24));

			$.remove_input_defaults(input_19);
			$.reset(label_24);

			var label_25 = $.sibling(label_24);
			var input_20 = $.sibling($.child(label_25), 2);

			$.remove_input_defaults(input_20);
			$.reset(label_25);

			var node_86 = $.sibling(label_25);

			{
				var consequent_60 = ($$anchor) => {
					var p_29 = root_128();
					var text_119 = $.child(p_29, true);

					$.reset(p_29);
					$.template_effect(() => $.set_text(text_119, $.get(loanError)));
					$.append($$anchor, p_29);
				};

				$.add_svelte_meta(
					() => $.if(node_86, ($$render) => {
						if ($.get(loanError)) $$render(consequent_60);
					}),
					'if',
					Home,
					239,
					1526
				);
			}

			var div_82 = $.sibling(node_86);
			var button_68 = $.child(div_82);
			var button_69 = $.sibling(button_68);
			var text_120 = $.child(button_69, true);

			$.reset(button_69);
			$.reset(div_82);
			$.reset(section_24);
			$.reset(div_81);

			$.template_effect(() => {
				$.set_text(text_117, $.equals($.get(loanEditingId), null) ? 'Add a loan' : 'Edit loan');
				button_69.disabled = $.get(loanSaving);

				$.set_text(text_120, $.get(loanSaving)
					? 'Saving…'
					: $.equals($.get(loanEditingId), null) ? 'Add loan' : 'Save changes');
			});

			$.event('click', button_67, () => $.set(showLoanForm, false));

			$.bind_value(
				input_14,
				function get() {
					return $.get(loanForm).loanName;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).loanName = $$value);
				}
			);

			$.bind_select_value(
				select_4,
				function get() {
					return $.get(loanForm).loanType;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).loanType = $$value);
				}
			);

			$.bind_value(
				input_15,
				function get() {
					return $.get(loanForm).originalPrincipal;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).originalPrincipal = $$value);
				}
			);

			$.bind_value(
				input_16,
				function get() {
					return $.get(loanForm).monthlyEmiAmount;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).monthlyEmiAmount = $$value);
				}
			);

			$.bind_value(
				input_17,
				function get() {
					return $.get(loanForm).totalTenureMonths;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).totalTenureMonths = $$value);
				}
			);

			$.bind_value(
				input_18,
				function get() {
					return $.get(loanForm).firstEmiDueDate;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).firstEmiDueDate = $$value);
				}
			);

			$.bind_value(
				input_19,
				function get() {
					return $.get(loanForm).lenderName;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).lenderName = $$value);
				}
			);

			$.bind_value(
				input_20,
				function get() {
					return $.get(loanForm).notes;
				},
				function set($$value) {
					$.mutate(loanForm, $.get(loanForm).notes = $$value);
				}
			);

			$.event('click', button_68, () => $.set(showLoanForm, false));
			$.event('click', button_69, saveLoan);
			$.append($$anchor, div_81);
		};

		$.add_svelte_meta(
			() => $.if(node_85, ($$render) => {
				if ($.get(showLoanForm)) $$render(consequent_61);
			}),
			'if',
			Home,
			238,
			0
		);
	}

	var node_87 = $.sibling(node_85, 2);

	{
		var consequent_70 = ($$anchor) => {
			var div_83 = root_129();
			var section_25 = $.child(div_83);
			var button_70 = $.child(section_25);
			var node_88 = $.sibling(button_70, 2);

			{
				var consequent_62 = ($$anchor) => {
					var div_84 = root_130();
					var p_30 = $.sibling($.child(div_84));
					var text_121 = $.child(p_30, true);

					$.reset(p_30);

					var h2_8 = $.sibling(p_30);
					var text_122 = $.child(h2_8, true);

					$.reset(h2_8);

					var p_31 = $.sibling(h2_8);
					var text_123 = $.child(p_31, true);

					$.reset(p_31);

					var button_71 = $.sibling(p_31);

					$.reset(div_84);

					$.template_effect(
						($0) => {
							$.set_text(text_121, (
								$.get(fundForm),
								$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES') ? 'SIP READY' : 'FUND ADDED')
							));

							$.set_text(text_122, (
								$.get(fundForm),
								$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES') ? 'Your SIP is set up' : 'Your fund is ready')
							));

							$.set_text(text_123, $0);
						},
						[
							() => (
								$.get(fundForm),
								$.get(selectedScheme),

								$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES')
									? `${money($.get(fundForm).sipAmount)} will be tracked monthly for ${$.get(selectedScheme).schemeName}. The first occurrence will be due in ${monthLabel($.get(fundForm).startMonth)}.`
									: `${$.get(selectedScheme).schemeName} is ready for occasional lump sums. You can set up a SIP later from its bell button.`)
							)
						]
					);

					$.event('click', button_71, () => $.set(showMutualFundForm, false));
					$.append($$anchor, div_84);
				};

				var alternate_37 = ($$anchor) => {
					var fragment_43 = root_131();
					var div_85 = $.sibling($.first_child(fragment_43), 4);
					var label_26 = $.sibling($.child(div_85));
					var input_21 = $.sibling($.child(label_26));

					$.remove_input_defaults(input_21);

					var node_89 = $.sibling(input_21);

					{
						var consequent_65 = ($$anchor) => {
							var div_86 = root_132();
							var node_90 = $.child(div_86);

							{
								var consequent_63 = ($$anchor) => {
									var p_32 = root_133();

									$.append($$anchor, p_32);
								};

								var alternate_36 = ($$anchor) => {
									var fragment_44 = $.comment();
									var node_91 = $.first_child(fragment_44);

									{
										var consequent_64 = ($$anchor) => {
											var p_33 = root_135();

											$.append($$anchor, p_33);
										};

										var alternate_35 = ($$anchor) => {
											var fragment_45 = $.comment();
											var node_92 = $.first_child(fragment_45);

											$.add_svelte_meta(
												() => $.each(
													node_92,
													1,
													() => $.get(schemeResults),
													$.index,
													($$anchor, scheme) => {
														var button_72 = root_137();
														var strong_22 = $.child(button_72);
														var text_124 = $.child(strong_22, true);

														$.reset(strong_22);

														var small_16 = $.sibling(strong_22);
														var text_125 = $.child(small_16);

														$.reset(small_16);
														$.reset(button_72);

														$.template_effect(
															($0) => {
																$.set_text(text_124, ($.get(scheme), $.untrack(() => $.get(scheme).schemeName)));
																$.set_text(text_125, `Scheme code ${($.get(scheme), $.untrack(() => $.get(scheme).schemeCode)) ?? ''} · ${$0 ?? ''}`);
															},
															[
																() => (
																	$.get(scheme),

																	$.untrack(() => $.equals($.get(scheme).latestNav, null)
																		? 'Latest NAV unavailable'
																		: `Latest NAV ${moneyDecimal($.get(scheme).latestNav)}`)
																)
															]
														);

														$.event('mousedown', button_72, $.preventDefault(() => selectScheme($.get(scheme))));
														$.append($$anchor, button_72);
													},
													($$anchor) => {
														var p_34 = root_138();

														$.append($$anchor, p_34);
													}
												),
												'each',
												Home,
												245,
												503
											);

											$.append($$anchor, fragment_45);
										};

										$.add_svelte_meta(
											() => $.if(
												node_91,
												($$render) => {
													if ((
														$.get(schemeQuery),
														$.untrack(() => $.get(schemeQuery).trim().length < 2)
													)) $$render(consequent_64); else $$render(alternate_35, false);
												},
												true
											),
											'if',
											Home,
											245,
											414
										);
									}

									$.append($$anchor, fragment_44);
								};

								$.add_svelte_meta(
									() => $.if(node_90, ($$render) => {
										if ($.strict_equals($.get(schemeSearchStatus), 'loading')) $$render(consequent_63); else $$render(alternate_36, false);
									}),
									'if',
									Home,
									245,
									353
								);
							}

							$.reset(div_86);
							$.append($$anchor, div_86);
						};

						$.add_svelte_meta(
							() => $.if(node_89, ($$render) => {
								if ($.get(showSchemeMenu)) $$render(consequent_65);
							}),
							'if',
							Home,
							245,
							308
						);
					}

					$.reset(label_26);

					var node_93 = $.sibling(label_26);

					{
						var consequent_66 = ($$anchor) => {
							var div_87 = root_139();
							var div_88 = $.sibling($.child(div_87));
							var small_17 = $.sibling($.child(div_88));
							var text_126 = $.child(small_17);

							$.reset(small_17);
							$.reset(div_88);
							$.reset(div_87);

							$.template_effect(
								($0) => $.set_text(text_126, `Code ${(
									$.get(selectedScheme),
									$.untrack(() => $.get(selectedScheme).schemeCode)
								) ?? ''} · ${$0 ?? ''}`),
								[
									() => (
										$.get(selectedScheme),

										$.untrack(() => $.equals($.get(selectedScheme).latestNav, null)
											? 'Latest NAV unavailable'
											: `Latest NAV ${moneyDecimal($.get(selectedScheme).latestNav)}`)
									)
								]
							);

							$.append($$anchor, div_87);
						};

						$.add_svelte_meta(
							() => $.if(node_93, ($$render) => {
								if ($.get(selectedScheme)) $$render(consequent_66);
							}),
							'if',
							Home,
							245,
							871
						);
					}

					$.reset(div_85);

					var div_89 = $.sibling(div_85, 2);
					var fieldset = $.sibling($.child(div_89));
					var label_27 = $.sibling($.child(fieldset));
					var input_22 = $.child(label_27);

					$.remove_input_defaults(input_22);
					input_22.value = input_22.__value = 'YES';
					$.next();
					$.reset(label_27);

					var label_28 = $.sibling(label_27);
					var input_23 = $.child(label_28);

					$.remove_input_defaults(input_23);
					input_23.value = input_23.__value = 'NO';
					$.next();
					$.reset(label_28);
					$.reset(fieldset);

					var node_94 = $.sibling(fieldset);

					{
						var consequent_67 = ($$anchor) => {
							var fragment_46 = root_140();
							var label_29 = $.first_child(fragment_46);
							var input_24 = $.sibling($.child(label_29));

							$.remove_input_defaults(input_24);
							$.reset(label_29);

							var div_90 = $.sibling(label_29);
							var label_30 = $.child(div_90);
							var select_5 = $.sibling($.child(label_30));

							$.template_effect(() => {
								$.get(fundForm);

								$.invalidate_inner_signals(() => {
									Array;
								});
							});

							$.add_svelte_meta(
								() => $.each(select_5, 4, () => Array(28), $.index, ($$anchor, _, index) => {
									var option_8 = root_141();

									option_8.textContent = `${index + 1}${$.strict_equals(index, 0)
										? 'st'
										: $.strict_equals(index, 1) ? 'nd' : $.strict_equals(index, 2) ? 'rd' : 'th'} of every month`;

									option_8.value = option_8.__value = index + 1;
									$.append($$anchor, option_8);
								}),
								'each',
								Home,
								246,
								594
							);

							$.reset(select_5);
							$.reset(label_30);

							var label_31 = $.sibling(label_30);
							var input_25 = $.sibling($.child(label_31));

							$.remove_input_defaults(input_25);
							$.reset(label_31);
							$.reset(div_90);

							$.bind_value(
								input_24,
								function get() {
									return $.get(fundForm).sipAmount;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).sipAmount = $$value);
								}
							);

							$.bind_select_value(
								select_5,
								function get() {
									return $.get(fundForm).sipDate;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).sipDate = $$value);
								}
							);

							$.bind_value(
								input_25,
								function get() {
									return $.get(fundForm).startMonth;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).startMonth = $$value);
								}
							);

							$.append($$anchor, fragment_46);
						};

						$.add_svelte_meta(
							() => $.if(node_94, ($$render) => {
								if ((
									$.get(fundForm),
									$.untrack(() => $.strict_equals($.get(fundForm).hasSip, 'YES'))
								)) $$render(consequent_67);
							}),
							'if',
							Home,
							246,
							367
						);
					}

					$.reset(div_89);

					var div_91 = $.sibling(div_89, 2);
					var fieldset_1 = $.sibling($.child(div_91));
					var label_32 = $.sibling($.child(fieldset_1));
					var input_26 = $.child(label_32);

					$.remove_input_defaults(input_26);
					input_26.value = input_26.__value = 'NO';
					$.next();
					$.reset(label_32);

					var label_33 = $.sibling(label_32);
					var input_27 = $.child(label_33);

					$.remove_input_defaults(input_27);
					input_27.value = input_27.__value = 'YES';
					$.next();
					$.reset(label_33);
					$.reset(fieldset_1);

					var node_95 = $.sibling(fieldset_1);

					{
						var consequent_68 = ($$anchor) => {
							var fragment_47 = root_142();
							var div_92 = $.first_child(fragment_47);
							var label_34 = $.child(div_92);
							var input_28 = $.sibling($.child(label_34));

							$.remove_input_defaults(input_28);
							$.reset(label_34);

							var label_35 = $.sibling(label_34);
							var input_29 = $.sibling($.child(label_35));

							$.remove_input_defaults(input_29);
							$.reset(label_35);
							$.reset(div_92);
							$.next();

							$.bind_value(
								input_28,
								function get() {
									return $.get(fundForm).currentUnits;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).currentUnits = $$value);
								}
							);

							$.bind_value(
								input_29,
								function get() {
									return $.get(fundForm).totalInvested;
								},
								function set($$value) {
									$.mutate(fundForm, $.get(fundForm).totalInvested = $$value);
								}
							);

							$.append($$anchor, fragment_47);
						};

						$.add_svelte_meta(
							() => $.if(node_95, ($$render) => {
								if ((
									$.get(fundForm),
									$.untrack(() => $.strict_equals($.get(fundForm).hasHolding, 'YES'))
								)) $$render(consequent_68);
							}),
							'if',
							Home,
							247,
							378
						);
					}

					$.reset(div_91);

					var node_96 = $.sibling(div_91, 2);

					{
						var consequent_69 = ($$anchor) => {
							var p_35 = root_143();
							var text_127 = $.child(p_35, true);

							$.reset(p_35);
							$.template_effect(() => $.set_text(text_127, $.get(fundError)));
							$.append($$anchor, p_35);
						};

						$.add_svelte_meta(
							() => $.if(node_96, ($$render) => {
								if ($.get(fundError)) $$render(consequent_69);
							}),
							'if',
							Home,
							248,
							6
						);
					}

					var div_93 = $.sibling(node_96);
					var button_73 = $.child(div_93);
					var button_74 = $.sibling(button_73);
					var text_128 = $.child(button_74, true);

					$.reset(button_74);
					$.reset(div_93);

					$.template_effect(() => {
						$.set_value(input_21, $.get(schemeQuery));
						button_74.disabled = $.get(fundSaving);
						$.set_text(text_128, $.get(fundSaving) ? 'Creating…' : 'Add mutual fund');
					});

					$.event('focus', input_21, () => $.set(showSchemeMenu, true));
					$.event('input', input_21, (e) => searchSchemes(e.currentTarget.value));

					$.bind_group(
						binding_group,
						[],
						input_22,
						function get() {
							return $.get(fundForm).hasSip;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasSip = $$value);
						}
					);

					$.bind_group(
						binding_group,
						[],
						input_23,
						function get() {
							return $.get(fundForm).hasSip;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasSip = $$value);
						}
					);

					$.bind_group(
						binding_group_1,
						[],
						input_26,
						function get() {
							return $.get(fundForm).hasHolding;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasHolding = $$value);
						}
					);

					$.bind_group(
						binding_group_1,
						[],
						input_27,
						function get() {
							return $.get(fundForm).hasHolding;
						},
						function set($$value) {
							$.mutate(fundForm, $.get(fundForm).hasHolding = $$value);
						}
					);

					$.event('click', button_73, () => $.set(showMutualFundForm, false));
					$.event('click', button_74, saveMutualFund);
					$.append($$anchor, fragment_43);
				};

				$.add_svelte_meta(
					() => $.if(node_88, ($$render) => {
						if ($.get(fundSaved)) $$render(consequent_62); else $$render(alternate_37, false);
					}),
					'if',
					Home,
					243,
					4
				);
			}

			$.reset(section_25);
			$.reset(div_83);
			$.event('click', button_70, () => $.set(showMutualFundForm, false));
			$.append($$anchor, div_83);
		};

		$.add_svelte_meta(
			() => $.if(node_87, ($$render) => {
				if ($.get(showMutualFundForm)) $$render(consequent_70);
			}),
			'if',
			Home,
			241,
			0
		);
	}

	var node_97 = $.sibling(node_87, 2);

	{
		var consequent_76 = ($$anchor) => {
			var div_94 = root_144();
			var section_26 = $.child(div_94);
			var button_75 = $.child(section_26);
			var div_95 = $.sibling(button_75, 4);
			var label_36 = $.sibling($.child(div_95));
			var input_30 = $.sibling($.child(label_36));

			$.remove_input_defaults(input_30);

			var node_98 = $.sibling(input_30);

			{
				var consequent_73 = ($$anchor) => {
					var div_96 = root_145();
					var node_99 = $.child(div_96);

					{
						var consequent_71 = ($$anchor) => {
							var p_36 = root_146();

							$.append($$anchor, p_36);
						};

						var alternate_39 = ($$anchor) => {
							var fragment_48 = $.comment();
							var node_100 = $.first_child(fragment_48);

							{
								var consequent_72 = ($$anchor) => {
									var p_37 = root_148();

									$.append($$anchor, p_37);
								};

								var alternate_38 = ($$anchor) => {
									var fragment_49 = $.comment();
									var node_101 = $.first_child(fragment_49);

									$.add_svelte_meta(
										() => $.each(
											node_101,
											1,
											() => $.get(stockResults),
											$.index,
											($$anchor, stock) => {
												var button_76 = root_150();
												var strong_23 = $.child(button_76);
												var text_129 = $.child(strong_23, true);

												$.reset(strong_23);

												var small_18 = $.sibling(strong_23);
												var text_130 = $.child(small_18);

												$.reset(small_18);
												$.reset(button_76);

												$.template_effect(
													($0) => {
														$.set_text(text_129, (
															$.get(stock),
															$.untrack(() => $.get(stock).name || $.get(stock).symbol)
														));

														$.set_text(text_130, `${($.get(stock), $.untrack(() => $.get(stock).symbol)) ?? ''}${(
															$.get(stock),
															$.untrack(() => $.get(stock).exchange ? ` · ${$.get(stock).exchange}` : '')
														) ?? ''} · ${$0 ?? ''}`);
													},
													[
														() => (
															$.get(stock),

															$.untrack(() => $.equals($.get(stock).latestPrice, null)
																? 'Latest price unavailable'
																: `Latest price ${moneyDecimal($.get(stock).latestPrice)}`)
														)
													]
												);

												$.event('mousedown', button_76, $.preventDefault(() => selectStock($.get(stock))));
												$.append($$anchor, button_76);
											},
											($$anchor) => {
												var p_38 = root_151();

												$.append($$anchor, p_38);
											}
										),
										'each',
										Home,
										252,
										923
									);

									$.append($$anchor, fragment_49);
								};

								$.add_svelte_meta(
									() => $.if(
										node_100,
										($$render) => {
											if ($.strict_equals($.get(stockSearchStatus), 'error')) $$render(consequent_72); else $$render(alternate_38, false);
										},
										true
									),
									'if',
									Home,
									252,
									847
								);
							}

							$.append($$anchor, fragment_48);
						};

						$.add_svelte_meta(
							() => $.if(node_99, ($$render) => {
								if ($.strict_equals($.get(stockSearchStatus), 'loading')) $$render(consequent_71); else $$render(alternate_39, false);
							}),
							'if',
							Home,
							252,
							781
						);
					}

					$.reset(div_96);
					$.append($$anchor, div_96);
				};

				$.add_svelte_meta(
					() => $.if(node_98, ($$render) => {
						if ((
							$.get(stockQuery),
							$.get(selectedStock),
							$.untrack(() => $.get(stockQuery).trim().length >= 2 && !$.get(selectedStock))
						)) $$render(consequent_73);
					}),
					'if',
					Home,
					252,
					707
				);
			}

			$.reset(label_36);

			var node_102 = $.sibling(label_36);

			{
				var consequent_74 = ($$anchor) => {
					var div_97 = root_152();
					var div_98 = $.sibling($.child(div_97));
					var small_19 = $.sibling($.child(div_98));
					var text_131 = $.child(small_19);

					$.reset(small_19);
					$.reset(div_98);
					$.reset(div_97);

					$.template_effect(
						($0) => $.set_text(text_131, `${(
							$.get(selectedStock),
							$.untrack(() => $.get(selectedStock).symbol)
						) ?? ''}${(
							$.get(selectedStock),
							$.untrack(() => $.get(selectedStock).exchange ? ` · ${$.get(selectedStock).exchange}` : '')
						) ?? ''} · ${$0 ?? ''}`),
						[
							() => (
								$.get(selectedStock),

								$.untrack(() => $.equals($.get(selectedStock).latestPrice, null)
									? 'Latest price unavailable'
									: `Latest price ${moneyDecimal($.get(selectedStock).latestPrice)}`)
							)
						]
					);

					$.append($$anchor, div_97);
				};

				$.add_svelte_meta(
					() => $.if(node_102, ($$render) => {
						if ($.get(selectedStock)) $$render(consequent_74);
					}),
					'if',
					Home,
					252,
					1331
				);
			}

			$.reset(div_95);

			var div_99 = $.sibling(div_95);
			var div_100 = $.sibling($.child(div_99));
			var label_37 = $.child(div_100);
			var input_31 = $.sibling($.child(label_37));

			$.remove_input_defaults(input_31);
			$.reset(label_37);

			var label_38 = $.sibling(label_37);
			var input_32 = $.sibling($.child(label_38));

			$.remove_input_defaults(input_32);
			$.reset(label_38);
			$.reset(div_100);
			$.reset(div_99);

			var node_103 = $.sibling(div_99);

			{
				var consequent_75 = ($$anchor) => {
					var p_39 = root_153();
					var text_132 = $.child(p_39, true);

					$.reset(p_39);
					$.template_effect(() => $.set_text(text_132, $.get(stockError)));
					$.append($$anchor, p_39);
				};

				$.add_svelte_meta(
					() => $.if(node_103, ($$render) => {
						if ($.get(stockError)) $$render(consequent_75);
					}),
					'if',
					Home,
					252,
					2048
				);
			}

			var div_101 = $.sibling(node_103);
			var button_77 = $.child(div_101);
			var button_78 = $.sibling(button_77);
			var text_133 = $.child(button_78, true);

			$.reset(button_78);
			$.reset(div_101);
			$.reset(section_26);
			$.reset(div_94);

			$.template_effect(() => {
				$.set_value(input_30, $.get(stockQuery));
				button_78.disabled = $.get(stockSaving);
				$.set_text(text_133, $.get(stockSaving) ? 'Adding…' : 'Add stock');
			});

			$.event('click', button_75, () => $.set(showStockForm, false));
			$.event('input', input_30, (e) => findStocks(e.currentTarget.value));

			$.bind_value(
				input_31,
				function get() {
					return $.get(stockForm).quantity;
				},
				function set($$value) {
					$.mutate(stockForm, $.get(stockForm).quantity = $$value);
				}
			);

			$.bind_value(
				input_32,
				function get() {
					return $.get(stockForm).totalInvested;
				},
				function set($$value) {
					$.mutate(stockForm, $.get(stockForm).totalInvested = $$value);
				}
			);

			$.event('click', button_77, () => $.set(showStockForm, false));
			$.event('click', button_78, saveStock);
			$.append($$anchor, div_94);
		};

		$.add_svelte_meta(
			() => $.if(node_97, ($$render) => {
				if ($.get(showStockForm)) $$render(consequent_76);
			}),
			'if',
			Home,
			251,
			0
		);
	}

	var node_104 = $.sibling(node_97, 2);

	{
		var consequent_78 = ($$anchor) => {
			var div_102 = root_154();
			var section_27 = $.child(div_102);
			var button_79 = $.child(section_27);
			var h2_9 = $.sibling(button_79, 2);
			var text_134 = $.child(h2_9);

			$.reset(h2_9);

			var label_39 = $.sibling(h2_9, 2);
			var input_33 = $.sibling($.child(label_39));

			$.remove_input_defaults(input_33);
			$.reset(label_39);

			var label_40 = $.sibling(label_39);
			var input_34 = $.sibling($.child(label_40));

			$.remove_input_defaults(input_34);
			$.reset(label_40);

			var label_41 = $.sibling(label_40);
			var input_35 = $.sibling($.child(label_41));

			$.remove_input_defaults(input_35);
			$.reset(label_41);

			var node_105 = $.sibling(label_41);

			{
				var consequent_77 = ($$anchor) => {
					var p_40 = root_155();
					var text_135 = $.child(p_40, true);

					$.reset(p_40);
					$.template_effect(() => $.set_text(text_135, $.get(fundError)));
					$.append($$anchor, p_40);
				};

				$.add_svelte_meta(
					() => $.if(node_105, ($$render) => {
						if ($.get(fundError)) $$render(consequent_77);
					}),
					'if',
					Home,
					254,
					653
				);
			}

			var div_103 = $.sibling(node_105);
			var button_80 = $.child(div_103);
			var button_81 = $.sibling(button_80);
			var text_136 = $.child(button_81, true);

			$.reset(button_81);
			$.reset(div_103);
			$.reset(section_27);
			$.reset(div_102);

			$.template_effect(() => {
				$.set_text(text_134, `Set up SIP for ${(
					$.get(fundSipTarget),
					$.untrack(() => $.get(fundSipTarget).schemeName)
				) ?? ''}`);

				button_81.disabled = $.get(fundSipSaving);
				$.set_text(text_136, $.get(fundSipSaving) ? 'Saving…' : 'Save SIP');
			});

			$.event('click', button_79, () => $.set(fundSipTarget, null));

			$.bind_value(
				input_33,
				function get() {
					return $.get(fundSipForm).amount;
				},
				function set($$value) {
					$.mutate(fundSipForm, $.get(fundSipForm).amount = $$value);
				}
			);

			$.bind_value(
				input_34,
				function get() {
					return $.get(fundSipForm).day;
				},
				function set($$value) {
					$.mutate(fundSipForm, $.get(fundSipForm).day = $$value);
				}
			);

			$.bind_value(
				input_35,
				function get() {
					return $.get(fundSipForm).startMonth;
				},
				function set($$value) {
					$.mutate(fundSipForm, $.get(fundSipForm).startMonth = $$value);
				}
			);

			$.event('click', button_80, () => $.set(fundSipTarget, null));
			$.event('click', button_81, saveFundSipPlan);
			$.append($$anchor, div_102);
		};

		$.add_svelte_meta(
			() => $.if(node_104, ($$render) => {
				if ($.get(fundSipTarget)) $$render(consequent_78);
			}),
			'if',
			Home,
			254,
			0
		);
	}

	var node_106 = $.sibling(node_104, 2);

	{
		var consequent_79 = ($$anchor) => {
			var div_104 = root_156();
			var section_28 = $.child(div_104);
			var button_82 = $.child(section_28);
			var h2_10 = $.sibling(button_82, 2);
			var text_137 = $.child(h2_10);

			$.reset(h2_10);

			var label_42 = $.sibling(h2_10);
			var input_36 = $.sibling($.child(label_42));

			$.remove_input_defaults(input_36);
			$.reset(label_42);

			var label_43 = $.sibling(label_42);
			var input_37 = $.sibling($.child(label_43));

			$.remove_input_defaults(input_37);
			$.reset(label_43);

			var label_44 = $.sibling(label_43);
			var input_38 = $.sibling($.child(label_44));

			$.remove_input_defaults(input_38);
			$.reset(label_44);

			var div_105 = $.sibling(label_44);
			var button_83 = $.child(div_105);
			var button_84 = $.sibling(button_83);
			var text_138 = $.child(button_84, true);

			$.reset(button_84);
			$.reset(div_105);
			$.reset(section_28);
			$.reset(div_104);

			$.template_effect(() => {
				$.set_text(text_137, `Plan ${(
					$.get(stockPlanTarget),
					$.untrack(() => $.get(stockPlanTarget).name)
				) ?? ''}`);

				button_84.disabled = $.get(stockPlanSaving);
				$.set_text(text_138, $.get(stockPlanSaving) ? 'Saving…' : 'Save monthly plan');
			});

			$.event('click', button_82, () => $.set(stockPlanTarget, null));

			$.bind_value(
				input_36,
				function get() {
					return $.get(stockPlanForm).amount;
				},
				function set($$value) {
					$.mutate(stockPlanForm, $.get(stockPlanForm).amount = $$value);
				}
			);

			$.bind_value(
				input_37,
				function get() {
					return $.get(stockPlanForm).day;
				},
				function set($$value) {
					$.mutate(stockPlanForm, $.get(stockPlanForm).day = $$value);
				}
			);

			$.bind_value(
				input_38,
				function get() {
					return $.get(stockPlanForm).startMonth;
				},
				function set($$value) {
					$.mutate(stockPlanForm, $.get(stockPlanForm).startMonth = $$value);
				}
			);

			$.event('click', button_83, () => $.set(stockPlanTarget, null));
			$.event('click', button_84, saveStockPlan);
			$.append($$anchor, div_104);
		};

		$.add_svelte_meta(
			() => $.if(node_106, ($$render) => {
				if ($.get(stockPlanTarget)) $$render(consequent_79);
			}),
			'if',
			Home,
			255,
			0
		);
	}

	var node_107 = $.sibling(node_106, 2);

	{
		var consequent_80 = ($$anchor) => {
			var div_106 = root_157();
			var section_29 = $.child(div_106);
			var button_85 = $.child(section_29);
			var label_45 = $.sibling(button_85, 3);
			var input_39 = $.sibling($.child(label_45));

			$.remove_input_defaults(input_39);
			$.reset(label_45);

			var label_46 = $.sibling(label_45);
			var input_40 = $.sibling($.child(label_46));

			$.remove_input_defaults(input_40);
			$.reset(label_46);

			var div_107 = $.sibling(label_46);
			var button_86 = $.child(div_107);
			var button_87 = $.sibling(button_86);

			$.reset(div_107);
			$.reset(section_29);
			$.reset(div_106);
			$.event('click', button_85, () => $.set(stockPlanConfirmationTarget, null));

			$.bind_value(
				input_39,
				function get() {
					return $.get(stockPlanConfirmation).amount;
				},
				function set($$value) {
					$.mutate(stockPlanConfirmation, $.get(stockPlanConfirmation).amount = $$value);
				}
			);

			$.bind_value(
				input_40,
				function get() {
					return $.get(stockPlanConfirmation).price;
				},
				function set($$value) {
					$.mutate(stockPlanConfirmation, $.get(stockPlanConfirmation).price = $$value);
				}
			);

			$.event('click', button_86, () => $.set(stockPlanConfirmationTarget, null));
			$.event('click', button_87, confirmStockPlan);
			$.append($$anchor, div_106);
		};

		$.add_svelte_meta(
			() => $.if(node_107, ($$render) => {
				if ($.get(stockPlanConfirmationTarget)) $$render(consequent_80);
			}),
			'if',
			Home,
			256,
			0
		);
	}

	var node_108 = $.sibling(node_107, 2);

	{
		var consequent_83 = ($$anchor) => {
			var div_108 = root_158();
			var section_30 = $.child(div_108);
			var button_88 = $.child(section_30);
			var node_109 = $.sibling(button_88);

			{
				var consequent_81 = ($$anchor) => {
					var h2_11 = root_159();

					$.append($$anchor, h2_11);
				};

				var alternate_41 = ($$anchor) => {
					var fragment_50 = $.comment();
					var node_110 = $.first_child(fragment_50);

					{
						var consequent_82 = ($$anchor) => {
							var h2_12 = root_161();

							$.append($$anchor, h2_12);
						};

						var alternate_40 = ($$anchor) => {
							var fragment_51 = root_162();
							var h2_13 = $.sibling($.first_child(fragment_51));
							var text_139 = $.child(h2_13, true);

							$.reset(h2_13);

							var div_109 = $.sibling(h2_13);
							var div_110 = $.child(div_109);
							var b_18 = $.sibling($.child(div_110));
							var text_140 = $.child(b_18, true);

							$.reset(b_18);
							$.reset(div_110);

							var div_111 = $.sibling(div_110);
							var b_19 = $.sibling($.child(div_111));
							var text_141 = $.child(b_19, true);

							$.reset(b_19);
							$.reset(div_111);
							$.reset(div_109);

							var section_31 = $.sibling(div_109);
							var node_111 = $.sibling($.child(section_31));

							$.add_svelte_meta(
								() => $.each(
									node_111,
									1,
									() => (
										$.get(stockDetail),
										$.untrack(() => $.get(stockDetail).history)
									),
									$.index,
									($$anchor, entry) => {
										var div_112 = root_163();
										var span_30 = $.child(div_112);
										var text_142 = $.child(span_30, true);

										$.reset(span_30);

										var strong_24 = $.sibling(span_30);
										var text_143 = $.child(strong_24, true);

										$.reset(strong_24);

										var span_31 = $.sibling(strong_24);
										var b_20 = $.child(span_31);
										var text_144 = $.child(b_20, true);

										$.reset(b_20);
										$.reset(span_31);

										var small_20 = $.sibling(span_31);
										var text_145 = $.child(small_20);

										$.reset(small_20);
										$.reset(div_112);

										$.template_effect(
											($0, $1, $2, $3) => {
												$.set_text(text_142, $0);

												$.set_text(text_143, (
													$.get(entry),
													$.untrack(() => $.strict_equals($.get(entry).kind, 'SIP') ? 'Monthly ETF purchase' : 'Opening holding')
												));

												$.set_text(text_144, $1);
												$.set_text(text_145, `Price ${$2 ?? ''} · ${$3 ?? ''} shares`);
											},
											[
												() => (
													$.get(entry),
													$.untrack(() => dateLabel($.get(entry).transactionDate))
												),

												() => ($.get(entry), $.untrack(() => money($.get(entry).amount))),

												() => (
													$.get(entry),
													$.untrack(() => moneyDecimal($.get(entry).executionPrice))
												),

												() => (
													$.get(entry),
													$.untrack(() => Number($.get(entry).units).toFixed(3))
												)
											]
										);

										$.append($$anchor, div_112);
									}
								),
								'each',
								Home,
								257,
								664
							);

							$.reset(section_31);

							$.template_effect(
								($0, $1) => {
									$.set_text(text_139, (
										$.get(stockDetail),
										$.untrack(() => $.get(stockDetail).stock.name)
									));

									$.set_text(text_140, $0);
									$.set_text(text_141, $1);
								},
								[
									() => (
										$.get(stockDetail),
										$.untrack(() => money($.get(stockDetail).stock.invested))
									),

									() => (
										$.get(stockDetail),
										$.untrack(() => Number($.get(stockDetail).stock.quantity).toFixed(3))
									)
								]
							);

							$.append($$anchor, fragment_51);
						};

						$.add_svelte_meta(
							() => $.if(
								node_110,
								($$render) => {
									if ($.strict_equals($.get(stockDetailStatus), 'error')) $$render(consequent_82); else $$render(alternate_40, false);
								},
								true
							),
							'if',
							Home,
							257,
							261
						);
					}

					$.append($$anchor, fragment_50);
				};

				$.add_svelte_meta(
					() => $.if(node_109, ($$render) => {
						if ($.strict_equals($.get(stockDetailStatus), 'loading')) $$render(consequent_81); else $$render(alternate_41, false);
					}),
					'if',
					Home,
					257,
					195
				);
			}

			$.reset(section_30);
			$.reset(div_108);
			$.event('click', button_88, () => $.set(stockDetail, null));
			$.append($$anchor, div_108);
		};

		$.add_svelte_meta(
			() => $.if(node_108, ($$render) => {
				if ($.get(stockDetail)) $$render(consequent_83);
			}),
			'if',
			Home,
			257,
			0
		);
	}

	var node_112 = $.sibling(node_108, 2);

	{
		var consequent_87 = ($$anchor) => {
			var div_113 = root_164();
			var section_32 = $.child(div_113);
			var button_89 = $.child(section_32);
			var node_113 = $.sibling(button_89);

			{
				var consequent_84 = ($$anchor) => {
					var fragment_52 = root_165();

					$.next();
					$.append($$anchor, fragment_52);
				};

				var alternate_43 = ($$anchor) => {
					var fragment_53 = $.comment();
					var node_114 = $.first_child(fragment_53);

					{
						var consequent_85 = ($$anchor) => {
							var fragment_54 = root_167();
							var p_41 = $.sibling($.first_child(fragment_54), 2);
							var text_146 = $.child(p_41, true);

							$.reset(p_41);

							var button_90 = $.sibling(p_41);

							$.template_effect(() => $.set_text(text_146, $.get(fundDetailError)));
							$.event('click', button_90, () => openFundDetail($.get(fundDetail).id));
							$.append($$anchor, fragment_54);
						};

						var alternate_42 = ($$anchor) => {
							const detailSummary = $.tag(
								$.derived_safe_equal(() => (
									$.get(fundDetail),
									$.untrack(() => fundSummary($.get(fundDetail).id))
								)),
								'detailSummary'
							);

							$.get(detailSummary);

							var fragment_55 = root_168();
							var h2_14 = $.sibling($.first_child(fragment_55));
							var text_147 = $.child(h2_14, true);

							$.reset(h2_14);

							var div_114 = $.sibling(h2_14);
							var strong_25 = $.sibling($.child(div_114));
							var text_148 = $.child(strong_25, true);

							$.reset(strong_25);
							$.reset(div_114);

							var div_115 = $.sibling(div_114);
							let classes_21;
							var strong_26 = $.sibling($.child(div_115));
							var text_149 = $.child(strong_26);

							$.reset(strong_26);

							var b_21 = $.sibling(strong_26);
							var text_150 = $.child(b_21);

							$.reset(b_21);
							$.reset(div_115);

							var div_116 = $.sibling(div_115);
							var div_117 = $.child(div_116);
							var b_22 = $.sibling($.child(div_117));
							var text_151 = $.child(b_22, true);

							$.reset(b_22);
							$.reset(div_117);

							var div_118 = $.sibling(div_117);
							var b_23 = $.sibling($.child(div_118));
							var text_152 = $.child(b_23, true);

							$.reset(b_23);
							$.reset(div_118);

							var div_119 = $.sibling(div_118);
							var b_24 = $.sibling($.child(div_119));
							var text_153 = $.child(b_24, true);

							$.reset(b_24);
							$.reset(div_119);

							var div_120 = $.sibling(div_119);
							var b_25 = $.sibling($.child(div_120));
							var text_154 = $.child(b_25, true);

							$.reset(b_25);
							$.reset(div_120);
							$.reset(div_116);

							var node_115 = $.sibling(div_116);

							{
								var consequent_86 = ($$anchor) => {
									var section_33 = root_169();
									var node_116 = $.sibling($.child(section_33));

									$.add_svelte_meta(
										() => $.each(
											node_116,
											1,
											() => (
												$.get(fundDetail),
												$.untrack(() => $.get(fundDetail).history)
											),
											$.index,
											($$anchor, entry) => {
												var div_121 = root_170();
												var span_32 = $.child(div_121);
												var text_155 = $.child(span_32, true);

												$.reset(span_32);

												var strong_27 = $.sibling(span_32);
												var text_156 = $.child(strong_27, true);

												$.reset(strong_27);

												var span_33 = $.sibling(strong_27);
												var b_26 = $.child(span_33);
												var text_157 = $.child(b_26, true);

												$.reset(b_26);

												var button_91 = $.sibling(b_26);

												$.reset(span_33);

												var small_21 = $.sibling(span_33);
												var text_158 = $.child(small_21);

												$.reset(small_21);
												$.reset(div_121);

												$.template_effect(
													($0, $1, $2, $3) => {
														$.set_text(text_155, $0);

														$.set_text(text_156, (
															$.get(entry),

															$.untrack(() => $.strict_equals($.get(entry).kind, "SIP")
																? "SIP"
																: $.strict_equals($.get(entry).kind, "LUMPSUM") ? "Lump sum" : "Opening holding")
														));

														$.set_text(text_157, $1);
														$.set_text(text_158, `NAV ${$2 ?? ''} · ${$3 ?? ''} units`);
													},
													[
														() => (
															$.get(entry),
															$.untrack(() => dateLabel($.get(entry).transactionDate))
														),

														() => ($.get(entry), $.untrack(() => money($.get(entry).amount))),

														() => (
															$.get(entry),
															$.untrack(() => moneyDecimal($.get(entry).nav))
														),

														() => (
															$.get(entry),
															$.untrack(() => Number($.get(entry).units).toFixed(3))
														)
													]
												);

												$.event('click', button_91, () => openHistoryEdit($.get(detailSummary), $.get(entry)));
												$.append($$anchor, div_121);
											}
										),
										'each',
										Home,
										259,
										1533
									);

									$.reset(section_33);
									$.append($$anchor, section_33);
								};

								$.add_svelte_meta(
									() => $.if(node_115, ($$render) => {
										if ((
											$.get(fundDetail),
											$.untrack(() => $.get(fundDetail).history?.length)
										)) $$render(consequent_86);
									}),
									'if',
									Home,
									259,
									1438
								);
							}

							$.next();

							$.template_effect(
								($0, $1, $2, $3, $4, $5, $6, $7, $8, $9) => {
									$.set_text(text_147, (
										$.get(fundDetail),
										$.untrack(() => $.get(fundDetail).schemeName)
									));

									$.set_text(text_148, $0);
									classes_21 = $.set_class(div_115, 1, 'detail-pnl', null, classes_21, $1);
									$.set_text(text_149, `${$2 ?? ''}${$3 ?? ''}`);
									$.set_text(text_150, `${$4 ?? ''}${$5 ?? ''}%`);
									$.set_text(text_151, $6);
									$.set_text(text_152, $7);
									$.set_text(text_153, $8);
									$.set_text(text_154, $9);
								},
								[
									() => (
										$.get(fundDetail),
										$.untrack(() => money($.get(fundDetail).currentValue))
									),

									() => ({
										positive: Number($.get(fundDetail).profitOrLoss) >= 0,
										negative: Number($.get(fundDetail).profitOrLoss) < 0
									}),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).profitOrLoss) >= 0 ? '+' : '')
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => money($.get(fundDetail).profitOrLoss))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).profitOrLossPercent) >= 0 ? '+' : '')
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).profitOrLossPercent).toFixed(2))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => money($.get(fundDetail).invested))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => Number($.get(fundDetail).units).toFixed(3))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => moneyDecimal($.get(fundDetail).averageNav))
									),

									() => (
										$.get(fundDetail),
										$.untrack(() => moneyDecimal($.get(fundDetail).currentNav))
									)
								]
							);

							$.append($$anchor, fragment_55);
						};

						$.add_svelte_meta(
							() => $.if(
								node_114,
								($$render) => {
									if ($.strict_equals($.get(fundDetailStatus), 'error')) $$render(consequent_85); else $$render(alternate_42, false);
								},
								true
							),
							'if',
							Home,
							259,
							296
						);
					}

					$.append($$anchor, fragment_53);
				};

				$.add_svelte_meta(
					() => $.if(node_113, ($$render) => {
						if ($.strict_equals($.get(fundDetailStatus), 'loading')) $$render(consequent_84); else $$render(alternate_43, false);
					}),
					'if',
					Home,
					259,
					193
				);
			}

			$.reset(section_32);
			$.reset(div_113);
			$.event('click', button_89, () => $.set(fundDetail, null));
			$.append($$anchor, div_113);
		};

		$.add_svelte_meta(
			() => $.if(node_112, ($$render) => {
				if ($.get(fundDetail)) $$render(consequent_87);
			}),
			'if',
			Home,
			259,
			0
		);
	}

	var node_117 = $.sibling(node_112, 2);

	{
		var consequent_89 = ($$anchor) => {
			var div_122 = root_171();
			var section_34 = $.child(div_122);
			var button_92 = $.child(section_34);
			var h2_15 = $.sibling(button_92, 2);
			var text_159 = $.child(h2_15);

			$.reset(h2_15);

			var label_47 = $.sibling(h2_15, 2);
			var input_41 = $.sibling($.child(label_47));

			$.remove_input_defaults(input_41);
			$.reset(label_47);

			var label_48 = $.sibling(label_47);
			var input_42 = $.sibling($.child(label_48));

			$.remove_input_defaults(input_42);
			$.reset(label_48);

			var label_49 = $.sibling(label_48);
			var input_43 = $.sibling($.child(label_49));

			$.remove_input_defaults(input_43);
			$.reset(label_49);

			var node_118 = $.sibling(label_49);

			{
				var consequent_88 = ($$anchor) => {
					var p_42 = root_172();
					var text_160 = $.child(p_42, true);

					$.reset(p_42);
					$.template_effect(() => $.set_text(text_160, $.get(lumpSumError)));
					$.append($$anchor, p_42);
				};

				$.add_svelte_meta(
					() => $.if(node_118, ($$render) => {
						if ($.get(lumpSumError)) $$render(consequent_88);
					}),
					'if',
					Home,
					260,
					718
				);
			}

			var div_123 = $.sibling(node_118);
			var button_93 = $.child(div_123);
			var button_94 = $.sibling(button_93);
			var text_161 = $.child(button_94, true);

			$.reset(button_94);
			$.reset(div_123);
			$.reset(section_34);
			$.reset(div_122);

			$.template_effect(() => {
				$.set_text(text_159, `Add to ${(
					$.get(lumpSumFund),
					$.untrack(() => $.get(lumpSumFund).schemeName)
				) ?? ''}`);

				button_94.disabled = $.get(lumpSumSaving);
				$.set_text(text_161, $.get(lumpSumSaving) ? 'Adding…' : 'Add lump sum');
			});

			$.event('click', button_92, () => $.set(lumpSumFund, null));

			$.bind_value(
				input_41,
				function get() {
					return $.get(lumpSumForm).amount;
				},
				function set($$value) {
					$.mutate(lumpSumForm, $.get(lumpSumForm).amount = $$value);
				}
			);

			$.bind_value(
				input_42,
				function get() {
					return $.get(lumpSumForm).transactionDate;
				},
				function set($$value) {
					$.mutate(lumpSumForm, $.get(lumpSumForm).transactionDate = $$value);
				}
			);

			$.bind_value(
				input_43,
				function get() {
					return $.get(lumpSumForm).nav;
				},
				function set($$value) {
					$.mutate(lumpSumForm, $.get(lumpSumForm).nav = $$value);
				}
			);

			$.event('click', button_93, () => $.set(lumpSumFund, null));
			$.event('click', button_94, saveLumpSum);
			$.append($$anchor, div_122);
		};

		$.add_svelte_meta(
			() => $.if(node_117, ($$render) => {
				if ($.get(lumpSumFund)) $$render(consequent_89);
			}),
			'if',
			Home,
			260,
			0
		);
	}

	var node_119 = $.sibling(node_117, 2);

	{
		var consequent_91 = ($$anchor) => {
			var div_124 = root_173();
			var section_35 = $.child(div_124);
			var button_95 = $.child(section_35);
			var div_125 = $.sibling(button_95, 4);
			var strong_28 = $.child(div_125);
			var text_162 = $.child(strong_28, true);

			$.reset(strong_28);

			var span_34 = $.sibling(strong_28);
			var text_163 = $.child(span_34);

			$.reset(span_34);
			$.reset(div_125);

			var label_50 = $.sibling(div_125);
			var input_44 = $.sibling($.child(label_50));

			$.remove_input_defaults(input_44);
			$.reset(label_50);

			var label_51 = $.sibling(label_50);
			var input_45 = $.sibling($.child(label_51));

			$.remove_input_defaults(input_45);
			$.reset(label_51);

			var label_52 = $.sibling(label_51);
			var input_46 = $.sibling($.child(label_52), 2);

			$.remove_input_defaults(input_46);
			$.reset(label_52);

			var node_120 = $.sibling(label_52);

			{
				var consequent_90 = ($$anchor) => {
					var p_43 = root_174();
					var text_164 = $.child(p_43, true);

					$.reset(p_43);
					$.template_effect(() => $.set_text(text_164, $.get(sipConfirmError)));
					$.append($$anchor, p_43);
				};

				$.add_svelte_meta(
					() => $.if(node_120, ($$render) => {
						if ($.get(sipConfirmError)) $$render(consequent_90);
					}),
					'if',
					Home,
					261,
					931
				);
			}

			var div_126 = $.sibling(node_120);
			var button_96 = $.child(div_126);
			var button_97 = $.sibling(button_96);
			var text_165 = $.child(button_97, true);

			$.reset(button_97);
			$.reset(div_126);
			$.reset(section_35);
			$.reset(div_124);

			$.template_effect(() => {
				$.set_text(text_162, (
					$.get(confirmingSip),
					$.untrack(() => $.get(confirmingSip).fund.schemeName)
				));

				$.set_text(text_163, `${(
					$.get(confirmingSip),
					$.untrack(() => $.get(confirmingSip).occurrence.scheduledMonth)
				) ?? ''} occurrence`);

				button_97.disabled = $.get(sipConfirmSaving);
				$.set_text(text_165, $.get(sipConfirmSaving) ? 'Confirming…' : 'Confirm estimate');
			});

			$.event('click', button_95, () => $.set(confirmingSip, null));

			$.bind_value(
				input_44,
				function get() {
					return $.get(sipConfirmForm).amount;
				},
				function set($$value) {
					$.mutate(sipConfirmForm, $.get(sipConfirmForm).amount = $$value);
				}
			);

			$.bind_value(
				input_45,
				function get() {
					return $.get(sipConfirmForm).transactionDate;
				},
				function set($$value) {
					$.mutate(sipConfirmForm, $.get(sipConfirmForm).transactionDate = $$value);
				}
			);

			$.bind_value(
				input_46,
				function get() {
					return $.get(sipConfirmForm).nav;
				},
				function set($$value) {
					$.mutate(sipConfirmForm, $.get(sipConfirmForm).nav = $$value);
				}
			);

			$.event('click', button_96, () => $.set(confirmingSip, null));
			$.event('click', button_97, saveSipConfirmation);
			$.append($$anchor, div_124);
		};

		$.add_svelte_meta(
			() => $.if(node_119, ($$render) => {
				if ($.get(confirmingSip)) $$render(consequent_91);
			}),
			'if',
			Home,
			261,
			0
		);
	}

	var node_121 = $.sibling(node_119, 2);

	{
		var consequent_93 = ($$anchor) => {
			var div_127 = root_175();
			var section_36 = $.child(div_127);
			var button_98 = $.child(section_36);
			var h2_16 = $.sibling(button_98, 2);
			var text_166 = $.child(h2_16, true);

			$.reset(h2_16);

			var label_53 = $.sibling(h2_16, 2);
			var input_47 = $.sibling($.child(label_53));

			$.remove_input_defaults(input_47);
			$.reset(label_53);

			var label_54 = $.sibling(label_53);
			var input_48 = $.sibling($.child(label_54));

			$.remove_input_defaults(input_48);
			$.reset(label_54);

			var label_55 = $.sibling(label_54);
			var input_49 = $.sibling($.child(label_55));

			$.remove_input_defaults(input_49);
			$.reset(label_55);

			var node_122 = $.sibling(label_55);

			{
				var consequent_92 = ($$anchor) => {
					var p_44 = root_176();
					var text_167 = $.child(p_44, true);

					$.reset(p_44);
					$.template_effect(() => $.set_text(text_167, $.get(fundTransactionError)));
					$.append($$anchor, p_44);
				};

				$.add_svelte_meta(
					() => $.if(node_122, ($$render) => {
						if ($.get(fundTransactionError)) $$render(consequent_92);
					}),
					'if',
					Home,
					262,
					850
				);
			}

			var div_128 = $.sibling(node_122);
			var button_99 = $.child(div_128);
			var button_100 = $.sibling(button_99);
			var text_168 = $.child(button_100, true);

			$.reset(button_100);
			$.reset(div_128);
			$.reset(section_36);
			$.reset(div_127);

			$.template_effect(() => {
				$.set_text(text_166, (
					$.get(editingFundTransaction),

					$.untrack(() => $.strict_equals($.get(editingFundTransaction).entry.kind, "SIP")
						? "Edit SIP allocation"
						: $.strict_equals($.get(editingFundTransaction).entry.kind, "LUMPSUM") ? "Edit lump sum" : "Edit opening holding")
				));

				button_100.disabled = $.get(fundTransactionSaving);
				$.set_text(text_168, $.get(fundTransactionSaving) ? "Saving…" : "Save changes");
			});

			$.event('click', button_98, () => $.set(editingFundTransaction, null));

			$.bind_value(
				input_47,
				function get() {
					return $.get(fundTransactionForm).amount;
				},
				function set($$value) {
					$.mutate(fundTransactionForm, $.get(fundTransactionForm).amount = $$value);
				}
			);

			$.bind_value(
				input_48,
				function get() {
					return $.get(fundTransactionForm).transactionDate;
				},
				function set($$value) {
					$.mutate(fundTransactionForm, $.get(fundTransactionForm).transactionDate = $$value);
				}
			);

			$.bind_value(
				input_49,
				function get() {
					return $.get(fundTransactionForm).nav;
				},
				function set($$value) {
					$.mutate(fundTransactionForm, $.get(fundTransactionForm).nav = $$value);
				}
			);

			$.event('click', button_99, () => $.set(editingFundTransaction, null));
			$.event('click', button_100, saveFundTransaction);
			$.append($$anchor, div_127);
		};

		$.add_svelte_meta(
			() => $.if(node_121, ($$render) => {
				if ($.get(editingFundTransaction)) $$render(consequent_93);
			}),
			'if',
			Home,
			262,
			0
		);
	}

	var node_123 = $.sibling(node_121, 2);

	{
		var consequent_94 = ($$anchor) => {
			var div_129 = root_177();
			var section_37 = $.child(div_129);
			var header = $.child(section_37);
			var button_101 = $.sibling($.child(header));

			$.reset(header);

			var div_130 = $.sibling(header);
			var node_124 = $.child(div_130);

			$.add_svelte_meta(() => Normalization(node_124, {}), 'component', Home, 264, 552, { componentTag: 'Normalization' });
			$.reset(div_130);
			$.reset(section_37);
			$.reset(div_129);
			$.event('click', button_101, () => $.set(showNormalization, false));

			$.event('click', section_37, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_129, () => $.set(showNormalization, false));
			$.event('keydown', div_129, (event) => $.strict_equals(event.key, 'Escape') && $.set(showNormalization, false));
			$.append($$anchor, div_129);
		};

		$.add_svelte_meta(
			() => $.if(node_123, ($$render) => {
				if ($.get(showNormalization)) $$render(consequent_94);
			}),
			'if',
			Home,
			264,
			0
		);
	}

	var node_125 = $.sibling(node_123, 2);

	{
		var consequent_104 = ($$anchor) => {
			var div_131 = root_178();
			var section_38 = $.child(div_131);
			var button_102 = $.child(section_38);
			var p_45 = $.sibling(button_102);
			var text_169 = $.child(p_45);

			$.reset(p_45);

			var node_126 = $.sibling(p_45);

			{
				var consequent_103 = ($$anchor) => {
					const cards = $.tag(
						$.derived_safe_equal(() => (
							$.get(openedStory),
							$.untrack(() => $.get(openedStory).cards.slice().sort((a, b) => (a.sequence || 0) - (b.sequence || 0)))
						)),
						'cards'
					);

					$.get(cards);

					const currentCard = $.tag(
						$.derived_safe_equal(() => (
							$.deep_read_state($.get(cards)),
							$.get(storySlide),
							$.untrack(() => $.get(cards)[$.get(storySlide)])
						)),
						'currentCard'
					);

					$.get(currentCard);

					var div_132 = root_179();
					var node_127 = $.child(div_132);

					{
						var consequent_95 = ($$anchor) => {
							var div_133 = root_180();

							$.add_svelte_meta(
								() => $.each(div_133, 5, () => $.get(cards), $.index, ($$anchor, _, index) => {
									var i_3 = root_181();
									let classes_22;

									$.template_effect(() => classes_22 = $.set_class(i_3, 1, '', null, classes_22, { active: $.strict_equals(index, $.get(storySlide)) }));
									$.append($$anchor, i_3);
								}),
								'each',
								Home,
								266,
								656
							);

							$.reset(div_133);
							$.append($$anchor, div_133);
						};

						$.add_svelte_meta(
							() => $.if(node_127, ($$render) => {
								if ((
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.get(cards).length > 1)
								)) $$render(consequent_95);
							}),
							'if',
							Home,
							266,
							608
						);
					}

					var article_5 = $.sibling(node_127);
					var node_128 = $.child(article_5);

					{
						var consequent_96 = ($$anchor) => {
							var p_46 = root_182();
							var text_170 = $.child(p_46, true);

							$.reset(p_46);

							$.template_effect(() => $.set_text(text_170, (
								$.deep_read_state($.get(currentCard)),
								$.untrack(() => $.get(currentCard).eyebrow)
							)));

							$.append($$anchor, p_46);
						};

						$.add_svelte_meta(
							() => $.if(node_128, ($$render) => {
								if ((
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).eyebrow)
								)) $$render(consequent_96);
							}),
							'if',
							Home,
							266,
							939
						);
					}

					var node_129 = $.sibling(node_128);

					{
						var consequent_97 = ($$anchor) => {
							var div_134 = root_183();
							var span_35 = $.child(div_134);
							var text_171 = $.child(span_35, true);

							$.reset(span_35);

							var strong_29 = $.sibling(span_35);
							var text_172 = $.child(strong_29, true);

							$.reset(strong_29);
							$.reset(div_134);

							$.template_effect(() => {
								$.set_text(text_171, (
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).components[0].label)
								));

								$.set_text(text_172, (
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).components[0].displayValue)
								));
							});

							$.append($$anchor, div_134);
						};

						$.add_svelte_meta(
							() => $.if(node_129, ($$render) => {
								if ((
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.strict_equals($.get(currentCard).layout, 'HERO_STAT') && $.get(currentCard).components?.[0])
								)) $$render(consequent_97);
							}),
							'if',
							Home,
							266,
							1019
						);
					}

					var h1_1 = $.sibling(node_129);
					var text_173 = $.child(h1_1, true);

					$.reset(h1_1);

					var p_47 = $.sibling(h1_1);
					var text_174 = $.child(p_47, true);

					$.reset(p_47);

					var node_130 = $.sibling(p_47);

					{
						var consequent_98 = ($$anchor) => {
							var div_135 = root_184();

							$.add_svelte_meta(
								() => $.each(
									div_135,
									5,
									() => (
										$.deep_read_state($.get(currentCard)),
										$.untrack(() => $.get(currentCard).components)
									),
									$.index,
									($$anchor, component) => {
										var div_136 = root_185();
										var span_36 = $.child(div_136);
										var text_175 = $.child(span_36, true);

										$.reset(span_36);

										var strong_30 = $.sibling(span_36);
										var text_176 = $.child(strong_30, true);

										$.reset(strong_30);
										$.reset(div_136);

										$.template_effect(() => {
											$.set_text(text_175, ($.get(component), $.untrack(() => $.get(component).label)));

											$.set_text(text_176, (
												$.get(component),
												$.untrack(() => $.get(component).displayValue)
											));
										});

										$.append($$anchor, div_136);
									}
								),
								'each',
								Home,
								266,
								1351
							);

							$.reset(div_135);
							$.append($$anchor, div_135);
						};

						$.add_svelte_meta(
							() => $.if(node_130, ($$render) => {
								if ((
									$.deep_read_state($.get(currentCard)),
									$.untrack(() => $.get(currentCard).components?.length)
								)) $$render(consequent_98);
							}),
							'if',
							Home,
							266,
							1279
						);
					}

					var node_131 = $.sibling(node_130);

					$.add_svelte_meta(
						() => $.each(
							node_131,
							1,
							() => (
								$.deep_read_state($.get(currentCard)),
								$.untrack(() => $.get(currentCard).actions || [])
							),
							$.index,
							($$anchor, action) => {
								var fragment_56 = $.comment();
								var node_132 = $.first_child(fragment_56);

								{
									var consequent_99 = ($$anchor) => {
										var button_103 = root_187();
										var text_177 = $.child(button_103, true);

										$.reset(button_103);
										$.template_effect(() => $.set_text(text_177, ($.get(action), $.untrack(() => $.get(action).label))));
										$.event('click', button_103, openCommitmentSources);
										$.append($$anchor, button_103);
									};

									var alternate_45 = ($$anchor) => {
										var fragment_57 = $.comment();
										var node_133 = $.first_child(fragment_57);

										{
											var consequent_100 = ($$anchor) => {
												var button_104 = root_189();
												var text_178 = $.child(button_104, true);

												$.reset(button_104);
												$.template_effect(() => $.set_text(text_178, ($.get(action), $.untrack(() => $.get(action).label))));

												$.event('click', button_104, () => {
													$.set(openedStory, null);
													openMoney();
												});

												$.append($$anchor, button_104);
											};

											var alternate_44 = ($$anchor) => {
												var fragment_58 = $.comment();
												var node_134 = $.first_child(fragment_58);

												{
													var consequent_101 = ($$anchor) => {
														var button_105 = root_191();
														var text_179 = $.child(button_105, true);

														$.reset(button_105);
														$.template_effect(() => $.set_text(text_179, ($.get(action), $.untrack(() => $.get(action).label))));

														$.event('click', button_105, function (...$$args) {
															$.apply(() => openDueLoanFromStory, this, $$args, Home, [266, 1950]);
														});

														$.append($$anchor, button_105);
													};

													$.add_svelte_meta(
														() => $.if(
															node_134,
															($$render) => {
																if ((
																	$.get(action),
																	$.untrack(() => $.strict_equals($.get(action).type, 'OPEN_DUE_LOAN'))
																)) $$render(consequent_101);
															},
															true
														),
														'if',
														Home,
														266,
														1840
													);
												}

												$.append($$anchor, fragment_58);
											};

											$.add_svelte_meta(
												() => $.if(
													node_133,
													($$render) => {
														if ((
															$.get(action),
															$.untrack(() => $.strict_equals($.get(action).type, 'OPEN_SALARY_OUTLOOK'))
														)) $$render(consequent_100); else $$render(alternate_44, false);
													},
													true
												),
												'if',
												Home,
												266,
												1695
											);
										}

										$.append($$anchor, fragment_57);
									};

									$.add_svelte_meta(
										() => $.if(node_132, ($$render) => {
											if ((
												$.get(action),
												$.untrack(() => $.strict_equals($.get(action).type, 'OPEN_EVIDENCE'))
											)) $$render(consequent_99); else $$render(alternate_45, false);
										}),
										'if',
										Home,
										266,
										1535
									);
								}

								$.append($$anchor, fragment_56);
							}
						),
						'each',
						Home,
						266,
						1494
					);

					$.reset(article_5);

					var node_135 = $.sibling(article_5);

					{
						var consequent_102 = ($$anchor) => {
							var div_137 = root_192();
							var button_106 = $.child(div_137);
							var span_37 = $.sibling(button_106);
							var text_180 = $.child(span_37);

							$.reset(span_37);

							var button_107 = $.sibling(span_37);

							$.reset(div_137);

							$.template_effect(() => {
								button_106.disabled = $.strict_equals($.get(storySlide), 0);

								$.set_text(text_180, `${$.get(storySlide) + 1} of ${(
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.get(cards).length)
								) ?? ''}`);

								button_107.disabled = (
									$.get(storySlide),
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.strict_equals($.get(storySlide), $.get(cards).length - 1))
								);
							});

							$.event('click', button_106, () => $.set(storySlide, $.get(storySlide) - 1));
							$.event('click', button_107, () => $.set(storySlide, $.get(storySlide) + 1));
							$.append($$anchor, div_137);
						};

						$.add_svelte_meta(
							() => $.if(node_135, ($$render) => {
								if ((
									$.deep_read_state($.get(cards)),
									$.untrack(() => $.get(cards).length > 1)
								)) $$render(consequent_102);
							}),
							'if',
							Home,
							266,
							2017
						);
					}

					$.reset(div_132);

					$.template_effect(() => {
						$.set_class(article_5, 1, (
							$.deep_read_state($.get(currentCard)),
							$.untrack(() => `story-slide deck-theme-${$.get(currentCard).theme || 'CALM_CONTEXT'}`)
						));

						$.set_text(text_173, (
							$.deep_read_state($.get(currentCard)),
							$.untrack(() => $.get(currentCard).title)
						));

						$.set_text(text_174, (
							$.deep_read_state($.get(currentCard)),
							$.untrack(() => $.get(currentCard).body)
						));
					});

					$.event('touchstart', article_5, (event) => $.set(storyTouchStart, event.touches[0].clientX));
					$.event('touchend', article_5, (event) => endStorySwipe(event, $.get(cards).length));
					$.append($$anchor, div_132);
				};

				$.add_svelte_meta(
					() => $.if(node_126, ($$render) => {
						if (hasDeck) $$render(consequent_103);
					}),
					'if',
					Home,
					266,
					448
				);
			}

			$.reset(section_38);
			$.reset(div_131);

			$.template_effect(($0, $1) => $.set_text(text_169, `${$0 ?? ''} · ${$1 ?? ''}`), [
				() => (
					$.get(openedStory),
					$.untrack(() => storySource($.get(openedStory)).toUpperCase())
				),

				() => (
					$.get(openedStory),
					$.untrack(() => storyName($.get(openedStory)))
				)
			]);

			$.event('click', button_102, () => $.set(openedStory, null));

			$.event('click', section_38, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_131, () => $.set(openedStory, null));
			$.event('keydown', div_131, (event) => $.strict_equals(event.key, 'Escape') && $.set(openedStory, null));
			$.append($$anchor, div_131);
		};

		$.add_svelte_meta(
			() => $.if(node_125, ($$render) => {
				if ($.get(openedStory)) $$render(consequent_104);
			}),
			'if',
			Home,
			266,
			0
		);
	}

	var node_136 = $.sibling(node_125, 2);

	{
		var consequent_108 = ($$anchor) => {
			var div_138 = root_193();
			var section_39 = $.child(div_138);
			var button_108 = $.child(section_39);
			var node_137 = $.sibling(button_108, 4);

			{
				var consequent_105 = ($$anchor) => {
					var p_48 = root_194();

					$.append($$anchor, p_48);
				};

				var alternate_47 = ($$anchor) => {
					var fragment_59 = $.comment();
					var node_138 = $.first_child(fragment_59);

					{
						var consequent_106 = ($$anchor) => {
							var p_49 = root_196();
							var text_181 = $.child(p_49, true);

							$.reset(p_49);
							$.template_effect(() => $.set_text(text_181, $.get(commitmentError)));
							$.append($$anchor, p_49);
						};

						var alternate_46 = ($$anchor) => {
							var fragment_60 = root_197();
							var node_139 = $.first_child(fragment_60);

							$.add_svelte_meta(
								() => $.each(node_139, 1, () => $.get(commitmentReview), $.index, ($$anchor, candidate) => {
									var fragment_61 = root_198();
									var div_139 = $.first_child(fragment_61);
									var strong_31 = $.child(div_139);
									var text_182 = $.child(strong_31);

									$.reset(strong_31);

									var span_38 = $.sibling(strong_31);
									var text_183 = $.child(span_38, true);

									$.reset(span_38);
									$.reset(div_139);

									var node_140 = $.sibling(div_139, 2);

									$.add_svelte_meta(
										() => $.each(node_140, 1, () => ($.get(candidate), $.untrack(() => $.get(candidate).choices)), $.index, ($$anchor, choice) => {
											var button_109 = root_199();
											var text_184 = $.child(button_109, true);

											$.reset(button_109);

											$.template_effect(() => {
												button_109.disabled = (
													$.get(resolvingCandidate),
													$.get(candidate),
													$.untrack(() => $.strict_equals($.get(resolvingCandidate), $.get(candidate).transactionId))
												);

												$.set_text(text_184, ($.get(choice), $.untrack(() => $.get(choice).label)));
											});

											$.event('click', button_109, () => resolveCandidate($.get(candidate).transactionId, $.get(choice).id));
											$.append($$anchor, button_109);
										}),
										'each',
										Home,
										268,
										791
									);

									var button_110 = $.sibling(node_140);

									$.template_effect(
										($0, $1) => {
											$.set_text(text_182, `${$0 ?? ''} · ${($.get(candidate), $.untrack(() => $.get(candidate).category)) ?? ''} / ${(
												$.get(candidate),
												$.untrack(() => $.get(candidate).subcategory)
											) ?? ''}`);

											$.set_text(text_183, $1);

											button_110.disabled = (
												$.get(resolvingCandidate),
												$.get(candidate),
												$.untrack(() => $.strict_equals($.get(resolvingCandidate), $.get(candidate).transactionId))
											);
										},
										[
											() => (
												$.get(candidate),
												$.untrack(() => money($.get(candidate).amount))
											),

											() => (
												$.get(candidate),
												$.untrack(() => dateLabel($.get(candidate).transactionDate))
											)
										]
									);

									$.event('click', button_110, () => resolveCandidate($.get(candidate).transactionId, null));
									$.append($$anchor, fragment_61);
								}),
								'each',
								Home,
								268,
								545
							);

							var node_141 = $.sibling(node_139);

							{
								var consequent_107 = ($$anchor) => {
									var p_50 = root_200();

									$.append($$anchor, p_50);
								};

								$.add_svelte_meta(
									() => $.if(node_141, ($$render) => {
										if ((
											$.get(commitmentReview),
											$.untrack(() => !$.get(commitmentReview).length)
										)) $$render(consequent_107);
									}),
									'if',
									Home,
									268,
									1192
								);
							}

							$.append($$anchor, fragment_60);
						};

						$.add_svelte_meta(
							() => $.if(
								node_138,
								($$render) => {
									if ($.strict_equals($.get(commitmentReviewStatus), 'error')) $$render(consequent_106); else $$render(alternate_46, false);
								},
								true
							),
							'if',
							Home,
							268,
							452
						);
					}

					$.append($$anchor, fragment_59);
				};

				$.add_svelte_meta(
					() => $.if(node_137, ($$render) => {
						if ($.strict_equals($.get(commitmentReviewStatus), 'loading')) $$render(consequent_105); else $$render(alternate_47, false);
					}),
					'if',
					Home,
					268,
					381
				);
			}

			$.reset(section_39);
			$.reset(div_138);
			$.event('click', button_108, () => $.set(showCommitmentReview, false));
			$.append($$anchor, div_138);
		};

		$.add_svelte_meta(
			() => $.if(node_136, ($$render) => {
				if ($.get(showCommitmentReview)) $$render(consequent_108);
			}),
			'if',
			Home,
			268,
			0
		);
	}

	var node_142 = $.sibling(node_136, 2);

	{
		var consequent_114 = ($$anchor) => {
			var div_140 = root_201();
			var section_40 = $.child(div_140);
			var button_111 = $.child(section_40);
			var h2_17 = $.sibling(button_111, 2);
			var text_185 = $.child(h2_17, true);

			$.reset(h2_17);

			var node_143 = $.sibling(h2_17);

			{
				var consequent_113 = ($$anchor) => {
					var fragment_62 = root_202();
					var p_51 = $.first_child(fragment_62);
					var text_186 = $.child(p_51);

					$.reset(p_51);

					var div_141 = $.sibling(p_51);

					$.add_svelte_meta(
						() => $.each(div_141, 5, () => $.get(evidenceItems), $.index, ($$anchor, item) => {
							const loanItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => (/loan/i).test($.get(item).category))
								)),
								'loanItem'
							);

							$.get(loanItem);

							const fundItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => $.strict_equals($.get(item).sourceType, 'mutual_fund_sip'))
								)),
								'fundItem'
							);

							$.get(fundItem);

							const stockItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => $.strict_equals($.get(item).sourceType, 'stock_monthly_plan'))
								)),
								'stockItem'
							);

							$.get(stockItem);

							const recurringItem = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => $.strict_equals($.get(item).sourceType, 'recurring_commitment'))
								)),
								'recurringItem'
							);

							$.get(recurringItem);

							const recurringStatus = $.tag(
								$.derived_safe_equal(() => (
									$.get(item),
									$.untrack(() => recurringOccurrence($.get(item).sourceId)?.status)
								)),
								'recurringStatus'
							);

							$.get(recurringStatus);

							var div_142 = root_203();
							let classes_23;
							var div_143 = $.child(div_142);
							var strong_32 = $.child(div_143);
							var text_187 = $.child(strong_32, true);

							$.reset(strong_32);

							var span_39 = $.sibling(strong_32);
							var text_188 = $.child(span_39);

							$.reset(span_39);
							$.reset(div_143);

							var b_27 = $.sibling(div_143);
							var text_189 = $.child(b_27, true);

							$.reset(b_27);

							var node_144 = $.sibling(b_27);

							{
								var consequent_109 = ($$anchor) => {
									var button_112 = root_204();

									$.event('click', button_112, openIncludedLoan);
									$.append($$anchor, button_112);
								};

								var alternate_50 = ($$anchor) => {
									var fragment_63 = $.comment();
									var node_145 = $.first_child(fragment_63);

									{
										var consequent_110 = ($$anchor) => {
											var button_113 = root_206();

											$.template_effect(() => $.set_attribute(button_113, 'data-testid', (
												$.get(item),
												$.untrack(() => `included-mutual-fund-commitment-${$.get(item).sourceId}`)
											)));

											$.event('click', button_113, () => openIncludedMutualFund($.get(item)));
											$.append($$anchor, button_113);
										};

										var alternate_49 = ($$anchor) => {
											var fragment_64 = $.comment();
											var node_146 = $.first_child(fragment_64);

											{
												var consequent_111 = ($$anchor) => {
													var button_114 = root_208();

													$.template_effect(() => $.set_attribute(button_114, 'data-testid', (
														$.get(item),
														$.untrack(() => `included-stock-commitment-${$.get(item).sourceId}`)
													)));

													$.event('click', button_114, () => openIncludedStock($.get(item)));
													$.append($$anchor, button_114);
												};

												var alternate_48 = ($$anchor) => {
													var fragment_65 = $.comment();
													var node_147 = $.first_child(fragment_65);

													{
														var consequent_112 = ($$anchor) => {
															var button_115 = root_210();

															$.template_effect(() => $.set_attribute(button_115, 'data-testid', (
																$.get(item),
																$.untrack(() => `included-recurring-commitment-${$.get(item).sourceId}`)
															)));

															$.event('click', button_115, () => openIncludedCommitment($.get(item)));
															$.append($$anchor, button_115);
														};

														$.add_svelte_meta(
															() => $.if(
																node_147,
																($$render) => {
																	if ($.get(recurringItem)) $$render(consequent_112);
																},
																true
															),
															'if',
															Home,
															269,
															1923
														);
													}

													$.append($$anchor, fragment_65);
												};

												$.add_svelte_meta(
													() => $.if(
														node_146,
														($$render) => {
															if ($.get(stockItem)) $$render(consequent_111); else $$render(alternate_48, false);
														},
														true
													),
													'if',
													Home,
													269,
													1764
												);
											}

											$.append($$anchor, fragment_64);
										};

										$.add_svelte_meta(
											() => $.if(
												node_145,
												($$render) => {
													if ($.get(fundItem)) $$render(consequent_110); else $$render(alternate_49, false);
												},
												true
											),
											'if',
											Home,
											269,
											1595
										);
									}

									$.append($$anchor, fragment_63);
								};

								$.add_svelte_meta(
									() => $.if(node_144, ($$render) => {
										if ($.get(loanItem)) $$render(consequent_109); else $$render(alternate_50, false);
									}),
									'if',
									Home,
									269,
									1473
								);
							}

							$.reset(div_142);

							$.template_effect(
								($0) => {
									classes_23 = $.set_class(div_142, 1, 'evidence-row', null, classes_23, $0);
									$.set_text(text_187, ($.get(item), $.untrack(() => $.get(item).merchant)));

									$.set_text(text_188, `${($.get(item), $.untrack(() => $.get(item).date)) ?? ''}${(
										$.get(item),
										$.untrack(() => $.get(item).date && $.get(item).category ? ' · ' : '')
									) ?? ''}${($.get(item), $.untrack(() => $.get(item).category)) ?? ''}`);

									$.set_text(text_189, ($.get(item), $.untrack(() => $.get(item).amount)));
								},
								[
									() => ({
										'due-commitment': $.get(loanItem) && currentCommitmentIsDue() || $.get(fundItem) && sipIsDue($.get(item)) || $.get(stockItem) && $.strict_equals($.get(stocks).find((stock) => $.strict_equals(String(stock.id), String($.get(item).sourceId)))?.currentMonthlyPlan?.status, 'DUE') || $.get(recurringItem) && $.strict_equals($.get(recurringStatus), 'DUE'),
										'confirmed-commitment': $.get(fundItem) && sipIsConfirmed($.get(item)) || $.get(recurringItem) && $.strict_equals($.get(recurringStatus), 'COMPLETED')
									})
								]
							);

							$.append($$anchor, div_142);
						}),
						'each',
						Home,
						269,
						645
					);

					$.reset(div_141);

					$.template_effect(() => $.set_text(text_186, `${(
						$.get(evidenceItems),
						$.untrack(() => $.get(evidenceItems).length)
					) ?? ''} included ${(
						$.get(evidenceItems),
						$.untrack(() => $.strict_equals($.get(evidenceItems).length, 1) ? 'commitment' : 'commitments')
					) ?? ''}`));

					$.append($$anchor, fragment_62);
				};

				var alternate_51 = ($$anchor) => {
					var div_144 = root_211();

					$.append($$anchor, div_144);
				};

				$.add_svelte_meta(
					() => $.if(node_143, ($$render) => {
						if ((
							$.get(evidenceItems),
							$.untrack(() => $.get(evidenceItems).length)
						)) $$render(consequent_113); else $$render(alternate_51, false);
					}),
					'if',
					Home,
					269,
					477
				);
			}

			$.reset(section_40);
			$.reset(div_140);

			$.template_effect(($0) => $.set_text(text_185, $0), [
				() => (
					$.get(openedStory),
					$.untrack(() => isCommitment($.get(openedStory)) ? 'What makes up this month' : 'Supporting evidence')
				)
			]);

			$.event('click', button_111, () => $.set(showStoryEvidence, false));

			$.event('click', section_40, $.stopPropagation(function ($$arg) {
				$.bubble_event.call(this, $$props, $$arg);
			}));

			$.event('click', div_140, () => $.set(showStoryEvidence, false));
			$.event('keydown', div_140, (event) => $.strict_equals(event.key, 'Escape') && $.set(showStoryEvidence, false));
			$.append($$anchor, div_140);
		};

		$.add_svelte_meta(
			() => $.if(node_142, ($$render) => {
				if ($.get(showStoryEvidence)) $$render(consequent_114);
			}),
			'if',
			Home,
			269,
			0
		);
	}

	var node_148 = $.sibling(node_142, 2);

	{
		var consequent_118 = ($$anchor) => {
			var div_145 = root_212();
			var section_41 = $.child(div_145);
			var button_116 = $.child(section_41);
			var label_56 = $.sibling(button_116, 4);
			var input_50 = $.sibling($.child(label_56));

			$.remove_input_defaults(input_50);
			$.reset(label_56);

			var label_57 = $.sibling(label_56);
			var input_51 = $.sibling($.child(label_57));

			$.remove_input_defaults(input_51);
			$.reset(label_57);

			var node_149 = $.sibling(label_57);

			{
				var consequent_115 = ($$anchor) => {
					var p_52 = root_213();

					$.append($$anchor, p_52);
				};

				var alternate_53 = ($$anchor) => {
					var fragment_66 = $.comment();
					var node_150 = $.first_child(fragment_66);

					{
						var consequent_116 = ($$anchor) => {
							var p_53 = root_215();
							var text_190 = $.child(p_53, true);

							$.reset(p_53);
							$.template_effect(() => $.set_text(text_190, $.get(optionsError)));
							$.append($$anchor, p_53);
						};

						var alternate_52 = ($$anchor) => {
							var fragment_67 = root_216();
							var label_58 = $.first_child(fragment_67);
							var select_6 = $.sibling($.child(label_58));
							var option_9 = $.child(select_6);

							option_9.value = option_9.__value = '';

							var node_151 = $.sibling(option_9);

							$.add_svelte_meta(
								() => $.each(
									node_151,
									1,
									() => (
										$.get(editOptions),
										$.untrack(() => $.get(editOptions).categories)
									),
									$.index,
									($$anchor, option) => {
										var option_10 = root_217();
										var text_191 = $.child(option_10, true);

										$.reset(option_10);

										var option_10_value = {};

										$.template_effect(() => {
											$.set_text(text_191, ($.get(option), $.untrack(() => $.get(option).name)));

											if (option_10_value !== (option_10_value = ($.get(option), $.untrack(() => $.get(option).name)))) {
												option_10.value = (option_10.__value = ($.get(option), $.untrack(() => $.get(option).name))) ?? '';
											}
										});

										$.append($$anchor, option_10);
									}
								),
								'each',
								Home,
								270,
								911
							);

							$.reset(select_6);

							var select_6_value;

							$.init_select(select_6);
							$.reset(label_58);

							var label_59 = $.sibling(label_58);
							var select_7 = $.sibling($.child(label_59));

							$.template_effect(() => {
								$.get(editSubcategory);

								$.invalidate_inner_signals(() => {
									$.get(editCategory);
									$.get(editSubcategories);
								});
							});

							var option_11 = $.child(select_7);

							option_11.value = option_11.__value = '';

							var node_152 = $.sibling(option_11);

							$.add_svelte_meta(
								() => $.each(node_152, 1, () => $.get(editSubcategories), $.index, ($$anchor, option) => {
									var option_12 = root_218();
									var text_192 = $.child(option_12, true);

									$.reset(option_12);

									var option_12_value = {};

									$.template_effect(() => {
										$.set_text(text_192, $.get(option));

										if (option_12_value !== (option_12_value = $.get(option))) {
											option_12.value = (option_12.__value = $.get(option)) ?? '';
										}
									});

									$.append($$anchor, option_12);
								}),
								'each',
								Home,
								270,
								1160
							);

							$.reset(select_7);
							$.reset(label_59);

							var label_60 = $.sibling(label_59);
							var select_8 = $.sibling($.child(label_60));

							$.template_effect(() => {
								$.get(editMerchantId);

								$.invalidate_inner_signals(() => {
									$.get(editOptions);
									String;
								});
							});

							var option_13 = $.child(select_8);

							option_13.value = option_13.__value = '';

							var node_153 = $.sibling(option_13);

							$.add_svelte_meta(
								() => $.each(
									node_153,
									1,
									() => (
										$.get(editOptions),
										$.untrack(() => $.get(editOptions).merchants)
									),
									$.index,
									($$anchor, option) => {
										var option_14 = root_219();
										var text_193 = $.child(option_14, true);

										$.reset(option_14);

										var option_14_value = {};

										$.template_effect(
											($0) => {
												$.set_text(text_193, ($.get(option), $.untrack(() => $.get(option).name)));

												if (option_14_value !== (option_14_value = $0)) {
													option_14.value = (option_14.__value = $0) ?? '';
												}
											},
											[
												() => ($.get(option), $.untrack(() => String($.get(option).id)))
											]
										);

										$.append($$anchor, option_14);
									}
								),
								'each',
								Home,
								270,
								1362
							);

							$.reset(select_8);
							$.reset(label_60);

							var label_61 = $.sibling(label_60);
							var select_9 = $.sibling($.child(label_61));

							$.template_effect(() => {
								$.get(editAccountId);

								$.invalidate_inner_signals(() => {
									$.get(editOptions);
									String;
								});
							});

							var option_15 = $.child(select_9);

							option_15.value = option_15.__value = '';

							var node_154 = $.sibling(option_15);

							$.add_svelte_meta(
								() => $.each(
									node_154,
									1,
									() => (
										$.get(editOptions),
										$.untrack(() => $.get(editOptions).accounts)
									),
									$.index,
									($$anchor, option) => {
										var option_16 = root_220();
										var text_194 = $.child(option_16, true);

										$.reset(option_16);

										var option_16_value = {};

										$.template_effect(
											($0) => {
												$.set_text(text_194, ($.get(option), $.untrack(() => $.get(option).name)));

												if (option_16_value !== (option_16_value = $0)) {
													option_16.value = (option_16.__value = $0) ?? '';
												}
											},
											[
												() => ($.get(option), $.untrack(() => String($.get(option).id)))
											]
										);

										$.append($$anchor, option_16);
									}
								),
								'each',
								Home,
								270,
								1589
							);

							$.reset(select_9);
							$.reset(label_61);

							$.template_effect(() => {
								if (select_6_value !== (select_6_value = $.get(editCategory))) {
									(
										select_6.value = (select_6.__value = $.get(editCategory)) ?? '',
										$.select_option(select_6, $.get(editCategory))
									);
								}

								select_7.disabled = !$.get(editCategory);
							});

							$.event('change', select_6, changeEditCategory);

							$.bind_select_value(
								select_7,
								function get() {
									return $.get(editSubcategory);
								},
								function set($$value) {
									$.set(editSubcategory, $$value);
								}
							);

							$.bind_select_value(
								select_8,
								function get() {
									return $.get(editMerchantId);
								},
								function set($$value) {
									$.set(editMerchantId, $$value);
								}
							);

							$.bind_select_value(
								select_9,
								function get() {
									return $.get(editAccountId);
								},
								function set($$value) {
									$.set(editAccountId, $$value);
								}
							);

							$.append($$anchor, fragment_67);
						};

						$.add_svelte_meta(
							() => $.if(
								node_150,
								($$render) => {
									if ($.strict_equals($.get(optionsStatus), 'error')) $$render(consequent_116); else $$render(alternate_52, false);
								},
								true
							),
							'if',
							Home,
							270,
							703
						);
					}

					$.append($$anchor, fragment_66);
				};

				$.add_svelte_meta(
					() => $.if(node_149, ($$render) => {
						if ($.strict_equals($.get(optionsStatus), 'loading')) $$render(consequent_115); else $$render(alternate_53, false);
					}),
					'if',
					Home,
					270,
					593
				);
			}

			var node_155 = $.sibling(node_149);

			{
				var consequent_117 = ($$anchor) => {
					var p_54 = root_221();
					var text_195 = $.child(p_54, true);

					$.reset(p_54);
					$.template_effect(() => $.set_text(text_195, $.get(actionError)));
					$.append($$anchor, p_54);
				};

				$.add_svelte_meta(
					() => $.if(node_155, ($$render) => {
						if ($.get(actionError)) $$render(consequent_117);
					}),
					'if',
					Home,
					270,
					1712
				);
			}

			var div_146 = $.sibling(node_155);
			var button_117 = $.child(div_146);
			var button_118 = $.sibling(button_117);
			var text_196 = $.child(button_118, true);

			$.reset(button_118);
			$.reset(div_146);
			$.reset(section_41);
			$.reset(div_145);

			$.template_effect(
				($0) => {
					$.set_attribute(input_51, 'max', $0);
					button_118.disabled = $.get(saving) || $.strict_equals($.get(optionsStatus), 'ready', false);
					$.set_text(text_196, $.get(saving) ? 'Saving…' : 'Save changes');
				},
				[
					() => ($.untrack(() => new Date().toISOString().slice(0, 10)))
				]
			);

			$.event('click', button_116, () => $.set(editing, null));

			$.bind_value(
				input_50,
				function get() {
					return $.get(editAmount);
				},
				function set($$value) {
					$.set(editAmount, $$value);
				}
			);

			$.bind_value(
				input_51,
				function get() {
					return $.get(editDate);
				},
				function set($$value) {
					$.set(editDate, $$value);
				}
			);

			$.event('click', button_117, () => $.set(editing, null));
			$.event('click', button_118, saveEdit);
			$.append($$anchor, div_145);
		};

		$.add_svelte_meta(
			() => $.if(node_148, ($$render) => {
				if ($.get(editing)) $$render(consequent_118);
			}),
			'if',
			Home,
			270,
			0
		);
	}

	var node_156 = $.sibling(node_148, 2);

	{
		var consequent_119 = ($$anchor) => {
			var div_147 = root_222();
			var section_42 = $.child(div_147);
			var h2_18 = $.sibling($.child(section_42));
			var text_197 = $.child(h2_18);

			$.reset(h2_18);

			var div_148 = $.sibling(h2_18, 2);
			var button_119 = $.child(div_148);
			var button_120 = $.sibling(button_119);

			$.reset(div_148);
			$.reset(section_42);
			$.reset(div_147);

			$.template_effect(($0) => $.set_text(text_197, `Delete ${$0 ?? ''}?`), [
				() => ($.get(deleting), $.untrack(() => merchant($.get(deleting))))
			]);

			$.event('click', button_119, () => $.set(deleting, null));
			$.event('click', button_120, confirmDelete);
			$.append($$anchor, div_147);
		};

		$.add_svelte_meta(
			() => $.if(node_156, ($$render) => {
				if ($.get(deleting)) $$render(consequent_119);
			}),
			'if',
			Home,
			271,
			0
		);
	}

	var node_157 = $.sibling(node_156, 2);

	{
		var consequent_121 = ($$anchor) => {
			var div_149 = root_223();
			var section_43 = $.child(div_149);
			var button_121 = $.child(section_43);
			var p_55 = $.sibling(button_121, 3);
			var text_198 = $.child(p_55);

			$.reset(p_55);

			var node_158 = $.sibling(p_55);

			{
				var consequent_120 = ($$anchor) => {
					var a_1 = root_224();

					$.template_effect(() => $.set_attribute(a_1, 'href', ($.get(handoff), $.untrack(() => $.get(handoff).whatsappUrl))));
					$.append($$anchor, a_1);
				};

				$.add_svelte_meta(
					() => $.if(node_158, ($$render) => {
						if (($.get(handoff), $.untrack(() => $.get(handoff).whatsappUrl))) $$render(consequent_120);
					}),
					'if',
					Home,
					272,
					337
				);
			}

			var button_122 = $.sibling(node_158);

			$.reset(section_43);
			$.reset(div_149);

			$.template_effect(($0) => $.set_text(text_198, `Send the missing transaction for ${$0 ?? ''}.`), [
				() => (
					$.get(handoff),
					$.untrack(() => dateLabel(`${$.get(handoff).date}T12:00:00`))
				)
			]);

			$.event('click', button_121, () => $.set(handoff, null));
			$.event('click', button_122, () => $.set(handoff, null));
			$.append($$anchor, div_149);
		};

		$.add_svelte_meta(
			() => $.if(node_157, ($$render) => {
				if ($.get(handoff)) $$render(consequent_121);
			}),
			'if',
			Home,
			272,
			0
		);
	}

	$.append($$anchor, fragment);

	return $.pop($$exports);
}

if (import.meta.hot) {
	Home = $.hmr(Home, () => Home[$.HMR].source);

	import.meta.hot.acceptExports(["default"],(module) => {
		module.default[$.HMR].source = Home[$.HMR].source;
		$.set(Home[$.HMR].source, module.default[$.HMR].original);
	});
}

export default Home;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7O09BRVMsa0JBQWtCO09BQ2xCLCtCQUErQjtTQUM3QixPQUFPLEVBQUUsSUFBSSxRQUFRLFFBQVE7OztDQUM3QixRQUFRO0NBQUUsY0FBYztDQUFFLDJCQUEyQjtDQUFFLG9CQUFvQjtDQUFFLHVCQUF1QjtDQUFFLGdCQUFnQjtDQUFFLFVBQVU7Q0FBRSx3QkFBd0I7Q0FBRSxnQkFBZ0I7Q0FBRSx1QkFBdUI7Q0FBRSxtQkFBbUI7Q0FBRSxXQUFXO0NBQUUsc0JBQXNCO0NBQUUseUJBQXlCO0NBQUUsYUFBYTtDQUFFLFVBQVU7Q0FBRSxnQkFBZ0I7Q0FBRSx5QkFBeUI7Q0FBRSxXQUFXO0NBQUUsVUFBVTtDQUFFLG1CQUFtQjtDQUFFLGNBQWM7Q0FBRSxpQkFBaUI7Q0FBRSxrQkFBa0I7Q0FBRSxnQkFBZ0I7Q0FBRSxjQUFjO0NBQUUsUUFBUTtDQUFFLGFBQWE7Q0FBRSxjQUFjO0NBQUUsNkJBQTZCO0NBQUUsdUJBQXVCO0NBQUUsUUFBUTtDQUFFLFNBQVM7Q0FBRSxNQUFNO0NBQUUsZUFBZTtDQUFFLG1DQUFtQztDQUFFLHVCQUF1QjtDQUFFLGlCQUFpQjtDQUFFLGlCQUFpQjtDQUFFLFlBQVk7Q0FBRSxnQkFBZ0I7Q0FBRSxhQUFhO0NBQUUsVUFBVTtDQUFFLHlCQUF5QjtDQUFFLG1CQUFtQjtDQUFFLDJCQUEyQjtPQUFRLGNBQWM7O09BQzkzQixZQUFZLE1BQU0sdUJBQXVCO09BQ3pDLGFBQWEsTUFBTSx3QkFBd0I7T0FDM0MsU0FBUyxNQUFNLCtCQUErQjtPQUM5QyxTQUFTLE1BQU0sK0JBQStCO09BQzlDLFdBQVcsTUFBTSxpQ0FBaUM7T0FDbEQsZUFBZSxNQUFNLHFDQUFxQztPQUMxRCxhQUFhLE1BQU0sbUNBQW1DO09BQ3RELGVBQWUsTUFBTSwyQ0FBMkM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0FiekUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQWNZLGVBQWU7S0FBYSxhQUFhO0tBQWEsY0FBYztLQUFhLGFBQWE7S0FBYSxnQkFBZ0I7S0FBYSxjQUFjO0tBQWEsUUFBUTtLQUFhLGdCQUFnQjtLQUFhLGFBQWE7S0FBYSxlQUFlO0tBQWEsYUFBYTtLQUFhLGNBQWM7S0FBYSxpQkFBaUI7S0FBYSxRQUFRO0tBRTdXLElBQUksb0JBQUMsTUFBTTtLQUFFLFNBQVMsb0JBQUMsS0FBSztLQUFFLGlCQUFpQixvQkFBQyxLQUFLO0tBQUUsV0FBVyxvQkFBQyxJQUFJO0tBQUUsV0FBVyxvQkFBQyxRQUFRO0tBQUUsUUFBUTtLQUFLLFNBQVMsb0JBQUMsTUFBTTtLQUFFLE9BQU8sb0JBQUMsS0FBSztLQUFFLFVBQVUsb0JBQUMsSUFBSTtLQUM1SixXQUFXLG9CQUFDLElBQUk7S0FBRSxPQUFPLG9CQUFDLElBQUk7S0FBRSxhQUFhLG9CQUFDLEtBQUs7S0FBRSxXQUFXLG9CQUFDLEVBQUU7S0FBRSxVQUFVLG9CQUFDLEtBQUs7S0FBRSxZQUFZLG9CQUFDLEVBQUU7S0FBRSxhQUFhLG9CQUFDLEtBQUs7S0FBRSxTQUFTLG9CQUFDLEVBQUU7S0FBRSxVQUFVLG9CQUFDLENBQUM7S0FBRSxlQUFlLG9CQUFDLElBQUk7S0FBRSxpQkFBaUIsb0JBQUMsS0FBSztLQUFFLFdBQVcsb0JBQUMsS0FBSztLQUFFLGNBQWMsb0JBQUMsQ0FBQztLQUFFLGdCQUFnQixvQkFBQyxDQUFDO0tBQUUsbUJBQW1CLG9CQUFDLElBQUk7S0FDelIsZUFBZSxvQkFBQyxTQUFTO0tBQ3pCLE9BQU8sb0JBQUMsSUFBSTtLQUFFLFVBQVUsb0JBQUMsRUFBRTtLQUFFLFFBQVEsb0JBQUMsRUFBRTtLQUFFLFlBQVksb0JBQUMsRUFBRTtLQUFFLGVBQWUsb0JBQUMsRUFBRTtLQUFFLGNBQWMsb0JBQUMsRUFBRTtLQUFFLGFBQWEsb0JBQUMsRUFBRTtLQUFFLE1BQU0sb0JBQUMsS0FBSztLQUFFLFFBQVEsb0JBQUMsSUFBSTtLQUMvSSxXQUFXLHNCQUFFLFVBQVUsTUFBSSxTQUFTLE1BQUksUUFBUTtLQUFNLGFBQWEsb0JBQUMsTUFBTTtLQUFFLFlBQVksb0JBQUMsRUFBRTtLQUMzRixhQUFhLEtBQUUsUUFBUSxFQUFDLElBQUksRUFBQyxXQUFXLEVBQUMsSUFBSSxFQUFDLFFBQVEsRUFBQyxJQUFJO0tBQzNELFlBQVksb0JBQUMsS0FBSztLQUFFLFNBQVMsb0JBQUMsRUFBRTtLQUFFLFVBQVUsb0JBQUMsTUFBTTtLQUFFLGFBQWEsb0JBQUMsSUFBSTtLQUFFLFVBQVUsb0JBQUMsS0FBSztLQUFFLGNBQWMsb0JBQUMsSUFBSTtLQUFFLGVBQWUsb0JBQUMsS0FBSzs7S0FDckksUUFBUTtFQUFFLFFBQVEsRUFBQyxFQUFFO0VBQUMsUUFBUSxFQUFDLE1BQU07RUFBQyxVQUFVLEVBQUMsRUFBRTtFQUFDLGlCQUFpQixFQUFDLEVBQUU7RUFBQyxnQkFBZ0IsRUFBQyxFQUFFO0VBQUMsaUJBQWlCLEVBQUMsRUFBRTtFQUFDLGVBQWUsRUFBQyxFQUFFO0VBQUMsS0FBSyxFQUFDLEVBQUU7OztLQUM3SSxLQUFLO0tBQ0wsV0FBVyxvQkFBQyxJQUFJO0tBQUUsaUJBQWlCLG9CQUFDLE1BQU07S0FBRSxnQkFBZ0Isb0JBQUMsRUFBRTtLQUMvRCxXQUFXO0tBQUssZ0JBQWdCLG9CQUFDLE1BQU07S0FBRSxlQUFlLG9CQUFDLEVBQUU7S0FBRSxrQkFBa0Isb0JBQUMsS0FBSztLQUFFLGdCQUFnQixvQkFBQyxLQUFLO0tBQUUsbUJBQW1CLG9CQUFDLElBQUk7S0FBRSxvQkFBb0Isb0JBQUMsSUFBSTtLQUFFLHNCQUFzQixHQUFDLElBQUk7S0FDL0wsaUJBQWlCLG9CQUFDLElBQUk7S0FBRSx1QkFBdUIsb0JBQUMsTUFBTTtLQUFFLHNCQUFzQixvQkFBQyxFQUFFOztLQUNqRixjQUFjO0VBQUUsS0FBSyxFQUFDLEVBQUU7RUFBQyxjQUFjLEVBQUMsRUFBRTtFQUFDLE1BQU0sRUFBQyxFQUFFO0VBQUMsVUFBVSxFQUFDLE9BQU87RUFBQyxjQUFjLEVBQUMsT0FBTztFQUFDLGtCQUFrQixFQUFDLEdBQUc7RUFBQyxnQkFBZ0IsRUFBQyxLQUFLO0VBQUMsZ0JBQWdCLEVBQUMsRUFBRTs7O0tBQ2hLLG9CQUFvQixvQkFBQyxJQUFJO0tBQUUsY0FBYyxzQkFBRSxZQUFZLEVBQUMsRUFBRSxFQUFDLFdBQVcsRUFBQyxFQUFFLEVBQUMsZ0JBQWdCLEVBQUMsRUFBRTtLQUM3RixXQUFXO0tBQUssZ0JBQWdCLG9CQUFDLE1BQU07S0FBRSxlQUFlLG9CQUFDLEVBQUU7S0FBRSxrQkFBa0Isb0JBQUMsS0FBSztLQUFFLGdCQUFnQixvQkFBQyxLQUFLO0tBQUUsbUJBQW1CLG9CQUFDLElBQUk7O0tBQ3ZJLGNBQWM7RUFBRSxrQkFBa0IsRUFBQyxFQUFFO0VBQUMsUUFBUSxFQUFDLEVBQUU7RUFBQyxVQUFVLEVBQUMsRUFBRTtFQUFDLFlBQVksRUFBQyxFQUFFO0VBQUMsTUFBTSxFQUFDLEVBQUU7OztLQUN6RixvQkFBb0Isb0JBQUMsS0FBSztLQUFFLGdCQUFnQjtLQUFLLHNCQUFzQixvQkFBQyxNQUFNO0tBQUUsa0JBQWtCLG9CQUFDLElBQUk7S0FDdkcsYUFBYSxzQkFBRSxNQUFNLEVBQUMsSUFBSTtLQUFHLFlBQVksb0JBQUMsTUFBTTtLQUFFLFdBQVcsb0JBQUMsRUFBRTtLQUFFLFlBQVksb0JBQUMsS0FBSztLQUFFLGNBQWMsb0JBQUMsS0FBSzs7S0FDMUcsVUFBVTtFQUFFLGdCQUFnQixFQUFDLE9BQU87RUFBQyxXQUFXLEVBQUMsc0JBQXNCO0VBQUMsa0JBQWtCLEVBQUMsRUFBRTtFQUFDLGVBQWUsRUFBQyxTQUFTOzs7S0FDdkgsa0JBQWtCLG9CQUFDLEtBQUs7S0FBRSxXQUFXLG9CQUFDLEVBQUU7S0FBRSxjQUFjLG9CQUFDLEtBQUs7S0FBRSxjQUFjLG9CQUFDLElBQUk7S0FBRSxTQUFTLG9CQUFDLEVBQUU7S0FBRSxTQUFTLG9CQUFDLEtBQUs7S0FBRSxVQUFVLG9CQUFDLEtBQUs7S0FBRSxrQkFBa0Isb0JBQUMsTUFBTTtLQUFFLGFBQWE7S0FBSyxtQkFBbUIsR0FBQyxDQUFDO0tBQ3hNLFdBQVc7S0FBSyxnQkFBZ0Isb0JBQUMsTUFBTTtLQUFFLGVBQWUsb0JBQUMsRUFBRTtLQUFFLG9CQUFvQixvQkFBQyxJQUFJO0tBQ3RGLE1BQU07S0FBSyxXQUFXLG9CQUFDLE1BQU07S0FBRSxVQUFVLG9CQUFDLEVBQUU7S0FBRSxhQUFhLG9CQUFDLEtBQUs7S0FBRSxVQUFVLG9CQUFDLEVBQUU7S0FBRSxhQUFhLG9CQUFDLElBQUk7S0FBRSxZQUFZO0tBQUssaUJBQWlCLG9CQUFDLE1BQU07S0FBRSxrQkFBa0IsR0FBQyxDQUFDO0tBQUUsV0FBVyxvQkFBQyxLQUFLO0tBQUUsZUFBZSxvQkFBQyxJQUFJO0tBQzlNLGVBQWUsb0JBQUMsSUFBSTtLQUFDLGFBQWEsc0JBQUUsTUFBTSxFQUFDLEVBQUUsRUFBQyxHQUFHLEVBQUMsRUFBRSxFQUFDLFVBQVUsRUFBQyxFQUFFO0tBQUUsZUFBZSxvQkFBQyxLQUFLO0tBQUMsMkJBQTJCLG9CQUFDLElBQUk7S0FBQyxxQkFBcUIsc0JBQUUsTUFBTSxFQUFDLEVBQUUsRUFBQyxLQUFLLEVBQUMsRUFBRTtLQUFFLFdBQVcsb0JBQUMsSUFBSTtLQUFDLGlCQUFpQixvQkFBQyxNQUFNO0tBQUMsa0JBQWtCLG9CQUFDLElBQUk7S0FDdk8sU0FBUyxzQkFBRSxRQUFRLEVBQUMsRUFBRSxFQUFDLGFBQWEsRUFBQyxFQUFFO0tBQ3ZDLE9BQU87S0FBSyxhQUFhLEdBQUMsTUFBTTtLQUFFLFlBQVksR0FBQyxFQUFFO0tBQUUsa0JBQWtCLG9CQUFDLElBQUk7S0FBRSxpQkFBaUIsb0JBQUMsSUFBSTtLQUFFLGlCQUFpQixHQUFDLElBQUk7S0FDMUgsYUFBYSxvQkFBQyxJQUFJO0tBQUUsZUFBZSxvQkFBQyxFQUFFO0tBQUUsZ0JBQWdCLG9CQUFDLEtBQUs7O0tBQUUsY0FBYztFQUFFLE1BQU0sRUFBQyxFQUFFO0VBQUMsZUFBZSxNQUFLLElBQUksR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBQyxFQUFFO0VBQUUsR0FBRyxFQUFDLEVBQUU7OztLQUNySixVQUFVLG9CQUFDLElBQUk7S0FBRSxnQkFBZ0Isb0JBQUMsTUFBTTtLQUFFLGVBQWUsb0JBQUMsRUFBRTtLQUFFLFdBQVcsb0JBQUMsSUFBSTtLQUFFLGFBQWEsb0JBQUMsS0FBSztLQUFFLFlBQVksb0JBQUMsRUFBRTtLQUFFLFdBQVcsc0JBQUUsTUFBTSxFQUFDLEVBQUUsRUFBQyxlQUFlLEVBQUMsRUFBRSxFQUFDLEdBQUcsRUFBQyxFQUFFO0tBQ3RLLHNCQUFzQixvQkFBQyxJQUFJO0tBQUUscUJBQXFCLG9CQUFDLEtBQUs7S0FBRSxvQkFBb0Isb0JBQUMsRUFBRTtLQUFFLG1CQUFtQixzQkFBRSxNQUFNLEVBQUMsRUFBRSxFQUFDLGVBQWUsRUFBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEVBQUU7T0FDekksdUJBQXVCLEdBQUMsc0NBQXNDOztLQUNoRSxRQUFRO0VBQUUsTUFBTSxFQUFDLEtBQUs7RUFBQyxTQUFTLEVBQUMsT0FBTztFQUFDLE9BQU8sRUFBQyxHQUFHO0VBQUMsVUFBVSxFQUFDLFNBQVM7RUFBQyxVQUFVLEVBQUMsS0FBSztFQUFDLFlBQVksRUFBQyxTQUFTO0VBQUMsYUFBYSxFQUFDLE9BQU87OztLQUN2SSxhQUFhLG9CQUFDLElBQUk7S0FBRSxXQUFXLHNCQUFFLE1BQU0sRUFBQyxFQUFFLEVBQUMsR0FBRyxFQUFDLEVBQUUsRUFBQyxVQUFVLEVBQUMsRUFBRTtLQUFHLGFBQWEsb0JBQUMsS0FBSzs7T0FlbkYsS0FBSyxJQUFDLEtBQUssU0FBTSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU87RUFBRSxLQUFLLEVBQUMsVUFBVTtFQUFDLFFBQVEsUUFBUixRQUFRO0VBQUMscUJBQXFCLEVBQUMsQ0FBQztJQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFFLENBQUM7O09BQ3RILFlBQVksSUFBQyxLQUFLLFNBQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPO0VBQUUsS0FBSyxFQUFDLFVBQVU7RUFBQyxRQUFRLFFBQVIsUUFBUTtFQUFDLHFCQUFxQixFQUFDLENBQUM7RUFBQyxxQkFBcUIsRUFBQyxDQUFDO0lBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUUsQ0FBQzs7T0FDckosWUFBWSxJQUFDLEtBQUssU0FBTSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU87RUFBRSxLQUFLLEVBQUMsVUFBVTtFQUFDLFFBQVEsUUFBUixRQUFRO0VBQUMsUUFBUSxFQUFDLFNBQVM7RUFBQyxxQkFBcUIsRUFBQyxDQUFDO0lBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUUsQ0FBQzs7T0FDaEosWUFBWSxJQUFDLElBQUksTUFBRSxTQUFTLEVBQUMsSUFBSSxDQUFDLElBQUksSUFBRSxzQkFBc0IsR0FBQyxpQkFBaUI7T0FBUSxVQUFVLElBQUMsRUFBRSxNQUFHLE9BQU8sRUFBQyxNQUFNLEVBQUMsUUFBUSxFQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsRUFBRSxJQUFFLENBQUMsSUFBRSxDQUFDO09BQ3ZKLFFBQVEsSUFBQyxJQUFJLEtBQUUsSUFBSSxDQUFDLFFBQVEsSUFBRSxJQUFJLENBQUMsWUFBWSxJQUFFLElBQUksQ0FBQyxXQUFXLElBQUUsSUFBSSxDQUFDLGVBQWUsSUFBRSxTQUFTO09BQVEsUUFBUSxJQUFDLElBQUksS0FBRSxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksSUFBRSxJQUFJLENBQUMsUUFBUSxJQUFFLGVBQWU7T0FBUSxlQUFlLElBQUMsSUFBSSxLQUFFLElBQUksQ0FBQyxlQUFlLElBQUUsSUFBSSxDQUFDLGVBQWUsSUFBRSxJQUFJLENBQUMsSUFBSTs7T0FDL1AsU0FBUyxJQUFDLEtBQUssS0FBRSxLQUFLO1FBQUssSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLElBQUUsR0FBRyxFQUFDLFNBQVMsRUFBQyxLQUFLLEVBQUMsT0FBTyxJQUFHLE1BQU0sS0FBSyxJQUFJLENBQUMsS0FBSztJQUFHLEVBQUU7O09BQ2xILFVBQVUsSUFBQyxLQUFLLEtBQUUsQ0FBQztTQUFNLENBQUMsRUFBQyxDQUFDLElBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLE1BQU07O2FBQWEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLElBQUUsS0FBSyxFQUFDLE1BQU0sRUFBQyxJQUFJLEVBQUMsU0FBUyxJQUFHLE1BQU0sS0FBSyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDO0NBQUcsQ0FBQzs7T0FDNUosUUFBUSxhQUFTLElBQUksR0FBRyxRQUFRLEtBQUcsRUFBRTtJQUFDLGNBQWM7UUFBSyxJQUFJLEdBQUcsUUFBUSxLQUFHLEVBQUUsR0FBQyxnQkFBZ0IsR0FBQyxjQUFjOztPQUFRLE9BQU8sSUFBQyxHQUFHLFFBQUssYUFBYSxNQUFJLE1BQU0sQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBQyxHQUFHO09BQ2hMLE9BQU8sSUFBQyxLQUFLLEtBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxLQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFDLENBQUM7T0FBUSxTQUFTLElBQUMsS0FBSyxLQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFFLEtBQUssQ0FBQyxJQUFJLElBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUMsR0FBRztPQUFTLFNBQVMsSUFBQyxLQUFLLEtBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUUsTUFBTTtPQUFRLGFBQWEsSUFBQyxLQUFLLEtBQUUsS0FBSyxDQUFDLFFBQVEsTUFBRyxPQUFPLEVBQUMsYUFBYSxFQUFDLFlBQVksRUFBQyxNQUFNLEVBQUMsS0FBSyxFQUFDLE1BQU07T0FBUyxXQUFXLElBQUMsS0FBSyxLQUFFLEtBQUssQ0FBQyxNQUFNLElBQUUsS0FBSyxDQUFDLE1BQU0scUJBQUcsS0FBSyxDQUFDLFNBQVMsRUFBRyxvQkFBb0IsSUFBQyxVQUFVLEdBQUMsVUFBVTtPQUM3YSxZQUFZLElBQUMsS0FBSyxxQkFBRSxLQUFLLEVBQUUsU0FBUyxFQUFHLG9CQUFvQjtPQUFRLFNBQVMsSUFBQyxLQUFLLEtBQUUsWUFBWSxDQUFDLEtBQUssSUFBRSxJQUFJLEdBQUMsRUFBRTtPQUFRLFlBQVksSUFBQyxLQUFLLEtBQUUsYUFBYSxDQUFDLEtBQUssRUFBRSxPQUFPOztVQUNwSyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUMsQ0FBQztRQUFBLGVBQWUsRUFBQyxLQUFLOztNQUFJLENBQUM7R0FBQSxZQUFZLENBQUMsT0FBTyxDQUFDLGdDQUFnQyxFQUFDLEtBQUs7RUFBRSxDQUFDLE9BQUssQ0FBQyxDQUFDO0NBQUE7O1VBR3pILGNBQWMsQ0FBQyxLQUFLLEVBQUMsQ0FBQztPQUFJLEtBQUssU0FBUSxFQUFFOztRQUFPLElBQUksR0FBQyxNQUFNLENBQUMsS0FBSzs7T0FBSyxxQkFBcUIsRUFBQyxJQUFJLENBQUMsSUFBSSxVQUFTLElBQUk7O1FBQU8sSUFBSSxPQUFLLElBQUksQ0FBQyxJQUFJOztTQUFTLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU87S0FBSSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxFQUFFO1FBQUssSUFBSSxDQUFDLFdBQVcsTUFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsS0FBRyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBQyxHQUFHLEtBQUssTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksUUFBUSxDQUFDLENBQUMsRUFBQyxHQUFHO0NBQUk7O1VBQ2pULFdBQVcsQ0FBQyxLQUFLLEVBQUMsS0FBSyxHQUFDLENBQUMsRUFBQyxDQUFDO1FBQU0sSUFBSSxHQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxHQUFHLElBQUksRUFBRSxDQUFDLEVBQUMsQ0FBQyxNQUFJLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxLQUFHLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxHQUFHLEtBQUs7UUFBUSxRQUFRLEdBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFFLE1BQU0sS0FBRyxLQUFLLEVBQUUsUUFBUTs7UUFBTyxHQUFHLEdBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRO0tBQUUsUUFBUTtLQUFDLFFBQVEsRUFBRSxZQUFZLElBQUUsUUFBUSxFQUFFLEtBQUssSUFBRSxLQUFLLEVBQUUsWUFBWTs7U0FBWSxHQUFHLENBQUMsR0FBRyxFQUFDLElBQUksS0FBRSxDQUFDO1VBQU0sTUFBTSxFQUFDLEVBQUUsSUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBRSxJQUFJLENBQUMsRUFBRSxJQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsR0FBRzs7O0lBQVMsVUFBVSxFQUFDLE1BQU07SUFBQyxRQUFRLEVBQUMsRUFBRTtJQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsYUFBYSxJQUFFLElBQUksQ0FBQyxRQUFRLElBQUUsSUFBSSxDQUFDLFlBQVksSUFBRSxJQUFJLENBQUMsV0FBVyxJQUFFLFNBQVM7SUFBQyxRQUFRLEVBQUMsSUFBSSxDQUFDLGFBQWEsSUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksSUFBRSxJQUFJLENBQUMsUUFBUSxJQUFFLGVBQWU7SUFBQyxNQUFNLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFFLElBQUksQ0FBQyxNQUFNLElBQUUsRUFBRTtJQUFDLElBQUksRUFBQyxJQUFJLENBQUMsU0FBUyxJQUFFLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxJQUFFLElBQUksQ0FBQyxlQUFlLElBQUUsSUFBSSxDQUFDLElBQUk7SUFBRSxNQUFNLEVBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxZQUFZLElBQUUsSUFBSSxDQUFDLGFBQWEsSUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU07O0VBQUUsQ0FBQztDQUFFOztVQUMveEIsWUFBWSxDQUFDLElBQUksRUFBQyxDQUFDO1FBQU0sS0FBSyxPQUFLLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZTs7TUFBZ0IsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxZQUFXLElBQUk7O1FBQU8sTUFBTSxHQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEtBQUcsQ0FBQztHQUFDLEdBQUcsR0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsSUFBRSxJQUFJLENBQUMsaUJBQWlCLEdBQUMsQ0FBQztHQUFDLFNBQVMsR0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsSUFBRSxJQUFJLENBQUMsaUJBQWlCLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsTUFBTSxHQUFDLEdBQUc7R0FBRSxRQUFRLE9BQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUcsS0FBSyxDQUFDLFFBQVEsS0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxNQUFNLEdBQUMsQ0FBQyxHQUFFLEtBQUssQ0FBQyxPQUFPOzs7R0FBVyxHQUFHO0dBQUMsU0FBUztHQUFDLE1BQU07R0FBQyxPQUFPLEVBQUMsTUFBTSxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFDLE1BQU0sR0FBQyxHQUFHLElBQUUsQ0FBQztHQUFDLFFBQVEsTUFBSyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsSUFBRSxLQUFLLEVBQUMsT0FBTyxFQUFDLElBQUksRUFBQyxTQUFTLElBQUcsTUFBTSxDQUFDLFFBQVE7O0NBQUc7O1VBQ2psQixrQkFBa0IsQ0FBQyxNQUFNLEVBQUMsQ0FBQztzQkFBRyxNQUFNLENBQUMsVUFBVSxFQUFHLDJCQUEyQixHQUFDLENBQUM7U0FBTSxTQUFTLEdBQUMsTUFBTSxDQUFDLHVCQUF1QjtVQUFLLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxJQUFFLEdBQUcsRUFBQyxTQUFTLEVBQUMsS0FBSyxFQUFDLE9BQU8sRUFBQyxJQUFJLEVBQUMsU0FBUyxJQUFHLE1BQU0sS0FBSyxJQUFJLElBQUksTUFBTSxDQUFDLHVCQUF1QjtNQUFjLEVBQUU7O1NBQU8sV0FBVyxJQUFFLE1BQU0sQ0FBQyxXQUFXLHNDQUFvQyxTQUFTLEtBQUssT0FBTyxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsSUFBRSxFQUFFLEVBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxxREFBcUQsRUFBQyxFQUFFOzs7SUFBUyxLQUFLLEVBQUMsMkJBQTJCO0lBQUMsV0FBVztJQUFDLEdBQUcsRUFBQyxhQUFhOztFQUFFLENBQUM7O1NBQU8sSUFBSTtDQUFDOztPQUN2akIsb0JBQW9CLFlBQVEsdUJBQXVCLElBQUksUUFBUSxLQUFDLE1BQU0sR0FBQyxNQUFNOztVQUMxRSxxQkFBcUIsR0FBRSxDQUFDO01BQUcsQ0FBQztTQUFNLE1BQU0sR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLE9BQUssTUFBTTs7UUFBTSxNQUFNLFNBQVEsS0FBSzs7T0FBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUUsQ0FBQztVQUFBLEtBQUssRUFBQyxNQUFNLENBQUMsS0FBSztVQUFDLFVBQVUsRUFBQyxPQUFPO0dBQUMsQ0FBQzs7T0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEdBQUUsQ0FBQztVQUFBLFdBQVcsRUFBQyxNQUFNLENBQUMsV0FBVztVQUFDLGdCQUFnQixFQUFDLE9BQU87R0FBQyxDQUFDOztPQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRSxDQUFDO1VBQUEsTUFBTSxFQUFDLE1BQU0sQ0FBQyxNQUFNO1VBQUMsV0FBVyxFQUFDLE9BQU87R0FBQyxDQUFDOztVQUFPLElBQUk7RUFBQyxDQUFDLE9BQUssQ0FBQztVQUFPLEtBQUs7RUFBQyxDQUFDO0NBQUE7O1VBQ3BaLHFCQUFxQixHQUFFLENBQUM7TUFBRyxDQUFDO0dBQUEsWUFBWSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsSUFBRyxJQUFJLENBQUMsU0FBUztJQUFFLFNBQVMsTUFBSyxJQUFJLEdBQUcsV0FBVztJQUFHLEtBQUssUUFBTCxLQUFLO0lBQUMsV0FBVyxRQUFYLFdBQVc7SUFBQyxNQUFNLFFBQU4sTUFBTTs7RUFBSSxDQUFDLE9BQUssQ0FBQzs7RUFBNEQsQ0FBQztDQUFBOztnQkFDck4sU0FBUyxHQUFFLENBQUM7UUFBQSxVQUFVLFFBQUMsS0FBSyxFQUFDLE1BQU0sR0FBQyxZQUFZLEdBQUMsU0FBUzs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxRQUFROztTQUFHLEtBQUssRUFBQyxNQUFNLENBQUMsS0FBSztTQUFLLFVBQVUsRUFBQyxPQUFPO0dBQUMscUJBQXFCO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO2FBQUcsS0FBSyxFQUFDLE1BQU0sRUFBQyxDQUFDO1VBQUEsVUFBVSxFQUFDLE9BQU87OztHQUFRLENBQUM7O1NBQUEsVUFBVSxFQUFDLE9BQU87U0FBQyxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx1QkFBdUI7RUFBQyxDQUFDO0NBQUE7O2dCQUMvUixlQUFlLEdBQUUsQ0FBQztRQUFBLGdCQUFnQixFQUFDLFNBQVM7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyx1QkFBdUI7O1NBQUcsV0FBVyxFQUFDLE1BQU0sQ0FBQyxLQUFLO1NBQUssZ0JBQWdCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGdCQUFnQixFQUFDLE9BQU87U0FBQyxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSw2QkFBNkI7RUFBQyxDQUFDO0NBQUE7O09BQ3RSLGVBQWUsSUFBQyxJQUFJLEtBQUUsQ0FBQztRQUFNLENBQUMsR0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtCQUFrQixJQUFFLENBQUM7R0FBRSxJQUFJLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUUsT0FBTyxFQUFFLFdBQVc7O1FBQVMsSUFBSSxzQkFBSSxDQUFDLEVBQUcsQ0FBQyxJQUFDLEVBQUUsTUFBSSxDQUFDLE1BQU0sSUFBSSxtQkFBRyxDQUFDLEVBQUcsQ0FBQyxJQUFDLEVBQUUsR0FBQyxHQUFHOztTQUFVLElBQUksQ0FBQyxnQkFBZ0Isb0JBQWtCLElBQUksY0FBWSxJQUFJO0NBQUcsQ0FBQzs7T0FDdlAsYUFBYSxJQUFDLElBQUksS0FBRSxJQUFJO1FBQUssSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLElBQUUsR0FBRyxFQUFDLFNBQVMsRUFBQyxLQUFLLEVBQUMsT0FBTyxFQUFDLElBQUksRUFBQyxTQUFTLElBQUcsTUFBTSxLQUFLLElBQUksSUFBSSxJQUFJO0lBQWMsRUFBRTs7VUFDN0ksa0JBQWtCLENBQUMsSUFBSSxHQUFDLElBQUksRUFBQyxDQUFDO1FBQU0sZUFBZSxHQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUUsZ0JBQWdCLElBQUksSUFBSTs7UUFBRSxlQUFlLEVBQUMsRUFBRTtRQUFDLG1CQUFtQixFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsRUFBRSxHQUFDLElBQUk7O1FBQUMsY0FBYyxFQUFDLElBQUk7O0lBQUUsS0FBSyxFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLFFBQVEsQ0FBQyxJQUFJO0lBQUUsY0FBYyxFQUFDLE1BQU0sQ0FBQyxlQUFlLEdBQUMsSUFBSSxDQUFDLGNBQWMsR0FBQyxJQUFJLENBQUMsTUFBTSxJQUFFLEVBQUU7O0lBQUUsTUFBTSxFQUFDLE1BQU0sQ0FBQyxlQUFlO09BQUMsSUFBSSxDQUFDLE1BQU0sSUFBRSxFQUFFO1dBQUssSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEdBQUcsT0FBTyxNQUFJLEVBQUU7O0lBQUUsVUFBVSxFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLE9BQU8sR0FBQyxPQUFPO0lBQUMsY0FBYyxFQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsY0FBYyxJQUFFLE9BQU8sR0FBQyxPQUFPO0lBQUMsa0JBQWtCLEVBQUMsTUFBTSxDQUFDLGVBQWUsR0FBQyxJQUFJLENBQUMsa0JBQWtCLElBQUUsQ0FBQyxHQUFDLENBQUM7SUFBRSxnQkFBZ0IsRUFBQyxlQUFlLEdBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBRSxLQUFLO0lBQUMsZ0JBQWdCLEVBQUMsZUFBZSxHQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBRSxFQUFFLEdBQUMsYUFBYSxLQUFDLEtBQUs7T0FBSyxlQUFlLFVBQUssbUJBQW1CLEVBQUMsSUFBSSxDQUFDLEVBQUU7OztJQUFLLEtBQUssRUFBQyxFQUFFO0lBQUMsY0FBYyxFQUFDLEVBQUU7SUFBQyxNQUFNLEVBQUMsRUFBRTtJQUFDLFVBQVUsRUFBQyxPQUFPO0lBQUMsY0FBYyxFQUFDLE9BQU87SUFBQyxrQkFBa0IsRUFBQyxHQUFHO0lBQUMsZ0JBQWdCLEVBQUMsS0FBSztJQUFDLGdCQUFnQixFQUFDLGFBQWEsS0FBQyxLQUFLOzs7UUFBRSxrQkFBa0IsRUFBQyxJQUFJO0NBQUM7O2dCQUN2OUIsY0FBYyxHQUFFLENBQUM7UUFBTSxjQUFjLEdBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxjQUFjO0dBQUUsTUFBTSxTQUFDLGNBQWMsRUFBQyxNQUFNLEdBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxNQUFNLElBQUUsSUFBSTtHQUFDLGtCQUFrQixHQUFDLE1BQU0sT0FBQyxjQUFjLEVBQUMsa0JBQWtCOzthQUFNLGNBQWMsRUFBQyxLQUFLLENBQUMsSUFBSSxRQUFNLGNBQWMsR0FBQyxDQUFDLE9BQUssa0JBQWtCLEdBQUMsQ0FBQyxZQUFJLGNBQWMsRUFBQyxnQkFBZ0Isb0JBQUUsTUFBTSxFQUFHLElBQUksYUFBRyxNQUFNLEdBQUMsQ0FBQyxJQUFFLE1BQU0sR0FBQyxFQUFFLEdBQUUsQ0FBQztTQUFBLGVBQWUsRUFBQywwRUFBMEU7OztFQUFRLENBQUM7O1FBQUEsZ0JBQWdCLEVBQUMsSUFBSTs7TUFBSSxDQUFDO1NBQU0sT0FBTzthQUFLLGNBQWM7SUFBQyxLQUFLLFFBQUMsY0FBYyxFQUFDLEtBQUssQ0FBQyxJQUFJO0lBQUcsY0FBYztJQUFDLE1BQU07SUFBQyxrQkFBa0I7SUFBQyxjQUFjLEVBQUMsYUFBYTs7OzZCQUFLLG1CQUFtQixHQUFHLElBQUksaUJBQVEsT0FBTyxDQUFDLG1CQUFtQjs7d0RBQVEsbUJBQW1CLEdBQUcsSUFBSTtNQUFDLHlCQUF5QixDQUFDLE9BQU87TUFBRSx5QkFBeUIsT0FBQyxtQkFBbUIsR0FBQyxPQUFPOztTQUFHLGtCQUFrQixFQUFDLEtBQUs7a0NBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxlQUFlLElBQUcsY0FBYztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGlDQUFpQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7VUFDNytCLGNBQWMsQ0FBQyxVQUFVLEVBQUMsQ0FBQztRQUFBLG9CQUFvQixFQUFDLFVBQVU7O1FBQU8sS0FBSyxPQUFLLElBQUksR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBQyxFQUFFOztRQUFFLGNBQWM7R0FBRSxZQUFZLEVBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUFjO0dBQUUsV0FBVyxFQUFDLEtBQUs7R0FBQyxnQkFBZ0IsRUFBQyxVQUFVLENBQUMsZ0JBQWdCLElBQUUsS0FBSzs7Q0FBRTs7VUFDbFAsU0FBUyxDQUFDLE1BQU0sRUFBQyxDQUFDO1FBQU0sSUFBSSxPQUFLLElBQUksVUFBSSxjQUFjLEVBQUMsV0FBVzs7RUFBYSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUcsTUFBTTtXQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsZ0JBQWdCLEdBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFDLEVBQUU7Q0FBRTs7Z0JBQy9LLGNBQWMsR0FBRSxDQUFDO2FBQUksb0JBQW9COztNQUFXLENBQUM7a0NBQU0sbUNBQW1DLE9BQUMsb0JBQW9CLEVBQUMsRUFBRTtJQUFFLFlBQVksRUFBQyxNQUFNLE9BQUMsY0FBYyxFQUFDLFlBQVk7SUFBRSxXQUFXLFFBQUMsY0FBYyxFQUFDLFdBQVc7SUFBQyxnQkFBZ0IsUUFBQyxjQUFjLEVBQUMsZ0JBQWdCOzs7U0FBRyxvQkFBb0IsRUFBQyxJQUFJO2tDQUFPLE9BQU8sQ0FBQyxHQUFHLEVBQUUsZUFBZSxJQUFHLGNBQWM7RUFBSyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSw0QkFBNEI7RUFBQyxDQUFDO0NBQUE7O2dCQUNqYSxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUMsQ0FBQzs0QkFBRyxvQkFBb0IsR0FBRyxJQUFJOztRQUFRLG9CQUFvQixFQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQUMsZUFBZSxFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsRUFBRTtTQUFFLFdBQVcsUUFBQyxXQUFXLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRyxVQUFVLENBQUMsRUFBRTtrQ0FBUSxjQUFjO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsbUNBQW1DO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxvQkFBb0IsRUFBQyxJQUFJO0VBQUMsQ0FBQztDQUFBOztnQkFDdlgsZUFBZSxHQUFFLENBQUM7UUFBQSxnQkFBZ0IsUUFBQyxXQUFXLEVBQUMsTUFBTSxHQUFDLFlBQVksR0FBQyxTQUFTO1FBQUMsZUFBZSxFQUFDLEVBQUU7O01BQUksQ0FBQztTQUFNLE1BQU0sa0NBQU8sY0FBYzs7U0FBRyxXQUFXLEVBQUMsTUFBTSxDQUFDLFdBQVc7U0FBSyxnQkFBZ0IsRUFBQyxPQUFPO0dBQUMscUJBQXFCO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO2FBQUcsV0FBVyxFQUFDLE1BQU0sRUFBQyxDQUFDO1VBQUEsZ0JBQWdCLEVBQUMsT0FBTzs7O0dBQVEsQ0FBQzs7U0FBQSxnQkFBZ0IsRUFBQyxPQUFPO1NBQUMsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsOEJBQThCO0VBQUMsQ0FBQztDQUFBOztnQkFDM1gsVUFBVSxHQUFFLENBQUM7UUFBQSxXQUFXLFFBQUMsTUFBTSxFQUFDLE1BQU0sR0FBQyxZQUFZLEdBQUMsU0FBUztRQUFDLFVBQVUsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBTSxNQUFNLGtDQUFPLFNBQVM7O1NBQUcsTUFBTSxFQUFDLE1BQU0sQ0FBQyxNQUFNO1NBQUssV0FBVyxFQUFDLE9BQU87R0FBQyxxQkFBcUI7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7YUFBRyxNQUFNLEVBQUMsTUFBTSxFQUFDLENBQUM7VUFBQSxXQUFXLEVBQUMsT0FBTzs7O0dBQVEsQ0FBQzs7U0FBQSxXQUFXLEVBQUMsT0FBTztTQUFDLFVBQVUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLHdCQUF3QjtFQUFDLENBQUM7Q0FBQTs7Z0JBQ3pULFdBQVcsR0FBRSxDQUFDO0VBQUEsYUFBYSxTQUFDLE9BQU8sRUFBQyxNQUFNLEdBQUMsWUFBWSxHQUFDLFNBQVM7RUFBQyxZQUFZLEdBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxVQUFVOztTQUFHLE9BQU8sRUFBQyxNQUFNLENBQUMsT0FBTztHQUFLLGFBQWEsR0FBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO0dBQUEsYUFBYSxHQUFDLE9BQU87R0FBQyxZQUFZLEdBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx5QkFBeUI7RUFBQyxDQUFDO0NBQUE7O2dCQUNuUSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUMsQ0FBQzs0QkFBRyxrQkFBa0IsR0FBRyxJQUFJOztRQUFRLGtCQUFrQixFQUFDLE1BQU0sQ0FBQyxFQUFFO0VBQUMsWUFBWSxHQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUU7U0FBRSxPQUFPLFFBQUMsT0FBTyxFQUFDLE1BQU0sRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxFQUFFLEVBQUcsTUFBTSxDQUFDLEVBQUU7a0NBQVEsT0FBTyxDQUFDLEdBQUcsRUFBRSxTQUFTLElBQUcsV0FBVztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztHQUFBLFlBQVksR0FBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGlDQUFpQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsa0JBQWtCLEVBQUMsSUFBSTtFQUFDLENBQUM7Q0FBQTs7VUFDdFcsaUJBQWlCLENBQUMsSUFBSSxFQUFDLEVBQUUsRUFBQyxDQUFDO3NCQUFHLElBQUksRUFBRyxNQUFNLEdBQUMsQ0FBQztTQUFNLElBQUksU0FBQyxLQUFLLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLEVBQUU7O1VBQVUsSUFBSTtPQUFNLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyx5Q0FBeUM7S0FBRyxJQUFJLEVBQUMsR0FBRyxLQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLFdBQVcsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRO0VBQUcsQ0FBQzs7c0JBQUcsSUFBSSxFQUFHLFlBQVksVUFBUSxRQUFRLENBQUMsYUFBYSw2QkFBNkIsRUFBRTtzQkFBUyxJQUFJLEVBQUcsT0FBTyxVQUFRLFFBQVEsQ0FBQyxhQUFhLDZCQUE2QixFQUFFOztRQUFZLElBQUksR0FBQyxXQUFXLENBQUMsRUFBRTs7U0FBUyxJQUFJO01BQU0sUUFBUSxDQUFDLGdCQUFnQixDQUFDLHFEQUFxRDtJQUFHLElBQUksRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxXQUFZLElBQUksQ0FBQyxVQUFVO0NBQVk7O2dCQUM3b0IsZ0JBQWdCLENBQUMsSUFBSSxFQUFDLEVBQUUsRUFBQyxDQUFDO2lDQUFNLElBQUk7cUNBQWEsT0FBTyxFQUFDLE9BQU8sS0FBRSxxQkFBcUIsQ0FBQyxPQUFPOztRQUFTLE1BQU0sR0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUMsRUFBRTs7T0FBTSxNQUFNOztFQUFRLE1BQU0sQ0FBQyxRQUFRLElBQUUsQ0FBQztFQUFDLE1BQU0sQ0FBQyxjQUFjLEdBQUUsUUFBUSxFQUFDLFFBQVEsRUFBQyxLQUFLLEVBQUMsUUFBUTtFQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUUsYUFBYSxFQUFDLElBQUk7Q0FBRzs7Z0JBQzVRLGlCQUFpQixDQUFDLE1BQU0sRUFBQyxDQUFDO1FBQUEsaUJBQWlCLEVBQUMsTUFBTSxDQUFDLFdBQVc7UUFBQyxTQUFTLEVBQUMsSUFBSTtpQ0FBTyxPQUFPLENBQUMsR0FBRyxFQUFFLFNBQVMsSUFBRyxXQUFXO2lDQUFXLGdCQUFnQixDQUFDLE1BQU0sRUFBQyxNQUFNLENBQUMsV0FBVztDQUFFOztnQkFDL0sscUJBQXFCLEdBQUUsQ0FBQztRQUFBLGlCQUFpQixFQUFDLElBQUk7aUNBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxlQUFlLElBQUcsZUFBZTtDQUFLOztnQkFDeEcsZ0JBQWdCLENBQUMsS0FBSyxFQUFDLENBQUM7UUFBTSxTQUFTLFNBQUMsYUFBYSxFQUFDLE1BQU0sRUFBQyxJQUFJLE1BQUUsT0FBTyxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUTs7UUFBUyxPQUFPO01BQUssUUFBUSxDQUFDLGdCQUFnQixDQUFDLDBDQUEwQzs7O1FBQVMsSUFBSSxHQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhOztPQUFPLElBQUk7O1FBQVEsaUJBQWlCLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxJQUFJO2lDQUFPLFNBQVM7aUNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxRQUFRO0NBQUU7O2dCQUM1VyxzQkFBc0IsQ0FBQyxJQUFJLEVBQUMsQ0FBQztFQUFBLGlCQUFpQixHQUFDLElBQUksQ0FBQyxRQUFRO1FBQUMsaUJBQWlCLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxJQUFJO2lDQUFPLFNBQVM7aUNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxRQUFRO0NBQUU7O2dCQUNySyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLGtCQUFrQixFQUFDLElBQUksQ0FBQyxRQUFRO1FBQUMsaUJBQWlCLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxJQUFJO2lDQUFPLFNBQVM7aUNBQVMsZ0JBQWdCLENBQUMsT0FBTyxFQUFDLElBQUksQ0FBQyxRQUFRO0NBQUU7O2dCQUNsSyxzQkFBc0IsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLGlCQUFpQixFQUFDLEtBQUs7UUFBQyxXQUFXLEVBQUMsSUFBSTtpQ0FBTyxTQUFTO2lDQUFTLGdCQUFnQixDQUFDLFlBQVksRUFBQyxJQUFJLENBQUMsUUFBUTtDQUFFOztPQUNwSixtQkFBbUIsSUFBQyxJQUFJLEtBQUUsQ0FBQztRQUFNLEVBQUUsMEJBQVEsSUFBSSxFQUFHLFFBQVEsSUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLElBQUk7UUFBTyxLQUFLLFNBQUMsV0FBVyxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFJLE1BQU0sQ0FBQyxFQUFFLGFBQUksV0FBVyxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUcsSUFBSSxFQUFFLFFBQVE7O1VBQVUsS0FBSywwQkFBRSxXQUFXLEVBQUMsTUFBTSxFQUFHLENBQUMsV0FBRSxXQUFXLEVBQUMsQ0FBQyxJQUFJLGlCQUFpQjtDQUFDLENBQUM7O2dCQUMxUSxrQkFBa0IsQ0FBQyxVQUFVLEVBQUMsQ0FBQztzQkFBRyxzQkFBc0IsRUFBRyxJQUFJOztRQUFjLFVBQVUsR0FBQyxVQUFVLENBQUMsaUJBQWlCOztPQUFLLFVBQVUsRUFBRSxLQUFLOztFQUFRLHNCQUFzQixHQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQUMsZUFBZSxFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSwyQkFBMkIsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFDLFVBQVUsQ0FBQyxLQUFLO2tDQUFRLE9BQU8sQ0FBQyxHQUFHLEVBQUUsZUFBZSxJQUFHLGNBQWM7RUFBSyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxzQ0FBc0M7RUFBQyxDQUFDLFNBQU8sQ0FBQztHQUFBLHNCQUFzQixHQUFDLElBQUk7RUFBQyxDQUFDO0NBQUE7O1VBQ3pjLFFBQVEsQ0FBQyxJQUFJLEVBQUMsQ0FBQzsrQkFBTyxXQUFXLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUksVUFBVSxFQUFFLE1BQU0sRUFBRyxLQUFLO0NBQUM7O1VBQ2xILGNBQWMsQ0FBQyxJQUFJLEVBQUMsQ0FBQzsrQkFBTyxXQUFXLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUksVUFBVSxFQUFFLE1BQU0sRUFBRyxXQUFXO0NBQUM7O1VBQzlILHNCQUFzQixHQUFFLENBQUM7UUFBTSxJQUFJLFNBQUMsV0FBVyxHQUFFLEtBQUssRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFFLENBQUMsRUFBQyxDQUFDLE1BQUksQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLFNBQUcsVUFBVTs7U0FBUyxJQUFJLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBQyxTQUFTLHFCQUFFLFNBQVMsQ0FBQyxLQUFLLEVBQUcsWUFBWSxLQUFFLFNBQVMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLEtBQUs7Q0FBRzs7T0FDaFAsZ0JBQWdCLElBQUMsS0FBSztFQUFJLFdBQVcsRUFBQyxZQUFZO0VBQUMsbUJBQW1CLEVBQUMsV0FBVztFQUFDLG9CQUFvQixFQUFDLFVBQVU7RUFBQyxxQkFBcUIsRUFBQyxTQUFTO0VBQUMsV0FBVyxFQUFDLFVBQVU7SUFBRyxLQUFLLEtBQUcsWUFBWTs7Z0JBQ3ZMLGlCQUFpQixHQUFFLENBQUM7UUFBQSxZQUFZLEVBQUMsU0FBUztRQUFDLFdBQVcsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBQSxhQUFhLGlDQUFPLGdCQUFnQjtTQUFHLFlBQVksRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsWUFBWSxFQUFDLE9BQU87U0FBQyxXQUFXLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxxQ0FBcUM7RUFBQyxDQUFDO0NBQUE7O2dCQUNoTyxTQUFTLEdBQUUsQ0FBQztRQUFBLFNBQVMsRUFBQyxJQUFJO0VBQUMscUJBQXFCOztpQ0FBUyxPQUFPLENBQUMsR0FBRztHQUFFLFNBQVM7R0FBRyxlQUFlO0dBQUcsVUFBVTtHQUFHLGlCQUFpQjtHQUFHLGVBQWU7R0FBRyxlQUFlO0dBQUcsa0JBQWtCOztDQUFLOztVQUN0TSxVQUFVLEdBQUUsQ0FBQztRQUFBLFNBQVMsRUFBQyxLQUFLO1FBQUMsaUJBQWlCLEVBQUMsSUFBSTtFQUFDLGlCQUFpQixHQUFDLElBQUk7Q0FBQzs7T0FDOUUsV0FBVyxJQUFDLEVBQUUsV0FBRSxXQUFXLEVBQUMsSUFBSSxFQUFDLElBQUkscUJBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUksTUFBTSxDQUFDLEVBQUU7O2dCQUN6RCxlQUFlLEdBQUUsQ0FBQztRQUFBLGdCQUFnQixFQUFDLFNBQVM7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxjQUFjOztTQUFHLFdBQVcsRUFBQyxNQUFNLENBQUMsS0FBSztTQUFLLGdCQUFnQixFQUFDLE9BQU87RUFBQyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxnQkFBZ0IsRUFBQyxPQUFPO1NBQUMsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsOEJBQThCO0VBQUMsQ0FBQztDQUFBOztnQkFDclEsa0JBQWtCLEdBQUUsQ0FBQzs0QkFBRyxhQUFhLEdBQUcsU0FBUzs7TUFBVyxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxpQkFBaUI7O1NBQUcsV0FBVztJQUFFLFVBQVUsRUFBQyxNQUFNLENBQUMsVUFBVTtJQUFLLFNBQVMsRUFBQyxNQUFNLENBQUMsU0FBUztJQUFLLFFBQVEsRUFBQyxNQUFNLENBQUMsUUFBUTs7O1NBQU0sYUFBYSxFQUFDLE9BQU87RUFBQyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxhQUFhLEVBQUMsT0FBTztTQUFDLFlBQVksRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDBCQUEwQjtFQUFDLENBQUM7Q0FBQTs7VUFDeFUsa0JBQWtCLENBQUMsSUFBSSxHQUFDLElBQUksRUFBQyxDQUFDO1FBQUEsZUFBZSxFQUFDLEVBQUU7UUFBQyxtQkFBbUIsRUFBQyxJQUFJLEVBQUUsRUFBRSxJQUFFLElBQUk7O1FBQUMsY0FBYyxFQUFDLElBQUk7O0lBQUUsa0JBQWtCLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0I7SUFBRSxRQUFRLEVBQUMsSUFBSSxDQUFDLFFBQVE7SUFBQyxVQUFVLEVBQUMsSUFBSSxDQUFDLFVBQVU7SUFBQyxZQUFZLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZO0lBQUUsTUFBTSxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTTs7O0lBQUksa0JBQWtCLEVBQUMsRUFBRTtJQUFDLFFBQVEsRUFBQyxFQUFFO0lBQUMsVUFBVSxFQUFDLEVBQUU7SUFBQyxZQUFZLEVBQUMsRUFBRTtJQUFDLE1BQU0sRUFBQyxFQUFFOzs7UUFBRSxrQkFBa0IsRUFBQyxJQUFJO0NBQUM7O2dCQUMvVyxjQUFjLEdBQUUsQ0FBQztRQUFNLFlBQVksR0FBQyxNQUFNLE9BQUMsY0FBYyxFQUFDLFlBQVk7R0FBRSxNQUFNLEdBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxNQUFNOzthQUFNLGNBQWMsRUFBQyxrQkFBa0IsV0FBRyxjQUFjLEVBQUMsUUFBUSxDQUFDLElBQUksYUFBSyxjQUFjLEVBQUMsVUFBVSxDQUFDLElBQUksTUFBSSxZQUFZLEdBQUMsQ0FBQyxJQUFFLFlBQVksR0FBQyxFQUFFLElBQUUsTUFBTSxHQUFDLENBQUMsSUFBRSxNQUFNLEdBQUMsRUFBRSxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsK0RBQStEOzs7RUFBUSxDQUFDOztRQUFBLGdCQUFnQixFQUFDLElBQUk7UUFBQyxlQUFlLEVBQUMsRUFBRTs7UUFBTyxPQUFPO0dBQUUsa0JBQWtCLEVBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxrQkFBa0I7R0FBRSxRQUFRLFFBQUMsY0FBYyxFQUFDLFFBQVEsQ0FBQyxJQUFJO0dBQUcsVUFBVSxRQUFDLGNBQWMsRUFBQyxVQUFVLENBQUMsSUFBSTtHQUFHLFlBQVk7R0FBQyxNQUFNOzs7TUFBSyxDQUFDO1NBQU0sS0FBSyx5QkFBQyxtQkFBbUIsR0FBRyxJQUFJO3FDQUFPLGdCQUFnQixDQUFDLE9BQU87cUNBQVEsZ0JBQWdCLE9BQUMsbUJBQW1CLEdBQUMsT0FBTzs7U0FBRSxXQUFXLHdCQUFDLG1CQUFtQixHQUFHLElBQUk7T0FBRSxLQUFLLFdBQUksV0FBVztZQUFFLFdBQVcsRUFBQyxHQUFHLEVBQUMsSUFBSSxxQkFBRSxJQUFJLENBQUMsRUFBRSxFQUFHLEtBQUssQ0FBQyxFQUFFLElBQUMsS0FBSyxHQUFDLElBQUk7O1NBQUUsZ0JBQWdCLEVBQUMsT0FBTztTQUFDLGtCQUFrQixFQUFDLEtBQUs7a0NBQU8sY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGtDQUFrQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7VUFDdi9CLGNBQWMsR0FBRSxDQUFDO1FBQUEsV0FBVyxFQUFDLEVBQUU7O1FBQUMsVUFBVTtHQUFFLGdCQUFnQixFQUFDLE9BQU87R0FBQyxXQUFXLEVBQUMsc0JBQXNCO0dBQUMsa0JBQWtCLEVBQUMsRUFBRTtHQUFDLGVBQWUsRUFBQyxTQUFTOzs7UUFBRSxjQUFjLEVBQUMsSUFBSTtDQUFDOztnQkFDdkssVUFBVSxHQUFFLENBQUM7UUFBQSxZQUFZLEVBQUMsSUFBSTtRQUFDLFdBQVcsRUFBQyxFQUFFOztNQUFJLENBQUM7a0NBQU0saUJBQWlCO2FBQUssVUFBVTtJQUFDLGtCQUFrQix3QkFBQyxVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTyxJQUFDLE1BQU0sT0FBQyxVQUFVLEVBQUMsa0JBQWtCLElBQUUsSUFBSTs7O2tDQUFTLGlCQUFpQjtTQUFHLGNBQWMsRUFBQyxLQUFLO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsaUNBQWlDO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxZQUFZLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7VUFDN1YsWUFBWSxDQUFDLElBQUksR0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLFNBQVMsRUFBQyxFQUFFO1FBQUMsYUFBYSxFQUFDLElBQUksRUFBRSxFQUFFLElBQUUsSUFBSTs7UUFBQyxRQUFRLEVBQUMsSUFBSTs7SUFBRSxRQUFRLEVBQUMsSUFBSSxDQUFDLFFBQVEsSUFBRSxFQUFFO0lBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxRQUFRLElBQUUsTUFBTTtJQUFDLFVBQVUsRUFBQyxJQUFJLENBQUMsVUFBVSxJQUFFLEVBQUU7SUFBQyxpQkFBaUIsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLEVBQUU7SUFBRSxnQkFBZ0IsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFFLEVBQUU7SUFBRSxpQkFBaUIsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLEVBQUU7SUFBRSxlQUFlLEVBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxlQUFlO0lBQUUsS0FBSyxFQUFDLElBQUksQ0FBQyxLQUFLLElBQUUsRUFBRTs7O0lBQUcsUUFBUSxFQUFDLEVBQUU7SUFBQyxRQUFRLEVBQUMsTUFBTTtJQUFDLFVBQVUsRUFBQyxFQUFFO0lBQUMsaUJBQWlCLEVBQUMsRUFBRTtJQUFDLGdCQUFnQixFQUFDLEVBQUU7SUFBQyxpQkFBaUIsRUFBQyxFQUFFO0lBQUMsZUFBZSxFQUFDLEVBQUU7SUFBQyxLQUFLLEVBQUMsRUFBRTs7O1FBQUUsWUFBWSxFQUFDLElBQUk7Q0FBQzs7Z0JBQ3BpQixRQUFRLEdBQUUsQ0FBQztRQUFNLGlCQUFpQixHQUFDLE1BQU0sT0FBQyxRQUFRLEVBQUMsaUJBQWlCO0dBQUUsZ0JBQWdCLEdBQUMsTUFBTSxPQUFDLFFBQVEsRUFBQyxnQkFBZ0I7R0FBRSxpQkFBaUIsR0FBQyxNQUFNLE9BQUMsUUFBUSxFQUFDLGlCQUFpQjs7YUFBTSxRQUFRLEVBQUMsUUFBUSxDQUFDLElBQUksYUFBSyxRQUFRLEVBQUMsVUFBVSxDQUFDLElBQUksYUFBSyxRQUFRLEVBQUMsZUFBZSxJQUFFLGlCQUFpQixJQUFFLENBQUMsSUFBRSxnQkFBZ0IsSUFBRSxDQUFDLEtBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsS0FBRyxpQkFBaUIsSUFBRSxDQUFDLEVBQUMsQ0FBQztTQUFBLFNBQVMsRUFBQyxrRUFBa0U7OztFQUFRLENBQUM7O1FBQU0sT0FBTztHQUFFLFFBQVEsUUFBQyxRQUFRLEVBQUMsUUFBUSxDQUFDLElBQUk7R0FBRyxRQUFRLFFBQUMsUUFBUSxFQUFDLFFBQVE7R0FBQyxVQUFVLFFBQUMsUUFBUSxFQUFDLFVBQVUsQ0FBQyxJQUFJO0dBQUcsaUJBQWlCO0dBQUMsZ0JBQWdCO0dBQUMsaUJBQWlCO0dBQUMsZUFBZSxRQUFDLFFBQVEsRUFBQyxlQUFlO0dBQUMsS0FBSyxRQUFDLFFBQVEsRUFBQyxLQUFLOzs7UUFBRSxVQUFVLEVBQUMsSUFBSTtRQUFDLFNBQVMsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBTSxLQUFLLGtCQUFDLGFBQWEsR0FBRSxJQUFJO3FDQUFPLFVBQVUsQ0FBQyxPQUFPO3FDQUFRLFVBQVUsT0FBQyxhQUFhLEdBQUMsT0FBTzs7U0FBRSxLQUFLLGlCQUFDLGFBQWEsR0FBRSxJQUFJO2dCQUFLLEtBQUssR0FBQyxLQUFLO1lBQUUsS0FBSyxFQUFDLEdBQUcsRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxFQUFFLEVBQUcsS0FBSyxDQUFDLEVBQUUsSUFBQyxLQUFLLEdBQUMsSUFBSTs7U0FBRSxZQUFZLEVBQUMsS0FBSztTQUFDLFVBQVUsRUFBQyxPQUFPO2tDQUFPLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwyQkFBMkI7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDL2hDLFVBQVUsQ0FBQyxJQUFJLEVBQUMsQ0FBQzs0QkFBRyxjQUFjLEdBQUcsSUFBSTs7UUFBUSxjQUFjLEVBQUMsSUFBSSxDQUFDLEVBQUU7UUFBQyxTQUFTLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtTQUFFLEtBQUssUUFBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRyxJQUFJLENBQUMsRUFBRTtHQUFFLHFCQUFxQjtrQ0FBUyxjQUFjO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsU0FBUyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsNkJBQTZCO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxjQUFjLEVBQUMsSUFBSTtFQUFDLENBQUM7Q0FBQTs7Z0JBQ2xULFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFDLENBQUM7TUFBRyxDQUFDO2tDQUFNLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFDLFVBQVUsQ0FBQyxLQUFLO2tDQUFRLE9BQU8sQ0FBQyxHQUFHLEVBQUUsU0FBUyxJQUFHLGNBQWM7RUFBSyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwrQkFBK0I7RUFBQyxDQUFDO0NBQUE7O2dCQUM1TSxlQUFlLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBQSxXQUFXLElBQUUsUUFBUSxFQUFDLElBQUksQ0FBQyxRQUFRO1FBQUUsaUJBQWlCLEVBQUMsU0FBUztRQUFDLGdCQUFnQixFQUFDLEVBQUU7O01BQUksQ0FBQztTQUFBLFdBQVcsaUNBQU8sY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO1NBQUUsaUJBQWlCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGlCQUFpQixFQUFDLE9BQU87U0FBQyxnQkFBZ0IsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLGlDQUFpQztFQUFDLENBQUM7Q0FBQTs7Z0JBQy9SLGlCQUFpQixDQUFDLFVBQVUsRUFBQyxDQUFDO2FBQUksV0FBVzs7TUFBVyxDQUFDO2tDQUFNLGVBQWUsT0FBQyxXQUFXLEVBQUMsRUFBRSxFQUFDLFVBQVUsQ0FBQyxLQUFLOztrQ0FBUSxPQUFPLENBQUMsR0FBRztJQUFFLFNBQVM7SUFBRyxlQUFlLE9BQUMsV0FBVztJQUFFLGNBQWM7O0VBQUssQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwrQkFBK0I7RUFBQyxDQUFDO0NBQUE7O2dCQUMvUSxxQkFBcUIsQ0FBQyxVQUFVLEVBQUMsQ0FBQztRQUFBLGlCQUFpQixJQUFFLEtBQUssRUFBQyxVQUFVLENBQUMsS0FBSztRQUFFLHVCQUF1QixFQUFDLFNBQVM7UUFBQyxzQkFBc0IsRUFBQyxFQUFFOztNQUFJLENBQUM7U0FBQSxpQkFBaUIsaUNBQU8sNkJBQTZCLENBQUMsVUFBVSxDQUFDLEVBQUU7U0FBRSx1QkFBdUIsRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsdUJBQXVCLEVBQUMsT0FBTztTQUFDLHNCQUFzQixFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsaUNBQWlDO0VBQUMsQ0FBQztDQUFBOztVQUNoWCxrQkFBa0IsR0FBRSxDQUFDO1FBQUEsU0FBUyxFQUFDLEVBQUU7UUFBQyxTQUFTLEVBQUMsS0FBSztRQUFDLFdBQVcsRUFBQyxFQUFFO1FBQUMsY0FBYyxFQUFDLElBQUk7UUFBQyxjQUFjLEVBQUMsS0FBSzs7UUFBQyxRQUFRO0dBQUUsTUFBTSxFQUFDLEtBQUs7R0FBQyxTQUFTLEVBQUMsT0FBTztHQUFDLE9BQU8sRUFBQyxHQUFHO0dBQUMsVUFBVSxFQUFDLFNBQVM7R0FBQyxVQUFVLEVBQUMsS0FBSztHQUFDLFlBQVksRUFBQyxTQUFTO0dBQUMsYUFBYSxFQUFDLE9BQU87OztRQUFFLGtCQUFrQixFQUFDLElBQUk7Q0FBQzs7Z0JBQ3JRLGFBQWEsQ0FBQyxLQUFLLEVBQUMsQ0FBQztRQUFBLFdBQVcsRUFBQyxLQUFLO1FBQUMsY0FBYyxFQUFDLElBQUk7UUFBQyxjQUFjLEVBQUMsSUFBSTtRQUFDLFNBQVMsRUFBQyxFQUFFOztNQUFJLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDO1NBQUEsYUFBYTtTQUFJLGtCQUFrQixFQUFDLE1BQU07OztFQUFRLENBQUM7O1FBQU0sU0FBUyxLQUFHLG1CQUFtQjs7UUFBQyxrQkFBa0IsRUFBQyxTQUFTOztNQUFJLENBQUM7U0FBTSxNQUFNLGtDQUFPLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxJQUFJOzt1QkFBTyxTQUFTLEVBQUcsbUJBQW1COztTQUFRLGFBQWEsRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBRSxNQUFNLEdBQUMsTUFBTSxDQUFDLE9BQU87U0FBSyxrQkFBa0IsRUFBQyxPQUFPO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO3VCQUFHLFNBQVMsRUFBRyxtQkFBbUI7O1NBQVEsYUFBYTtTQUFJLGtCQUFrQixFQUFDLE9BQU87U0FBQyxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxxQ0FBcUM7RUFBQyxDQUFDO0NBQUE7O1VBQ2psQixZQUFZLENBQUMsTUFBTSxFQUFDLENBQUM7UUFBQSxjQUFjLEVBQUMsTUFBTTtRQUFDLFdBQVcsRUFBQyxNQUFNLENBQUMsVUFBVTtRQUFDLGNBQWMsRUFBQyxLQUFLO1FBQUMsU0FBUyxFQUFDLEVBQUU7Q0FBQzs7Z0JBQ3JHLGNBQWMsR0FBRSxDQUFDO1FBQU0sU0FBUyxHQUFDLE1BQU0sT0FBQyxRQUFRLEVBQUMsU0FBUztHQUFFLEtBQUssR0FBQyxNQUFNLE9BQUMsUUFBUSxFQUFDLFlBQVk7R0FBRSxRQUFRLEdBQUMsTUFBTSxPQUFDLFFBQVEsRUFBQyxhQUFhOzthQUFNLGNBQWMsR0FBQyxDQUFDO1NBQUEsU0FBUyxFQUFDLGtEQUFrRDs7O0VBQVEsQ0FBQzs7NEJBQUcsUUFBUSxFQUFDLE1BQU0sRUFBRyxLQUFLLE1BQUcsU0FBUyxJQUFFLENBQUMsV0FBRyxRQUFRLEVBQUMsT0FBTyxXQUFHLFFBQVEsRUFBQyxVQUFVLEdBQUUsQ0FBQztTQUFBLFNBQVMsRUFBQyx3REFBd0Q7OztFQUFRLENBQUM7OzRCQUFHLFFBQVEsRUFBQyxVQUFVLEVBQUcsS0FBSyxRQUFLLEtBQUssR0FBQyxDQUFDLE9BQUssUUFBUSxHQUFDLENBQUMsSUFBRyxDQUFDO1NBQUEsU0FBUyxFQUFDLDREQUE0RDs7O0VBQVEsQ0FBQzs7UUFBTSxPQUFPO0dBQUUsVUFBVSxRQUFDLGNBQWMsRUFBQyxVQUFVO0dBQUMsVUFBVSxRQUFDLGNBQWMsRUFBQyxVQUFVOzs0QkFBSyxRQUFRLEVBQUMsTUFBTSxFQUFHLEtBQUs7O0tBQUUsZ0JBQWdCLEVBQUMsU0FBUztLQUFDLE1BQU0sRUFBQyxNQUFNLE9BQUMsUUFBUSxFQUFDLE9BQU87S0FBRSxVQUFVLFFBQUMsUUFBUSxFQUFDLFVBQVU7Ozs7WUFBVSxjQUFjLEVBQUMsSUFBSSxLQUFFLElBQUksUUFBQyxjQUFjLEVBQUMsSUFBSTs7NEJBQVUsUUFBUSxFQUFDLFVBQVUsRUFBRyxLQUFLOztLQUFFLGVBQWUsSUFBRSxZQUFZLEVBQUMsS0FBSyxFQUFDLG1CQUFtQixFQUFDLFFBQVE7Ozs7O1FBQVEsVUFBVSxFQUFDLElBQUk7UUFBQyxTQUFTLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLGdCQUFnQixDQUFDLE9BQU87U0FBRSxTQUFTLEVBQUMsSUFBSTtrQ0FBTyxlQUFlO2tDQUFTLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxvQ0FBb0M7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDem1DLGdCQUFnQixDQUFDLElBQUksRUFBQyxDQUFDOzRCQUFHLG9CQUFvQixHQUFHLElBQUk7O1FBQVEsb0JBQW9CLEVBQUMsSUFBSSxDQUFDLEVBQUU7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFO1NBQUUsV0FBVyxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUMsSUFBSSxxQkFBRSxJQUFJLENBQUMsRUFBRSxFQUFHLElBQUksQ0FBQyxFQUFFO0dBQUUscUJBQXFCO2tDQUFTLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxvQ0FBb0M7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLG9CQUFvQixFQUFDLElBQUk7RUFBQyxDQUFDO0NBQUE7O1VBQ3JYLGVBQWUsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLGFBQWEsRUFBQyxJQUFJOztRQUFDLFdBQVc7R0FBRSxNQUFNLEVBQUMsRUFBRTtHQUFDLEdBQUcsRUFBQyxFQUFFO0dBQUMsVUFBVSxNQUFLLElBQUksR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7UUFBRyxTQUFTLEVBQUMsRUFBRTtDQUFDOztnQkFDOUgsZUFBZSxHQUFFLENBQUM7UUFBTSxNQUFNLEdBQUMsTUFBTSxPQUFDLFdBQVcsRUFBQyxNQUFNO0dBQUUsR0FBRyxHQUFDLE1BQU0sT0FBQyxXQUFXLEVBQUMsR0FBRzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxPQUFLLEdBQUcsSUFBRSxDQUFDLElBQUUsR0FBRyxJQUFFLEVBQUUsWUFBSSxXQUFXLEVBQUMsVUFBVSxFQUFDLENBQUM7U0FBQSxTQUFTLEVBQUMseUVBQXlFOzs7RUFBUSxDQUFDOztRQUFBLGFBQWEsRUFBQyxJQUFJOztNQUFJLENBQUM7a0NBQU0sbUJBQW1CLE9BQUMsYUFBYSxFQUFDLEVBQUUsSUFBRSxNQUFNLEVBQUMsR0FBRyxFQUFDLFVBQVUsUUFBQyxXQUFXLEVBQUMsVUFBVTtTQUFHLGFBQWEsRUFBQyxJQUFJO2tDQUFPLGVBQWU7a0NBQVMsY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFNBQVMsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDBCQUEwQjtFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsYUFBYSxFQUFDLEtBQUs7RUFBQyxDQUFDO0NBQUE7O1VBQzFnQixhQUFhLEdBQUUsQ0FBQztRQUFBLFVBQVUsRUFBQyxFQUFFO1FBQUMsVUFBVSxFQUFDLEVBQUU7UUFBQyxhQUFhLEVBQUMsSUFBSTtRQUFDLFlBQVk7UUFBSSxTQUFTLElBQUUsUUFBUSxFQUFDLEVBQUUsRUFBQyxhQUFhLEVBQUMsRUFBRTtRQUFFLGFBQWEsRUFBQyxJQUFJO0NBQUM7O2dCQUNySSxVQUFVLENBQUMsS0FBSyxFQUFDLENBQUM7UUFBQSxVQUFVLEVBQUMsS0FBSztRQUFDLGFBQWEsRUFBQyxJQUFJO1FBQUMsVUFBVSxFQUFDLEVBQUU7O01BQUksS0FBSyxDQUFDLElBQUksR0FBRyxNQUFNLEdBQUMsQ0FBQyxFQUFDLENBQUM7U0FBQSxZQUFZO1NBQUksaUJBQWlCLEVBQUMsTUFBTTs7O0VBQVEsQ0FBQzs7UUFBTSxTQUFTLEtBQUcsa0JBQWtCOztRQUFDLGlCQUFpQixFQUFDLFNBQVM7O01BQUksQ0FBQztTQUFNLE1BQU0sa0NBQU8sWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJOzt1QkFBTyxTQUFTLEVBQUcsa0JBQWtCOztTQUFRLFlBQVksRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBRSxNQUFNO1NBQUksaUJBQWlCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQzt1QkFBRyxTQUFTLEVBQUcsa0JBQWtCOztTQUFRLFlBQVk7U0FBSSxpQkFBaUIsRUFBQyxPQUFPO1NBQUMsVUFBVSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsaUNBQWlDO0VBQUMsQ0FBQztDQUFBOztVQUN2aEIsV0FBVyxDQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsYUFBYSxFQUFDLEtBQUs7UUFBQyxVQUFVLEtBQUksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsTUFBTTtRQUFJLFlBQVk7UUFBSSxVQUFVLEVBQUMsRUFBRTtDQUFDOztnQkFDNUcsU0FBUyxHQUFFLENBQUM7UUFBTSxRQUFRLEdBQUMsTUFBTSxPQUFDLFNBQVMsRUFBQyxRQUFRO0dBQUUsbUJBQW1CLEdBQUMsTUFBTSxPQUFDLFNBQVMsRUFBQyxhQUFhOzthQUFNLGFBQWEsR0FBQyxDQUFDO1NBQUEsVUFBVSxFQUFDLHlDQUF5Qzs7O0VBQVEsQ0FBQzs7UUFBSyxRQUFRLEdBQUMsQ0FBQyxPQUFLLG1CQUFtQixHQUFDLENBQUMsR0FBRSxDQUFDO1NBQUEsVUFBVSxFQUFDLDBEQUEwRDs7O0VBQVEsQ0FBQzs7UUFBQSxXQUFXLEVBQUMsSUFBSTtRQUFDLFVBQVUsRUFBQyxFQUFFOztNQUFJLENBQUM7a0NBQU0sV0FBVztJQUFFLE1BQU0sUUFBQyxhQUFhLEVBQUMsTUFBTTtJQUFDLElBQUksUUFBQyxhQUFhLEVBQUMsSUFBSTtJQUFDLFFBQVEsUUFBQyxhQUFhLEVBQUMsUUFBUTtJQUFDLFFBQVE7SUFBQyxtQkFBbUI7OztTQUFHLGFBQWEsRUFBQyxLQUFLO2tDQUFPLFVBQVU7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSwyQkFBMkI7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLFdBQVcsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDcm1CLFdBQVcsQ0FBQyxLQUFLLEVBQUMsQ0FBQzs0QkFBRyxlQUFlLEdBQUcsSUFBSTs7UUFBUSxlQUFlLEVBQUMsS0FBSyxDQUFDLEVBQUU7UUFBQyxVQUFVLEVBQUMsRUFBRTs7TUFBSSxDQUFDO2tDQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtTQUFFLE1BQU0sUUFBQyxNQUFNLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRyxLQUFLLENBQUMsRUFBRTtHQUFFLHFCQUFxQjtFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDhCQUE4QjtFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZUFBZSxFQUFDLElBQUk7RUFBQyxDQUFDO0NBQUE7O1VBQy9TLGFBQWEsQ0FBQyxLQUFLLEVBQUMsQ0FBQztRQUFBLGVBQWUsRUFBQyxLQUFLOztRQUFDLGFBQWE7R0FBRSxNQUFNLEVBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLE1BQU0sSUFBRSxFQUFFO0dBQUMsR0FBRyxFQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLElBQUUsRUFBRTtHQUFDLFVBQVUsRUFBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsVUFBVSxRQUFNLElBQUksR0FBRyxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7UUFBRyxVQUFVLEVBQUMsRUFBRTtDQUFDOztnQkFDdk8sYUFBYSxHQUFFLENBQUM7UUFBTSxNQUFNLEdBQUMsTUFBTSxPQUFDLGFBQWEsRUFBQyxNQUFNO0dBQUUsR0FBRyxHQUFDLE1BQU0sT0FBQyxhQUFhLEVBQUMsR0FBRzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxPQUFLLEdBQUcsSUFBRSxDQUFDLElBQUUsR0FBRyxJQUFFLEVBQUUsWUFBSSxhQUFhLEVBQUMsVUFBVSxFQUFDLENBQUM7U0FBQSxVQUFVLEVBQUMsaUVBQWlFOzs7RUFBUSxDQUFDOztRQUFBLGVBQWUsRUFBQyxJQUFJOztNQUFJLENBQUM7a0NBQU0sc0JBQXNCLE9BQUMsZUFBZSxFQUFDLEVBQUUsSUFBRSxNQUFNLEVBQUMsR0FBRyxFQUFDLFVBQVUsUUFBQyxhQUFhLEVBQUMsVUFBVTtTQUFHLGVBQWUsRUFBQyxJQUFJO2tDQUFPLFVBQVU7a0NBQVMsY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLG1DQUFtQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZUFBZSxFQUFDLEtBQUs7RUFBQyxDQUFDO0NBQUE7O2dCQUNuaEIsZ0JBQWdCLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMscUJBQXFCLEVBQUMsTUFBTTtHQUFFLGNBQWMsR0FBQyxNQUFNLE9BQUMscUJBQXFCLEVBQUMsS0FBSzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxPQUFLLGNBQWMsR0FBQyxDQUFDOztNQUFZLENBQUM7a0NBQU0sdUJBQXVCLE9BQUMsMkJBQTJCLEVBQUMsRUFBRSxRQUFDLDJCQUEyQixFQUFDLGtCQUFrQixDQUFDLEtBQUs7SUFBRSxNQUFNO0lBQUMsY0FBYztJQUFDLGVBQWUsTUFBSyxJQUFJLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTs7O1NBQUksMkJBQTJCLEVBQUMsSUFBSTtrQ0FBTyxVQUFVO2tDQUFTLGNBQWM7RUFBRyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx3Q0FBd0M7RUFBQyxDQUFDO0NBQUE7O2dCQUNyZ0IsZUFBZSxDQUFDLEVBQUUsRUFBQyxDQUFDO1FBQUEsV0FBVyxJQUFFLEVBQUU7UUFBRSxpQkFBaUIsRUFBQyxTQUFTOztNQUFJLENBQUM7U0FBQSxXQUFXLGlDQUFPLFFBQVEsQ0FBQyxFQUFFO1NBQUUsaUJBQWlCLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGlCQUFpQixFQUFDLE9BQU87U0FBQyxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSw0QkFBNEI7RUFBQyxDQUFDO0NBQUE7O1VBQ3JPLG1CQUFtQixDQUFDLElBQUksRUFBQyxVQUFVLEVBQUMsQ0FBQztRQUFBLGFBQWEsSUFBRSxJQUFJLEVBQUMsVUFBVTtRQUFFLGVBQWUsRUFBQyxFQUFFOztRQUFDLGNBQWM7R0FBRSxNQUFNLEVBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLGdCQUFnQixJQUFFLEVBQUU7R0FBRSxlQUFlLEVBQUMsVUFBVSxDQUFDLGVBQWUsUUFBTSxJQUFJLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTtHQUFFLEdBQUcsV0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLElBQUksSUFBQyxFQUFFLEdBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHOztDQUFHOztnQkFDblMsbUJBQW1CLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMsY0FBYyxFQUFDLE1BQU07R0FBRSxHQUFHLEdBQUMsTUFBTSxPQUFDLGNBQWMsRUFBQyxHQUFHOztRQUFPLE1BQU0sR0FBQyxDQUFDLFlBQUksY0FBYyxFQUFDLGVBQWUsTUFBSSxHQUFHLEdBQUMsQ0FBQyxHQUFFLENBQUM7U0FBQSxlQUFlLEVBQUMsa0RBQWtEOzs7RUFBUSxDQUFDOztRQUFBLGdCQUFnQixFQUFDLElBQUk7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQU0sT0FBTztJQUFFLE1BQU07SUFBQyxlQUFlLFFBQUMsY0FBYyxFQUFDLGVBQWU7SUFBQyxHQUFHO0lBQUMsaUJBQWlCLEVBQUMsZUFBZTs7OzZCQUFLLGFBQWEsRUFBQyxVQUFVLENBQUMsTUFBTSxFQUFHLFdBQVcsa0NBQU8sbUJBQW1CLE9BQUMsYUFBYSxFQUFDLElBQUksQ0FBQyxFQUFFLFFBQUMsYUFBYSxFQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUMsT0FBTywyQ0FBYSxvQkFBb0IsT0FBQyxhQUFhLEVBQUMsSUFBSSxDQUFDLEVBQUUsUUFBQyxhQUFhLEVBQUMsVUFBVSxDQUFDLGNBQWMsRUFBQyxPQUFPOztTQUFFLGFBQWEsRUFBQyxJQUFJO2tDQUFPLGVBQWU7a0NBQVMsY0FBYztFQUFHLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLGVBQWUsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLHFDQUFxQztFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsZ0JBQWdCLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Z0JBQy95QixjQUFjLENBQUMsRUFBRSxFQUFDLENBQUM7UUFBQSxVQUFVLElBQUUsRUFBRTtRQUFFLGdCQUFnQixFQUFDLFNBQVM7UUFBQyxlQUFlLEVBQUMsRUFBRTs7TUFBSSxDQUFDO1NBQUEsVUFBVSxpQ0FBTyxhQUFhLENBQUMsRUFBRTtTQUFFLGdCQUFnQixFQUFDLE9BQU87RUFBQyxDQUFDLE9BQU0sS0FBSyxFQUFDLENBQUM7U0FBQSxnQkFBZ0IsRUFBQyxPQUFPO1NBQUMsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsMkJBQTJCO0VBQUMsQ0FBQztDQUFBOztVQUMzUCxXQUFXLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBQSxXQUFXLEVBQUMsSUFBSTtRQUFDLFlBQVksRUFBQyxFQUFFOztRQUFDLFdBQVc7R0FBRSxNQUFNLEVBQUMsRUFBRTtHQUFDLGVBQWUsTUFBSyxJQUFJLEdBQUcsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUMsRUFBRTtHQUFFLEdBQUcsRUFBQyxFQUFFOztDQUFFOztVQUN2SSxlQUFlLENBQUMsSUFBSSxFQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsc0JBQXNCLElBQUUsSUFBSSxFQUFDLEtBQUs7UUFBRSxvQkFBb0IsRUFBQyxFQUFFOztRQUFDLG1CQUFtQjtHQUFFLE1BQU0sRUFBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBRSxFQUFFO0dBQUUsZUFBZSxFQUFDLEtBQUssQ0FBQyxlQUFlLElBQUUsRUFBRTtHQUFDLEdBQUcsV0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksSUFBQyxFQUFFLEdBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHOztDQUFHOztnQkFDM04sbUJBQW1CLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMsbUJBQW1CLEVBQUMsTUFBTTtHQUFFLEdBQUcsR0FBQyxNQUFNLE9BQUMsbUJBQW1CLEVBQUMsR0FBRzs7UUFBTyxNQUFNLEdBQUMsQ0FBQyxZQUFJLG1CQUFtQixFQUFDLGVBQWUsTUFBSSxHQUFHLEdBQUMsQ0FBQyxHQUFFLENBQUM7U0FBQSxvQkFBb0IsRUFBQyxrREFBa0Q7OztFQUFRLENBQUM7O1FBQUEscUJBQXFCLEVBQUMsSUFBSTtRQUFDLG9CQUFvQixFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSwyQkFBMkIsT0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsRUFBRSxRQUFDLHNCQUFzQixFQUFDLEtBQUssQ0FBQyxFQUFFO0lBQUUsTUFBTTtJQUFDLGVBQWUsUUFBQyxtQkFBbUIsRUFBQyxlQUFlO0lBQUMsR0FBRztJQUFDLGlCQUFpQixFQUFDLGNBQWM7OztTQUFTLEVBQUUsU0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsRUFBRTs7U0FBQyxzQkFBc0IsRUFBQyxJQUFJO2tDQUFPLE9BQU8sQ0FBQyxHQUFHLEVBQUUsZUFBZSxJQUFHLGNBQWMsQ0FBQyxFQUFFLEdBQUUsY0FBYztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLG9CQUFvQixFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsbUNBQW1DO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxxQkFBcUIsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDandCLFdBQVcsR0FBRSxDQUFDO1FBQU0sTUFBTSxHQUFDLE1BQU0sT0FBQyxXQUFXLEVBQUMsTUFBTTtHQUFFLEdBQUcsR0FBQyxNQUFNLE9BQUMsV0FBVyxFQUFDLEdBQUc7O1FBQU8sTUFBTSxHQUFDLENBQUMsWUFBSSxXQUFXLEVBQUMsZUFBZSxNQUFJLEdBQUcsR0FBQyxDQUFDLEdBQUUsQ0FBQztTQUFBLFlBQVksRUFBQyxxREFBcUQ7OztFQUFRLENBQUM7O1FBQUEsYUFBYSxFQUFDLElBQUk7O01BQUksQ0FBQztrQ0FBTSx1QkFBdUIsT0FBQyxXQUFXLEVBQUMsRUFBRTtJQUFFLE1BQU07SUFBQyxlQUFlLFFBQUMsV0FBVyxFQUFDLGVBQWU7SUFBQyxHQUFHO0lBQUMsaUJBQWlCLEVBQUMsZUFBZTs7O1NBQUcsV0FBVyxFQUFDLElBQUk7a0NBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxlQUFlLElBQUcsY0FBYztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFlBQVksRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLDhCQUE4QjtFQUFDLENBQUMsU0FBTyxDQUFDO1NBQUEsYUFBYSxFQUFDLEtBQUs7RUFBQyxDQUFDO0NBQUE7O1VBQzVpQixRQUFRLENBQUMsSUFBSSxFQUFDLENBQUM7UUFBQSxJQUFJLEVBQUMsSUFBSTs7c0JBQUksSUFBSSxFQUFHLGNBQWMsVUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLElBQUk7U0FBQyxXQUFXLEVBQUMsUUFBUTtFQUFDLENBQUM7O0VBQUEsTUFBTSxDQUFDLFFBQVEsR0FBRSxHQUFHLEVBQUMsQ0FBQyxFQUFDLFFBQVEsRUFBQyxRQUFRO0NBQUc7O1VBQ3JJLGlCQUFpQixHQUFFLENBQUM7UUFBTSxHQUFHLE9BQUssSUFBSTs7WUFBYSxHQUFHLENBQUMsV0FBVyxNQUFNLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxLQUFHLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFDLEdBQUc7Q0FBSTs7VUFDbkgsV0FBVyxDQUFDLE1BQU0sRUFBQyxDQUFDO1NBQU0sQ0FBQyxFQUFDLENBQUMsSUFBRSxhQUFhLEdBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsTUFBTTtHQUFFLElBQUksT0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxNQUFNLEVBQUMsQ0FBQyxHQUFHLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUM7O01BQUssSUFBSSxJQUFFLGlCQUFpQixJQUFHLENBQUM7U0FBQSxXQUFXLEVBQUMsSUFBSTtTQUFDLFFBQVE7U0FBSSxXQUFXLEVBQUMsUUFBUTtHQUFDLGFBQWEsR0FBQyxJQUFJO0VBQUUsQ0FBQztDQUFBOztVQUMxTyxhQUFhLENBQUMsVUFBVSxFQUFDLE9BQU8sRUFBQyxDQUFDO1NBQU0sQ0FBQyxFQUFDLENBQUMsSUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsTUFBTTtHQUFFLEtBQUssT0FBSyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsT0FBTztHQUFHLE9BQU8sUUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLE1BQU0sS0FBRyxDQUFDLElBQUUsQ0FBQztHQUFDLE1BQU0sT0FBSyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBQyxDQUFDLE1BQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLElBQUcsQ0FBQztHQUFJLEtBQUssT0FBSyxJQUFJO0dBQUcsT0FBTyxtQkFBQyxLQUFLLENBQUMsV0FBVyxJQUFLLENBQUMscUJBQUUsS0FBSyxDQUFDLFFBQVEsS0FBRyxDQUFDLEVBQUcsQ0FBQzs7O0dBQVEsT0FBTzs7R0FBQyxJQUFJLEVBQUMsS0FBSyxDQUFDLElBQUksR0FBRSxNQUFNLEVBQUMsS0FBSyxLQUFHLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQztVQUFNLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUc7OztLQUFhLEdBQUc7S0FBQyxVQUFVLEVBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQztLQUFFLGdCQUFnQixFQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLElBQUUsQ0FBQztLQUFFLFNBQVMsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDO0tBQUksTUFBTSxFQUFDLE9BQU8sSUFBRSxHQUFHLEdBQUMsS0FBSyxDQUFDLE9BQU87O0dBQUksQ0FBQzs7Q0FBRzs7Z0JBQ3pqQixVQUFVLENBQUMsR0FBRyxFQUFDLENBQUM7T0FBSSxHQUFHLElBQUUsR0FBRyxDQUFDLE1BQU07O1FBQVEsV0FBVyxFQUFDLEdBQUcsQ0FBQyxHQUFHO1FBQUMsV0FBVyxFQUFDLEtBQUs7UUFBQyxPQUFPLEVBQUMsS0FBSztRQUFDLFVBQVUsRUFBQyxJQUFJO2lDQUFPLE9BQU87Q0FBRzs7Z0JBQy9ILE9BQU8sR0FBRSxDQUFDO3FCQUFHLFdBQVcsR0FBRSxJQUFJOztRQUFRLFNBQVMsRUFBQyxTQUFTOztNQUFJLENBQUM7U0FBTSxJQUFJLGtDQUFPLGtCQUFrQixDQUFDLGFBQWEsSUFBQyxPQUFPLE9BQUMsV0FBVyxJQUFFLEVBQUU7O1NBQUUsUUFBUSxFQUFDLElBQUksQ0FBQyxLQUFLLElBQUUsSUFBSSxDQUFDLFFBQVE7U0FBSyxTQUFTLEVBQUMsT0FBTztFQUFDLENBQUMsT0FBSyxDQUFDO1NBQUEsU0FBUyxFQUFDLE9BQU87RUFBQyxDQUFDO0NBQUE7O2dCQUM1TixTQUFTLENBQUMsS0FBSyxFQUFDLENBQUM7UUFBQSxXQUFXLEVBQUMsS0FBSztRQUFDLFVBQVUsRUFBQyxDQUFDO1FBQUMsaUJBQWlCLEVBQUMsS0FBSzs7UUFBTyxTQUFTLElBQUUsS0FBSyxDQUFDLEtBQUssUUFBTSxJQUFJLEVBQUMsSUFBSSxNQUFHLElBQUksQ0FBQyxPQUFPLFFBQU0sSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLElBQUksRUFBRyx3QkFBd0I7O01BQU0sU0FBUyxFQUFDLENBQUM7U0FBQSxzQkFBc0IsRUFBQyxTQUFTO1NBQUMsb0JBQW9CLEVBQUMsSUFBSTs7T0FBSSxDQUFDO1VBQU0sTUFBTSxrQ0FBTyxtQkFBbUIsQ0FBQyxhQUFhOztVQUFFLGdCQUFnQixFQUFDLE1BQU0sQ0FBQyxLQUFLO1VBQUssc0JBQXNCLEVBQUMsT0FBTztHQUFDLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztVQUFBLHNCQUFzQixFQUFDLE9BQU87VUFBQyxlQUFlLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSx5Q0FBeUM7R0FBQyxDQUFDO0VBQUEsQ0FBQztDQUFBOztVQUNqZ0IsWUFBWSxDQUFDLEtBQUssRUFBQyxDQUFDO1NBQU8sWUFBWSxDQUFDLEtBQUssS0FBRyxXQUFXLENBQUMsS0FBSyxRQUFDLFVBQVUsR0FBRSxJQUFJLEVBQUMsSUFBSSxNQUFFLE9BQU8sRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7Q0FBRzs7Z0JBQ2hILGdCQUFnQixDQUFDLGFBQWEsRUFBQyxZQUFZLEVBQUMsQ0FBQztRQUFBLGtCQUFrQixFQUFDLGFBQWE7O01BQUksQ0FBQztrQ0FBTSx1QkFBdUIsQ0FBQyxhQUFhLEVBQUMsWUFBWTtTQUFFLGdCQUFnQixRQUFDLGdCQUFnQixFQUFDLE1BQU0sRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxhQUFhLEVBQUcsYUFBYTtrQ0FBUSxjQUFjOztjQUFPLGdCQUFnQixFQUFDLE1BQU0sUUFBQyxvQkFBb0IsRUFBQyxLQUFLO0VBQUMsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsZUFBZSxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsNkJBQTZCO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxrQkFBa0IsRUFBQyxJQUFJO0VBQUMsQ0FBQztDQUFBOztVQUNqYSxhQUFhLENBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxDQUFDOzRCQUFHLGVBQWUsR0FBRyxJQUFJOztRQUFjLFFBQVEsR0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxPQUFPLFNBQUMsZUFBZTs7TUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBRSxFQUFFLFFBQUMsVUFBVSxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFDLENBQUMsUUFBQyxVQUFVLEtBQUUsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQzs7UUFBSSxlQUFlLEVBQUMsSUFBSTtDQUFDOztVQUNqUCxZQUFZLENBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxJQUFJLEVBQUMsQ0FBQzs0QkFBRyxtQkFBbUIsR0FBRyxJQUFJOztRQUFjLFFBQVEsR0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxPQUFPLFNBQUMsbUJBQW1COztNQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxJQUFFLEVBQUUsRUFBQyxDQUFDO1NBQU0sSUFBSSxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFDLENBQUMsbUJBQUUsSUFBSSxFQUFHLE1BQU0sVUFBQyxjQUFjLFVBQUMsZ0JBQWdCLE1BQUcsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQzs7dUJBQU8sSUFBSSxFQUFHLE1BQU0sU0FBQyxjQUFjLEVBQUMsSUFBSSxjQUFNLGdCQUFnQixFQUFDLElBQUk7RUFBQyxDQUFDOztRQUFBLG1CQUFtQixFQUFDLElBQUk7Q0FBQzs7Z0JBQ2xXLFNBQVMsQ0FBQyxJQUFJLEVBQUMsQ0FBQztRQUFBLE9BQU8sRUFBQyxJQUFJO1FBQUMsVUFBVSxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFFLEVBQUU7UUFBRSxRQUFRLEVBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxJQUFJO1FBQUcsWUFBWSxrQkFBQyxRQUFRLENBQUMsSUFBSSxHQUFJLGVBQWUsSUFBQyxFQUFFLEdBQUMsUUFBUSxDQUFDLElBQUk7UUFBRSxlQUFlLEVBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsSUFBRSxFQUFFO1FBQUMsY0FBYyxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxJQUFFLEVBQUU7UUFBRSxhQUFhLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLElBQUUsSUFBSSxDQUFDLGVBQWUsSUFBRSxFQUFFO1FBQUUsV0FBVyxFQUFDLEVBQUU7UUFBQyxZQUFZLEVBQUMsRUFBRTs7NEJBQUksYUFBYSxHQUFHLE9BQU8sR0FBQyxDQUFDO0dBQUEsdUJBQXVCLENBQUMsSUFBSTs7O0VBQVMsQ0FBQzs7UUFBQSxhQUFhLEVBQUMsU0FBUzs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyxpQkFBaUI7O1NBQUcsV0FBVztJQUFFLFVBQVUsRUFBQyxNQUFNLENBQUMsVUFBVTtJQUFLLFNBQVMsRUFBQyxNQUFNLENBQUMsU0FBUztJQUFLLFFBQVEsRUFBQyxNQUFNLENBQUMsUUFBUTs7O1NBQU0sYUFBYSxFQUFDLE9BQU87R0FBQyx1QkFBdUIsQ0FBQyxJQUFJO0VBQUUsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsYUFBYSxFQUFDLE9BQU87U0FBQyxZQUFZLEVBQUMsS0FBSyxFQUFFLE9BQU8sSUFBRSxpQ0FBaUM7RUFBQyxDQUFDO0NBQUE7O1VBQ3h5Qix1QkFBdUIsQ0FBQyxJQUFJLEVBQUMsQ0FBQzthQUFJLGNBQWMsR0FBQyxDQUFDO1NBQU0sS0FBSyxTQUFDLFdBQVcsRUFBQyxTQUFTLENBQUMsSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLElBQUksRUFBRSxXQUFXLElBQUssUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXOztPQUFPLEtBQUssUUFBQyxjQUFjLEVBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFO0VBQUUsQ0FBQzs7YUFBSSxhQUFhLEdBQUMsQ0FBQztTQUFNLE9BQU8sR0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsSUFBRSxFQUFFLEVBQUUsV0FBVztJQUFHLEtBQUssU0FBQyxXQUFXLEVBQUMsUUFBUSxDQUFDLElBQUksRUFBQyxNQUFNLHFCQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUUsV0FBVyxJQUFLLE9BQU87O09BQUssS0FBSyxRQUFDLGFBQWEsRUFBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUU7RUFBRSxDQUFDO0NBQUE7O1VBQ3ZiLGtCQUFrQixDQUFDLEtBQUssRUFBQyxDQUFDO1FBQUEsWUFBWSxFQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSzs7YUFBSyxpQkFBaUIsRUFBQyxRQUFRLE9BQUMsZUFBZSxVQUFFLGVBQWUsRUFBQyxFQUFFO0NBQUM7O2dCQUM5SCxRQUFRLEdBQUUsQ0FBQztRQUFNLE1BQU0sR0FBQyxNQUFNLE9BQUMsVUFBVTtHQUFFLFVBQVUsR0FBQyxNQUFNLE9BQUMsY0FBYztHQUFFLFNBQVMsR0FBQyxNQUFNLE9BQUMsYUFBYTs7YUFBTSxPQUFPLFdBQUUsTUFBTSwyQkFBRSxhQUFhLEdBQUcsT0FBTyxhQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFHLE1BQU0sSUFBRSxDQUFDLFdBQUcsUUFBUSxZQUFHLFlBQVksWUFBRyxlQUFlLE1BQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLE1BQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTOztRQUFTLE1BQU0sRUFBQyxJQUFJO1FBQUMsV0FBVyxFQUFDLEVBQUU7O01BQUksQ0FBQztrQ0FBTSxhQUFhLE9BQUMsT0FBTyxFQUFDLEVBQUU7SUFBRSxNQUFNO0lBQUMsZUFBZSxRQUFDLFFBQVE7SUFBQyxRQUFRLFFBQUMsWUFBWTtJQUFDLFdBQVcsUUFBQyxlQUFlO0lBQUMsVUFBVTtJQUFDLFNBQVM7OztTQUFHLE9BQU8sRUFBQyxJQUFJOztrQ0FBTyxPQUFPLENBQUMsR0FBRztJQUFFLE9BQU87SUFBRyxhQUFhO0lBQUcsZUFBZTtJQUFHLGNBQWM7O0VBQUssQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsbUNBQW1DO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxNQUFNLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Z0JBQ3pwQixhQUFhLEdBQUUsQ0FBQzthQUFJLFFBQVE7O01BQVcsQ0FBQztrQ0FBTSxhQUFhLE9BQUMsUUFBUSxFQUFDLEVBQUU7U0FBRSxRQUFRLEVBQUMsSUFBSTs7a0NBQU8sT0FBTyxDQUFDLEdBQUc7SUFBRSxPQUFPO0lBQUcsYUFBYTtJQUFHLGVBQWU7SUFBRyxjQUFjOztFQUFLLENBQUMsT0FBTSxLQUFLLEVBQUMsQ0FBQztTQUFBLFdBQVcsRUFBQyxLQUFLLEVBQUUsT0FBTyxJQUFFLG1DQUFtQztTQUFDLFFBQVEsRUFBQyxJQUFJO0VBQUMsQ0FBQztDQUFBOztnQkFDdFEsY0FBYyxHQUFFLENBQUM7YUFBSSxRQUFRLFdBQUUsYUFBYTs7UUFBUSxhQUFhLEVBQUMsSUFBSTs7TUFBSSxDQUFDO1NBQU0sTUFBTSxrQ0FBTyx3QkFBd0IsQ0FBQyxPQUFPLE9BQUMsUUFBUSxFQUFDLEdBQUcsU0FBRSxJQUFJLEVBQUMsUUFBUSxJQUFFLElBQUksQ0FBQyxjQUFjLEdBQUcsZUFBZSxHQUFHLFFBQVE7O1NBQUUsT0FBTyxPQUFLLE1BQU0sRUFBQyxJQUFJLEVBQUMsT0FBTyxPQUFDLFFBQVEsRUFBQyxHQUFHO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsV0FBVyxFQUFDLEtBQUssWUFBWSxRQUFRO01BQUMsS0FBSyxDQUFDLE9BQU87TUFBQyx1Q0FBdUM7RUFBQyxDQUFDLFNBQU8sQ0FBQztTQUFBLGFBQWEsRUFBQyxLQUFLO0VBQUMsQ0FBQztDQUFBOztnQkFDclksT0FBTyxHQUFFLENBQUM7UUFBQSxVQUFVLEVBQUMsSUFBSTs7TUFBSSxDQUFDO2tDQUFNLE1BQU07O09BQU0sQ0FBQztJQUFBLFlBQVksQ0FBQyxVQUFVLElBQUksdUJBQXVCO0lBQVMsWUFBWSxDQUFDLFVBQVUsSUFBSSx1QkFBdUI7R0FBUyxDQUFDLE9BQUssQ0FBQyxDQUFDOztHQUFBLFFBQVE7RUFBRyxDQUFDLE9BQUssQ0FBQztTQUFBLFVBQVUsRUFBQyxLQUFLO1NBQUMsWUFBWSxFQUFDLHFCQUFxQjtFQUFDLENBQUM7Q0FBQTs7Z0JBQ3RQLGNBQWMsR0FBRSxDQUFDO1lBQUcsYUFBYTs7UUFBUSxhQUFhLEVBQUMsSUFBSTtRQUFDLFNBQVMsRUFBQyxFQUFFOztNQUFJLENBQUM7a0NBQU0sZ0JBQWdCLElBQUUsUUFBUTtTQUFFLEtBQUs7U0FBSSxXQUFXO1NBQUksTUFBTTtTQUFJLE9BQU87U0FBSSxVQUFVLEVBQUMsTUFBTTtTQUFDLGdCQUFnQixFQUFDLE1BQU07U0FBQyxXQUFXLEVBQUMsTUFBTTtHQUFDLGFBQWEsR0FBQyxNQUFNO1NBQUMsVUFBVSxFQUFDLElBQUk7U0FBQyxRQUFRO1NBQUksV0FBVyxFQUFDLElBQUk7U0FBQyxXQUFXLElBQUUsVUFBVSxNQUFJLFNBQVMsTUFBSSxRQUFRO1NBQUssYUFBYSxFQUFDLE1BQU07U0FBQyxTQUFTLEVBQUMsS0FBSztrQ0FBTyxXQUFXO0VBQUcsQ0FBQyxPQUFNLEtBQUssRUFBQyxDQUFDO1NBQUEsU0FBUyxFQUFDLEtBQUssRUFBRSxPQUFPLElBQUUsNEJBQTRCO0VBQUMsQ0FBQyxTQUFPLENBQUM7U0FBQSxhQUFhLEVBQUMsS0FBSztFQUFDLENBQUM7Q0FBQTs7Q0FDM2YsT0FBTyxPQUFLLENBQUM7TUFBRyxDQUFDO1NBQUEsZUFBZSxFQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsZ0NBQWdDLEtBQUcsU0FBUztFQUFDLENBQUMsT0FBSyxDQUFDLENBQUM7O0VBQUEsV0FBVztDQUFHLENBQUM7OztRQXpIdkgsSUFBSSxFQUFDLGVBQWUsR0FBQyxJQUFJOzs7O1FBQVMsUUFBUSxRQUFDLElBQUksRUFBQyxRQUFRLElBQUUsS0FBSzs7OztRQUFLLFFBQVEsRUFBQyxhQUFhLENBQUMsYUFBYSxVQUFDLElBQUksRUFBQyxJQUFJOzs7O1FBQ2xILFVBQVUsRUFBQyxhQUFhLEdBQUMsSUFBSTs7OztRQUFTLFdBQVcsU0FBRSxVQUFVLEVBQUMsS0FBSyxVQUFFLFVBQVUsRUFBQyxRQUFRLFFBQU0sS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7O1FBQ3ZHLFNBQVMsRUFBQyxjQUFjLEdBQUMsSUFBSTs7OztRQUFTLE9BQU8sUUFBQyxTQUFTLEVBQUMsT0FBTyxVQUFFLFNBQVMsRUFBQyxZQUFZLFVBQUUsU0FBUyxFQUFDLFVBQVU7Ozs7UUFDN0csZUFBZSx3QkFBQyxXQUFXLEdBQUcsS0FBSztXQUFDLE9BQU87V0FBQyxPQUFPLEVBQUMsTUFBTSxFQUFDLEtBQUsscUJBQUUsV0FBVyxDQUFDLEtBQUssRUFBRSxXQUFXLFVBQUssV0FBVyxFQUFDLFdBQVc7Ozs7UUFDNUgsV0FBVyxRQUFDLE9BQU8sRUFBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUM7Ozs7WUFDMUIsY0FBYyxXQUFFLFdBQVcsRUFBQyxNQUFNLFFBQUMsY0FBYyxFQUFDLENBQUM7Ozs7WUFDbkQsZ0JBQWdCLFdBQUUsZUFBZSxFQUFDLE1BQU0sUUFBQyxnQkFBZ0IsRUFBQyxDQUFDOzs7O1FBQzlELFFBQVEsaUJBQUMsV0FBVyxHQUFFLElBQUk7S0FBQyxJQUFJO1dBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsR0FBRyxxQkFBRSxHQUFHLENBQUMsR0FBRyxRQUFHLFdBQVc7Ozs7UUFBTSxXQUFXLHdCQUFDLFdBQVcsR0FBRyxRQUFRLFVBQUMsV0FBVyxVQUFDLFFBQVE7Ozs7UUFBSyxZQUFZLFFBQUMsT0FBTyxVQUFDLFdBQVcsVUFBQyxXQUFXLEVBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7O1FBQ3JNLGlCQUFpQixRQUFDLFdBQVcsRUFBQyxVQUFVLENBQUMsSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLElBQUksUUFBRyxZQUFZLEtBQUcsYUFBYTs7OztRQUNoRyxXQUFXLFFBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxNQUFNLEVBQUcsUUFBUTs7OztRQUFNLFdBQVcsUUFBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLElBQUkscUJBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRyxRQUFROzs7O1FBQU0sZUFBZSxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLElBQUksS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBRSxDQUFDLEdBQUUsQ0FBQzs7OztRQUMvTSxlQUFlO0dBQUUsUUFBUSxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLElBQUksS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUUsQ0FBQyxHQUFFLENBQUM7O0dBQUUsT0FBTyxRQUFDLFdBQVcsRUFBQyxJQUFJLEVBQUMsSUFBSSxxQkFBRSxJQUFJLENBQUMsWUFBWSxFQUFHLElBQUk7WUFBRSxXQUFXLEVBQUMsTUFBTSxFQUFFLEtBQUssRUFBQyxJQUFJLEtBQUcsS0FBSyxHQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFFLENBQUMsR0FBRSxDQUFDO01BQUUsSUFBSTs7R0FBQyxHQUFHLFFBQUMsV0FBVyxFQUFDLElBQUksRUFBQyxJQUFJLHFCQUFFLElBQUksQ0FBQyxZQUFZLEVBQUcsSUFBSTtZQUFFLFdBQVcsRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLElBQUksS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUUsQ0FBQyxHQUFFLENBQUM7TUFBRSxJQUFJOzs7OztRQUNsVyxjQUFjO0dBQUUsUUFBUSxRQUFDLE1BQU0sRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLEtBQUssS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLElBQUUsQ0FBQyxHQUFFLENBQUM7O0dBQUUsT0FBTyxRQUFDLE1BQU0sRUFBQyxJQUFJLEVBQUMsS0FBSyxxQkFBRSxLQUFLLENBQUMsWUFBWSxFQUFHLElBQUk7WUFBRSxNQUFNLEVBQUMsTUFBTSxFQUFFLEtBQUssRUFBQyxLQUFLLEtBQUcsS0FBSyxHQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxJQUFFLENBQUMsR0FBRSxDQUFDO01BQUUsSUFBSTs7R0FBQyxHQUFHLFFBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLEtBQUssQ0FBQyxZQUFZLEVBQUcsSUFBSTtZQUFFLE1BQU0sRUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFDLEtBQUssS0FBRyxLQUFLLEdBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLElBQUUsQ0FBQyxHQUFFLENBQUM7TUFBRSxJQUFJOzs7OztRQUNsVixjQUFjLFFBQUMsT0FBTyxFQUFDLEdBQUcsRUFBQyxNQUFNLFFBQUksTUFBTSxFQUFDLFlBQVksRUFBQyxrQkFBa0IsQ0FBQyxNQUFNLE1BQUssTUFBTSxFQUFDLElBQUksS0FBRSxJQUFJLENBQUMsWUFBWTs7OztRQUNySCxxQkFBcUIsUUFBQyxPQUFPLEVBQUMsSUFBSSxFQUFDLE1BQU0scUJBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEdBQUksTUFBTSxPQUFDLGlCQUFpQix1QkFBRyxNQUFNLENBQUMsVUFBVSxFQUFHLDJCQUEyQjs7OztRQVlsSixlQUFlLGtCQUFDLGdCQUFnQixJQUFHLFFBQVE7S0FBQyxRQUFRO3FCQUFDLGdCQUFnQixJQUFHLFNBQVMsSUFBQyxTQUFTLEdBQUMsVUFBVTs7OztRQUN0RyxhQUFhO1NBQUUsV0FBVztHQUFDLFdBQVcsT0FBQyxXQUFXLFNBQUMsVUFBVTs7Ozs7Ozs7Ozs7Ozs7O09BaUdoRCxHQUFHO09BQTRDLE9BQU8sV0FBdEQsR0FBRztPQUErRyxNQUFNLFdBQXpFLE9BQU87T0FBbUssRUFBRSxhQUF6RyxNQUFNO3dCQUFpRyxFQUFFOztXQUFGLEVBQUU7OzBCQUFGLEVBQUU7Ozs7U0FBZ0UsQ0FBQzs7d0JBQUQsQ0FBQzs7Ozs7Ozs7O1dBQW9FLEdBQUM7NEJBQUQsR0FBQzs7ZUFBRCxHQUFDO3dEQUFFLGdCQUFnQjswQkFBbkIsR0FBQzs7OztXQUErQixTQUFPO3NDQUFQLFNBQU87Ozs7Ozs7Ozs7OztrQkFqSm5aLFdBQVc7a0NBaUppZSxXQUFXLEVBQUMsT0FBTzs7O3NCQUFJLEtBQUs7Z0JBQUUsS0FBRzs7Z0JBQWtFLElBQUksV0FBekUsS0FBRztpQ0FBa0UsSUFBSTs7b0JBQUosSUFBSTs7Z0JBQW1DLE1BQU0sYUFBN0MsSUFBSTtpQ0FBbUMsTUFBTTs7b0JBQU4sTUFBTTs7Z0JBQXdDLE1BQUksYUFBbEQsTUFBTTtnQkFBcUUsR0FBQyxXQUE5QixNQUFJO2lDQUF5QixHQUFDOztvQkFBRCxHQUFDO29CQUE5QixNQUFJOztnQkFBcUYsS0FBSyxhQUE5RixNQUFJO2lDQUFxRixLQUFLOztvQkFBTCxLQUFLOzttQ0FBTCxLQUFLOzs7O2tCQUEwSixLQUFHO21DQUFILEtBQUc7Ozs7c0JBQTVaLEtBQUs7NkNBQXNkLEtBQUssT0FBQyxLQUFLLEVBQUMsYUFBYTs7OztzQkFBcGYsS0FBSzt3Q0FBeWdCLFVBQVUsT0FBQyxLQUFLLEVBQUMsS0FBSzs7OztzQkFBMUcsV0FBVzs7Ozs7Ozs7O2lDQUEySCxpQkFBaUIsT0FBQyxLQUFLOzs7Ozs7Ozs7O3NCQUE5TCxLQUFHO2lDQUFILEtBQUc7Ozs7OztzQkFBNVosS0FBSztzREFBOFgsS0FBSyxFQUFDLE1BQU0sRUFBRyxLQUFLOzs7Ozs7Ozs7O29CQUFoWixLQUFHOzs7O29DQUFILEtBQUcsMkVBQTJDLEtBQUssRUFBQyxNQUFNLEVBQUcsS0FBSzs7Ozs7Ozs7cUJBQXpFLEtBQUs7K0JBQTZFLFNBQVMsT0FBQyxLQUFLLEVBQUMsT0FBTzs7OztxQkFBekcsS0FBSzsrQkFBc0gsVUFBVSxPQUFDLEtBQUssRUFBQyxLQUFLOzs7O3FCQUFqSixLQUFLOytCQUE0TCxLQUFLLE9BQUMsS0FBSyxFQUFDLFVBQVUsVUFBRSxLQUFLLEVBQUMsYUFBYTs7OztxQkFBNU8sS0FBSzs7cURBQTRQLEtBQUssRUFBQyxNQUFNLEVBQUcsTUFBTTs2QkFBWSxTQUFTLE9BQUMsS0FBSyxFQUFDLE1BQU07d0NBQUksS0FBSyxFQUFDLE1BQU0sRUFBRyxLQUFLLElBQUMsU0FBUyxTQUFDLEtBQUssRUFBQyxNQUFNLENBQUMsV0FBVzs7Ozs7K0JBQTVXLEtBQUc7Ozs7Ozs7Ozs7Ozs7YUFBaW5CLEdBQUM7OzRCQUFELEdBQUM7Ozs7OztpQkFqSi9uQyxXQUFXO2lDQWlKOGIsV0FBVyxFQUFDLE9BQU8sRUFBRSxNQUFNOzs7Ozs7Ozs7O2VBQXhGLFNBQU87MEJBQVAsU0FBTzs7Ozs7OzttQ0FBcEUsaUJBQWlCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBbEcsaUJBQWlCLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQTFPLE9BQU87V0FBdEQsR0FBRzs7O1VBakpmLFdBQVc7MEJBaUo4TixXQUFXLEVBQUMsUUFBUTs7O29CQUEvSCxNQUFNLGNBQTZCLFdBQVcsRUFBQyxJQUFJO3NCQUFySyxHQUFHOzs7OztjQUFoQixXQUFXOzs7Ozs7Ozs7Ozs7O09BQ1EsS0FBRztPQUE0QyxTQUFPLFdBQXRELEtBQUc7T0FBK0csUUFBTSxXQUF6RSxTQUFPO09BQStLLElBQUUsYUFBckgsUUFBTTt3QkFBNkcsSUFBRTs7V0FBRixJQUFFOzswQkFBRixJQUFFOzs7O1NBQXlFLEdBQUM7O3dCQUFELEdBQUM7Ozs7Ozs7OztXQUEwRSxHQUFDOzRCQUFELEdBQUM7O2VBQUQsR0FBQzt3REFBRSxzQkFBc0I7MEJBQXpCLEdBQUM7Ozs7V0FBcUMsU0FBTzt1Q0FBUCxTQUFPOzs7Ozs7Ozs7Ozs7a0JBaEoxYixpQkFBaUI7a0NBZ0oyZ0IsaUJBQWlCLEVBQUMsT0FBTzs7O3NCQUFJLEtBQUs7Z0JBQUUsS0FBRztnQkFBaUMsTUFBSSxXQUF4QyxLQUFHO2lDQUFpQyxNQUFJOztvQkFBSixNQUFJOztnQkFBbUMsUUFBTSxhQUE3QyxNQUFJO2tDQUFtQyxRQUFNOztvQkFBTixRQUFNOztnQkFBNEMsTUFBSSxhQUF0RCxRQUFNO2dCQUF5RSxHQUFDLFdBQTlCLE1BQUk7a0NBQXlCLEdBQUM7O29CQUFELEdBQUM7b0JBQTlCLE1BQUk7O2dCQUFvRyxPQUFLLGFBQTdHLE1BQUk7a0NBQW9HLE9BQUs7O29CQUFMLE9BQUs7b0JBQTFPLEtBQUc7Ozs7Ozs7Ozs7O3FCQUFWLEtBQUs7K0JBQTRDLFNBQVMsT0FBQyxLQUFLLEVBQUMsT0FBTzs7OztxQkFBeEUsS0FBSzsrQkFBcUYsVUFBVSxPQUFDLEtBQUssRUFBQyxLQUFLOzs7O3FCQUFoSCxLQUFLO3FCQWhKOWpCLGlCQUFpQjsrQkFnSjRzQixLQUFLLE9BQUMsS0FBSyxFQUFDLFlBQVksVUFBRSxpQkFBaUIsRUFBQyxjQUFjOzs7O3FCQUE5TixLQUFLOytCQUFzUCxTQUFTLE9BQUMsS0FBSyxFQUFDLFdBQVc7Ozs7OytCQUEvUSxLQUFHOzs7Ozs7Ozs7Ozs7O2FBQTJTLEdBQUM7OzRCQUFELEdBQUM7Ozs7OztpQkFoSi8yQixpQkFBaUI7aUNBZ0prZSxpQkFBaUIsRUFBQyxPQUFPLEVBQUUsTUFBTTs7Ozs7Ozs7OztlQUFqRyxTQUFPOzBCQUFQLFNBQU87Ozs7Ozs7bUNBQWhGLHVCQUF1QixHQUFHLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Z0NBQTlHLHVCQUF1QixHQUFHLFNBQVM7Ozs7Ozs7OztXQUEvUCxTQUFPO1dBQXRELEtBQUc7OztVQWhKckIsaUJBQWlCOzBCQWdKME8saUJBQWlCLEVBQUMsS0FBSzs7O29CQUE5SSxRQUFNLGNBQTZCLGlCQUFpQixFQUFDLElBQUk7c0JBQTNLLEtBQUc7Ozs7O2NBQXRCLGlCQUFpQjs7Ozs7Ozs7Ozs7O1FBRXJCLFNBQVM7O1dBQUUsZ0JBQWdCOzs7O2lCQUFHLGVBQWU7Ozs7V0FBVyxpQkFBaUI7OztpQkFBZ0IsUUFBUSxDQUFDLE1BQU07b0JBQW9CLFFBQVEsQ0FBQyxLQUFLOzs7Ozs7Ozs7S0FDMUksSUFBSTt1QkFBSixJQUFJOzs7O09BQzhCLFNBQU87T0FBdUMsS0FBRyxxQkFBakQsU0FBTztPQUE0QyxRQUFNLFdBQVgsS0FBRzt5QkFBRSxRQUFNOztXQUFOLFFBQU07O09BQTJFLEdBQUMsYUFBbEYsUUFBTTt5QkFBMkUsR0FBQzs7V0FBRCxHQUFDO1dBQXZGLEtBQUc7O09BQWdQLFFBQU0sYUFBelAsS0FBRzs7V0FBakQsU0FBTzs7O3dCQUFvRCxjQUFjLEtBQUMsOEJBQThCLEdBQUMsZ0JBQWdCOzt3QkFBYyxjQUFjO09BQUMsdURBQXVEO09BQUMsdUVBQXVFOzs7b0JBQVksUUFBTTtZQUFXLGlCQUFpQjs7O3NCQUFuVSxTQUFPOzs7Ozt3QkFBckMsZ0JBQWdCLElBQUcsU0FBUzs7Ozs7Ozs7Ozs7Ozs7T0FFOUIsU0FBTztPQUFzQixLQUFHLFdBQWhDLFNBQU87T0FBMkIsR0FBQyxXQUFOLEtBQUc7eUJBQUUsR0FBQzs7V0FBRCxHQUFDOztPQUFtRSxFQUFFLGFBQXRFLEdBQUM7eUJBQW1FLEVBQUU7O1dBQUYsRUFBRTs7V0FBM0UsS0FBRztXQUFoQyxTQUFPOzsyQkFBUCxTQUFPOzs7VUFDUCxZQUFZOzthQUFVLGVBQWU7Ozs7OzthQUFtQyxlQUFlOzs7O1VBQUcsUUFBTTtVQUE2RixRQUFNLHFCQUF6RyxRQUFNOzRCQUE2RixRQUFNOzs7Y0FBTixRQUFNOztVQUF3RCxHQUFDLGFBQS9ELFFBQU07NEJBQXdELEdBQUM7O2NBQUQsR0FBQztjQUFsSyxRQUFNOzs7Ozs7O2VBbkk5RixJQUFJOytCQW1Jd1AsSUFBSSxFQUFDLGdCQUFnQixJQUFFLENBQUM7Ozs7cUJBbklwUixJQUFJLG1CQW1JK0wsS0FBSyxPQUFDLElBQUksRUFBQyxVQUFVOzs7O3VCQUFoSSxRQUFNLFFBQXFDLFFBQVEsQ0FBQyxjQUFjO3lCQUFsRSxRQUFNOzs7Ozs7Ozs7Ozs7T0FDaEcsU0FBTztPQUF1QixLQUFHLFdBQWpDLFNBQU87T0FBd0ksUUFBTSxxQkFBdkgsS0FBRzs7V0FBSCxLQUFHOzsyQkFBSCxLQUFHOzs7VUFBaU0sWUFBWTs7YUFBVSxjQUFjOzs7Ozs7YUFBOEIsY0FBYzs7Ozs7Ozs7O1lBQTJCLEtBQUc7WUFBbUQsS0FBRyxXQUF6RCxLQUFHOzhCQUFtRCxLQUFHOzs7OENBQXVELFdBQVcsdUJBQUksS0FBSztjQUFRLFFBQU07Ozs7OzRCQUFOLFFBQU07NEJBQU4sUUFBTSxrQ0FBb0osS0FBSyxRQUFHLGNBQWMsS0FBQyxNQUFNLEdBQUMsU0FBUztvQ0FBak0sUUFBTSxvREFBZSxLQUFLLFFBQUcsY0FBYzs7Ozs7bUJBaElsZ0IsV0FBVzttQkFnSStiLEtBQUs7MkNBQStFLEtBQUssR0FBQyxDQUFDLGFBQU8sV0FBVyxFQUFDLE1BQU0sS0FBSyxhQUFhLE9BQUMsS0FBSyxHQUFFLE9BQU87Ozs7OzJCQUF4SSxRQUFNLGNBQTJNLGNBQWMsRUFBQyxLQUFLOzZCQUFyTyxRQUFNOzs7Ozs7OztZQUFrUCxNQUFJOzhCQUFKLE1BQUk7O2dCQUFKLE1BQUk7Z0JBQWxWLEtBQUc7O1lBQXVZLE1BQUcsYUFBN1ksS0FBRztZQUFxakIsTUFBRyxXQUFqTCxNQUFHOzs7c0JBQTJLLE1BQUcsaUJBQW9HLFdBQVcsdUJBQUksS0FBSztjQUFRLFFBQU07O2NBQTJILE1BQUksV0FBckksUUFBTTtnQ0FBMkgsTUFBSTs7a0JBQUosTUFBSTs7Y0FBa0QsUUFBTSxhQUE1RCxNQUFJO2dDQUFrRCxRQUFNOztrQkFBTixRQUFNOztjQUF5QyxHQUFDLGFBQWhELFFBQU07Z0NBQXlDLEdBQUM7O2tCQUFELEdBQUM7O2tCQUF2TyxRQUFNOzs7O29DQUFOLFFBQU0scURBQWtFLEtBQUssUUFBRyxjQUFjOzs7Ozs7O21CQUEzRyxLQUFLO29EQUE2QyxTQUFTLE9BQUMsS0FBSzs7O3lCQUFqRSxLQUFLLG1CQUFvSyxXQUFXLE9BQUMsS0FBSzs7O21CQUExTCxLQUFLOzZCQUF1TSxhQUFhLE9BQUMsS0FBSyxHQUFFLE9BQU87Ozs7bUJBQXhPLEtBQUs7NkJBQWlQLGFBQWEsT0FBQyxLQUFLLEdBQUUsWUFBWTs7Ozs7MkJBQTFRLFFBQU0sUUFBd0csU0FBUyxPQUFDLEtBQUs7NkJBQTdILFFBQU07Ozs7Ozs7O2dCQUF6SSxNQUFHO2dCQUFqTCxNQUFHO2dCQUFuYyxLQUFHOzs7c0NBQXVZLGNBQWMsSUFBQyxDQUFDO2dCQWhJcnVCLFdBQVc7Z0NBZ0krdEIsV0FBVyxFQUFDLE1BQU07OztxQkFBNkwsTUFBRyxxQ0FBa0UsY0FBYzs7OzhCQUFqUSxNQUFHLEdBQWdELEtBQUssV0FBRyxtQkFBbUIsRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPOzRCQUF2RyxNQUFHLEdBQW9ILEtBQUssS0FBRSxZQUFZLENBQUMsS0FBSyxRQUFDLFdBQVcsRUFBQyxNQUFNLEVBQUMsTUFBTTsyQkFBMW1CLEtBQUc7Ozs7WUFBK2lDLE1BQUc7OzJCQUFILE1BQUc7Ozs7OztnQkFoSWg0QyxXQUFXO2dDQWdJNFMsV0FBVyxFQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7V0FBM1UsU0FBTzs7T0FDUCxTQUFPLGFBRFAsU0FBTztPQUN1QixNQUFHLFdBQWpDLFNBQU87T0FBb0ksUUFBTSxxQkFBbkgsTUFBRzs7V0FBSCxNQUFHOztPQUFrTSxNQUFHLGFBQXhNLE1BQUc7Ozs7S0FBa00sTUFBRzs7O1lBcEk5TCxXQUFXOzRCQW9JZ04sV0FBVyxFQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQzs7O2dCQUFLLElBQUk7VUFBRSxRQUFNO1VBQThFLE1BQUcsV0FBdkYsUUFBTTtVQUFtRixRQUFNLFdBQVgsTUFBRzs0QkFBRSxRQUFNOztjQUFOLFFBQU07O1VBQTJCLE1BQUksYUFBckMsUUFBTTs0QkFBMkIsTUFBSTs7Y0FBSixNQUFJO2NBQTFDLE1BQUc7O1VBQTJHLEdBQUMsYUFBL0csTUFBRzs0QkFBMkcsR0FBQzs7Y0FBRCxHQUFDO2NBQW5NLFFBQU07Ozs7Ozs7OztxQkFBWixJQUFJLG1CQUFtRyxRQUFRLE9BQUMsSUFBSTtxQkFBcEgsSUFBSSxtQkFBa0ksUUFBUSxPQUFDLElBQUk7OztlQUFuSixJQUFJO3lCQUFxSixTQUFTLENBQUMsZUFBZSxPQUFDLElBQUk7OztxQkFBdkwsSUFBSSxtQkFBeU0sS0FBSyxPQUFDLElBQUksRUFBQyxNQUFNOzs7O3VCQUF4TixRQUFNLFFBQWdDLENBQUM7T0FBQSxRQUFRLENBQUMsY0FBYztPQUFFLFNBQVMsT0FBQyxJQUFJO01BQUUsQ0FBQzs7eUJBQWpGLFFBQU07OztVQUF5TyxHQUFDOzt5QkFBRCxHQUFDOzs7Ozs7Ozs7V0FBaFQsTUFBRztXQUF0TyxTQUFPOztPQUNQLFFBQU0sYUFETixTQUFPOzs7Ozs7Ozs7d0JBdEtvRixhQUFhO3NCQW1LL0MsVUFBVSxDQUFDLGFBQWEsSUFBRSxXQUFXOzs7c0JBQVksUUFBUTs7OztvQkFFNkIsUUFBTSxRQUFpQyxRQUFRLENBQUMsU0FBUztvQkFDN0QsUUFBTSxRQUFpQyxRQUFRLENBQUMsY0FBYztvQkFDek0sUUFBTSxFQUFtQyxTQUFTOzs7Ozs7Ozs7OztTQUVsRCxTQUFPO1NBQTJKLEtBQUsscUJBQXZLLFNBQU87U0FBeUwsU0FBTSxXQUFwQyxLQUFLO1NBQXdGLEtBQUssYUFBcEUsU0FBTTs7NkJBQXlELEtBQUs7O1NBQW9ILFNBQU0sYUFBL0gsS0FBSzs7YUFBbEcsS0FBSzthQUF2SyxTQUFPOzs2QkFBUCxTQUFPOzs7WUFDUCxZQUFZOztlQUFVLGVBQWU7Ozs7OztlQUFtQyxlQUFlOzs7O1lBQUcsU0FBTztZQUFxQixNQUFHLFdBQS9CLFNBQU87WUFBZ0QsTUFBRyxXQUE5QixNQUFHO1lBQXdELFFBQU0scUJBQXRDLE1BQUc7OEJBQTZCLFFBQU07O2dCQUFOLFFBQU07Z0JBQXRDLE1BQUc7O1lBQTRFLE1BQUcsYUFBbEYsTUFBRztZQUEwRyxRQUFNLHFCQUFwQyxNQUFHOzhCQUEyQixRQUFNOztnQkFBTixRQUFNO2dCQUFwQyxNQUFHOztZQUE0RSxNQUFHLGFBQWxGLE1BQUc7WUFBeUcsUUFBTSxxQkFBbkMsTUFBRzs4QkFBMEIsUUFBTTs7Z0JBQU4sUUFBTTtnQkFBbkMsTUFBRztnQkFBNUwsTUFBRzs7WUFBMFEsTUFBRyxhQUFoUixNQUFHOzs7c0JBQTBRLE1BQUcsWUFBMEIsS0FBSyxFQUFDLEtBQUssRUFBQyxLQUFLLEVBQUMsS0FBSyxFQUFDLEtBQUssRUFBQyxLQUFLLEVBQUMsS0FBSyx1QkFBSyxDQUFDO2NBQUUsTUFBSTtnQ0FBSixNQUFJOztrQkFBSixNQUFJO3NEQUFFLENBQUM7NkJBQVAsTUFBSTs7Ozs7Ozs7Z0JBQWxGLE1BQUc7O1lBQXdHLE1BQUcsYUFBOUcsTUFBRzs4QkFBd0csTUFBRzs7Ozs7OztpQkF6STNhLFFBQVE7MkJBeUk0YixLQUFLLE9BQUMsUUFBUSxFQUFDLE9BQU87OztxQkFBSyxDQUFDO2VBQUUsTUFBSTs7OEJBQUosTUFBSTs7Ozs7Ozs7Ozs7OytDQXpJdGUsUUFBUSx5QkF5SW9mLFFBQVEsRUFBQyxJQUFJLHdCQUFJLENBQUM7Y0FBRSxTQUFNOztnQ0FBTixTQUFNOztrQkFBTixTQUFNOzs7bUNBQU4sU0FBTSxZQUFULENBQUMsa0NBQXNGLENBQUMsRUFBQyxTQUFTOzBCQUExRSxDQUFDLEVBQUMsTUFBTTs0Q0FBa0IsV0FBVyxTQUFHLENBQUMsRUFBQyxHQUFHOzs7V0FBbEUsU0FBTSxtQkFBVCxDQUFDLHlCQUErRyxDQUFDLEVBQUMsTUFBTTtzQ0FBeEgsQ0FBQyx5QkFBdUosQ0FBQyxFQUFDLEdBQUc7OzsyQkFBMUosU0FBTSxRQUErSCxVQUFVLE9BQUMsQ0FBQzs2QkFBakosU0FBTTs7Ozs7Ozs7Z0JBQTlHLE1BQUc7O1lBQXVSLE1BQUcsYUFBN1IsTUFBRztZQUFtVSxNQUFHLHFCQUEvQyxNQUFHOzs7c0JBQXlDLE1BQUcsWUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyx1QkFBSyxDQUFDO2NBQUUsR0FBQzs7OENBQUQsR0FBQyxjQUFpQixDQUFDOzZCQUFuQixHQUFDOzs7Ozs7OztnQkFBOUIsTUFBRzs7Z0JBQS9DLE1BQUc7Z0JBQWpyQixTQUFPOzs7Ozs7O2lCQXpJL0YsSUFBSTtpQ0F5SWdRLElBQUksRUFBQyxnQkFBZ0IsSUFBRSxDQUFDOzs7Ozs7dUJBekk1UixJQUFJLG1CQXlJbUwsS0FBSyxPQUFDLElBQUksRUFBQyxVQUFVOzs7aUJBekk1TSxJQUFJOzJCQXlJOFUsS0FBSyxPQUFDLElBQUksRUFBQyxZQUFZOzs7OzsyQkFBalIsU0FBTzs7Ozs7Ozs7Ozs7O1NBQ2pHLFVBQU87U0FBMkMsTUFBRyxXQUFyRCxVQUFPO1NBQXNFLFNBQU0sV0FBakMsTUFBRzs7U0FBeUgsU0FBTSxhQUF2RyxTQUFNOzsyQkFBMkYsU0FBTTs7YUFBTixTQUFNO2FBQWxJLE1BQUc7OzZCQUFILE1BQUc7Ozs7V0FBeVQsTUFBRzs7MEJBQUgsTUFBRzs7Ozs7Ozs7O2FBQXlHLE1BQUc7YUFBd0QsU0FBTSxxQkFBakUsTUFBRzs7aUJBQUgsTUFBRzswQkFBd0QsU0FBTSxFQUFXLE9BQU87NEJBQW5GLE1BQUc7Ozs7O2FBQWtILE1BQUc7YUFBMkIsR0FBQyxXQUEvQixNQUFHOytCQUEyQixHQUFDOztpQkFBRCxHQUFDOzthQUE0SSxJQUFFLGFBQS9JLEdBQUM7K0JBQTRJLElBQUU7O2lCQUFGLElBQUU7aUJBQTdLLE1BQUc7O2FBQWdYLE1BQUcsYUFBdFgsTUFBRzs7OztXQUFnWCxNQUFHOzt1QkFBNkIsWUFBWTs7c0JBQUksSUFBSTtnQkFBRSxPQUFPOztnQkFBNEQsU0FBTSxXQUF6RSxPQUFPO2dCQUFpSixNQUFHLFdBQXhGLFNBQU07Z0JBQW9GLFFBQU0sV0FBWCxNQUFHO2tDQUFFLFFBQU07O29CQUFOLFFBQU07O2dCQUEyQixNQUFJLGFBQXJDLFFBQU07a0NBQTJCLE1BQUk7O29CQUFKLE1BQUk7b0JBQTFDLE1BQUc7O2dCQUEyRyxNQUFHLGFBQWpILE1BQUc7Z0JBQWtJLEdBQUMsV0FBeEIsTUFBRztrQ0FBb0IsR0FBQzs7b0JBQUQsR0FBQzs7Z0JBQTRCLE9BQUksYUFBakMsR0FBQzs7O29CQUF4QixNQUFHO29CQUF0TSxTQUFNOztvQ0FBTixTQUFNOzs7O2tCQUE4VixNQUFHO2tCQUFzQixTQUFNLFdBQS9CLE1BQUc7a0JBQXNGLFNBQU0sYUFBdEUsU0FBTTs7c0JBQS9CLE1BQUc7K0JBQXNCLFNBQU0sUUFBZSxTQUFTLE9BQUMsSUFBSTsrQkFBNkIsU0FBTSxjQUE4QixRQUFRLFFBQUMsSUFBSTtpQ0FBMUksTUFBRzs7Ozs7O3NCQXpLbHhDLFVBQVU7c0JBeUt3MUIsSUFBSTtzREFBbVosVUFBVSxTQUFHLElBQUksRUFBQyxFQUFFOzs7Ozs7Ozs7O29CQUFyYSxPQUFPOzs7O3NDQUFQLE9BQU8sdUVBQWlCLFVBQVUsU0FBRyxJQUFJLEVBQUMsRUFBRTs7OztzQ0FBOFEsT0FBSSxtRUFBYSxVQUFVLFNBQUcsSUFBSSxFQUFDLEVBQUU7OzsyQkFBclcsSUFBSSxtQkFBdUssUUFBUSxPQUFDLElBQUk7MkJBQXhMLElBQUksbUJBQXNNLFFBQVEsT0FBQyxJQUFJOzs7cUJBQXZOLElBQUk7K0JBQXlOLFNBQVMsQ0FBQyxlQUFlLE9BQUMsSUFBSTs7OzJCQUEzUCxJQUFJLG1CQUFvUyxLQUFLLE9BQUMsSUFBSSxFQUFDLE1BQU07Ozs7NkJBQWhQLFNBQU0sY0FBZ0MsVUFBVSx3QkFBQyxVQUFVLFNBQUcsSUFBSSxFQUFDLEVBQUUsSUFBQyxJQUFJLFNBQUMsSUFBSSxFQUFDLEVBQUU7K0JBQXJKLE9BQU87OztnQkFBd2xCLElBQUM7OytCQUFELElBQUM7Ozs7Ozs7OztpQkFBdHBCLE1BQUc7O2lDQUFILE1BQUc7Ozs7ZUFBaXZCLFNBQU07aUNBQU4sU0FBTTs7bUJBQU4sU0FBTTs7O2tCQXpLM2pELE9BQU87a0JBc0NuRCxXQUFXOztrQ0FtSStvRCxPQUFPO2VBQUMsY0FBYztpQ0FBYSxXQUFXLEVBQUMsTUFBTTs7OzRCQUE5RyxTQUFNLGNBQWdDLE9BQU8sU0FBRSxPQUFPOzhCQUF0RCxTQUFNOzs7Ozs7bUJBbkl2bUQsV0FBVzttQ0FtSWdrRCxXQUFXLEVBQUMsTUFBTSxHQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O2tCQXpLeG1ELFdBQVc7a0JBc0NyRixRQUFROzhCQXhDaUYsYUFBYTs7a0RBMks0aEIsV0FBVyxHQUFHLFFBQVE7ZUFBQyxpQkFBaUI7cUJBQUMsUUFBUTt5QkFBSSxRQUFRLEVBQUMsR0FBRyxJQUFJLFVBQVUsQ0FBQyxhQUFhO2dCQUFJLGVBQWU7Ozs7a0JBekt4cUIsV0FBVztrQkFnQy9DLFdBQVc7a0JBTWpELFFBQVE7O2tEQW1Jb3ZCLFdBQVcsR0FBRyxRQUFRO3dCQUFJLFdBQVcsRUFBQyxNQUFNO3FCQUF1QixRQUFRO3lCQUFJLFFBQVEsRUFBQyxnQkFBZ0IsbUJBQW1CLEtBQUssT0FBQyxRQUFRLEVBQUMsVUFBVTtnQkFBSSwrQkFBK0I7Ozs7Ozs7Ozs7OztxQ0FBcmdCLFdBQVcsR0FBRyxLQUFLLDJCQUFFLFNBQVMsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2tDQUF0SixXQUFXLEdBQUcsS0FBSywyQkFBRSxTQUFTLEdBQUcsU0FBUzs7Ozs7Ozs7O2FBQTVXLFVBQU87O1NBQ1AsU0FBTSxhQUROLFVBQU87MkJBQ1AsU0FBTTs7YUFBTixTQUFNOztTQUFxTSxTQUFNLGFBQWpOLFNBQU07Ozs7bUJBSHlQLEtBQUssRUFBcUIsYUFBYTt1QkFBdkMsS0FBSzsrQkFFdkwsU0FBTSwwREFBZSxXQUFXLEdBQUcsUUFBUTsrQkFBc0QsU0FBTSwwREFBZSxXQUFXLEdBQUcsS0FBSzs7O2NBbklwTixRQUFROzhCQW1JZ1AsUUFBUSxhQUFJLFFBQVEsRUFBQyxHQUFHLGNBQVksZUFBZTs7O09BQzdTLFNBQU0sbUJBQWdDLFFBQVEsV0FBRSxhQUFhOztpQ0FBNkIsYUFBYTtVQUFDLHFCQUFxQjtnQkFBQyxRQUFRO1dBQUMsdUJBQXVCO1dBQUMsaUNBQWlDOzt3QkFINkcsaUJBQWlCOzs7c0JBQTlILFNBQU0sUUFBNkIsV0FBVyxFQUFFLENBQUM7dUJBQWMsS0FBSyxHQUF5RSxDQUFDLEtBQUUsYUFBYSxHQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSztzQkFBSyxTQUFNLFFBQTZCLFdBQVcsQ0FBQyxDQUFDO3NCQUUzVixTQUFNLGNBQXFELFdBQVcsRUFBQyxRQUFRO3NCQUFrQixTQUFNLGNBQWtELFdBQVcsRUFBQyxLQUFLO3NCQUN2UCxTQUFNLEVBQW1FLGNBQWM7c0JBQW9ILFNBQU0sY0FBb0MsaUJBQWlCLEVBQUMsSUFBSTs7Ozs7Ozs7Ozs7V0FFeEYsTUFBRzs7O3FCQUFILE1BQUcsWUFBK0IsS0FBSyxFQUFDLFVBQVUsRUFBQyxXQUFXLEVBQUMsVUFBVSx1QkFBSyxNQUFNO2FBQUUsU0FBTTs7K0JBQU4sU0FBTTs7aUJBQU4sU0FBTTs7O2tDQUFOLFNBQU0sMERBQWUsV0FBVyxHQUFHLE1BQU07OEJBQTJELE1BQU07OzswQkFBMUcsU0FBTSxRQUFtRCxDQUFDO2dCQUFBLFdBQVcsRUFBQyxNQUFNO2dCQUFDLGdCQUFnQixFQUFDLENBQUM7U0FBQyxDQUFDOzs0QkFBakcsU0FBTTs7Ozs7Ozs7ZUFBNUYsTUFBRzs7V0FBcU4sTUFBRyxhQUEzTixNQUFHO1dBQXdSLFNBQU0scUJBQXpFLE1BQUc7O1dBQXVLLFNBQU0sYUFBN0csU0FBTTs7O2VBQXpFLE1BQUc7OytCQUFILE1BQUc7OztjQUErUixZQUFZOztpQkFBVSxjQUFjOzs7Ozs7aUJBQXlCLGNBQWM7Ozs7Ozs7OztnQkFBK0IsTUFBRztnQkFBbUYsTUFBRyxXQUF6RixNQUFHO2tDQUFtRixNQUFHOzs7a0RBQXVELGVBQWUsdUJBQUksS0FBSztrQkFBUSxTQUFNOzs7OztnQ0FBTixTQUFNO2dDQUFOLFNBQU0sa0NBQTBKLEtBQUssUUFBRyxnQkFBZ0IsS0FBQyxNQUFNLEdBQUMsU0FBUzt5Q0FBek0sU0FBTSxxREFBZSxLQUFLLFFBQUcsZ0JBQWdCOzs7Ozt1QkExSWwvQixlQUFlO3VCQTBJeTZCLEtBQUs7K0NBQWlGLEtBQUssR0FBQyxDQUFDLGFBQU8sZUFBZSxFQUFDLE1BQU0sS0FBSyxhQUFhLE9BQUMsS0FBSyxHQUFFLE9BQU87Ozs7OytCQUE5SSxTQUFNLGNBQW1OLGdCQUFnQixFQUFDLEtBQUs7aUNBQS9PLFNBQU07Ozs7Ozs7O2dCQUE0UCxPQUFJO2tDQUFKLE9BQUk7O29CQUFKLE9BQUk7b0JBQWhXLE1BQUc7O2dCQUEyWixNQUFHLGFBQWphLE1BQUc7Z0JBQTZrQixNQUFHLFdBQXJMLE1BQUc7OzswQkFBK0ssTUFBRyxpQkFBc0csZUFBZSx1QkFBSSxLQUFLO2tCQUFRLFNBQU07O2tCQUEwTyxPQUFJLFdBQXBQLFNBQU07b0NBQTBPLE9BQUk7O3NCQUFKLE9BQUk7O3NDQUFKLE9BQUk7Ozs7b0JBQXdFLE9BQUk7c0NBQUosT0FBSTs7d0JBQUosT0FBSTs7OzhCQUE3VSxLQUFLLG1CQUFrVyxTQUFTLE9BQUMsS0FBSzs7O21DQUE3QyxPQUFJOzs7Ozs0QkFBN1UsS0FBSyxtQkFBa1QsU0FBUyxPQUFDLEtBQUs7Ozs7Ozs7OztrQkFBK0QsU0FBTTtvQ0FBTixTQUFNOztzQkFBTixTQUFNOztrQkFBZ0MsR0FBQyxhQUF2QyxTQUFNO29DQUFnQyxHQUFDOztzQkFBRCxHQUFDOztzQkFBL1osU0FBTTs7Ozt5Q0FBTixTQUFNOzs7Ozs7O3VCQUFuQixLQUFLO3dEQUE2QyxTQUFTLE9BQUMsS0FBSzs7OztvQ0FBNEIsWUFBWSxPQUFDLEtBQUs7MEJBQWtCLFlBQVksT0FBQyxLQUFLLDRCQUFHLGVBQWUsR0FBRyxTQUFTOzBDQUFpQixLQUFLLFFBQUcsZ0JBQWdCOzs7NkJBQTFOLEtBQUssbUJBQW1SLFdBQVcsT0FBQyxLQUFLOzZCQUF6UyxLQUFLLG1CQUF3WSxZQUFZLE9BQUMsS0FBSzs7O3VCQUEvWixLQUFLO2lDQUF5YSxhQUFhLE9BQUMsS0FBSyxHQUFFLFlBQVk7Ozs7OytCQUFsYyxTQUFNLFFBQXVOLFNBQVMsT0FBQyxLQUFLO2lDQUE1TyxTQUFNOzs7Ozs7OztvQkFBL0ksTUFBRztvQkFBckwsTUFBRztvQkFBdmYsTUFBRzs7OzZCQUFILE1BQUcseUJBQTJELFdBQVc7OzBDQUErVyxnQkFBZ0IsSUFBQyxDQUFDO29CQTFJL3RDLGVBQWU7b0NBMElxdEMsZUFBZSxFQUFDLE1BQU07Ozt5QkFBaU0sTUFBRyxxQ0FBa0UsZ0JBQWdCOzs7a0NBQXZRLE1BQUcsR0FBZ0QsS0FBSyxXQUFHLG1CQUFtQixFQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU87Z0NBQXZHLE1BQUcsR0FBb0gsS0FBSyxLQUFFLFlBQVksQ0FBQyxLQUFLLFFBQUMsZUFBZSxFQUFDLE1BQU0sRUFBQyxNQUFNOytCQUFscUIsTUFBRzs7OztnQkFBcXlDLE1BQUc7Z0JBQW9DLElBQUUscUJBQXpDLE1BQUc7a0NBQW9DLElBQUU7O29CQUFGLElBQUU7O29CQUF6QyxNQUFHOzs7O29CQTNLdjNELFdBQVc7b0NBMkt1NUQsV0FBVyxFQUFDLFdBQVc7Ozs7K0JBQXJFLE1BQUc7Ozs7OztvQkExSWhrRSxlQUFlO29DQTBJOHVCLGVBQWUsRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBdlUsU0FBTSwwREFBZSxlQUFlLEdBQUcsTUFBTTtpQ0FBMEQsU0FBTSwyREFBZSxlQUFlLEdBQUcsU0FBUzs7O3dCQUF2SixTQUFNLFFBQXVELGtCQUFrQixDQUFDLE1BQU07d0JBQWlCLFNBQU0sUUFBMEQsa0JBQWtCLENBQUMsU0FBUzs7Ozs7Ozs7O2NBRWpwQixlQUFlOztpQkFBRSxRQUFROzs7O3VCQUFHLGFBQWE7Ozs7dUJBQUcsU0FBUzs7Ozt1QkFBRyxVQUFVOzs7O3VCQUFHLFlBQVk7Ozs7aUJBQUcsYUFBYTs7O3FCQUFjLFFBQVE7c0JBQWUsU0FBUzsyQkFBb0IsY0FBYztvQkFBYSxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O21DQUg5TCxJQUFJLEdBQUcsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQUxoQixJQUFJLEdBQUcsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs4QkFOMUIsSUFBSSxHQUFHLE1BQU07Ozs7Ozs7OztTQUZqQixJQUFJOzt5QkFBSixJQUFJOzs7UUFtQkosU0FBUzs7aUJBQUUsSUFBSTs7O2VBQWMsUUFBUTs7Ozs7Ozs7Ozs7OztPQUluQyxNQUFHO09BQ0QsVUFBTyxXQURULE1BQUc7T0FFQyxTQUFNLFdBRFIsVUFBTztPQUlMLFVBQU8sYUFIUCxTQUFNO21DQUdOLFVBQU87Ozs7U0FBbVAsSUFBQzs7d0JBQUQsSUFBQzs7Ozs7Ozs7O1dBQW9FLE1BQUc7V0FBMkIsT0FBSSxXQUFsQyxNQUFHOzZCQUEyQixPQUFJOztlQUFKLE9BQUk7O1dBQXNCLFNBQU0sYUFBaEMsT0FBSTs7ZUFBbEMsTUFBRzt5REFBaUMsV0FBVzt3QkFBUyxTQUFNLEVBQVcsaUJBQWlCOzBCQUExRixNQUFHOzs7Ozs7Ozs7YUFBaUosTUFBRzthQUF5RCxTQUFNLHFCQUFsRSxNQUFHOytCQUF5RCxTQUFNOztpQkFBTixTQUFNOzthQUE2QyxTQUFNLGFBQXpELFNBQU07OztpQkFBbEUsTUFBRzs7O2dCQXpLdmQsYUFBYTtnQ0F5SzJnQixhQUFhLEVBQUMsTUFBTSxDQUFDLFdBQVc7OzswQkFBVyxTQUFNLEVBQStCLGNBQWM7NEJBQWxLLE1BQUc7Ozs7O2FBQStiLFNBQU07OzBCQUFOLFNBQU0sRUFBZ0MsY0FBYzs7Ozs7Ozs7O2tCQXpLMThCLGFBQWE7a0NBeUtpYixhQUFhLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0FBMUssWUFBWSxHQUFHLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Z0NBQTdGLFlBQVksR0FBRyxTQUFTOzs7Ozs7Ozs7V0FBeFAsVUFBTzs7T0FDUCxVQUFPLGFBRFAsVUFBTzttQ0FDUCxVQUFPOzs7O1NBQXFQLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUFrRixNQUFHO1dBQTJCLE9BQUksV0FBbEMsTUFBRzs2QkFBMkIsT0FBSTs7ZUFBSixPQUFJOztXQUEwQixTQUFNLGFBQXBDLE9BQUk7O2VBQWxDLE1BQUc7eURBQWlDLGVBQWU7d0JBQVMsU0FBTSxFQUFXLGVBQWU7MEJBQTVGLE1BQUc7Ozs7Ozs7Ozs7Ozs7K0NBQXVKLFdBQVcsdUJBQUksVUFBVTtlQUFFLFNBQU87O2VBQWdKLE1BQUcscUJBQTFKLFNBQU87ZUFBcUosU0FBTSxXQUFYLE1BQUc7aUNBQUUsU0FBTTtlQUFzQyxTQUFNO2VBQXFILFNBQU0sYUFBakksU0FBTTtpQ0FBcUgsU0FBTTs7bUJBQU4sU0FBTTttQkFBN0ssU0FBTTs7ZUFBMlgsT0FBSyxhQUF0WSxTQUFNO2lDQUEyWCxPQUFLOzttQkFBTCxPQUFLOztlQUFtSSxPQUFLLGFBQTdJLE9BQUs7aUNBQW1JLE9BQUs7O21CQUFMLE9BQUs7O21DQUFMLE9BQUs7Ozs7aUJBQWlMLE9BQUs7bUNBQUwsT0FBSzs7cUJBQUwsT0FBSzs7OztxQkFBNTJCLFVBQVU7K0JBQW0zQixhQUFhLE9BQUMsVUFBVSxFQUFDLGdCQUFnQjs7OztnQ0FBL0QsT0FBSzs7Ozs7O3FCQUE1MkIsVUFBVTtxQ0FBZzBCLFVBQVUsRUFBQyxnQkFBZ0I7Ozs7Ozs7Ozs7bUJBQWxzQixNQUFHOztlQUFzeEIsTUFBRyxhQUE1eEIsTUFBRztlQUEyeEIsR0FBQyxXQUFOLE1BQUc7aUNBQUUsR0FBQzs7bUJBQUQsR0FBQzttQkFBTixNQUFHOzttQ0FBSCxNQUFHOzttQ0FBaUQsZUFBZSw0QkFBZSxxQkFBcUIsT0FBQyxVQUFVOztlQUFLLFNBQU07O21CQUE3aUMsU0FBTzs7OztzQ0FBUCxTQUFPO3FEQUFtRixVQUFVLEVBQUMsaUJBQWlCLEVBQUUsTUFBTSxFQUFHLEtBQUs7Ozs2QkFBdEksU0FBTztvQkFBbkIsVUFBVTtrREFBc0QsVUFBVSxFQUFDLEVBQUU7Ozt3Q0FBN0UsVUFBVSx5QkFBd0wsVUFBVSxFQUFDLEtBQUs7OzZCQUFFLFNBQU07b0JBQTFOLFVBQVU7NENBQXFTLFVBQVUsRUFBQyxLQUFLOzs7NkJBQWdCLFNBQU07b0JBQXJWLFVBQVU7OENBQWthLFVBQVUsRUFBQyxLQUFLOzs7YUFBN0csU0FBTSxrQ0FBcUgsb0JBQW9CLEdBQUcsSUFBSTs7O29CQWpMcjFCLG9CQUFvQjtvQkFpTDRWLFVBQVU7b0RBQThkLG9CQUFvQixTQUFHLFVBQVUsRUFBQyxFQUFFLElBQUMsR0FBRyxHQUFDLElBQUk7Ozs7b0JBQXJoQixVQUFVO29EQUFzaUIsVUFBVSxFQUFDLFVBQVUsRUFBRyxzQkFBc0IsSUFBQyxzQkFBc0IsR0FBQyxpQkFBaUI7Ozs7Ozs7O29CQUF2b0IsVUFBVTs4QkFBa29CLGVBQWUsT0FBQyxVQUFVOzs7O29CQUF0cUIsVUFBVTs7b0RBQThxQixVQUFVLEVBQUMsaUJBQWlCLEVBQUUsTUFBTSxFQUFHLFdBQVc7aUJBQUMsV0FBVzt1Q0FBQyxVQUFVLEVBQUMsTUFBTSxFQUFHLFFBQVEsSUFBQyxRQUFRLFNBQUMsVUFBVSxFQUFDLE1BQU0sQ0FBQyxXQUFXOzs7O29CQUExekIsVUFBVTs4QkFBMDdCLEtBQUssT0FBQyxVQUFVLEVBQUMsY0FBYzs7Ozs7NEJBQS93QixTQUFNLFFBQWlDLGtCQUFrQixPQUFDLFVBQVU7NEJBQXVELFNBQU0sUUFBbUMsZ0JBQWdCLE9BQUMsVUFBVTs0QkFBZ3FCLFNBQU0sUUFBaUMsY0FBYyxPQUFDLFVBQVU7OEJBQXZtQyxTQUFPOzs7Ozs7Ozs7Ozs7YUFBbXBDLElBQUM7OzRCQUFELElBQUM7Ozs7Ozs7O2tCQWpMaHFELFdBQVc7a0NBaUxxYyxXQUFXLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0FBOUssZ0JBQWdCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBL0csZ0JBQWdCLEdBQUcsU0FBUzs7Ozs7Ozs7O09BQXM5QyxTQUFNOztXQUF0dEQsVUFBTzs7T0FDUCxVQUFPLGFBRFAsVUFBTzttQ0FDUCxVQUFPOzs7O1NBQXlNLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUFtRixNQUFHO1dBQTJCLE9BQUksV0FBbEMsTUFBRzs2QkFBMkIsT0FBSTs7ZUFBSixPQUFJOztXQUEwQixTQUFNLGFBQXBDLE9BQUk7O2VBQWxDLE1BQUc7eURBQWlDLGVBQWU7d0JBQVMsU0FBTSxFQUFXLGVBQWU7MEJBQTVGLE1BQUc7Ozs7Ozs7Ozs7Ozs7K0NBQXVKLFdBQVcsdUJBQUksSUFBSTtlQUFFLFNBQU87ZUFBaUMsTUFBRyxxQkFBM0MsU0FBTztlQUFzQyxTQUFNLFdBQVgsTUFBRztpQ0FBRSxTQUFNO2VBQW1DLFNBQU07O21CQUEvQyxTQUFNOztlQUF1TCxPQUFLLGFBQWxNLFNBQU07aUNBQXVMLE9BQUs7O21CQUFMLE9BQUs7bUJBQXZNLE1BQUc7O2VBQXNRLE1BQUcsYUFBNVEsTUFBRztlQUEyUSxHQUFDLFdBQU4sTUFBRztpQ0FBRSxHQUFDOzttQkFBRCxHQUFDOztlQUF1QixPQUFLLGFBQTdCLEdBQUM7aUNBQXVCLE9BQUs7O21CQUFMLE9BQUs7bUJBQWxDLE1BQUc7bUJBQXBULFNBQU87Ozt1Q0FBYixJQUFJLHlCQUF5RSxJQUFJLEVBQUMsUUFBUTs0QkFBRSxTQUFNLHVCQUFsRyxJQUFJLGlDQUE2SyxJQUFJLEVBQUMsUUFBUTswQ0FBOUwsSUFBSSx5QkFBbVAsSUFBSSxFQUFDLFVBQVUsaUNBQXRRLElBQUkseUJBQW1SLElBQUksRUFBQyxXQUFXOzhDQUF2UyxJQUFJLHlCQUErVCxJQUFJLEVBQUMsTUFBTTtvREFBOVUsSUFBSSx5QkFBaVcsSUFBSSxFQUFDLFlBQVk7Ozs0QkFBMVIsU0FBTSxRQUFpQyxrQkFBa0IsT0FBQyxJQUFJOzhCQUFwSixTQUFPOzs7Ozs7Ozs7Ozs7YUFBaVosSUFBQzs7NEJBQUQsSUFBQzs7Ozs7Ozs7a0JBOUs3MkIsV0FBVztrQ0E4SzBaLFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUE5SyxnQkFBZ0IsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUFoSCxnQkFBZ0IsR0FBRyxTQUFTOzs7Ozs7Ozs7T0FBK3ZCLFNBQU07O1dBQW45QixVQUFPOzsyQkFBUCxVQUFPOzs7Ozs7O09BQ0MsR0FBRyxFQUFDLGdCQUFnQixFQUFDLDJCQUEyQjtPQUFHLEdBQUcsRUFBQyxPQUFPLEVBQUMsdUJBQXVCO09BQUcsR0FBRyxFQUFDLFNBQVMsRUFBQyw0QkFBNEI7OztnQkFBTSxNQUFNO1VBQ3JKLFNBQU07VUFBMkMsT0FBSSxXQUFyRCxTQUFNOzRCQUEyQyxPQUFJOztjQUFKLE9BQUk7O1VBQW9CLE1BQUcsYUFBM0IsT0FBSTtVQUF5QixTQUFNLFdBQVgsTUFBRzs0QkFBRSxTQUFNOztjQUFOLFNBQU07O1VBQXNCLE9BQUssYUFBakMsU0FBTTs0QkFBc0IsT0FBSzs7Y0FBTCxPQUFLO2NBQXRDLE1BQUc7O2NBQTVFLFNBQU07Ozs0QkFEeUksTUFBTSxrQkFDOUYsTUFBTSxDQUFDLENBQUM7NEJBRGdGLE1BQU0sa0JBQy9ELE1BQU0sQ0FBQyxDQUFDOzRCQURpRCxNQUFNLGtCQUNwQyxNQUFNLENBQUMsQ0FBQzs7O3VCQUF6SCxTQUFNLEVBQThCLFVBQVU7eUJBQTlDLFNBQU07Ozs7Ozs7OztPQUVSLFVBQU87bUNBQVAsVUFBTzs7OztTQUFrUCxJQUFDOzt3QkFBRCxJQUFDOzs7Ozs7Ozs7V0FBOEQsTUFBRztXQUEyQixPQUFJLFdBQWxDLE1BQUc7NkJBQTJCLE9BQUk7O2VBQUosT0FBSTs7V0FBMEIsU0FBTSxhQUFwQyxPQUFJOztlQUFsQyxNQUFHO3lEQUFpQyxlQUFlO3dCQUFTLFNBQU0sRUFBVyxlQUFlOzBCQUE1RixNQUFHOzs7Ozs7Ozs7O2FBQWlKLFVBQU87eUNBQVAsVUFBTzs7Ozs7ZUFBZ0csU0FBTTtpQ0FBTixTQUFNOzttQkFBTixTQUFNOztlQUEyQyxPQUFLLGFBQXRELFNBQU07O2lDQUEyQyxPQUFLOzttQkFBTCxPQUFLOzs7OztzQ0FBTCxPQUFLOzs7b0JBdkozbUIsZUFBZTtvQ0F1SjZyQixlQUFlLEVBQUMsR0FBRyxJQUFFLENBQUMsR0FBQyxHQUFHLEdBQUMsRUFBRTs7Ozs7b0JBdkp6dUIsZUFBZTs4QkF1SjhpQixLQUFLLE9BQUMsZUFBZSxFQUFDLE9BQU87Ozs7d0JBQWtDLE1BQU0sT0FBQyxlQUFlLEVBQUMsR0FBRyxLQUFHLENBQUM7d0JBQWtCLE1BQU0sT0FBQyxlQUFlLEVBQUMsR0FBRyxJQUFFLENBQUM7Ozs7b0JBdkp6c0IsZUFBZTs4QkF1SjR0QixLQUFLLE9BQUMsZUFBZSxFQUFDLEdBQUc7Ozs7Ozs7Ozs7ZUFBa0MsU0FBTTtpQ0FBTixTQUFNOzttQkFBTixTQUFNOzs7OzttQkF2SjV5QixlQUFlOzZCQXVKK3hCLEtBQUssT0FBQyxlQUFlLEVBQUMsUUFBUTs7Ozs7Ozs7OzttQkF2SjUwQixlQUFlO21EQXVKc2dCLGVBQWUsRUFBQyxPQUFPLEVBQUcsSUFBSTs7Ozs7Ozs7OztpQkFBckcsVUFBTzs7YUFBNmMsTUFBRyxhQUF2ZCxVQUFPOzs7dUJBQTZjLE1BQUcsaUJBQStCLFdBQVcsdUJBQUksSUFBSTtlQUFFLFNBQU07ZUFBc0ssTUFBRyxxQkFBL0ssU0FBTTtlQUFtTSxTQUFNLFdBQW5DLE1BQUc7aUNBQTBCLFNBQU07O21CQUFOLFNBQU07O2VBQTRCLE9BQUksYUFBdEMsU0FBTTtpQ0FBNEIsT0FBSTs7bUJBQUosT0FBSTs7ZUFBNFYsT0FBSyxhQUFyVyxPQUFJO2lDQUE0VixPQUFLOzttQkFBTCxPQUFLO21CQUFwYSxNQUFHOzttQ0FBSCxNQUFHOzs7OztpQkFBOGUsTUFBRztpQkFBMkIsTUFBRyxXQUFqQyxNQUFHOztpQkFBK0ksSUFBQyxxQkFBckgsTUFBRzttQ0FBaUgsSUFBQzs7cUJBQUQsSUFBQzs7aUJBQTRFLFFBQUssYUFBbEYsSUFBQzttQ0FBNEUsUUFBSzs7cUJBQUwsUUFBSztxQkFBdE0sTUFBRzs7aUJBQTZTLE1BQUcsYUFBblQsTUFBRztpQkFBdVUsSUFBQyxxQkFBM0IsTUFBRzttQ0FBdUIsSUFBQzs7cUJBQUQsSUFBQztxQkFBM0IsTUFBRzs7aUJBQWlFLE1BQUcsYUFBdkUsTUFBRztpQkFBMEYsSUFBQyxxQkFBMUIsTUFBRzttQ0FBc0IsSUFBQzs7cUJBQUQsSUFBQztxQkFBMUIsTUFBRztxQkFBclosTUFBRzs7aUJBQTRkLElBQUMsYUFBaGUsTUFBRzttQ0FBNGQsSUFBQzs7Ozs7bUJBQXVGLE9BQUk7O3VEQUFKLE9BQUk7c0JBQTl0QyxJQUFJO3FEQUE4eUMsSUFBSSxFQUFDLFVBQVU7OztnQ0FBdkcsT0FBSSwwQkFBcUosZUFBZSxPQUFDLElBQUk7O2tDQUE3SyxPQUFJLHFCQUF5TSxLQUFLLEtBQUcsQ0FBQztvQ0FBRyxLQUFLLENBQUMsR0FBRyxFQUFHLE9BQU8scUJBQUUsS0FBSyxDQUFDLEdBQUcsRUFBRyxHQUFHLEdBQUMsQ0FBQztpQkFBQSxLQUFLLENBQUMsY0FBYztpQkFBRyxlQUFlLE9BQUMsSUFBSTtnQkFBRSxDQUFDO2VBQUEsQ0FBQzs7a0NBQTlTLE9BQUk7Ozs7OzJCQUE5dEMsSUFBSSwwQkFBc3NDLElBQUksRUFBQyxTQUFTOzs7Ozs7Ozs7cUJBQXRGLElBQUM7Ozs7d0NBQWxjLE1BQUc7Ozs7Ozs7OzswQkFBaUIsTUFBTSxPQUFDLElBQUksRUFBQyxZQUFZLEtBQUcsQ0FBQzswQkFBa0IsTUFBTSxPQUFDLElBQUksRUFBQyxZQUFZLElBQUUsQ0FBQzs7OztzQkFBOXhCLElBQUk7Z0NBQW96QixNQUFNLE9BQUMsSUFBSSxFQUFDLFlBQVksS0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEVBQUU7Ozs7c0JBQTMxQixJQUFJO2dDQUF5MUIsWUFBWSxPQUFDLElBQUksRUFBQyxZQUFZOzs7O3NCQUEzM0IsSUFBSTtnQ0FBcTRCLE1BQU0sT0FBQyxJQUFJLEVBQUMsbUJBQW1CLEtBQUcsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFOzs7O3NCQUFuN0IsSUFBSTtnQ0FBaTdCLE1BQU0sT0FBQyxJQUFJLEVBQUMsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7c0JBQS85QixJQUFJO2dDQUEwZ0MsWUFBWSxPQUFDLElBQUksRUFBQyxRQUFROzs7O3NCQUF4aUMsSUFBSTtnQ0FBNmtDLFlBQVksT0FBQyxJQUFJLEVBQUMsWUFBWTs7OztzQkFBL21DLElBQUk7Z0NBQWtxQyxZQUFZLE9BQUMsSUFBSSxFQUFDLFNBQVM7Ozs7Ozs7OztpQkFBbVcsSUFBQzttQ0FBRCxJQUFDOztxQkFBRCxJQUFDOzs7MkJBQXJpRCxJQUFJLG1CQUE0b0QsS0FBSyxPQUFDLElBQUksRUFBQyxRQUFROzs7Z0NBQS9ILElBQUM7Ozs7OztxQkFBcmlELElBQUk7cURBQXFvQixJQUFJLEVBQUMsWUFBWSxFQUFHLElBQUk7Ozs7Ozs7Ozs7ZUFBK2dDLE1BQU07ZUFBRSxPQUFJLFdBQVosTUFBTTtpQ0FBRSxPQUFJOzttQkFBSixPQUFJOztlQUEwUCxPQUFJLGFBQWxRLE9BQUk7ZUFBZ1QsT0FBSSxxQkFBMUQsT0FBSTs7bUJBQUosT0FBSTttQkFBMVEsTUFBTTs7bUNBQU4sTUFBTTs7Ozs7Ozs7O3FCQUF0ckQsSUFBSTt3REFBNnJFLElBQUksRUFBQyxFQUFFOzs7O3FCQUF4c0UsSUFBSTs0Q0FBNnRFLEtBQUssT0FBQyxJQUFJLEVBQUMsVUFBVSxDQUFDLE1BQU07Ozs7cUJBQW5HLFdBQVc7Ozs7Ozs7Ozs7Z0NBQTRJLG1CQUFtQixPQUFDLElBQUksU0FBQyxJQUFJLEVBQUMsVUFBVTs7Ozs7Ozs7Ozs7Ozs7OztxQkFBejFFLElBQUk7cURBQXFuRSxJQUFJLEVBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRyxLQUFLOzs7Ozs7Ozs7O21CQUFscEUsU0FBTTs7Ozt5QkFBTixTQUFNOzs2QkFBTixTQUFNO29CQUFaLElBQUk7NENBQStHLElBQUksRUFBQyxVQUFVOzs7d0NBQWxJLElBQUkseUJBQW1OLElBQUksRUFBQyxVQUFVOzs2QkFBVyxPQUFJO29CQUFyUCxJQUFJOzhDQUF1VCxJQUFJLEVBQUMsVUFBVTs7OztvQkE1Sy90QyxvQkFBb0I7b0JBNEtpNEIsSUFBSTtvREFBNmhCLG9CQUFvQixTQUFHLElBQUksRUFBQyxFQUFFLElBQUMsR0FBRyxHQUFDLElBQUk7Ozs7Ozs7O29CQUF4a0IsSUFBSTsyQ0FBNkIsVUFBVSxPQUFDLElBQUksRUFBQyxFQUFFOzs7O29CQUFuRCxJQUFJOzhCQUFvbEIsWUFBWSxPQUFDLElBQUksRUFBQyxVQUFVOzs7O29CQUFwbkIsSUFBSTs7b0NBQW10RCxJQUFJLEVBQUMsU0FBUzs0QkFBWSxZQUFZLE9BQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxNQUFNLGtCQUFZLElBQUksRUFBQyxTQUFTLENBQUMsR0FBRyx5QkFBRyxJQUFJLEVBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRyxDQUFDO2tCQUFDLElBQUk7d0NBQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUcsQ0FBQzttQkFBQyxJQUFJO3lDQUFDLElBQUksRUFBQyxTQUFTLENBQUMsR0FBRyxFQUFHLENBQUMsSUFBQyxJQUFJLEdBQUMsSUFBSTtpQkFBa0IsZUFBZTs7Ozs7NEJBQTVyRCxPQUFJLDBCQUFrSixnQkFBZ0IsT0FBQyxJQUFJOzs4QkFBM0ssT0FBSSxxQkFBdU0sS0FBSyxLQUFHLENBQUM7Z0NBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRyxPQUFPLHFCQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUcsR0FBRyxHQUFDLENBQUM7YUFBQSxLQUFLLENBQUMsY0FBYzthQUFHLGdCQUFnQixPQUFDLElBQUk7WUFBRSxDQUFDO1dBQUEsQ0FBQzs7NEJBQTg4QyxPQUFJLDBCQUFnRixXQUFXLE9BQUMsSUFBSTs0QkFBMWtFLFNBQU0sUUFBMEQsY0FBYyxPQUFDLElBQUksRUFBQyxFQUFFOzhCQUF0RixTQUFNOzs7Ozs7OztpQkFBN0QsTUFBRzs7Ozs7YUFBODZFLElBQUM7OzRCQUFELElBQUM7Ozs7Ozs7O2tCQTVLbjFHLFdBQVc7a0NBNEs4YSxXQUFXLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0FBOUssZ0JBQWdCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBM0YsZ0JBQWdCLEdBQUcsU0FBUzs7Ozs7Ozs7O09BQW10RyxTQUFNOztXQUFoOUcsVUFBTzs7T0FDUCxVQUFPLGFBRFAsVUFBTzttQ0FDUCxVQUFPOzs7O1NBRXdCLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUNFLE1BQUc7V0FBMkIsT0FBSSxXQUFsQyxNQUFHOzZCQUEyQixPQUFJOztlQUFKLE9BQUk7O1dBQXFCLFNBQU0sYUFBL0IsT0FBSTs7ZUFBbEMsTUFBRzt5REFBaUMsVUFBVTt3QkFBUyxTQUFNLEVBQVcsVUFBVTswQkFBbEYsTUFBRzs7Ozs7Ozs7OzthQUVqQyxVQUFPO3lDQUFQLFVBQU87Ozs7O2VBQTJGLFNBQU07aUNBQU4sU0FBTTs7bUJBQU4sU0FBTTs7ZUFBMEMsUUFBSyxhQUFyRCxTQUFNOztpQ0FBMEMsUUFBSzs7bUJBQUwsUUFBSzs7Ozs7O3NDQUFMLFFBQUs7OEJBQWlCLGNBQWMsRUFBQyxHQUFHLElBQUUsQ0FBQzs4QkFBa0IsY0FBYyxFQUFDLEdBQUcsR0FBQyxDQUFDOzs7O29CQTVKek8sY0FBYztvQ0E0SjhOLGNBQWMsRUFBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFOzs7OztvQkE1SnhRLGNBQWM7OEJBNEprRyxLQUFLLE9BQUMsY0FBYyxFQUFDLE9BQU87Ozs7b0JBNUo1SSxjQUFjOzhCQTRKNFAsS0FBSyxPQUFDLGNBQWMsRUFBQyxHQUFHOzs7Ozs7Ozs7O2VBQWtDLFNBQU07aUNBQU4sU0FBTTs7bUJBQU4sU0FBTTs7Ozs7bUJBNUoxVSxjQUFjOzZCQTRKOFQsS0FBSyxPQUFDLGNBQWMsRUFBQyxRQUFROzs7Ozs7Ozs7O21CQTVKelcsY0FBYzttREE0SjJELGNBQWMsRUFBQyxPQUFPLEVBQUcsSUFBSTs7Ozs7Ozs7OztpQkFBaEcsVUFBTzs7YUFDUCxNQUFHLGFBREgsVUFBTzs7O3VCQUNQLE1BQUcsaUJBQStCLE1BQU0sdUJBQUksS0FBSztlQUFFLFNBQU87O2VBQ3JCLE1BQUcscUJBRFcsU0FBTztlQUNRLFNBQU0sV0FBbkMsTUFBRztpQ0FBMEIsU0FBTTs7bUJBQU4sU0FBTTs7ZUFBdUIsT0FBSSxhQUFqQyxTQUFNO2lDQUF1QixPQUFJOzttQkFBSixPQUFJOztlQUFxUyxRQUFLLGFBQTlTLE9BQUk7aUNBQXFTLFFBQUs7O21CQUFMLFFBQUs7bUJBQXhXLE1BQUc7O21DQUFILE1BQUc7Ozs7O2lCQUNQLE1BQUc7aUJBQTJCLE1BQUcsV0FBakMsTUFBRzs7aUJBQWlKLElBQUMscUJBQXZILE1BQUc7bUNBQW1ILElBQUM7O3FCQUFELElBQUM7O2lCQUE4RSxRQUFLLGFBQXBGLElBQUM7bUNBQThFLFFBQUs7O3FCQUFMLFFBQUs7cUJBQTFNLE1BQUc7O2lCQUFtVCxNQUFHLGFBQXpULE1BQUc7aUJBQTZVLElBQUMscUJBQTNCLE1BQUc7bUNBQXVCLElBQUM7O3FCQUFELElBQUM7cUJBQTNCLE1BQUc7O2lCQUFrRSxNQUFHLGFBQXhFLE1BQUc7aUJBQTJGLElBQUMscUJBQTFCLE1BQUc7bUNBQXNCLElBQUM7O3FCQUFELElBQUM7cUJBQTFCLE1BQUc7cUJBQTVaLE1BQUc7O2lCQUFvZSxJQUFDLGFBQXhlLE1BQUc7bUNBQW9lLElBQUM7aUJBQW9ILFNBQU07O3FCQUEzSCxJQUFDOzs7O3dDQUExYyxNQUFHOzs7Ozs7OytCQUEyakIsU0FBTTtzQkFGdmxCLEtBQUs7d0VBRThwQixLQUFLLEVBQUMsSUFBSTs7Ozs7MEJBQXRvQixNQUFNLE9BQUMsS0FBSyxFQUFDLFlBQVksS0FBRyxDQUFDOzBCQUFrQixNQUFNLE9BQUMsS0FBSyxFQUFDLFlBQVksSUFBRSxDQUFDOzs7O3NCQUZsSCxLQUFLO2dDQUV1SSxNQUFNLE9BQUMsS0FBSyxFQUFDLFlBQVksS0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEVBQUU7Ozs7c0JBRmhMLEtBQUs7Z0NBRTZLLFlBQVksT0FBQyxLQUFLLEVBQUMsWUFBWTs7OztzQkFGak4sS0FBSztnQ0FFME4sTUFBTSxPQUFDLEtBQUssRUFBQyxtQkFBbUIsS0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEVBQUU7Ozs7c0JBRjFRLEtBQUs7Z0NBRXVRLE1BQU0sT0FBQyxLQUFLLEVBQUMsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7c0JBRnZULEtBQUs7Z0NBRWlXLFlBQVksT0FBQyxLQUFLLEVBQUMsUUFBUTs7OztzQkFGalksS0FBSztnQ0FFcWEsWUFBWSxPQUFDLEtBQUssRUFBQyxZQUFZOzs7O3NCQUZ6YyxLQUFLO2dDQUU2ZixZQUFZLE9BQUMsS0FBSyxFQUFDLFdBQVc7Ozs7c0JBRmhpQixLQUFLO2dDQUVpaUIsTUFBTSxPQUFDLEtBQUssRUFBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7OzhCQUFXLFNBQU0sUUFBMkksYUFBYSxPQUFDLEtBQUs7Ozs7O2lCQUEwQixJQUFDO21DQUFELElBQUM7O3FCQUFELElBQUM7OzsyQkFGaHhCLEtBQUssbUJBRWszQixLQUFLLE9BQUMsS0FBSyxFQUFDLFFBQVE7OztnQ0FBNUgsSUFBQzs7Ozs7O3FCQUZoeEIsS0FBSztxREFFM0MsS0FBSyxFQUFDLFlBQVksRUFBRyxJQUFJOzs7Ozs7Ozs7O2VBQzdCLFFBQU07ZUFBRSxPQUFJLFdBQVosUUFBTTtpQ0FBRSxPQUFJOzttQkFBSixPQUFJOzttQ0FBSixPQUFJOzttQ0FBMFMsZUFBZSw0QkFBZSxlQUFlLE9BQUMsS0FBSyxFQUFDLEVBQUU7bUJBQTVXLFFBQU07O21DQUFOLFFBQU07Ozs7Ozs7OztxQkFIb0MsS0FBSzsyREFJeUMsS0FBSyxFQUFDLEVBQUU7Ozs7cUJBSnRELEtBQUs7NENBSTBFLEtBQUssT0FBQyxLQUFLLEVBQUMsa0JBQWtCLENBQUMsTUFBTTs7OztxQkFBaEgsV0FBVzs7Ozs7Ozs7Ozs7Z0NBQXlKLENBQUM7dUJBQUEsMkJBQTJCLFFBQUMsS0FBSzs7dUJBQUMscUJBQXFCO2tCQUFFLE1BQU0sRUFBQyxNQUFNLE9BQUMsS0FBSyxFQUFDLGtCQUFrQixDQUFDLE1BQU07a0JBQUUsS0FBSyxFQUFDLE1BQU0sT0FBQyxLQUFLLEVBQUMsV0FBVyxJQUFFLEVBQUU7O2dCQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7cUJBSnRULEtBQUs7cURBSTNDLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxNQUFNLEVBQUcsS0FBSzs7Ozs7Ozs7OzttQkFKSyxTQUFPOzs7O3NDQUFQLFNBQU87OzZCQUFQLFNBQU87b0JBQWQsS0FBSztrREFBaUYsS0FBSyxFQUFDLEVBQUU7Ozt3Q0FBOUYsS0FBSyx5QkFDeUIsS0FBSyxFQUFDLElBQUk7NkJBQVcsT0FBSSx1QkFEdkQsS0FBSyxtQ0FDd0gsS0FBSyxFQUFDLElBQUk7OztvQkFuTEUsZUFBZTtvQkFrTHhKLEtBQUs7b0RBQzJTLGVBQWUsU0FBRyxLQUFLLEVBQUMsRUFBRSxJQUFDLEdBQUcsR0FBQyxJQUFJOzs7MkNBRG5WLEtBQUsseUJBQzhWLEtBQUssRUFBQyxNQUFNO29CQUQvVyxLQUFLO29DQUM0VyxLQUFLLEVBQUMsUUFBUSxlQUFPLEtBQUssRUFBQyxRQUFRLEtBQUcsRUFBRTs7Ozs7OztvQkFEelosS0FBSzsyQ0FBOEIsVUFBVSxPQUFDLEtBQUssRUFBQyxFQUFFOzs7OzJDQUE2RCxNQUFNLE9BQUMsS0FBSyxFQUFDLEVBQUUsR0FBSSxNQUFNLE9BQUMsa0JBQWtCOzs7O29CQUEvSixLQUFLOztvQ0FHUixLQUFLLEVBQUMsaUJBQWlCO21DQUFtQixZQUFZLE9BQUMsS0FBSyxFQUFDLGlCQUFpQixDQUFDLE1BQU0sa0JBQVksS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcseUJBQUcsS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRyxDQUFDO2tCQUFDLElBQUk7d0NBQUMsS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRyxDQUFDO21CQUFDLElBQUk7eUNBQUMsS0FBSyxFQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRyxDQUFDLElBQUMsSUFBSSxHQUFDLElBQUk7aUJBQUcsaUJBQWlCOzs7Ozs0QkFGaE4sT0FBSSxRQUF1SCxXQUFXLE9BQUMsS0FBSzs7OEJBQTVJLE9BQUksR0FBd0osS0FBSyxLQUFHLENBQUM7Z0NBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRyxPQUFPLHFCQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUcsR0FBRyxHQUFDLENBQUM7YUFBQSxLQUFLLENBQUMsY0FBYzthQUFHLFdBQVcsT0FBQyxLQUFLO1lBQUUsQ0FBQztXQUFBLENBQUM7OzhCQUR0UyxTQUFPOzs7Ozs7OztpQkFBMUQsTUFBRzs7Ozs7YUFNRSxJQUFDOzs0QkFBRCxJQUFDOzs7Ozs7O3NCQXhMWCxNQUFNLHlCQWdMTSxNQUFNLEVBQUMsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQURiLFdBQVcsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUQxQixXQUFXLEdBQUcsU0FBUzs7Ozs7Ozs7O09BVzNCLFNBQU07O1dBYlIsVUFBTzs7T0FlUCxVQUFPLGFBZlAsVUFBTztPQWVtRCxNQUFHLFdBQTdELFVBQU87bUNBQW1ELE1BQUc7Ozs7U0FBd0ksTUFBRztTQUFtRCxJQUFDLHFCQUF2RCxNQUFHOzJCQUFtRCxJQUFDOzthQUFELElBQUM7YUFBdkQsTUFBRzs7OzthQXhLcEYsZUFBZTt1QkF3SzJILEtBQUssT0FBQyxlQUFlOzs7O3dCQUE5RSxNQUFHOzs7Ozs7YUF4SzFNLFdBQVc7NkJBd0t3SyxXQUFXLEVBQUMsTUFBTTs7Ozs7Ozs7OztXQUF6SSxNQUFHOzsyQkFBSCxNQUFHOzs7O1NBQy9CLElBQUM7O3dCQUFELElBQUM7Ozs7Ozs7OztXQUEyRSxNQUFHO1dBQTJCLE9BQUksV0FBbEMsTUFBRzs2QkFBMkIsT0FBSTs7ZUFBSixPQUFJOztXQUFvQixTQUFNLGFBQTlCLE9BQUk7O2VBQWxDLE1BQUc7eURBQWlDLFNBQVM7d0JBQVMsU0FBTSxFQUFXLFNBQVM7MEJBQWhGLE1BQUc7Ozs7Ozs7Ozs7Ozs7K0NBQTJJLFdBQVcsdUJBQUksSUFBSTtpQkFBUyxRQUFRLDJDQUFyQixJQUFJLG1CQUFrQixZQUFZLE9BQUMsSUFBSTs7aUJBQTFCLFFBQVE7O2VBQXFCLFNBQU87O2VBQThGLE1BQUcscUJBQXhHLFNBQU87ZUFBbUcsU0FBTSxXQUFYLE1BQUc7aUNBQUUsU0FBTTtlQUFtQyxTQUFNO2VBQXdILFNBQU0sYUFBcEksU0FBTTtpQ0FBd0gsU0FBTTs7bUJBQU4sU0FBTTttQkFBN0ssU0FBTTs7ZUFBOFcsUUFBSyxhQUF6WCxTQUFNO2lDQUE4VyxRQUFLOzttQkFBTCxRQUFLO21CQUE5WCxNQUFHOztlQUFvZSxNQUFHLGFBQTFlLE1BQUc7ZUFBeWUsSUFBQyxXQUFOLE1BQUc7aUNBQUUsSUFBQzs7bUJBQUQsSUFBQzs7ZUFBdUMsUUFBSyxhQUE3QyxJQUFDO2lDQUF1QyxRQUFLOzttQkFBTCxRQUFLO21CQUFsRCxNQUFHOzttQ0FBSCxNQUFHOzttQ0FBd0csZUFBZSw0QkFBZSxlQUFlLE9BQUMsSUFBSTs7Ozs7O2lCQUFtQixNQUFHO2lCQUF3QixNQUFHLFdBQTlCLE1BQUc7aUJBQTZCLE9BQUksV0FBVCxNQUFHO21DQUFFLE9BQUk7O3FCQUFKLE9BQUk7cUJBQVQsTUFBRzs7aUJBQXdGLEdBQUMsYUFBNUYsTUFBRzs7cUJBQTlCLE1BQUc7Ozs7dUNBQTV4QixRQUFRO3FDQUF1ekIsUUFBUSxFQUFDLEdBQUc7O3VDQUEzMEIsUUFBUTtxQ0FBeTBCLFFBQVEsRUFBQyxNQUFNOzs7MEJBQStDLEdBQUM7dUNBQWg1QixRQUFRO3dEQUFtNkIsUUFBUSxFQUFDLE9BQU87Ozs7Z0NBQWxLLE1BQUc7Ozs7O3dCQUFiLFFBQVE7Ozs7Ozs7Ozs7Ozs7aUJBQWlRLE1BQUc7aUJBQXVILFNBQU0scUJBQWhJLE1BQUc7bUNBQXVILFNBQU07O3FCQUFOLFNBQU07cUJBQWhJLE1BQUc7OztjQUF1SCxTQUFNLGtDQUE2RCxrQkFBa0IsR0FBRyxJQUFJOzs7cUJBekxoOUMsa0JBQWtCO3FCQW9CdEUscUJBQXFCO3FEQXFLMmlELGtCQUFrQixTQUFHLHFCQUFxQixFQUFDLEVBQUUsSUFBQyxzQkFBc0IsR0FBQyxxQkFBcUI7Ozs7OEJBQWxQLFNBQU0sUUFBc0csa0JBQWtCLE9BQUMscUJBQXFCO2dDQUE5USxNQUFHOzs7Ozs7cUJBQXhpQyxJQUFJO3FCQXpMaE0saUJBQWlCO3FCQW9COUYscUJBQXFCOytDQXFLcXRDLE1BQU0sT0FBQyxJQUFJLEVBQUMsRUFBRSxHQUFJLE1BQU0sT0FBQyxpQkFBaUIsYUFBRyxxQkFBcUI7Ozs7Ozs7Ozs7bUJBQXovQixTQUFPOzs7O3NDQUFQLFNBQU87d0NBQWpELElBQUkseUJBQTBLLElBQUksRUFBQyxRQUFROzZCQUFFLFNBQU0sdUJBQW5NLElBQUksaUNBQXdRLElBQUksRUFBQyxRQUFROzs2QkFBa0MsU0FBTTtvQkFBalUsSUFBSTs4Q0FBd1ksSUFBSSxFQUFDLFFBQVE7OzthQUE5RixTQUFNLGtDQUEwSCxjQUFjLEdBQUcsSUFBSTs7O29CQTNNN25CLGNBQWM7b0JBMk0rSixJQUFJO29EQUErYyxjQUFjLFNBQUcsSUFBSSxFQUFDLEVBQUUsSUFBQyxHQUFHLEdBQUMsSUFBSTs7OzJDQUFwZixJQUFJLHlCQUEyZ0IsSUFBSSxFQUFDLFVBQVUsbUNBQTloQixJQUFJLHlCQUFxa0IsSUFBSSxFQUFDLGlCQUFpQjs7Ozs7OzBDQUE1Z0IsTUFBTSxPQUFDLElBQUksRUFBQyxFQUFFLEdBQUksTUFBTSxPQUFDLGlCQUFpQjs7OztvQkFBN0gsSUFBSTtvQ0FBK2hCLElBQUksRUFBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBQyxHQUFHOzs7O29CQUFua0IsSUFBSTs4QkFBMG5CLEtBQUssT0FBQyxJQUFJLEVBQUMsZ0JBQWdCOzs7O29CQUF6cEIsSUFBSTs4QkFBc3FCLEtBQUssT0FBQyxJQUFJLEVBQUMsaUJBQWlCOzs7Ozs0QkFBemdCLFNBQU0sUUFBaUMsWUFBWSxPQUFDLElBQUk7NEJBQXNFLFNBQU0sUUFBbUMsVUFBVSxPQUFDLElBQUk7OEJBQXpVLFNBQU87Ozs7Ozs7Ozs7OzthQUE4NEMsSUFBQzs7NEJBQUQsSUFBQzs7Ozs7Ozs7a0JBekt6c0QsV0FBVztrQ0F5S3FOLFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUE1SixVQUFVLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBbEcsVUFBVSxHQUFHLFNBQVM7Ozs7Ozs7Ozs7Ozs7O1NBQ0YsU0FBTTs0QkFBTixTQUFNO1NBQW1MLE9BQUk7NEJBQUosT0FBSTs7YUFBSixPQUFJO2FBQTdMLFNBQU07OzZCQUFOLFNBQU07Ozs7V0FBdVAsTUFBRzs7O3FCQUFILE1BQUcsaUJBQWtDLFdBQVcsdUJBQUksSUFBSTs7Ozs7Z0JBQUUsYUFBYTs7eUJBQUUsSUFBSTs7O1dBQUcsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7ZUFBckYsTUFBRzswQkFBSCxNQUFHOzs7OztrQkFBcEIsZUFBZTs7Ozs7Ozs7OztzQkFBM1AsU0FBTSx5QkFBOEUsZUFBZTs7O2FBMUtwRSxXQUFXOzZCQTBLMkgsV0FBVyxFQUFDLE1BQU07OztpQ0FBUSxlQUFlLElBQUMsR0FBRyxHQUFDLEdBQUc7OztzQkFBdE4sU0FBTSxjQUE2RyxlQUFlLFNBQUUsZUFBZTs7Ozs7OzthQTFLcEgsV0FBVzs2QkEwSzlELFdBQVcsRUFBQyxNQUFNOzs7Ozs7Ozs7O09BQ3RCLFNBQU07O1dBSFIsVUFBTzs7V0ExQlQsVUFBTztXQURULE1BQUc7b0JBRUMsU0FBTSxFQUF5QixVQUFVO29CQUl1cUQsU0FBTSxRQUFvQyxrQkFBa0I7b0JBQy96QixTQUFNLFFBQW9DLGtCQUFrQjtvQkFJaThFLFNBQU0sRUFBZ0Msa0JBQWtCO29CQWNoZ0gsU0FBTSxFQUFnQyxhQUFhO29CQUtuRCxTQUFNLFFBQW9DLFlBQVk7O29CQTdCMUQsVUFBTzs7OztvQkFEVCxNQUFHLEVBQWtDLFVBQVU7c0JBQS9DLE1BQUcsR0FBMkQsS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsS0FBRSxVQUFVO3NCQUF0RyxNQUFHOzs7OztjQURELFNBQVM7Ozs7Ozs7Ozs7Ozs7T0FxQ1csTUFBRztPQUF5QixVQUFPLFdBQW5DLE1BQUc7T0FBMEYsU0FBTSxXQUF2RSxVQUFPO09BQXVLLElBQUUsYUFBL0csU0FBTTswQkFBdUcsSUFBRTs7V0FBRixJQUFFOztPQUF5SyxPQUFLLGFBQWhMLElBQUU7T0FBb0wsT0FBSyxxQkFBaEIsT0FBSzs7MkJBQU0sT0FBSztXQUFoQixPQUFLOztPQUF3RSxPQUFLLGFBQWxGLE9BQUs7T0FBOEYsT0FBSyxxQkFBM0IsT0FBSzs7MkJBQWlCLE9BQUs7V0FBM0IsT0FBSzs7T0FBeUgsT0FBSyxhQUFuSSxPQUFLO09BQXlJLE1BQU0scUJBQXRCLE9BQUs7OztVQUFxRCxjQUFjOzs7OztpQkFBeEQsTUFBTSxZQUEyRSxLQUFLLEVBQUMsTUFBTSxFQUFDLE9BQU8sRUFBQyxNQUFNLHVCQUFLLElBQUk7U0FBRSxRQUFNOzRCQUFOLFFBQU07O2FBQU4sUUFBTTs7Ozs7Ozs7Z0RBQVEsSUFBSTtRQUFsQixRQUFNLFVBQU4sUUFBTSxXQUFRLElBQUk7OztjQUF4QixJQUFJLGtCQUF1QixJQUFJLENBQUMsV0FBVzs7O3dCQUFyQyxRQUFNOzs7Ozs7OztXQUE3SCxNQUFNO1dBQXRCLE9BQUs7O09BQTRNLE9BQUssYUFBdE4sT0FBSztPQUF3TixPQUFLLHFCQUFqQixPQUFLOzsyQkFBTyxPQUFLO1dBQWpCLE9BQUs7O09BQStHLE9BQUssYUFBekgsT0FBSztPQUF3SSxPQUFLLHFCQUE5QixPQUFLOzsyQkFBb0IsT0FBSztXQUE5QixPQUFLOztPQUE2RixPQUFLLGFBQXZHLE9BQUs7T0FBb0csT0FBSyxXQUFaLE9BQUs7OzJCQUFFLE9BQUs7O1dBQVosT0FBSzs7T0FBbUcsT0FBSyxhQUE3RyxPQUFLO09BQXNILFFBQU0scUJBQXpCLE9BQUs7OztVQUFpQyxjQUFjOzs7O09BQWMsUUFBTSxXQUFyRCxRQUFNOztHQUF5QyxRQUFNLFNBQU4sUUFBTTs7T0FBcUMsUUFBTSxhQUFqRCxRQUFNOztHQUFxQyxRQUFNLFNBQU4sUUFBTTtXQUFoRyxRQUFNO1dBQXpCLE9BQUs7OzJCQUFMLE9BQUs7Ozs7U0FBZ00sSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLGVBQWU7d0JBQXJDLElBQUM7Ozs7O2dCQUFsQixlQUFlOzs7Ozs7Ozs7T0FBa0QsTUFBRztPQUF3QixTQUFNLFdBQWpDLE1BQUc7T0FBeUcsU0FBTSxhQUF2RixTQUFNOzBCQUEyRSxTQUFNOztXQUFOLFNBQU07V0FBbEgsTUFBRztXQUEzeUMsVUFBTztXQUFuQyxNQUFHOzs7K0NBQTJNLG1CQUFtQixHQUFHLElBQUksSUFBQyw2QkFBNkIsR0FBQyxpQkFBaUI7SUFBd3BDLFNBQU0sa0JBQXFELGdCQUFnQjs7K0JBQUcsZ0JBQWdCO09BQUMsU0FBUzs2QkFBQyxtQkFBbUIsR0FBRyxJQUFJLElBQUMsZ0JBQWdCLEdBQUMsY0FBYzs7O29CQUF0L0MsU0FBTSxjQUE2QixrQkFBa0IsRUFBQyxLQUFLOzs7SUFBd08sT0FBSzthQUFDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLEtBQUs7O2FBQWhDLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLEtBQUs7Ozs7O0lBQWtELE9BQUs7YUFBOEMsR0FBVTtrQkFBRSxjQUFjLEVBQUMsY0FBYzs7YUFBekMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsY0FBYzs7Ozs7SUFBNEIsTUFBTTthQUF3QixHQUFVO2tCQUFFLGNBQWMsRUFBQyxjQUFjOzthQUF6QyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxjQUFjOzs7OztJQUFzSSxPQUFLO2FBQTBDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLGtCQUFrQjs7YUFBN0MsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsa0JBQWtCOzs7OztJQUFxQyxPQUFLO2FBQWEsR0FBVTtrQkFBRSxjQUFjLEVBQUMsZ0JBQWdCOzthQUEzQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxnQkFBZ0I7Ozs7O0lBQW1CLE9BQUs7YUFBaUIsR0FBWTtrQkFBRSxjQUFjLEVBQUMsZ0JBQWdCOzthQUE3QyxHQUFZO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxnQkFBZ0I7Ozs7O0lBQWlELFFBQU07YUFBQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxVQUFVOzthQUFyQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxVQUFVOzs7O29CQUFpTixTQUFNLGNBQWlDLGtCQUFrQixFQUFDLEtBQUs7b0JBQWtCLFNBQU0sRUFBMkIsY0FBYztzQkFBLzlDLE1BQUc7Ozs7O2NBQXZCLGtCQUFrQjs7Ozs7Ozs7Ozs7OztPQUNJLE1BQUc7T0FBeUIsVUFBTyxXQUFuQyxNQUFHO09BQTBGLFNBQU0sV0FBdkUsVUFBTztPQUF3SyxJQUFFLGFBQWhILFNBQU07MEJBQXdHLElBQUU7O1dBQUYsSUFBRTs7T0FBa0QsT0FBSyxhQUF6RCxJQUFFO09BQXNFLE9BQUsscUJBQXpCLE9BQUs7OzJCQUFlLE9BQUs7V0FBekIsT0FBSzs7T0FBaUcsT0FBSyxhQUEzRyxPQUFLO09BQW9ILE9BQUsscUJBQXhCLE9BQUs7OzJCQUFjLE9BQUs7V0FBeEIsT0FBSzs7T0FBa0YsUUFBSyxhQUE1RixPQUFLO09BQTJHLE9BQUsscUJBQTlCLFFBQUs7OzJCQUFvQixPQUFLO1dBQTlCLFFBQUs7O09BQTZGLFNBQU0sYUFBeEcsUUFBSzswQkFBNkYsU0FBTTs7V0FBTixTQUFNOztPQUFpTyxNQUFHLGFBQTFPLFNBQU07T0FBNFAsU0FBTSxXQUFqQyxNQUFHO09BQTBHLFNBQU0sYUFBeEYsU0FBTTs7V0FBakMsTUFBRztXQUE1dUIsVUFBTztXQUFuQyxNQUFHOzs7OztZQTdNeEIsb0JBQW9COzRCQTZNcU4sb0JBQW9CLEVBQUMsS0FBSzs7OztZQTdNblEsb0JBQW9COzRCQTZNeW9CLG9CQUFvQixFQUFDLGtCQUFrQixJQUFFLENBQUM7Ozs7O1lBN012c0Isb0JBQW9CO3NCQTZNc3JCLE1BQU0sT0FBQyxvQkFBb0IsRUFBQyxjQUFjLElBQUUsT0FBTyxFQUFFLFdBQVc7Ozs7O29CQUF4cEIsU0FBTSxjQUE2QixvQkFBb0IsRUFBQyxJQUFJOzs7SUFBMEgsT0FBSzthQUEwQixHQUFVO2tCQUFFLGNBQWMsRUFBQyxZQUFZOzthQUF2QyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxZQUFZOzs7OztJQUErQixPQUFLO2FBQWEsR0FBVTtrQkFBRSxjQUFjLEVBQUMsV0FBVzs7YUFBdEMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsV0FBVzs7Ozs7SUFBcUMsT0FBSzthQUFhLEdBQVU7a0JBQUUsY0FBYyxFQUFDLGdCQUFnQjs7YUFBM0MsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsZ0JBQWdCOzs7O29CQUFZLFNBQU0sUUFBaUMsU0FBUyxDQUFDLE1BQU0sT0FBQyxvQkFBb0IsRUFBQyxrQkFBa0IsSUFBRSxDQUFDO29CQUFnSyxTQUFNLGNBQWlDLG9CQUFvQixFQUFDLElBQUk7b0JBQWtCLFNBQU0sRUFBMkIsY0FBYztzQkFBajZCLE1BQUc7Ozs7O2NBQXpCLG9CQUFvQjs7Ozs7Ozs7Ozs7OztPQUNBLE1BQUc7T0FBeUIsVUFBTyxXQUFuQyxNQUFHO09BQTBGLFNBQU0sV0FBdkUsVUFBTztPQUFnTCxJQUFFLGFBQXhILFNBQU07MEJBQWdILElBQUU7O1dBQUYsSUFBRTs7T0FBcU4sUUFBSyxhQUE1TixJQUFFO09BQTRPLFFBQU0scUJBQTdCLFFBQUs7OztVQUFxQyxjQUFjOzs7Ozs7OztPQUFzQixRQUFNLFdBQTdELFFBQU07O0dBQWlELFFBQU0sU0FBTixRQUFNOzsyQkFBTixRQUFNOzs7Ozs7O1lBdk5qaEIsV0FBVzs0QkF1TmdrQixXQUFXLEVBQUMsUUFBUTs7O2dCQUFJLE9BQU87VUFBRSxRQUFNOzZCQUFOLFFBQU07O2NBQU4sUUFBTTs7Ozs7O29DQUFmLE9BQU8seUJBQXFDLE9BQU8sRUFBQyxJQUFJOzs7U0FBL0MsUUFBTSxVQUFOLFFBQU07Ozs7cUJBQWYsT0FBTyxtQkFBZ0IsTUFBTSxPQUFDLE9BQU8sRUFBQyxFQUFFOzs7O3lCQUEvQixRQUFNOzs7Ozs7Ozs7V0FBOUosUUFBTTtXQUE3QixRQUFLOztPQUE0UCxRQUFLLGFBQXRRLFFBQUs7T0FBNFEsT0FBSyxxQkFBckIsUUFBSzs7MkJBQVcsT0FBSztXQUFyQixRQUFLOztPQUE2RyxRQUFLLGFBQXZILFFBQUs7T0FBbUksUUFBSyxxQkFBM0IsUUFBSzs7MkJBQWlCLFFBQUs7V0FBM0IsUUFBSzs7T0FBcUgsUUFBSyxhQUEvSCxRQUFLO09BQStJLFFBQUsscUJBQS9CLFFBQUs7OzJCQUFxQixRQUFLO1dBQS9CLFFBQUs7O09BQTZHLFFBQUssYUFBdkgsUUFBSztPQUFtSSxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOzsyQkFBTCxRQUFLOzs7O1NBQXdILElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixlQUFlO3dCQUFyQyxJQUFDOzs7OztnQkFBbEIsZUFBZTs7Ozs7Ozs7O09BQWtELE1BQUc7T0FBd0IsU0FBTSxXQUFqQyxNQUFHO09BQXlHLFNBQU0sYUFBdkYsU0FBTTswQkFBMkUsU0FBTTs7V0FBTixTQUFNO1dBQWxILE1BQUc7V0FBN3BDLFVBQU87V0FBbkMsTUFBRzs7OytDQUFvTixtQkFBbUIsR0FBRyxJQUFJLElBQUMsbUJBQW1CLEdBQUMsa0JBQWtCO0lBQTBnQyxTQUFNLGtCQUFxRCxnQkFBZ0IsMkJBQUUsYUFBYSxHQUFHLE9BQU87OytCQUFHLGdCQUFnQjtPQUFDLFNBQVM7NkJBQUMsbUJBQW1CLEdBQUcsSUFBSSxJQUFDLGlCQUFpQixHQUFDLGNBQWM7OztvQkFBbDRDLFNBQU0sY0FBNkIsa0JBQWtCLEVBQUMsS0FBSzs7O0lBQXlTLFFBQU07YUFBQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxrQkFBa0I7O2FBQTdDLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLGtCQUFrQjs7Ozs7SUFBc00sT0FBSzthQUFDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLFFBQVE7O2FBQW5DLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLFFBQVE7Ozs7O0lBQStFLFFBQUs7YUFBQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxVQUFVOzthQUFyQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxVQUFVOzs7OztJQUFtRixRQUFLO2FBQWdDLEdBQVU7a0JBQUUsY0FBYyxFQUFDLFlBQVk7O2FBQXZDLEdBQVU7Y0FBRSxjQUFjLFFBQWQsY0FBYyxFQUFDLFlBQVk7Ozs7O0lBQWtDLFFBQUs7YUFBZ0MsR0FBVTtrQkFBRSxjQUFjLEVBQUMsTUFBTTs7YUFBakMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsTUFBTTs7OztvQkFBNEcsU0FBTSxjQUFpQyxrQkFBa0IsRUFBQyxLQUFLO29CQUFrQixTQUFNLEVBQTJCLGNBQWM7c0JBQWoxQyxNQUFHOzs7OztjQUF2QixrQkFBa0I7Ozs7Ozs7Ozs7Ozs7T0FDRixNQUFHO09BQThDLFVBQU8sV0FBeEQsTUFBRztPQUFpSCxTQUFNLFdBQXpFLFVBQU87T0FBNFYsTUFBRyxhQUFuUyxTQUFNOzs7O0tBQTBSLE1BQUc7OztNQUErQixhQUFhO01BQUMscUJBQXFCO01BQUMsc0JBQXNCO01BQUMsdUJBQXVCO01BQUMsYUFBYTs7O2dCQUFLLEtBQUs7VUFBRSxTQUFNOzs2QkFBTixTQUFNOztjQUFOLFNBQU07Ozs7aUNBQU4sU0FBTTt1Q0FBZSxVQUFVLEVBQUMsV0FBVyxFQUFHLEtBQUssMkJBQUUsVUFBVSxFQUFDLGdCQUFnQixFQUFHLE9BQU87Ozs7O2VBQWpHLEtBQUssa0JBQWtMLGdCQUFnQixDQUFDLEtBQUs7Ozt1QkFBdE0sU0FBTSxRQUFvRyxDQUFDO2dCQUFBLFVBQVUsUUFBVixVQUFVLEVBQUMsZ0JBQWdCLEdBQUMsT0FBTztnQkFBQyxVQUFVLFFBQVYsVUFBVSxFQUFDLFdBQVcsR0FBQyxLQUFLO01BQUMsQ0FBQzs7eUJBQTdLLFNBQU07Ozs7Ozs7OztXQUFwSixNQUFHOztPQUEwVyxTQUFNLGFBQW5YLE1BQUc7MEJBQTBXLFNBQU07O1dBQU4sU0FBTTs7MkJBQU4sU0FBTTs7OztTQUFxUyxRQUFLO1NBQTBCLFFBQUsscUJBQXBDLFFBQUs7OzZCQUEwQixRQUFLO2FBQXBDLFFBQUs7OztNQUEwQixRQUFLO2VBQTJDLEdBQVU7b0JBQUUsVUFBVSxFQUFDLGtCQUFrQjs7ZUFBekMsR0FBVTtnQkFBRSxVQUFVLFFBQVYsVUFBVSxFQUFDLGtCQUFrQjs7Ozt3QkFBeEgsUUFBSzs7Ozs7O2FBMU1oa0MsVUFBVTs2Q0EwTTBnQyxVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTzs7Ozs7Ozs7OztPQUErSyxRQUFLO09BQTJCLFFBQU0scUJBQXRDLFFBQUs7OztVQUE4QyxVQUFVOzs7OztpQkFBN0IsUUFBTSxZQUFpRCxTQUFTLEVBQUMsZUFBZSxFQUFDLFFBQVEsRUFBQyxXQUFXLHVCQUFLLFNBQVM7U0FBRSxRQUFNOzRCQUFOLFFBQU07O2FBQU4sUUFBTTs7Ozs7Ozs7Z0RBQVEsU0FBUztRQUF2QixRQUFNLFVBQU4sUUFBTSxXQUFRLFNBQVM7Ozs7O1FBQWxDLFNBQVM7d0JBQTRCLFNBQVMsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFDLEdBQUcsRUFBRSxXQUFXOzs7Ozt3QkFBbkUsUUFBTTs7Ozs7Ozs7V0FBM0gsUUFBTTtXQUF0QyxRQUFLOzsyQkFBTCxRQUFLOzs7O1NBQXlRLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixXQUFXO3dCQUFqQyxJQUFDOzs7OztnQkFBZCxXQUFXOzs7Ozs7Ozs7T0FBOEMsTUFBRztPQUF3QixTQUFNLFdBQWpDLE1BQUc7T0FBb0ssU0FBTSxhQUFsSixTQUFNOzBCQUFzSSxTQUFNOztXQUFOLFNBQU07V0FBN0ssTUFBRztXQUFyK0MsVUFBTztXQUF4RCxNQUFHOzs7O1dBMU1sQixVQUFVOzsyQ0EwTXE1QixVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTztRQUFDLHFCQUFxQjtRQUFDLDBDQUEwQzs7O0lBQXdqQixTQUFNLGtCQUFrRyxZQUFZO0lBQXdCLFNBQU0sa0JBQWlELFlBQVk7K0JBQUcsWUFBWSxJQUFDLFNBQVMsR0FBQyxxQkFBcUI7OztvQkFBeHJELFNBQU0sY0FBNkIsY0FBYyxFQUFDLEtBQUs7b0JBQXNsQixTQUFNLGlCQUFxRCxVQUFVLFFBQVYsVUFBVSxFQUFDLGdCQUFnQix5QkFBQyxVQUFVLEVBQUMsZ0JBQWdCLEVBQUcsT0FBTyxJQUFDLE9BQU8sR0FBQyxPQUFPOzs7SUFBNFcsUUFBTTthQUFDLEdBQVU7a0JBQUUsVUFBVSxFQUFDLGVBQWU7O2FBQXRDLEdBQVU7Y0FBRSxVQUFVLFFBQVYsVUFBVSxFQUFDLGVBQWU7Ozs7b0JBQXdRLFNBQU0sUUFBaUMsQ0FBQzthQUFBLFVBQVUsUUFBVixVQUFVLEVBQUMsZ0JBQWdCLEdBQUMsU0FBUztJQUFDLFVBQVU7R0FBRyxDQUFDOztvQkFBZ0QsU0FBTSxFQUEyQixVQUFVO3NCQUFydUQsTUFBRzs7Ozs7Y0FBbkIsY0FBYzs7Ozs7Ozs7Ozs7OztPQUVoQixNQUFHO09BQWdFLFVBQU8sV0FBMUUsTUFBRztPQUErSSxTQUFNLFdBQXJGLFVBQU87T0FBaUwsSUFBRSxhQUEzRyxTQUFNOzBCQUFtRyxJQUFFOztXQUFGLElBQUU7O09BQWdKLFFBQUssYUFBdkosSUFBRTtPQUFnSyxRQUFLLHFCQUFyQixRQUFLOzsyQkFBVyxRQUFLO1dBQXJCLFFBQUs7O09BQTZHLFFBQUssYUFBdkgsUUFBSztPQUE2SCxRQUFNLHFCQUF0QixRQUFLOzs7VUFBOEIsUUFBUTs7Ozs7O0tBQTNCLFFBQU07OztNQUF3QyxNQUFNO01BQUMsU0FBUztNQUFDLFVBQVU7TUFBQyxXQUFXO01BQUMsaUJBQWlCO01BQUMsT0FBTzs7O2dCQUFLLElBQUk7VUFBRSxRQUFNOzZCQUFOLFFBQU07O2NBQU4sUUFBTTs7Ozs7Ozs7aURBQVEsSUFBSTtTQUFsQixRQUFNLFVBQU4sUUFBTSxXQUFRLElBQUk7OztlQUF4QixJQUFJLGtCQUF1QixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBQyxHQUFHOzs7eUJBQTVDLFFBQU07Ozs7Ozs7OztXQUFoSSxRQUFNO1dBQXRCLFFBQUs7O09BQXFOLFFBQUssYUFBL04sUUFBSztPQUFtUCxRQUFLLHFCQUFuQyxRQUFLOzsyQkFBeUIsUUFBSztXQUFuQyxRQUFLOztPQUF1SixRQUFLLGFBQWpLLFFBQUs7T0FBZ0wsUUFBSyxxQkFBOUIsUUFBSzs7MkJBQW9CLFFBQUs7V0FBOUIsUUFBSzs7T0FBK0ksUUFBSyxhQUF6SixRQUFLO09BQTRLLFFBQUsscUJBQWxDLFFBQUs7OzJCQUF3QixRQUFLO1dBQWxDLFFBQUs7O09BQWtKLFFBQUssYUFBNUosUUFBSztPQUEySyxRQUFLLHFCQUE5QixRQUFLOzsyQkFBb0IsUUFBSztXQUE5QixRQUFLOztPQUF1RixRQUFLLGFBQWpHLFFBQUs7T0FBMkcsUUFBSyxxQkFBekIsUUFBSzs7MkJBQWUsUUFBSztXQUF6QixRQUFLOztPQUE4RyxRQUFLLGFBQXhILFFBQUs7T0FBaUssUUFBSyxxQkFBeEQsUUFBSzs7MkJBQThDLFFBQUs7V0FBeEQsUUFBSzs7MkJBQUwsUUFBSzs7OztTQUErSSxJQUFDOzRCQUFELElBQUM7O2FBQUQsSUFBQzt3REFBcUIsU0FBUzt3QkFBL0IsSUFBQzs7Ozs7Z0JBQVosU0FBUzs7Ozs7Ozs7O09BQTRDLE1BQUc7T0FBd0IsU0FBTSxXQUFqQyxNQUFHO09BQW1HLFNBQU0sYUFBakYsU0FBTTswQkFBcUUsU0FBTTs7V0FBTixTQUFNO1dBQTVHLE1BQUc7V0FBNytDLFVBQU87V0FBMUUsTUFBRzs7O3dDQUE0UCxhQUFhLEdBQUUsSUFBSSxJQUFDLFlBQVksR0FBQyxXQUFXO0lBQXcyQyxTQUFNLGtCQUErQyxVQUFVOzsrQkFBRyxVQUFVO09BQUMsU0FBUztzQkFBQyxhQUFhLEdBQUUsSUFBSSxJQUFDLFVBQVUsR0FBQyxjQUFjOzs7b0JBQXJvRCxTQUFNLGNBQTZCLFlBQVksRUFBQyxLQUFLOzs7SUFBc04sUUFBSzthQUFDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLFFBQVE7O2FBQTdCLEdBQVU7Y0FBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLFFBQVE7Ozs7O0lBQStFLFFBQU07YUFBQyxHQUFVO2tCQUFFLFFBQVEsRUFBQyxRQUFROzthQUE3QixHQUFVO2NBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxRQUFROzs7OztJQUFvTSxRQUFLO2FBQTJDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLGlCQUFpQjs7YUFBdEMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsaUJBQWlCOzs7OztJQUFpRSxRQUFLO2FBQTJDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLGdCQUFnQjs7YUFBckMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsZ0JBQWdCOzs7OztJQUFtRSxRQUFLO2FBQTJDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLGlCQUFpQjs7YUFBdEMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsaUJBQWlCOzs7OztJQUE2RCxRQUFLO2FBQWEsR0FBVTtrQkFBRSxRQUFRLEVBQUMsZUFBZTs7YUFBcEMsR0FBVTtjQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsZUFBZTs7Ozs7SUFBaUMsUUFBSzthQUFDLEdBQVU7a0JBQUUsUUFBUSxFQUFDLFVBQVU7O2FBQS9CLEdBQVU7Y0FBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLFVBQVU7Ozs7O0lBQTZHLFFBQUs7YUFBQyxHQUFVO2tCQUFFLFFBQVEsRUFBQyxLQUFLOzthQUExQixHQUFVO2NBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxLQUFLOzs7O29CQUFzSSxTQUFNLGNBQWlDLFlBQVksRUFBQyxLQUFLO29CQUFrQixTQUFNLEVBQTJCLFFBQVE7c0JBQTVyRCxNQUFHOzs7OztjQURELFlBQVk7Ozs7Ozs7Ozs7Ozs7T0FJZCxNQUFHO09BQWdFLFVBQU8sV0FBMUUsTUFBRztPQUErSSxTQUFNLFdBQXJGLFVBQU87MkJBQXdFLFNBQU07Ozs7U0FDdkksTUFBRztTQUFxQyxJQUFDLHFCQUF6QyxNQUFHOzRCQUFxQyxJQUFDOzthQUFELElBQUM7O1NBQTRFLElBQUUsYUFBL0UsSUFBQzs0QkFBNEUsSUFBRTs7YUFBRixJQUFFOztTQUEwRSxJQUFDLGFBQTdFLElBQUU7NEJBQTBFLElBQUM7O2FBQUQsSUFBQzs7U0FBbVQsU0FBTSxhQUExVCxJQUFDOzthQUFsTSxNQUFHOzs7OztjQXJNakIsUUFBUTs4Q0FxTXFFLFFBQVEsRUFBQyxNQUFNLEVBQUcsS0FBSyxJQUFDLFdBQVcsR0FBQyxZQUFZOzs7O2NBck03SCxRQUFROzhDQXFNK0gsUUFBUSxFQUFDLE1BQU0sRUFBRyxLQUFLLElBQUMsb0JBQW9CLEdBQUMsb0JBQW9COzs7Ozs7O2NBck14TSxRQUFRO2NBVndELGNBQWM7OzhDQStNb0ksUUFBUSxFQUFDLE1BQU0sRUFBRyxLQUFLO2NBQUksS0FBSyxPQUFDLFFBQVEsRUFBQyxTQUFTLHVDQUFpQyxjQUFjLEVBQUMsVUFBVSx5Q0FBeUMsVUFBVSxPQUFDLFFBQVEsRUFBQyxVQUFVO29CQUFRLGNBQWMsRUFBQyxVQUFVOzs7OztzQkFBNEYsU0FBTSxjQUErQixrQkFBa0IsRUFBQyxLQUFLO3dCQUFsakIsTUFBRzs7Ozs7U0FFaEIsTUFBRztTQUF1RSxRQUFLLHFCQUEvRSxNQUFHO1NBQTRILFFBQUsscUJBQTFELFFBQUs7OzZCQUFnRCxRQUFLOzs2QkFBTCxRQUFLOzs7O1dBQThMLE1BQUc7NkJBQUgsTUFBRzs7OzthQUEwRCxJQUFDOzs0QkFBRCxJQUFDOzs7Ozs7Ozs7ZUFBOEQsSUFBQzs7OEJBQUQsSUFBQzs7Ozs7Ozs7Ozs7eUJBQXdELGFBQWE7O3dCQUFJLE1BQU07a0JBQUUsU0FBTTtrQkFBdUUsU0FBTSxXQUFuRixTQUFNO3FDQUF1RSxTQUFNOztzQkFBTixTQUFNOztrQkFBOEIsUUFBSyxhQUF6QyxTQUFNO3FDQUE4QixRQUFLOztzQkFBTCxRQUFLO3NCQUF0SCxTQUFNOzs7OzRDQUFkLE1BQU0seUJBQXVGLE1BQU0sRUFBQyxVQUFVOzJEQUE5RyxNQUFNLHlCQUFzSSxNQUFNLEVBQUMsVUFBVTs7Ozt1QkFBN0osTUFBTTs7Z0RBQTRKLE1BQU0sRUFBQyxTQUFTLEVBQUUsSUFBSTtvQkFBQyx3QkFBd0I7a0NBQWUsWUFBWSxPQUFDLE1BQU0sRUFBQyxTQUFTOzs7OzttQ0FBclAsU0FBTSx5QkFBZ0QsWUFBWSxPQUFDLE1BQU07aUNBQXpFLFNBQU07OztrQkFBNFEsSUFBQzs7aUNBQUQsSUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBak4xd0IsV0FBVztvQ0FpTjZYLFdBQVcsRUFBQyxJQUFJLEdBQUcsTUFBTSxHQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O29DQUE3RixrQkFBa0IsR0FBRyxTQUFTOzs7Ozs7Ozs7ZUFBM0QsTUFBRzswQkFBSCxNQUFHOzs7OztrQkFBbkIsY0FBYzs7Ozs7Ozs7O2FBQXRQLFFBQUs7OzZCQUFMLFFBQUs7Ozs7V0FBc3lCLE1BQUc7V0FBeUMsTUFBRyxxQkFBL0MsTUFBRztXQUF3RixRQUFLLHFCQUFwRCxNQUFHOzhCQUE0QyxRQUFLOztlQUFMLFFBQUs7ZUFBcEQsTUFBRztlQUEvQyxNQUFHOzs7O2VBak56ekIsY0FBYzsrQkFpTis0QixjQUFjLEVBQUMsVUFBVTs7OztnQkFqTnQ3QixjQUFjOzt5Q0FpTjY2QixjQUFjLEVBQUMsU0FBUyxFQUFFLElBQUk7YUFBQyx3QkFBd0I7MkJBQWUsWUFBWSxPQUFDLGNBQWMsRUFBQyxTQUFTOzs7OzswQkFBaFAsTUFBRzs7Ozs7a0JBQW5CLGNBQWM7Ozs7Ozs7OzthQUFuM0IsTUFBRzs7U0FDSCxNQUFHLGFBREgsTUFBRztTQUN3RixRQUFRLHFCQUFuRyxNQUFHO1NBQTJKLFFBQUsscUJBQXhFLFFBQVE7U0FBaUYsUUFBSyxXQUEzQixRQUFLOzs2QkFBaUIsUUFBSztLQUFMLFFBQUssU0FBTCxRQUFLOzthQUEzQixRQUFLOztTQUE0RixRQUFLLGFBQXRHLFFBQUs7U0FBa0gsUUFBSyxXQUEzQixRQUFLOzs2QkFBaUIsUUFBSztLQUFMLFFBQUssU0FBTCxRQUFLOzthQUEzQixRQUFLO2FBQXpLLFFBQVE7OzZCQUFSLFFBQVE7Ozs7O1dBQW1TLFFBQUs7V0FBb0IsUUFBSyxxQkFBOUIsUUFBSzs7K0JBQW9CLFFBQUs7ZUFBOUIsUUFBSzs7V0FBK0csTUFBRyxhQUF2SCxRQUFLO1dBQTRJLFFBQUssV0FBbEMsTUFBRztXQUF5QyxRQUFNLHFCQUFyQixRQUFLOzs7Y0FBNkIsUUFBUTs7Ozs7Ozs7cUJBQTNCLFFBQU0sV0FBc0MsS0FBSyxDQUFDLEVBQUUsdUJBQUssQ0FBQzthQUFRLFFBQU07O1NBQU4sUUFBTSxrQkFBa0IsS0FBSyxHQUFDLENBQUMsbUJBQUUsS0FBSyxFQUFHLENBQUM7WUFBQyxJQUFJOzRCQUFDLEtBQUssRUFBRyxDQUFDLElBQUMsSUFBSSxtQkFBQyxLQUFLLEVBQUcsQ0FBQyxJQUFDLElBQUksR0FBQyxJQUFJOztTQUFsRixRQUFNLFNBQU4sUUFBTSxXQUFRLEtBQUssR0FBQyxDQUFDOzRCQUFyQixRQUFNOzs7Ozs7OztlQUF4RSxRQUFNO2VBQXJCLFFBQUs7O1dBQWdOLFFBQUssYUFBMU4sUUFBSztXQUFrTyxRQUFLLHFCQUF2QixRQUFLOzsrQkFBYSxRQUFLO2VBQXZCLFFBQUs7ZUFBdlAsTUFBRzs7O1FBQTlGLFFBQUs7aUJBQTJDLEdBQVU7c0JBQUUsUUFBUSxFQUFDLFNBQVM7O2lCQUE5QixHQUFVO2tCQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsU0FBUzs7Ozs7UUFBeUQsUUFBTTtpQkFBQyxHQUFVO3NCQUFFLFFBQVEsRUFBQyxPQUFPOztpQkFBNUIsR0FBVTtrQkFBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLE9BQU87Ozs7O1FBQXFMLFFBQUs7aUJBQWMsR0FBVTtzQkFBRSxRQUFRLEVBQUMsVUFBVTs7aUJBQS9CLEdBQVU7a0JBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxVQUFVOzs7Ozs7Ozs7O2VBeE1qekIsUUFBUTsrQ0F3TXNXLFFBQVEsRUFBQyxNQUFNLEVBQUcsS0FBSzs7Ozs7Ozs7OzthQUFwWSxNQUFHOztTQUNILE1BQUcsYUFESCxNQUFHO1NBQ3FHLFVBQVEscUJBQWhILE1BQUc7U0FBOEosUUFBSyxxQkFBOUQsVUFBUTtTQUF1RSxRQUFLLFdBQTNCLFFBQUs7OzZCQUFpQixRQUFLO0tBQUwsUUFBSyxTQUFMLFFBQUs7O2FBQTNCLFFBQUs7O1NBQThGLFFBQUssYUFBeEcsUUFBSztTQUFvSCxRQUFLLFdBQTNCLFFBQUs7OzZCQUFpQixRQUFLO0tBQUwsUUFBSyxTQUFMLFFBQUs7O2FBQTNCLFFBQUs7YUFBakssVUFBUTs7NkJBQVIsVUFBUTs7Ozs7V0FBcVMsTUFBRztXQUEwQixRQUFLLFdBQWxDLE1BQUc7V0FBOEMsUUFBSyxxQkFBekIsUUFBSzs7K0JBQWUsUUFBSztlQUF6QixRQUFLOztXQUE4SCxRQUFLLGFBQXhJLFFBQUs7V0FBMEosUUFBSyxxQkFBakMsUUFBSzs7K0JBQXVCLFFBQUs7ZUFBakMsUUFBSztlQUFySyxNQUFHOzs7O1FBQThDLFFBQUs7aUJBQTRELEdBQVU7c0JBQUUsUUFBUSxFQUFDLFlBQVk7O2lCQUFqQyxHQUFVO2tCQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsWUFBWTs7Ozs7UUFBeUMsUUFBSztpQkFBOEMsR0FBVTtzQkFBRSxRQUFRLEVBQUMsYUFBYTs7aUJBQWxDLEdBQVU7a0JBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxhQUFhOzs7Ozs7Ozs7O2VBek12cUIsUUFBUTsrQ0F5TWlYLFFBQVEsRUFBQyxVQUFVLEVBQUcsS0FBSzs7Ozs7Ozs7OzthQUFuWixNQUFHOzs2QkFBSCxNQUFHOzs7O1dBQ1ksSUFBQzs4QkFBRCxJQUFDOztlQUFELElBQUM7MERBQXFCLFNBQVM7MEJBQS9CLElBQUM7Ozs7O2tCQUFaLFNBQVM7Ozs7Ozs7OztTQUE0QyxNQUFHO1NBQXdCLFNBQU0sV0FBakMsTUFBRztTQUF5RyxTQUFNLGFBQXZGLFNBQU07NEJBQTJFLFNBQU07O2FBQU4sU0FBTTthQUFsSCxNQUFHOzs7a0JBSG1FLFFBQUssUUFBUSxXQUFXO01BR2MsU0FBTSxrQkFBcUQsVUFBVTtpQ0FBRyxVQUFVLElBQUMsV0FBVyxHQUFDLGlCQUFpQjs7O3NCQUh0SixRQUFLLGNBQW1DLGNBQWMsRUFBQyxJQUFJO3NCQUEzRCxRQUFLLEdBQWtFLENBQUMsS0FBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLOzs7OztNQUN4RCxRQUFLO2VBQWMsR0FBVTtvQkFBRSxRQUFRLEVBQUMsTUFBTTs7ZUFBM0IsR0FBVTtnQkFBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLE1BQU07Ozs7Ozs7TUFBbUQsUUFBSztlQUFjLEdBQVU7b0JBQUUsUUFBUSxFQUFDLE1BQU07O2VBQTNCLEdBQVU7Z0JBQUUsUUFBUSxRQUFSLFFBQVEsRUFBQyxNQUFNOzs7Ozs7O01BQzVJLFFBQUs7ZUFBYyxHQUFVO29CQUFFLFFBQVEsRUFBQyxVQUFVOztlQUEvQixHQUFVO2dCQUFFLFFBQVEsUUFBUixRQUFRLEVBQUMsVUFBVTs7Ozs7OztNQUFpRCxRQUFLO2VBQWMsR0FBVTtvQkFBRSxRQUFRLEVBQUMsVUFBVTs7ZUFBL0IsR0FBVTtnQkFBRSxRQUFRLFFBQVIsUUFBUSxFQUFDLFVBQVU7Ozs7c0JBQ3hQLFNBQU0sY0FBaUMsa0JBQWtCLEVBQUMsS0FBSztzQkFBa0IsU0FBTSxFQUEyQixjQUFjOzs7Ozs7Z0JBTGxOLFNBQVM7Ozs7Ozs7OztXQURvRCxVQUFPO1dBQTFFLE1BQUc7b0JBQStJLFNBQU0sY0FBNkIsa0JBQWtCLEVBQUMsS0FBSztzQkFBN00sTUFBRzs7Ozs7Y0FERCxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7T0FXcEIsTUFBRztPQUFnRSxVQUFPLFdBQTFFLE1BQUc7T0FBK0ksU0FBTSxXQUFyRixVQUFPO09BQWdYLE1BQUcsYUFBM1MsU0FBTTtPQUE2VyxRQUFLLHFCQUFoRixNQUFHO09BQTRILFFBQUsscUJBQXpELFFBQUs7OzJCQUErQyxRQUFLOzsyQkFBTCxRQUFLOzs7O1NBQW9MLE1BQUc7MkJBQUgsTUFBRzs7OztXQUF5RCxJQUFDOzswQkFBRCxJQUFDOzs7Ozs7Ozs7YUFBb0UsSUFBQzs7NEJBQUQsSUFBQzs7Ozs7Ozs7Ozs7dUJBQTJDLFlBQVk7O3NCQUFJLEtBQUs7Z0JBQUUsU0FBTTtnQkFBcUUsU0FBTSxXQUFqRixTQUFNO21DQUFxRSxTQUFNOztvQkFBTixTQUFNOztnQkFBcUMsUUFBSyxhQUFoRCxTQUFNO21DQUFxQyxRQUFLOztvQkFBTCxRQUFLO29CQUEzSCxTQUFNOzs7OztxQkFBYixLQUFLO3FDQUFxRixLQUFLLEVBQUMsSUFBSSxVQUFFLEtBQUssRUFBQyxNQUFNOzs7NkNBQWxILEtBQUsseUJBQStILEtBQUssRUFBQyxNQUFNO3FCQUFoSixLQUFLO3FDQUE2SSxLQUFLLEVBQUMsUUFBUSxlQUFPLEtBQUssRUFBQyxRQUFRLEtBQUcsRUFBRTs7Ozs7cUJBQTFMLEtBQUs7OzhDQUEwTCxLQUFLLEVBQUMsV0FBVyxFQUFFLElBQUk7a0JBQUMsMEJBQTBCO2tDQUFpQixZQUFZLE9BQUMsS0FBSyxFQUFDLFdBQVc7Ozs7O2lDQUF6UixTQUFNLHlCQUFnRCxXQUFXLE9BQUMsS0FBSzsrQkFBdkUsU0FBTTs7O2dCQUFnVCxJQUFDOzsrQkFBRCxJQUFDOzs7Ozs7Ozs7Ozs7Ozs7O3FDQUF2WixpQkFBaUIsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2tDQUFsRyxpQkFBaUIsR0FBRyxTQUFTOzs7Ozs7Ozs7YUFBMUQsTUFBRzt3QkFBSCxNQUFHOzs7Ozs7YUF0Ti9xQixVQUFVO2FBQUssYUFBYTs2QkFzTm1tQixVQUFVLEVBQUMsSUFBSSxHQUFHLE1BQU0sSUFBRSxDQUFDLFdBQUcsYUFBYTs7Ozs7Ozs7OztXQUEzTyxRQUFLOzs0QkFBTCxRQUFLOzs7O1NBQTB6QixNQUFHO1NBQXlDLE1BQUcscUJBQS9DLE1BQUc7U0FBcUYsUUFBSyxxQkFBakQsTUFBRzs0QkFBeUMsUUFBSzs7YUFBTCxRQUFLO2FBQWpELE1BQUc7YUFBL0MsTUFBRzs7OzthQXRObHZDLGFBQWE7NkJBc05pMEMsYUFBYSxFQUFDLE1BQU07O2FBdE5sMkMsYUFBYTs2QkFzTnUxQyxhQUFhLEVBQUMsUUFBUSxlQUFPLGFBQWEsRUFBQyxRQUFRLEtBQUcsRUFBRTs7OztjQXRONTVDLGFBQWE7O3VDQXNObzVDLGFBQWEsRUFBQyxXQUFXLEVBQUUsSUFBSTtXQUFDLDBCQUEwQjsyQkFBaUIsWUFBWSxPQUFDLGFBQWEsRUFBQyxXQUFXOzs7Ozt3QkFBblMsTUFBRzs7Ozs7Z0JBQWxCLGFBQWE7Ozs7Ozs7OztXQUF4NEIsTUFBRzs7T0FBOHNDLE1BQUcsYUFBcHRDLE1BQUc7T0FBMnhDLE9BQUcscUJBQWhGLE1BQUc7T0FBdUcsUUFBSyxXQUFsQyxPQUFHO09BQTRDLFFBQUsscUJBQXZCLFFBQUs7OzJCQUFhLFFBQUs7V0FBdkIsUUFBSzs7T0FBeUgsUUFBSyxhQUFuSSxRQUFLO09BQXFKLFFBQUsscUJBQWpDLFFBQUs7OzJCQUF1QixRQUFLO1dBQWpDLFFBQUs7V0FBaEssT0FBRztXQUFoRixNQUFHOzs0QkFBSCxNQUFHOzs7O1NBQWdZLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixVQUFVO3dCQUFoQyxJQUFDOzs7OztnQkFBYixVQUFVOzs7Ozs7Ozs7T0FBNkMsT0FBRztPQUF3QixTQUFNLFdBQWpDLE9BQUc7T0FBb0csU0FBTSxhQUFsRixTQUFNOzBCQUFzRSxTQUFNOztXQUFOLFNBQU07V0FBN0csT0FBRztXQUF6L0QsVUFBTztXQUExRSxNQUFHOzs7Z0JBQXNqQixRQUFLLFFBQVEsVUFBVTtJQUFnbEQsU0FBTSxrQkFBZ0QsV0FBVzsrQkFBRyxXQUFXLElBQUMsU0FBUyxHQUFDLFdBQVc7OztvQkFBbm5FLFNBQU0sY0FBNkIsYUFBYSxFQUFDLEtBQUs7b0JBQWlYLFFBQUssR0FBOEIsQ0FBQyxLQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUs7OztJQUF3b0MsUUFBSzthQUE0RCxHQUFVO2tCQUFFLFNBQVMsRUFBQyxRQUFROzthQUE5QixHQUFVO2NBQUUsU0FBUyxRQUFULFNBQVMsRUFBQyxRQUFROzs7OztJQUF5QyxRQUFLO2FBQThDLEdBQVU7a0JBQUUsU0FBUyxFQUFDLGFBQWE7O2FBQW5DLEdBQVU7Y0FBRSxTQUFTLFFBQVQsU0FBUyxFQUFDLGFBQWE7Ozs7b0JBQStHLFNBQU0sY0FBaUMsYUFBYSxFQUFDLEtBQUs7b0JBQWtCLFNBQU0sRUFBMkIsU0FBUztzQkFBMXNFLE1BQUc7Ozs7O2NBREQsYUFBYTs7Ozs7Ozs7Ozs7OztPQUdFLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQTZHLFNBQU0sV0FBdkUsVUFBTztPQUFrSyxJQUFFLGFBQTFHLFNBQU07MEJBQWtHLElBQUU7O1dBQUYsSUFBRTs7T0FBb0osUUFBSyxhQUEzSixJQUFFO09BQXlLLFFBQUsscUJBQTFCLFFBQUs7OzJCQUFnQixRQUFLO1dBQTFCLFFBQUs7O09BQXlGLFFBQUssYUFBbkcsUUFBSztPQUF3RyxRQUFLLHFCQUFwQixRQUFLOzsyQkFBVSxRQUFLO1dBQXBCLFFBQUs7O09BQXNGLFFBQUssYUFBaEcsUUFBSztPQUF3RyxRQUFLLHFCQUF2QixRQUFLOzsyQkFBYSxRQUFLO1dBQXZCLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBNkYsSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLFNBQVM7d0JBQS9CLElBQUM7Ozs7O2dCQUFaLFNBQVM7Ozs7Ozs7OztPQUE0QyxPQUFHO09BQXdCLFNBQU0sV0FBakMsT0FBRztPQUFtRyxTQUFNLGFBQWpGLFNBQU07MEJBQXFFLFNBQU07O1dBQU4sU0FBTTtXQUE1RyxPQUFHO1dBQXZvQixVQUFPO1dBQXRELE9BQUc7Ozs7V0EvTWpCLGFBQWE7MkJBK000TyxhQUFhLEVBQUMsVUFBVTs7O0lBQXNoQixTQUFNLGtCQUFzRCxhQUFhOytCQUFHLGFBQWEsSUFBQyxTQUFTLEdBQUMsVUFBVTs7O29CQUF2eEIsU0FBTSxjQUE2QixhQUFhLEVBQUMsSUFBSTs7O0lBQThOLFFBQUs7YUFBMEIsR0FBVTtrQkFBRSxXQUFXLEVBQUMsTUFBTTs7YUFBOUIsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsTUFBTTs7Ozs7SUFBMkIsUUFBSzthQUFnQyxHQUFVO2tCQUFFLFdBQVcsRUFBQyxHQUFHOzthQUEzQixHQUFVO2NBQUUsV0FBVyxRQUFYLFdBQVcsRUFBQyxHQUFHOzs7OztJQUE4QixRQUFLO2FBQWMsR0FBVTtrQkFBRSxXQUFXLEVBQUMsVUFBVTs7YUFBbEMsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsVUFBVTs7OztvQkFBZ0csU0FBTSxjQUFpQyxhQUFhLEVBQUMsSUFBSTtvQkFBa0IsU0FBTSxFQUEyQixlQUFlO3NCQUF6MEIsT0FBRzs7Ozs7Y0FBbEIsYUFBYTs7Ozs7Ozs7Ozs7OztPQUNJLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQTZHLFNBQU0sV0FBdkUsVUFBTztPQUF5SyxLQUFFLGFBQWpILFNBQU07MEJBQXlHLEtBQUU7O1dBQUYsS0FBRTs7T0FBa0MsUUFBSyxhQUF6QyxLQUFFO09BQXVELFFBQUsscUJBQTFCLFFBQUs7OzJCQUFnQixRQUFLO1dBQTFCLFFBQUs7O09BQTJGLFFBQUssYUFBckcsUUFBSztPQUFnSCxRQUFLLHFCQUExQixRQUFLOzsyQkFBZ0IsUUFBSztXQUExQixRQUFLOztPQUE4RixRQUFLLGFBQXhHLFFBQUs7T0FBZ0gsUUFBSyxxQkFBdkIsUUFBSzs7MkJBQWEsUUFBSztXQUF2QixRQUFLOztPQUFnRixPQUFHLGFBQXhGLFFBQUs7T0FBMkcsU0FBTSxXQUFqQyxPQUFHO09BQXFHLFNBQU0sYUFBbkYsU0FBTTswQkFBdUUsU0FBTTs7V0FBTixTQUFNO1dBQTlHLE9BQUc7V0FBL2UsVUFBTztXQUF0RCxPQUFHOzs7O1dBeE5uQixlQUFlOzJCQXdOeU8sZUFBZSxFQUFDLElBQUk7OztJQUF1WSxTQUFNLGtCQUFvRCxlQUFlOytCQUFHLGVBQWUsSUFBQyxTQUFTLEdBQUMsbUJBQW1COzs7b0JBQTVvQixTQUFNLGNBQTZCLGVBQWUsRUFBQyxJQUFJOzs7SUFBaUgsUUFBSzthQUEwQixHQUFVO2tCQUFFLGFBQWEsRUFBQyxNQUFNOzthQUFoQyxHQUFVO2NBQUUsYUFBYSxRQUFiLGFBQWEsRUFBQyxNQUFNOzs7OztJQUFpQyxRQUFLO2FBQWdDLEdBQVU7a0JBQUUsYUFBYSxFQUFDLEdBQUc7O2FBQTdCLEdBQVU7Y0FBRSxhQUFhLFFBQWIsYUFBYSxFQUFDLEdBQUc7Ozs7O0lBQThCLFFBQUs7YUFBYyxHQUFVO2tCQUFFLGFBQWEsRUFBQyxVQUFVOzthQUFwQyxHQUFVO2NBQUUsYUFBYSxRQUFiLGFBQWEsRUFBQyxVQUFVOzs7O29CQUF1QyxTQUFNLGNBQWlDLGVBQWUsRUFBQyxJQUFJO29CQUFrQixTQUFNLEVBQTJCLGFBQWE7c0JBQWpyQixPQUFHOzs7OztjQUFwQixlQUFlOzs7Ozs7Ozs7Ozs7O09BQ2MsT0FBRztPQUE0QyxVQUFPLFdBQXRELE9BQUc7T0FBNkcsU0FBTSxXQUF2RSxVQUFPO09BQWtPLFFBQUssYUFBN0ssU0FBTTtPQUF3TCxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUFvRyxRQUFLLGFBQTlHLFFBQUs7T0FBZ0ksUUFBSyxxQkFBakMsUUFBSzs7MkJBQXVCLFFBQUs7V0FBakMsUUFBSzs7T0FBMkcsT0FBRyxhQUFuSCxRQUFLO09BQXNJLFNBQU0sV0FBakMsT0FBRztPQUFpSCxTQUFNLGFBQS9GLFNBQU07O1dBQWpDLE9BQUc7V0FBcmMsVUFBTztXQUF0RCxPQUFHO29CQUE2RyxTQUFNLGNBQTZCLDJCQUEyQixFQUFDLElBQUk7OztJQUEySCxRQUFLO2FBQTBCLEdBQVU7a0JBQUUscUJBQXFCLEVBQUMsTUFBTTs7YUFBeEMsR0FBVTtjQUFFLHFCQUFxQixRQUFyQixxQkFBcUIsRUFBQyxNQUFNOzs7OztJQUF3QyxRQUFLO2FBQTRCLEdBQVU7a0JBQUUscUJBQXFCLEVBQUMsS0FBSzs7YUFBdkMsR0FBVTtjQUFFLHFCQUFxQixRQUFyQixxQkFBcUIsRUFBQyxLQUFLOzs7O29CQUF1QyxTQUFNLGNBQWlDLDJCQUEyQixFQUFDLElBQUk7b0JBQWtCLFNBQU0sRUFBMkIsZ0JBQWdCO3NCQUF0cEIsT0FBRzs7Ozs7Y0FBaEMsMkJBQTJCOzs7Ozs7Ozs7Ozs7O09BQ2QsT0FBRztPQUE0QyxVQUFPLFdBQXRELE9BQUc7T0FBK0csU0FBTSxXQUF6RSxVQUFPOzRCQUE0RCxTQUFNOzs7O1NBQTZGLEtBQUU7O3dCQUFGLEtBQUU7Ozs7Ozs7OztXQUFtRSxLQUFFOzswQkFBRixLQUFFOzs7OztXQUE4RSxLQUFFOzhCQUFGLEtBQUU7O2VBQUYsS0FBRTs7V0FBK0IsT0FBRyxhQUFwQyxLQUFFO1dBQXdELE9BQUcsV0FBNUIsT0FBRztXQUFnRCxJQUFDLHFCQUEzQixPQUFHOzhCQUF1QixJQUFDOztlQUFELElBQUM7ZUFBM0IsT0FBRzs7V0FBdUUsT0FBRyxhQUE3RSxPQUFHO1dBQStGLElBQUMscUJBQXpCLE9BQUc7OEJBQXFCLElBQUM7O2VBQUQsSUFBQztlQUF6QixPQUFHO2VBQXRHLE9BQUc7O1dBQTBMLFVBQU8sYUFBcE0sT0FBRzt3Q0FBMEwsVUFBTzs7Ozs7OztnQkExTnJiLFdBQVc7Z0NBME53ZSxXQUFXLEVBQUMsT0FBTzs7O29CQUFJLEtBQUs7Y0FBRSxPQUFHO2NBQWlDLE9BQUksV0FBeEMsT0FBRztpQ0FBaUMsT0FBSTs7a0JBQUosT0FBSTs7Y0FBMkMsU0FBTSxhQUFyRCxPQUFJO2lDQUEyQyxTQUFNOztrQkFBTixTQUFNOztjQUF3RSxPQUFJLGFBQWxGLFNBQU07Y0FBcUcsSUFBQyxXQUE5QixPQUFJO2lDQUF5QixJQUFDOztrQkFBRCxJQUFDO2tCQUE5QixPQUFJOztjQUE0RCxRQUFLLGFBQXJFLE9BQUk7aUNBQTRELFFBQUs7O2tCQUFMLFFBQUs7a0JBQXRPLE9BQUc7Ozs7Ozs7bUJBQVYsS0FBSzttREFBNkYsS0FBSyxFQUFDLElBQUksRUFBRyxLQUFLLElBQUMsc0JBQXNCLEdBQUMsaUJBQWlCOzs7Ozs7OzttQkFBN0osS0FBSzs2QkFBNEMsU0FBUyxPQUFDLEtBQUssRUFBQyxlQUFlOzs7eUJBQWhGLEtBQUssbUJBQW1NLEtBQUssT0FBQyxLQUFLLEVBQUMsTUFBTTs7O21CQUExTixLQUFLOzZCQUFnUCxZQUFZLE9BQUMsS0FBSyxFQUFDLGNBQWM7Ozs7bUJBQXRSLEtBQUs7NkJBQXVSLE1BQU0sT0FBQyxLQUFLLEVBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDOzs7Ozs2QkFBbFQsT0FBRzs7Ozs7Ozs7O2VBQXRHLFVBQU87Ozs7O2dCQTFOcmIsV0FBVztnQ0EwTnlNLFdBQVcsRUFBQyxLQUFLLENBQUMsSUFBSTs7Ozs7Ozs7Z0JBMU4xTyxXQUFXOzBCQTBONFIsS0FBSyxPQUFDLFdBQVcsRUFBQyxLQUFLLENBQUMsUUFBUTs7OztnQkExTnZVLFdBQVc7MEJBME5vVyxNQUFNLE9BQUMsV0FBVyxFQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7Ozs7Ozs7Ozs7OzttQ0FBeFQsaUJBQWlCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBbEcsaUJBQWlCLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQXBLLFVBQU87V0FBdEQsT0FBRztvQkFBK0csU0FBTSxjQUE2QixXQUFXLEVBQUMsSUFBSTtzQkFBckssT0FBRzs7Ozs7Y0FBaEIsV0FBVzs7Ozs7Ozs7Ozs7OztPQUVDLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQStHLFNBQU0sV0FBekUsVUFBTzs0QkFBNEQsU0FBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7V0FBNFEsSUFBQzs4QkFBRCxJQUFDOztlQUFELElBQUM7O1dBQXVCLFNBQU0sYUFBOUIsSUFBQzs7MERBQUUsZUFBZTt3QkFBTSxTQUFNLFFBQStCLGNBQWMsT0FBQyxVQUFVLEVBQUMsRUFBRTs7Ozs7YUFBb0MsYUFBYTs7ZUF4TnpoQixVQUFVO3lCQXdOZ2hCLFdBQVcsT0FBQyxVQUFVLEVBQUMsRUFBRTs7Ozs7YUFBdkMsYUFBYTs7O1dBQW9FLEtBQUU7OEJBQUYsS0FBRTs7ZUFBRixLQUFFOztXQUE4QixPQUFHLGFBQW5DLEtBQUU7V0FBa0YsU0FBTSxxQkFBMUQsT0FBRzs4QkFBaUQsU0FBTTs7ZUFBTixTQUFNO2VBQTFELE9BQUc7O1dBQXdHLE9BQUcsYUFBOUcsT0FBRzs7V0FBaVEsU0FBTSxxQkFBL0osT0FBRzs4QkFBc0osU0FBTTs7ZUFBTixTQUFNOztXQUFzRixJQUFDLGFBQTdGLFNBQU07OEJBQXNGLElBQUM7O2VBQUQsSUFBQztlQUF0UCxPQUFHOztXQUFxVyxPQUFHLGFBQTNXLE9BQUc7V0FBOFgsT0FBRyxXQUE1QixPQUFHO1dBQWdELElBQUMscUJBQTNCLE9BQUc7OEJBQXVCLElBQUM7O2VBQUQsSUFBQztlQUEzQixPQUFHOztXQUFnRSxPQUFHLGFBQXRFLE9BQUc7V0FBdUYsSUFBQyxxQkFBeEIsT0FBRzs4QkFBb0IsSUFBQzs7ZUFBRCxJQUFDO2VBQXhCLE9BQUc7O1dBQXNFLE9BQUcsYUFBNUUsT0FBRztXQUFtRyxJQUFDLHFCQUE5QixPQUFHOzhCQUEwQixJQUFDOztlQUFELElBQUM7ZUFBOUIsT0FBRzs7V0FBNEUsT0FBRyxhQUFsRixPQUFHO1dBQXlHLElBQUMscUJBQTlCLE9BQUc7OEJBQTBCLElBQUM7O2VBQUQsSUFBQztlQUE5QixPQUFHO2VBQXZQLE9BQUc7O2dDQUFILE9BQUc7Ozs7YUFBc1csVUFBTzswQ0FBUCxVQUFPOzs7Ozs7O2tCQXhOaDhDLFVBQVU7a0NBd05vL0MsVUFBVSxFQUFDLE9BQU87OztzQkFBSSxLQUFLO2dCQUFFLE9BQUc7Z0JBQWlDLE9BQUksV0FBeEMsT0FBRzttQ0FBaUMsT0FBSTs7b0JBQUosT0FBSTs7Z0JBQTJDLFNBQU0sYUFBckQsT0FBSTttQ0FBMkMsU0FBTTs7b0JBQU4sU0FBTTs7Z0JBQXlGLE9BQUksYUFBbkcsU0FBTTtnQkFBc0gsSUFBQyxXQUE5QixPQUFJO21DQUF5QixJQUFDOztvQkFBRCxJQUFDOztnQkFBMkIsU0FBTSxhQUFsQyxJQUFDOztvQkFBOUIsT0FBSTs7Z0JBQXVOLFFBQUssYUFBaE8sT0FBSTttQ0FBdU4sUUFBSzs7b0JBQUwsUUFBSztvQkFBbFosT0FBRzs7Ozs7OztxQkFBVixLQUFLOztxREFBNkYsS0FBSyxFQUFDLElBQUksRUFBRyxLQUFLO2tCQUFDLEtBQUs7d0NBQUMsS0FBSyxFQUFDLElBQUksRUFBRyxTQUFTLElBQUMsVUFBVSxHQUFDLGlCQUFpQjs7Ozs7Ozs7cUJBQTlLLEtBQUs7K0JBQTRDLFNBQVMsT0FBQyxLQUFLLEVBQUMsZUFBZTs7OzJCQUFoRixLQUFLLG1CQUFvTixLQUFLLE9BQUMsS0FBSyxFQUFDLE1BQU07OztxQkFBM08sS0FBSzsrQkFBMFosWUFBWSxPQUFDLEtBQUssRUFBQyxHQUFHOzs7O3FCQUFyYixLQUFLOytCQUFzYixNQUFNLE9BQUMsS0FBSyxFQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQzs7Ozs7NkJBQXRPLFNBQU0sUUFBb0MsZUFBZSxPQUFDLGFBQWEsU0FBQyxLQUFLOytCQUF4VCxPQUFHOzs7Ozs7Ozs7aUJBQXJHLFVBQU87NEJBQVAsVUFBTzs7Ozs7O2lCQXhOaDhDLFVBQVU7aUNBd05tNUMsVUFBVSxFQUFDLE9BQU8sRUFBRSxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Z0JBeE52N0MsVUFBVTtnQ0F3TnVsQixVQUFVLEVBQUMsVUFBVTs7OztrQ0FBa0gsT0FBRzs7Ozs7Ozs7OztnQkF4TjN1QixVQUFVOzBCQXdOK3FCLEtBQUssT0FBQyxVQUFVLEVBQUMsWUFBWTs7OztvQkFBc0MsTUFBTSxPQUFDLFVBQVUsRUFBQyxZQUFZLEtBQUcsQ0FBQztvQkFBa0IsTUFBTSxPQUFDLFVBQVUsRUFBQyxZQUFZLElBQUUsQ0FBQzs7OztnQkF4TmoxQixVQUFVOzBCQXdOKzNCLE1BQU0sT0FBQyxVQUFVLEVBQUMsWUFBWSxLQUFHLENBQUMsR0FBQyxHQUFHLEdBQUMsRUFBRTs7OztnQkF4Tmw3QixVQUFVOzBCQXdOMDZCLEtBQUssT0FBQyxVQUFVLEVBQUMsWUFBWTs7OztnQkF4Tmo5QixVQUFVOzBCQXdOczlCLE1BQU0sT0FBQyxVQUFVLEVBQUMsbUJBQW1CLEtBQUcsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFOzs7O2dCQXhOaGhDLFVBQVU7MEJBd053Z0MsTUFBTSxPQUFDLFVBQVUsRUFBQyxtQkFBbUIsRUFBRSxPQUFPLENBQUMsQ0FBQzs7OztnQkF4TmxrQyxVQUFVOzBCQXdONG5DLEtBQUssT0FBQyxVQUFVLEVBQUMsUUFBUTs7OztnQkF4Ti9wQyxVQUFVOzBCQXdONHJDLE1BQU0sT0FBQyxVQUFVLEVBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDOzs7O2dCQXhOeHVDLFVBQVU7MEJBd04yd0MsWUFBWSxPQUFDLFVBQVUsRUFBQyxVQUFVOzs7O2dCQXhOdnpDLFVBQVU7MEJBd04wMUMsWUFBWSxPQUFDLFVBQVUsRUFBQyxVQUFVOzs7Ozs7Ozs7Ozs7bUNBQTFsQyxnQkFBZ0IsR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O2dDQUF0SSxnQkFBZ0IsR0FBRyxTQUFTOzs7Ozs7Ozs7V0FBbEssVUFBTztXQUF0RCxPQUFHO29CQUErRyxTQUFNLGNBQTZCLFVBQVUsRUFBQyxJQUFJO3NCQUFwSyxPQUFHOzs7OztjQUFmLFVBQVU7Ozs7Ozs7Ozs7Ozs7T0FDRyxPQUFHO09BQTRDLFVBQU8sV0FBdEQsT0FBRztPQUE2RyxTQUFNLFdBQXZFLFVBQU87T0FBd0ssS0FBRSxhQUFoSCxTQUFNOzBCQUF3RyxLQUFFOztXQUFGLEtBQUU7O09BQTZKLFFBQUssYUFBcEssS0FBRTtPQUFtTCxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUFzRyxRQUFLLGFBQWhILFFBQUs7T0FBNkgsUUFBSyxxQkFBNUIsUUFBSzs7MkJBQWtCLFFBQUs7V0FBNUIsUUFBSzs7T0FBdUYsUUFBSyxhQUFqRyxRQUFLO09BQWlHLFFBQUsscUJBQWYsUUFBSzs7MkJBQUssUUFBSztXQUFmLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBc0ksSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLFlBQVk7d0JBQWxDLElBQUM7Ozs7O2dCQUFmLFlBQVk7Ozs7Ozs7OztPQUErQyxPQUFHO09BQXdCLFNBQU0sV0FBakMsT0FBRztPQUFpRyxTQUFNLGFBQS9FLFNBQU07MEJBQW1FLFNBQU07O1dBQU4sU0FBTTtXQUExRyxPQUFHO1dBQWh0QixVQUFPO1dBQXRELE9BQUc7Ozs7V0F6TitDLFdBQVc7MkJBeU40SyxXQUFXLEVBQUMsVUFBVTs7O0lBQWltQixTQUFNLGtCQUFrRCxhQUFhOytCQUFHLGFBQWEsSUFBQyxTQUFTLEdBQUMsY0FBYzs7O29CQUE5MUIsU0FBTSxjQUE2QixXQUFXLEVBQUMsSUFBSTs7O0lBQWdQLFFBQUs7YUFBc0MsR0FBVTtrQkFBRSxXQUFXLEVBQUMsTUFBTTs7YUFBOUIsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsTUFBTTs7Ozs7SUFBbUMsUUFBSzthQUFhLEdBQVU7a0JBQUUsV0FBVyxFQUFDLGVBQWU7O2FBQXZDLEdBQVU7Y0FBRSxXQUFXLFFBQVgsV0FBVyxFQUFDLGVBQWU7Ozs7O0lBQXNCLFFBQUs7YUFBMEMsR0FBVTtrQkFBRSxXQUFXLEVBQUMsR0FBRzs7YUFBM0IsR0FBVTtjQUFFLFdBQVcsUUFBWCxXQUFXLEVBQUMsR0FBRzs7OztvQkFBK0gsU0FBTSxjQUFpQyxXQUFXLEVBQUMsSUFBSTtvQkFBa0IsU0FBTSxFQUEyQixXQUFXO3NCQUE1NEIsT0FBRzs7Ozs7Y0FBaEIsV0FBVzs7Ozs7Ozs7Ozs7OztPQUNJLE9BQUc7T0FBNEMsVUFBTyxXQUF0RCxPQUFHO09BQTZHLFNBQU0sV0FBdkUsVUFBTztPQUF5VixPQUFHLGFBQWxTLFNBQU07T0FBa1QsU0FBTSxXQUEvQixPQUFHOzBCQUFzQixTQUFNOztXQUFOLFNBQU07O09BQTBDLE9BQUksYUFBcEQsU0FBTTswQkFBMEMsT0FBSTs7V0FBSixPQUFJO1dBQTdFLE9BQUc7O09BQTZJLFFBQUssYUFBckosT0FBRztPQUFtSyxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUF5RyxRQUFLLGFBQW5ILFFBQUs7T0FBZ0ksUUFBSyxxQkFBNUIsUUFBSzs7MkJBQWtCLFFBQUs7V0FBNUIsUUFBSzs7T0FBMEYsUUFBSyxhQUFwRyxRQUFLO09BQTRJLFFBQUsscUJBQXZELFFBQUs7OzJCQUE2QyxRQUFLO1dBQXZELFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBb0wsSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLGVBQWU7d0JBQXJDLElBQUM7Ozs7O2dCQUFsQixlQUFlOzs7Ozs7Ozs7T0FBa0QsT0FBRztPQUF3QixTQUFNLFdBQWpDLE9BQUc7T0FBbUcsU0FBTSxhQUFqRixTQUFNOzBCQUFxRSxTQUFNOztXQUFOLFNBQU07V0FBNUcsT0FBRztXQUF6NkIsVUFBTztXQUF0RCxPQUFHOzs7O1dBM05qQixhQUFhOzJCQTJOaWIsYUFBYSxFQUFDLElBQUksQ0FBQyxVQUFVOzs7O1dBM04zZCxhQUFhOzJCQTJOK2QsYUFBYSxFQUFDLFVBQVUsQ0FBQyxjQUFjOzs7SUFBc2pCLFNBQU0sa0JBQTBELGdCQUFnQjsrQkFBRyxnQkFBZ0IsSUFBQyxhQUFhLEdBQUMsa0JBQWtCOzs7b0JBQS9rQyxTQUFNLGNBQTZCLGFBQWEsRUFBQyxJQUFJOzs7SUFBZ1osUUFBSzthQUFzQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxNQUFNOzthQUFqQyxHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxNQUFNOzs7OztJQUFtQyxRQUFLO2FBQWEsR0FBVTtrQkFBRSxjQUFjLEVBQUMsZUFBZTs7YUFBMUMsR0FBVTtjQUFFLGNBQWMsUUFBZCxjQUFjLEVBQUMsZUFBZTs7Ozs7SUFBOEQsUUFBSzthQUEwQyxHQUFVO2tCQUFFLGNBQWMsRUFBQyxHQUFHOzthQUE5QixHQUFVO2NBQUUsY0FBYyxRQUFkLGNBQWMsRUFBQyxHQUFHOzs7O29CQUFxSSxTQUFNLGNBQWlDLGFBQWEsRUFBQyxJQUFJO29CQUFrQixTQUFNLEVBQTJCLG1CQUFtQjtzQkFBL21DLE9BQUc7Ozs7O2NBQWxCLGFBQWE7Ozs7Ozs7Ozs7Ozs7T0FDVyxPQUFHO09BQTRDLFVBQU8sV0FBdEQsT0FBRztPQUE2RyxTQUFNLFdBQXZFLFVBQU87T0FBK0ssS0FBRSxhQUF2SCxTQUFNOzBCQUErRyxLQUFFOztXQUFGLEtBQUU7O09BQWdSLFFBQUssYUFBdlIsS0FBRTtPQUFzUyxRQUFLLHFCQUEzQixRQUFLOzsyQkFBaUIsUUFBSztXQUEzQixRQUFLOztPQUE4RyxRQUFLLGFBQXhILFFBQUs7T0FBcUksUUFBSyxxQkFBNUIsUUFBSzs7MkJBQWtCLFFBQUs7V0FBNUIsUUFBSzs7T0FBK0YsUUFBSyxhQUF6RyxRQUFLO09BQXlHLFFBQUsscUJBQWYsUUFBSzs7MkJBQUssUUFBSztXQUFmLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBNkgsSUFBQzs0QkFBRCxJQUFDOzthQUFELElBQUM7d0RBQXFCLG9CQUFvQjt3QkFBMUMsSUFBQzs7Ozs7Z0JBQXZCLG9CQUFvQjs7Ozs7Ozs7O09BQXVELE9BQUc7T0FBd0IsU0FBTSxXQUFqQyxPQUFHO09BQTRHLFVBQU0sYUFBMUYsU0FBTTswQkFBOEUsVUFBTTs7V0FBTixVQUFNO1dBQXJILE9BQUc7V0FBejFCLFVBQU87V0FBdEQsT0FBRzs7OztXQTFOMUIsc0JBQXNCOzsyQ0EwTjBPLHNCQUFzQixFQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUcsS0FBSztRQUFDLHFCQUFxQjs4QkFBQyxzQkFBc0IsRUFBQyxLQUFLLENBQUMsSUFBSSxFQUFHLFNBQVMsSUFBQyxlQUFlLEdBQUMsc0JBQXNCOzs7SUFBdW5CLFVBQU0sa0JBQTBELHFCQUFxQjsrQkFBRyxxQkFBcUIsSUFBQyxTQUFTLEdBQUMsY0FBYzs7O29CQUExZ0MsU0FBTSxjQUE2QixzQkFBc0IsRUFBQyxJQUFJOzs7SUFBK1YsUUFBSzthQUFzQyxHQUFVO2tCQUFFLG1CQUFtQixFQUFDLE1BQU07O2FBQXRDLEdBQVU7Y0FBRSxtQkFBbUIsUUFBbkIsbUJBQW1CLEVBQUMsTUFBTTs7Ozs7SUFBbUMsUUFBSzthQUFhLEdBQVU7a0JBQUUsbUJBQW1CLEVBQUMsZUFBZTs7YUFBL0MsR0FBVTtjQUFFLG1CQUFtQixRQUFuQixtQkFBbUIsRUFBQyxlQUFlOzs7OztJQUFzQixRQUFLO2FBQTBDLEdBQVU7a0JBQUUsbUJBQW1CLEVBQUMsR0FBRzs7YUFBbkMsR0FBVTtjQUFFLG1CQUFtQixRQUFuQixtQkFBbUIsRUFBQyxHQUFHOzs7O29CQUFzSCxTQUFNLGNBQWlDLHNCQUFzQixFQUFDLElBQUk7b0JBQWtCLFVBQU0sRUFBMkIsbUJBQW1CO3NCQUF4aUMsT0FBRzs7Ozs7Y0FBM0Isc0JBQXNCOzs7Ozs7Ozs7Ozs7O09BRUgsT0FBRztPQUFtSyxVQUFPLFdBQTdLLE9BQUc7T0FBaVIsTUFBTSxXQUFwSCxVQUFPO09BQThQLFVBQU0scUJBQTdKLE1BQU07O1dBQU4sTUFBTTs7T0FBbU4sT0FBRyxhQUE1TixNQUFNOzBCQUFtTixPQUFHOzsyQkFBaUMsYUFBYTtXQUFqRCxPQUFHO1dBQTFVLFVBQU87V0FBN0ssT0FBRztvQkFBd2EsVUFBTSxjQUFlLGlCQUFpQixFQUFDLEtBQUs7O29CQUFqVCxVQUFPOzs7O29CQUE3SyxPQUFHLGNBQW1FLGlCQUFpQixFQUFDLEtBQUs7c0JBQTdGLE9BQUcsR0FBeUcsS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsV0FBRyxpQkFBaUIsRUFBQyxLQUFLO3NCQUFsSyxPQUFHOzs7OztjQUF0QixpQkFBaUI7Ozs7Ozs7Ozs7Ozs7T0FFSixPQUFHO09BQW1KLFVBQU8sV0FBN0osT0FBRztPQUF3UCxVQUFNLFdBQTNHLFVBQU87T0FBb0wsSUFBQyxhQUF2RixVQUFNOzBCQUFnRixJQUFDOztXQUFELElBQUM7OzRCQUFELElBQUM7Ozs7V0FBaUgsS0FBSzs7YUF4UHBkLFdBQVc7NkJBd1AwYyxXQUFXLEVBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLEVBQUUsQ0FBQyxFQUFDLENBQUMsTUFBSSxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUM7Ozs7O1dBQTFFLEtBQUs7O1dBQWdGLFdBQVc7OytCQUFoRyxLQUFLO2FBeFB6VSxVQUFVOzZCQXdQMlosS0FBSyxRQUFDLFVBQVU7Ozs7O1dBQTVCLFdBQVc7O1NBQW9CLE9BQUc7NEJBQUgsT0FBRzs7OztXQUF5QyxPQUFHOzs7cUJBQUgsT0FBRyxpQkFBK0IsS0FBSyx1QkFBSSxDQUFDO2FBQVEsR0FBQzs7OzBEQUFELEdBQUMscURBQWUsS0FBSyxRQUFHLFVBQVU7NEJBQWxDLEdBQUM7Ozs7Ozs7O2VBQXJELE9BQUc7MEJBQUgsT0FBRzs7Ozs7O2lDQUFuSyxLQUFLOytCQUEySSxLQUFLLEVBQUMsTUFBTSxHQUFDLENBQUM7Ozs7Ozs7Ozs7U0FBaUgsU0FBTzs0QkFBUCxTQUFPOzs7O1dBQTBOLElBQUM7OEJBQUQsSUFBQzs7ZUFBRCxJQUFDOzs7Z0NBQTVaLFdBQVc7OEJBQXlhLFdBQVcsRUFBQyxPQUFPOzs7MEJBQTVDLElBQUM7Ozs7OztpQ0FBNVosV0FBVzsrQkFBMlgsV0FBVyxFQUFDLE9BQU87Ozs7Ozs7Ozs7Ozs7O1dBQTRILE9BQUc7V0FBdUIsT0FBSSxXQUE5QixPQUFHOzhCQUF1QixPQUFJOztlQUFKLE9BQUk7O1dBQTBDLFNBQU0sYUFBcEQsT0FBSTs4QkFBMEMsU0FBTTs7ZUFBTixTQUFNO2VBQTlFLE9BQUc7Ozs7aUNBQXhoQixXQUFXOytCQUEwaUIsV0FBVyxFQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsS0FBSzs7OztpQ0FBcGxCLFdBQVc7K0JBQTBsQixXQUFXLEVBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxZQUFZOzs7OzBCQUF0SCxPQUFHOzs7Ozs7aUNBQXhoQixXQUFXOytDQUEyYyxXQUFXLEVBQUMsTUFBTSxFQUFHLFdBQVcsV0FBRSxXQUFXLEVBQUMsVUFBVSxHQUFHLENBQUM7Ozs7Ozs7Ozs7U0FBK0ksSUFBRTs0QkFBRixJQUFFOzthQUFGLElBQUU7O1NBQTBCLElBQUMsYUFBN0IsSUFBRTs0QkFBMEIsSUFBQzs7YUFBRCxJQUFDOzs4QkFBRCxJQUFDOzs7O1dBQTRELE9BQUc7Ozs7U0FBSCxPQUFHOzs7a0NBQTd2QixXQUFXO2dDQUF5eEIsV0FBVyxFQUFDLFVBQVU7OztvQkFBSSxTQUFTO2NBQUUsT0FBRztjQUFFLE9BQUksV0FBVCxPQUFHO2lDQUFFLE9BQUk7O2tCQUFKLE9BQUk7O2NBQTBCLFNBQU0sYUFBcEMsT0FBSTtpQ0FBMEIsU0FBTTs7a0JBQU4sU0FBTTtrQkFBekMsT0FBRzs7O3VDQUFkLFNBQVMseUJBQWEsU0FBUyxFQUFDLEtBQUs7OztrQkFBckMsU0FBUztrQ0FBNkMsU0FBUyxFQUFDLFlBQVk7Ozs7NkJBQWpFLE9BQUc7Ozs7Ozs7OztlQUFsRixPQUFHOzBCQUFILE9BQUc7Ozs7OztpQ0FBN3ZCLFdBQVc7K0JBQStzQixXQUFXLEVBQUMsVUFBVSxFQUFFLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7O2dDQUF4dkIsV0FBVzs4QkFBdzZCLFdBQVcsRUFBQyxPQUFPOzs7a0JBQVEsTUFBTTs7Ozs7O2NBQXFDLFVBQU07aUNBQU4sVUFBTTs7a0JBQU4sVUFBTTs4REFBakQsTUFBTSx5QkFBMkksTUFBTSxFQUFDLEtBQUs7MkJBQWxILFVBQU0sRUFBd0UscUJBQXFCOzZCQUFuRyxVQUFNOzs7Ozs7Ozs7Z0JBQXFLLFVBQU07bUNBQU4sVUFBTTs7b0JBQU4sVUFBTTtnRUFBNU4sTUFBTSx5QkFBNFIsTUFBTSxFQUFDLEtBQUs7OzZCQUF4RixVQUFNLFFBQW9DLENBQUM7bUJBQUEsV0FBVyxFQUFDLElBQUk7YUFBQyxTQUFTO1lBQUcsQ0FBQzs7K0JBQXpFLFVBQU07Ozs7Ozs7OztrQkFBcUksVUFBTTtxQ0FBTixVQUFNOztzQkFBTixVQUFNO2tFQUF2VyxNQUFNLHlCQUF1YixNQUFNLEVBQUMsS0FBSzs7K0JBQXhHLFVBQU07NkJBQStELG9CQUFvQjs7O2lDQUF6RixVQUFNOzs7Ozs7Ozt1QkFBdlcsTUFBTTt1REFBNFQsTUFBTSxFQUFDLElBQUksRUFBRyxlQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFBL1YsTUFBTTtxREFBMkssTUFBTSxFQUFDLElBQUksRUFBRyxxQkFBcUI7Ozs7Ozs7Ozs7Ozs7Ozs7OztrQkFBcE4sTUFBTTtrREFBTSxNQUFNLEVBQUMsSUFBSSxFQUFHLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFBN3pCLFNBQU87OzhCQUFQLFNBQU87Ozs7V0FBMndDLE9BQUc7V0FBOEIsVUFBTSxXQUF2QyxPQUFHO1dBQXVHLE9BQUksYUFBN0UsVUFBTTs4QkFBbUUsT0FBSTs7ZUFBSixPQUFJOztXQUF5QyxVQUFNLGFBQW5ELE9BQUk7O2VBQTlHLE9BQUc7OztRQUE4QixVQUFNLGtDQUFXLFVBQVUsR0FBRyxDQUFDOztzQ0FBZ0QsVUFBVSxJQUFDLENBQUM7aUNBQTdwRCxLQUFLOytCQUE4cEQsS0FBSyxFQUFDLE1BQU07OztRQUFTLFVBQU07ZUF4UGxnRSxVQUFVO2lDQXdQMFQsS0FBSzsrQ0FBb3NELFVBQVUsU0FBRyxLQUFLLEVBQUMsTUFBTSxHQUFDLENBQUM7Ozs7d0JBQWxLLFVBQU0sY0FBeUMsVUFBVSxRQUFWLFVBQVUsSUFBRSxDQUFDO3dCQUEwRCxVQUFNLGNBQXNELFVBQVUsUUFBVixVQUFVLElBQUUsQ0FBQzswQkFBaE8sT0FBRzs7Ozs7O2lDQUFwaUQsS0FBSzsrQkFBNGdELEtBQUssRUFBQyxNQUFNLEdBQUMsQ0FBQzs7Ozs7Ozs7OzthQUEzNkMsT0FBRzs7O2tCQUF3SixTQUFPOytCQUFqTSxXQUFXO3VEQUF3TixXQUFXLEVBQUMsS0FBSyxJQUFFLGNBQWM7Ozs7K0JBQXBRLFdBQVc7NkJBQTBwQixXQUFXLEVBQUMsS0FBSzs7OzsrQkFBdHJCLFdBQVc7NkJBQXFyQixXQUFXLEVBQUMsSUFBSTs7OzsyQkFBdGhCLFNBQU8sR0FBc0YsS0FBSyxXQUFHLGVBQWUsRUFBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPO3lCQUE3SSxTQUFPLEdBQXNKLEtBQUssS0FBRSxhQUFhLENBQUMsS0FBSyxRQUFDLEtBQUssRUFBQyxNQUFNO3dCQUEvVixPQUFHOzs7OztVQUF2SSxPQUFPOzs7Ozs7Ozs7V0FBcFMsVUFBTztXQUE3SixPQUFHOzs7O1dBeFBmLFdBQVc7cUJBd1B5VyxXQUFXLE9BQUMsV0FBVyxHQUFFLFdBQVc7Ozs7V0F4UHhaLFdBQVc7cUJBd1BvWixTQUFTLE9BQUMsV0FBVzs7OztvQkFBN0ssVUFBTSxjQUFtQyxXQUFXLEVBQUMsSUFBSTs7b0JBQTlKLFVBQU87Ozs7b0JBQTdKLE9BQUcsY0FBaUUsV0FBVyxFQUFDLElBQUk7c0JBQXBGLE9BQUcsR0FBZ0csS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsV0FBRyxXQUFXLEVBQUMsSUFBSTtzQkFBbEosT0FBRzs7Ozs7Y0FBaEIsV0FBVzs7Ozs7Ozs7Ozs7OztPQUVXLE9BQUc7T0FBeUIsVUFBTyxXQUFuQyxPQUFHO09BQWdGLFVBQU0sV0FBN0QsVUFBTzs0QkFBZ0QsVUFBTTs7OztTQUFrVCxJQUFDOzt3QkFBRCxJQUFDOzs7Ozs7Ozs7V0FBeUUsSUFBQzs4QkFBRCxJQUFDOztlQUFELElBQUM7MERBQXFCLGVBQWU7MEJBQXJDLElBQUM7Ozs7Ozs7OzhDQUF1RCxnQkFBZ0IsdUJBQUksU0FBUzs7YUFBRSxPQUFHO2FBQXNCLFNBQU0sV0FBL0IsT0FBRztnQ0FBc0IsU0FBTTs7aUJBQU4sU0FBTTs7YUFBcUYsT0FBSSxhQUEvRixTQUFNO2dDQUFxRixPQUFJOztpQkFBSixPQUFJO2lCQUF4SCxPQUFHOztrQ0FBSCxPQUFHOzs7aURBQWQsU0FBUyx5QkFBeU4sU0FBUyxFQUFDLE9BQU8sd0JBQUksTUFBTTtlQUFFLFVBQU07a0NBQU4sVUFBTTs7bUJBQU4sVUFBTTs7O1lBQU4sVUFBTTttQkEzTzN1QixrQkFBa0I7bUJBMk9vZCxTQUFTO21EQUErVixrQkFBa0IsU0FBRyxTQUFTLEVBQUMsYUFBYTs7O3dDQUE3SixNQUFNLHlCQUEwSixNQUFNLEVBQUMsS0FBSzs7OzRCQUFwSyxVQUFNLFFBQW9DLGdCQUFnQixPQUFDLFNBQVMsRUFBQyxhQUFhLFFBQUMsTUFBTSxFQUFDLEVBQUU7OEJBQTVGLFVBQU07Ozs7Ozs7O2FBQWdMLFVBQU07Ozs7d0RBQTNiLFNBQVMseUJBQStELFNBQVMsRUFBQyxRQUFRO2tCQUExRixTQUFTO2tDQUFzRixTQUFTLEVBQUMsV0FBVzs7Ozs7V0FBaVUsVUFBTTtrQkEzT2o2QixrQkFBa0I7a0JBMk9vZCxTQUFTO2tEQUE2Z0Isa0JBQWtCLFNBQUcsU0FBUyxFQUFDLGFBQWE7Ozs7O2tCQUFsa0IsU0FBUzs0QkFBbUMsS0FBSyxPQUFDLFNBQVMsRUFBQyxNQUFNOzs7O2tCQUFsRSxTQUFTOzRCQUE0SCxTQUFTLE9BQUMsU0FBUyxFQUFDLGVBQWU7Ozs7OzBCQUE2USxVQUFNLFFBQWlDLGdCQUFnQixPQUFDLFNBQVMsRUFBQyxhQUFhLEVBQUMsSUFBSTs7Ozs7Ozs7Ozs7OzthQUFrSSxJQUFDOzs0QkFBRCxJQUFDOzs7Ozs7aUJBM090cUMsZ0JBQWdCO2tDQTJPNG5DLGdCQUFnQixFQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7O21DQUF2dkIsc0JBQXNCLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBNUcsc0JBQXNCLEdBQUcsU0FBUzs7Ozs7Ozs7O1dBQTdXLFVBQU87V0FBbkMsT0FBRztvQkFBZ0YsVUFBTSxjQUE2QixvQkFBb0IsRUFBQyxLQUFLO3NCQUFoSixPQUFHOzs7OztjQUF6QixvQkFBb0I7Ozs7Ozs7Ozs7Ozs7T0FDRCxPQUFHO09BQTBKLFVBQU8sV0FBcEssT0FBRztPQUF3UCxVQUFNLFdBQXBHLFVBQU87T0FBNk0sS0FBRSxhQUF4SCxVQUFNOzBCQUFnSCxLQUFFOztXQUFGLEtBQUU7OzRCQUFGLEtBQUU7Ozs7O1NBQTZHLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDOztTQUFrSCxPQUFHLGFBQXRILElBQUM7OzttQkFBa0gsT0FBRyxpQkFBOEIsYUFBYSx1QkFBSSxJQUFJO2FBQVMsUUFBUTs7ZUFBckIsSUFBSTswQkFBa0IsT0FBTyxFQUFDLElBQUksT0FBQyxJQUFJLEVBQUMsUUFBUTs7Ozs7YUFBbkMsUUFBUTs7YUFBcUMsUUFBUTs7ZUFBbEUsSUFBSTsrQ0FBK0QsSUFBSSxFQUFDLFVBQVUsRUFBRyxpQkFBaUI7Ozs7O2FBQTVDLFFBQVE7O2FBQTZDLFNBQVM7O2VBQXhILElBQUk7K0NBQXFILElBQUksRUFBQyxVQUFVLEVBQUcsb0JBQW9COzs7OzthQUFoRCxTQUFTOzthQUFnRCxhQUFhOztlQUFyTCxJQUFJOytDQUFrTCxJQUFJLEVBQUMsVUFBVSxFQUFHLHNCQUFzQjs7Ozs7YUFBdEQsYUFBYTs7YUFBa0QsZUFBZTs7ZUFBdFAsSUFBSTt5QkFBbVAsbUJBQW1CLE9BQUMsSUFBSSxFQUFDLFFBQVEsR0FBRyxNQUFNOzs7OzthQUExRCxlQUFlOztXQUE2QyxPQUFHOztXQUFzWCxPQUFHLFdBQTVYLE9BQUc7V0FBMlgsU0FBTSxXQUFYLE9BQUc7OEJBQUUsU0FBTTs7ZUFBTixTQUFNOztXQUEwQixPQUFJLGFBQXBDLFNBQU07OEJBQTBCLE9BQUk7O2VBQUosT0FBSTtlQUF6QyxPQUFHOztXQUFrSCxJQUFDLGFBQXRILE9BQUc7OEJBQWtILElBQUM7O2VBQUQsSUFBQzs7Z0NBQUQsSUFBQzs7OzthQUFpQyxVQUFNOzswQkFBTixVQUFNLEVBQW9FLGdCQUFnQjs0QkFBMUYsVUFBTTs7Ozs7Ozs7O2VBQXlILFVBQU07O21EQUFOLFVBQU07a0JBQXg3QixJQUFJO3FFQUF1L0IsSUFBSSxFQUFDLFFBQVE7Ozs0QkFBdEYsVUFBTSxRQUFrRyxzQkFBc0IsT0FBQyxJQUFJOzhCQUFuSSxVQUFNOzs7Ozs7Ozs7aUJBQW9LLFVBQU07O3FEQUFOLFVBQU07b0JBQWxtQyxJQUFJO2lFQUEycEMsSUFBSSxFQUFDLFFBQVE7Ozs4QkFBaEYsVUFBTSxRQUE0RixpQkFBaUIsT0FBQyxJQUFJO2dDQUF4SCxVQUFNOzs7Ozs7Ozs7bUJBQTZKLFVBQU07O3VEQUFOLFVBQU07c0JBQXJ3QyxJQUFJO3VFQUFrMEMsSUFBSSxFQUFDLFFBQVE7OztnQ0FBcEYsVUFBTSxRQUFnRyxzQkFBc0IsT0FBQyxJQUFJO2tDQUFqSSxVQUFNOzs7Ozs7OzJCQUFyQixhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7eUJBQTVLLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkFBbEwsUUFBUTs7Ozs7Ozs7Ozs7Ozs7OztvQkFBdkksUUFBUTs7Ozs7Ozs7O2VBQTlnQixPQUFHOzs7O2tDQUFILE9BQUc7cUNBQXRTLElBQUkseUJBQXFxQixJQUFJLEVBQUMsUUFBUTs7d0NBQXRyQixJQUFJLHlCQUFtc0IsSUFBSSxFQUFDLElBQUk7Z0JBQWh0QixJQUFJO2dDQUE4c0IsSUFBSSxFQUFDLElBQUksVUFBRSxJQUFJLEVBQUMsUUFBUSxHQUFDLEtBQUssR0FBQyxFQUFFOzBCQUFudkIsSUFBSSx5QkFBaXZCLElBQUksRUFBQyxRQUFROztxQ0FBbHdCLElBQUkseUJBQWd4QixJQUFJLEVBQUMsTUFBTTs7OztrQ0FBamUsUUFBUSxLQUFFLHNCQUFzQixZQUFNLFFBQVEsS0FBRSxRQUFRLE9BQUMsSUFBSSxZQUFLLFNBQVMsMkJBQUUsTUFBTSxFQUFDLElBQUksRUFBQyxLQUFLLHFCQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFJLE1BQU0sT0FBQyxJQUFJLEVBQUMsUUFBUSxLQUFJLGtCQUFrQixFQUFFLE1BQU0sRUFBRyxLQUFLLFdBQUksYUFBYSwyQkFBRSxlQUFlLEdBQUcsS0FBSzt3Q0FBZ0MsUUFBUSxLQUFFLGNBQWMsT0FBQyxJQUFJLFlBQUssYUFBYSwyQkFBRSxlQUFlLEdBQUcsV0FBVzs7Ozs7MEJBQWhXLE9BQUc7Ozs7Ozs7O2FBQXhWLE9BQUc7OztZQW5Nem1CLGFBQWE7NEJBbU1nZ0IsYUFBYSxFQUFDLE1BQU07O1lBbk1qaUIsYUFBYTs0Q0FtTWdpQixhQUFhLEVBQUMsTUFBTSxFQUFHLENBQUMsSUFBQyxZQUFZLEdBQUMsYUFBYTs7Ozs7OztTQUEwK0MsT0FBRzs7d0JBQUgsT0FBRzs7Ozs7O2FBbk03a0UsYUFBYTs2QkFtTWdkLGFBQWEsRUFBQyxNQUFNOzs7Ozs7Ozs7O1dBQWpVLFVBQU87V0FBcEssT0FBRzs7OztXQTNQckIsV0FBVztxQkEyUDRYLFlBQVksT0FBQyxXQUFXLEtBQUUsMEJBQTBCLEdBQUMscUJBQXFCOzs7O29CQUFwTSxVQUFNLGNBQTZCLGlCQUFpQixFQUFDLEtBQUs7O29CQUF4SixVQUFPOzs7O29CQUFwSyxPQUFHLGNBQXNDLGlCQUFpQixFQUFDLEtBQUs7c0JBQWhFLE9BQUcsR0FBNEUsS0FBSyxxQkFBRyxLQUFLLENBQUMsR0FBRyxFQUFHLFFBQVEsV0FBRyxpQkFBaUIsRUFBQyxLQUFLO3NCQUFySSxPQUFHOzs7OztjQUF0QixpQkFBaUI7Ozs7Ozs7Ozs7Ozs7T0FDUixPQUFHO09BQXlCLFVBQU8sV0FBbkMsT0FBRztPQUE4RixVQUFNLFdBQTNFLFVBQU87T0FBK1QsUUFBSyxhQUF0USxVQUFNO09BQXdRLFFBQUsscUJBQWxCLFFBQUs7OzJCQUFRLFFBQUs7V0FBbEIsUUFBSzs7T0FBeUcsUUFBSyxhQUFuSCxRQUFLO09BQWdJLFFBQUsscUJBQTVCLFFBQUs7OzJCQUFrQixRQUFLO1dBQTVCLFFBQUs7OzRCQUFMLFFBQUs7Ozs7U0FBOEksSUFBQzs7d0JBQUQsSUFBQzs7Ozs7Ozs7O1dBQWdILElBQUM7OEJBQUQsSUFBQzs7ZUFBRCxJQUFDOzBEQUFxQixZQUFZOzBCQUFsQyxJQUFDOzs7OztXQUE4QyxRQUFLO1dBQVUsUUFBTSxxQkFBckIsUUFBSztXQUFzRSxRQUFNLFdBQWxFLFFBQU07O09BQXNELFFBQU0sU0FBTixRQUFNOztnQ0FBTixRQUFNOzs7Ozs7O2dCQXpQNTFCLFdBQVc7Z0NBeVBxNEIsV0FBVyxFQUFDLFVBQVU7OztvQkFBSSxNQUFNO2NBQUUsU0FBTTtpQ0FBTixTQUFNOztrQkFBTixTQUFNOzs7Ozt1Q0FBZCxNQUFNLHlCQUE4QixNQUFNLEVBQUMsSUFBSTs7NkRBQS9DLE1BQU0seUJBQWdCLE1BQU0sRUFBQyxJQUFJO1lBQXpCLFNBQU0sVUFBTixTQUFNLGtCQUFkLE1BQU0seUJBQWdCLE1BQU0sRUFBQyxJQUFJOzs7OzZCQUF6QixTQUFNOzs7Ozs7Ozs7ZUFBOUosUUFBTTs7OztxQkFBTixRQUFNO2VBQXJCLFFBQUs7O1dBQTRPLFFBQUssYUFBdFAsUUFBSztXQUE4UCxRQUFNLHFCQUF4QixRQUFLOzs7Y0FBZ0MsZUFBZTs7Ozs7Ozs7V0FBNEIsU0FBTSxXQUFwRSxRQUFNOztPQUF3RCxTQUFNLFNBQU4sU0FBTTs7Z0NBQU4sU0FBTTs7OzhDQUF1RCxpQkFBaUIsdUJBQUksTUFBTTthQUFFLFNBQU07Z0NBQU4sU0FBTTs7aUJBQU4sU0FBTTs7Ozs7cUNBQWlCLE1BQU07OzJEQUFmLE1BQU07V0FBcEIsU0FBTSxVQUFOLFNBQU0saUJBQVEsTUFBTTs7Ozs0QkFBcEIsU0FBTTs7Ozs7Ozs7ZUFBOUosUUFBTTtlQUF4QixRQUFLOztXQUFxTyxRQUFLLGFBQS9PLFFBQUs7V0FBb1AsUUFBTSxxQkFBckIsUUFBSzs7O2NBQTZCLGNBQWM7Ozs7Ozs7O1dBQUcsU0FBTSxXQUExQyxRQUFNOztPQUE4QixTQUFNLFNBQU4sU0FBTTs7Z0NBQU4sU0FBTTs7Ozs7OztnQkF6UC94QyxXQUFXO2dDQXlQdzBDLFdBQVcsRUFBQyxTQUFTOzs7b0JBQUksTUFBTTtjQUFFLFNBQU07aUNBQU4sU0FBTTs7a0JBQU4sU0FBTTs7Ozs7O3dDQUFkLE1BQU0seUJBQW9DLE1BQU0sRUFBQyxJQUFJOzs7YUFBN0MsU0FBTSxVQUFOLFNBQU07Ozs7eUJBQWQsTUFBTSxtQkFBZ0IsTUFBTSxPQUFDLE1BQU0sRUFBQyxFQUFFOzs7OzZCQUE5QixTQUFNOzs7Ozs7Ozs7ZUFBckksUUFBTTtlQUFyQixRQUFLOztXQUF5TixRQUFLLGFBQW5PLFFBQUs7V0FBOE8sUUFBTSxxQkFBM0IsUUFBSzs7O2NBQW1DLGFBQWE7Ozs7Ozs7O1dBQUcsU0FBTSxXQUF6QyxRQUFNOztPQUE2QixTQUFNLFNBQU4sU0FBTTs7Z0NBQU4sU0FBTTs7Ozs7OztnQkF6UGxnRCxXQUFXO2dDQXlQMmlELFdBQVcsRUFBQyxRQUFROzs7b0JBQUksTUFBTTtjQUFFLFNBQU07aUNBQU4sU0FBTTs7a0JBQU4sU0FBTTs7Ozs7O3dDQUFkLE1BQU0seUJBQW9DLE1BQU0sRUFBQyxJQUFJOzs7YUFBN0MsU0FBTSxVQUFOLFNBQU07Ozs7eUJBQWQsTUFBTSxtQkFBZ0IsTUFBTSxPQUFDLE1BQU0sRUFBQyxFQUFFOzs7OzZCQUE5QixTQUFNOzs7Ozs7Ozs7ZUFBbkksUUFBTTtlQUEzQixRQUFLOzs7dURBQWpxQixZQUFZOztVQUExQixRQUFNLFVBQU4sUUFBTSxpQkFBUSxZQUFZOzBCQUExQixRQUFNLFFBQVEsWUFBWTs7OztRQUEwTixRQUFNLG1CQUF5QyxZQUFZOzs7eUJBQS9TLFFBQU0sRUFBaUMsa0JBQWtCOzs7UUFBMkwsUUFBTTtpQkFBQyxHQUFVO3NCQUFFLGVBQWU7O2lCQUEzQixHQUFVO2VBQUUsZUFBZTs7Ozs7UUFBcU0sUUFBTTtpQkFBQyxHQUFVO3NCQUFFLGNBQWM7O2lCQUExQixHQUFVO2VBQUUsY0FBYzs7Ozs7UUFBbU0sUUFBTTtpQkFBQyxHQUFVO3NCQUFFLGFBQWE7O2lCQUF6QixHQUFVO2VBQUUsYUFBYTs7Ozs7Ozs7Ozs7bUNBQXR6QixhQUFhLEdBQUcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztnQ0FBMUksYUFBYSxHQUFHLFNBQVM7Ozs7Ozs7Ozs7Ozs7U0FBbWxDLElBQUM7NEJBQUQsSUFBQzs7YUFBRCxJQUFDO3dEQUFxQixXQUFXO3dCQUFqQyxJQUFDOzs7OztnQkFBZCxXQUFXOzs7Ozs7Ozs7T0FBOEMsT0FBRztPQUF3QixVQUFNLFdBQWpDLE9BQUc7T0FBNkYsVUFBTSxhQUEzRSxVQUFNOzBCQUErRCxVQUFNOztXQUFOLFVBQU07V0FBdEcsT0FBRztXQUF2c0QsVUFBTztXQUFuQyxPQUFHOzs7O3FCQUFvZSxRQUFLO0tBQW8xQyxVQUFNLGtCQUErQyxNQUFNLDJCQUFFLGFBQWEsR0FBRyxPQUFPO2dDQUFHLE1BQU0sSUFBQyxTQUFTLEdBQUMsY0FBYzs7O2dDQUFwN0MsSUFBSSxHQUFHLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFDLEVBQUU7Ozs7b0JBQWhjLFVBQU0sY0FBNkIsT0FBTyxFQUFDLElBQUk7OztJQUErTixRQUFLO2FBQTBELEdBQVU7a0JBQUUsVUFBVTs7YUFBdEIsR0FBVTtXQUFFLFVBQVU7Ozs7O0lBQW1DLFFBQUs7YUFBd0QsR0FBVTtrQkFBRSxRQUFROzthQUFwQixHQUFVO1dBQUUsUUFBUTs7OztvQkFBbXNDLFVBQU0sY0FBaUMsT0FBTyxFQUFDLElBQUk7b0JBQWtCLFVBQU0sRUFBMkIsUUFBUTtzQkFBejJELE9BQUc7Ozs7O2NBQVosT0FBTzs7Ozs7Ozs7Ozs7OztPQUNHLE9BQUc7T0FBeUIsVUFBTyxXQUFuQyxPQUFHO09BQWdKLEtBQUUscUJBQXpILFVBQU87MEJBQWdILEtBQUU7O1dBQUYsS0FBRTs7T0FBdUYsT0FBRyxhQUE1RixLQUFFO09BQWtILFVBQU0sV0FBakMsT0FBRztPQUE4RixVQUFNLGFBQTVFLFVBQU07O1dBQWpDLE9BQUc7V0FBbk4sVUFBTztXQUFuQyxPQUFHOzs7aUJBM1BzSCxRQUFRLG1CQTJQNkIsUUFBUSxPQUFDLFFBQVE7OztvQkFBd0YsVUFBTSxjQUFpQyxRQUFRLEVBQUMsSUFBSTtvQkFBa0IsVUFBTSxFQUEwQyxhQUFhO3NCQUExWSxPQUFHOzs7OztjQUFiLFFBQVE7Ozs7Ozs7Ozs7Ozs7T0FDQyxPQUFHO09BQXlCLFVBQU8sV0FBbkMsT0FBRztPQUErRyxVQUFNLFdBQTVGLFVBQU87T0FBaU4sSUFBQyxhQUFuSSxVQUFNOzBCQUE0SCxJQUFDOztXQUFELElBQUM7OzRCQUFELElBQUM7Ozs7U0FBd0csR0FBQzs7NkNBQUQsR0FBQyxpQkE5UHBWLE9BQU8seUJBOFAwWCxPQUFPLEVBQUMsV0FBVzt3QkFBakUsR0FBQzs7Ozs7aUJBOVBwVixPQUFPLHlCQThQdVQsT0FBTyxFQUFDLFdBQVc7Ozs7Ozs7OztPQUEySCxVQUFNOztXQUFoYyxVQUFPO1dBQW5DLE9BQUc7Ozs7V0E5UE8sT0FBTztxQkE4UHVRLFNBQVMsVUFBSSxPQUFPLEVBQUMsSUFBSTs7OztvQkFBL0wsVUFBTSxjQUE2QixPQUFPLEVBQUMsSUFBSTtvQkFBcVQsVUFBTSxjQUFzQyxPQUFPLEVBQUMsSUFBSTtzQkFBOWdCLE9BQUc7Ozs7O2NBQVosT0FBTzs7Ozs7Ozs7Ozs7O0NBdEdaIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIb21lLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8IS0tIEZJTi1FUElDLTAwMiwgRklOLUVQSUMtMDAzLCBGSU4tRVBJQy0wMDUsIGFuZCBGSU4tRVBJQy0wMDY6IHNlZSBkb2NzL2ppcmEvcGVyc29uYWwtZXhwZW5zZS9GSU4tRVBJQy0wMDItY29ycmVjdG5lc3MubWQsIEZJTi1FUElDLTAwMy1pbnNpZ2h0cy5tZCwgRklOLUVQSUMtMDA1LXBsYW5uaW5nLm1kLCBhbmQgRklOLUVQSUMtMDA2LWVzc2VudGlhbC1jb21taXRtZW50cy5tZC4gLS0+XG48c2NyaXB0PlxuICBpbXBvcnQgJy4vY29tbWl0bWVudC5jc3MnO1xuICBpbXBvcnQgJy4vY29tcG9uZW50cy9kZXRhaWwtc2hlZXQuY3NzJztcbiAgaW1wb3J0IHsgb25Nb3VudCwgdGljayB9IGZyb20gJ3N2ZWx0ZSc7XG4gIGltcG9ydCB7IEFwaUVycm9yLCBjb21wbGV0ZUFjdGlvbiwgY29tcGxldGVSZWN1cnJpbmdDb21taXRtZW50LCBjb25maXJtU2lwT2NjdXJyZW5jZSwgY29uZmlybVN0b2NrTW9udGhseVBsYW4sIGNyZWF0ZUNyZWRpdENhcmQsIGNyZWF0ZUxvYW4sIGNyZWF0ZU1pc3NpbmdEYXRlQ29udGV4dCwgY3JlYXRlTXV0dWFsRnVuZCwgY3JlYXRlTXV0dWFsRnVuZEx1bXBTdW0sIGNyZWF0ZU11dHVhbEZ1bmRTaXAsIGNyZWF0ZVN0b2NrLCBjcmVhdGVTdG9ja01vbnRobHlQbGFuLCBjcmVhdGVSZWN1cnJpbmdDb21taXRtZW50LCBkZWxldGVFeHBlbnNlLCBkZWxldGVMb2FuLCBkZWxldGVNdXR1YWxGdW5kLCBkZWxldGVSZWN1cnJpbmdDb21taXRtZW50LCBkZWxldGVTdG9jaywgZ2V0QWN0aW9ucywgZ2V0Q29tbWl0bWVudFJldmlldywgZ2V0Q3JlZGl0Q2FyZHMsIGdldEV4cGVuc2VPcHRpb25zLCBnZXRFeHBlbnNlc0ZvckRhdGUsIGdldEluY29tZU91dGxvb2ssIGdldExvYW5IaXN0b3J5LCBnZXRMb2FucywgZ2V0TXV0dWFsRnVuZCwgZ2V0TXV0dWFsRnVuZHMsIGdldFJlY3VycmluZ0NvbW1pdG1lbnRIaXN0b3J5LCBnZXRSZWN1cnJpbmdDb21taXRtZW50cywgZ2V0U3RvY2ssIGdldFN0b2NrcywgbG9nb3V0LCBtYXJrTG9hbkVtaVBhaWQsIHJlY29yZFJlY3VycmluZ0NvbW1pdG1lbnRDb21wbGV0aW9uLCByZXNvbHZlQ29tbWl0bWVudFJldmlldywgc2F2ZUluY29tZVByb2ZpbGUsIHNlYXJjaE11dHVhbEZ1bmRzLCBzZWFyY2hTdG9ja3MsIHVwZGF0ZUNyZWRpdENhcmQsIHVwZGF0ZUV4cGVuc2UsIHVwZGF0ZUxvYW4sIHVwZGF0ZVJlY3VycmluZ0NvbW1pdG1lbnQsIHVwZGF0ZVNpcE9jY3VycmVuY2UsIHVwZGF0ZU11dHVhbEZ1bmRUcmFuc2FjdGlvbiB9IGZyb20gJy4vbGliL2FwaS5qcyc7XG4gIGltcG9ydCBTZWN0aW9uU3RhdGUgZnJvbSAnLi9TZWN0aW9uU3RhdGUuc3ZlbHRlJztcbiAgaW1wb3J0IE5vcm1hbGl6YXRpb24gZnJvbSAnLi9Ob3JtYWxpemF0aW9uLnN2ZWx0ZSc7XG4gIGltcG9ydCBBcHBIZWFkZXIgZnJvbSAnLi9jb21wb25lbnRzL0FwcEhlYWRlci5zdmVsdGUnO1xuICBpbXBvcnQgQm90dG9tTmF2IGZyb20gJy4vY29tcG9uZW50cy9Cb3R0b21OYXYuc3ZlbHRlJztcbiAgaW1wb3J0IER1ZVJlbWluZGVyIGZyb20gJy4vY29tcG9uZW50cy9EdWVSZW1pbmRlci5zdmVsdGUnO1xuICBpbXBvcnQgVmlld0RldGFpbHNMaW5rIGZyb20gJy4vY29tcG9uZW50cy9WaWV3RGV0YWlsc0xpbmsuc3ZlbHRlJztcbiAgaW1wb3J0IENsb3NlZExvYW5Sb3cgZnJvbSAnLi9jb21wb25lbnRzL0Nsb3NlZExvYW5Sb3cuc3ZlbHRlJztcbiAgaW1wb3J0IFByb2ZpbGVTZXR0aW5ncyBmcm9tICcuL2ZlYXR1cmVzL3Byb2ZpbGUvUHJvZmlsZVNldHRpbmdzLnN2ZWx0ZSc7XG4gIGV4cG9ydCBsZXQgY2FsZW5kYXJTZWN0aW9uOyBleHBvcnQgbGV0IHJlY2VudFNlY3Rpb247IGV4cG9ydCBsZXQgc3Rvcmllc1NlY3Rpb247IGV4cG9ydCBsZXQgc2VsZWN0ZWRNb250aDsgZXhwb3J0IGxldCBjb25uZWN0aW9uU3RhdHVzOyBleHBvcnQgbGV0IGNhY2hlVXBkYXRlZEF0OyBleHBvcnQgbGV0IGRlbW9Nb2RlOyBleHBvcnQgbGV0IG9uRGVtb01vZGVDaGFuZ2U7IGV4cG9ydCBsZXQgb25Nb250aENoYW5nZTsgZXhwb3J0IGxldCByZWZyZXNoQ2FsZW5kYXI7IGV4cG9ydCBsZXQgcmVmcmVzaFJlY2VudDsgZXhwb3J0IGxldCByZWZyZXNoU3RvcmllczsgZXhwb3J0IGxldCBvblJldHJ5Q29ubmVjdGlvbjsgZXhwb3J0IGxldCBvbkxvZ291dDtcblxuICBsZXQgdmlldz0naG9tZScsIHNob3dNb25leT1mYWxzZSwgc2hvd05vcm1hbGl6YXRpb249ZmFsc2UsIHNlbGVjdGVkRGF5PW51bGwsIGFjdGl2aXR5VGFiPSdyZWNlbnQnLCBkYXlJdGVtcz1bXSwgZGF5U3RhdHVzPSdpZGxlJywgc2hvd0FsbD1mYWxzZSwgZXhwYW5kZWRJZD1udWxsO1xuICBsZXQgb3BlbmVkU3Rvcnk9bnVsbCwgaGFuZG9mZj1udWxsLCBhZGRpbmdDb250ZXh0PWZhbHNlLCBhY3Rpb25FcnJvcj0nJywgbG9nZ2luZ091dD1mYWxzZSwgc2lnbk91dEVycm9yPScnLCBkZW1vU3dpdGNoaW5nPWZhbHNlLCBkZW1vRXJyb3I9JycsIHN0b3J5U2xpZGU9MCwgc3RvcnlUb3VjaFN0YXJ0PW51bGwsIHNob3dTdG9yeUV2aWRlbmNlPWZhbHNlLCBzdG9yeUZpbHRlcj0nQWxsJywgaG9tZVN0b3J5SW5kZXg9MCwgc3Rvcmllc1JhaWxJbmRleD0wLCBzdG9yeVJhaWxUb3VjaFN0YXJ0PW51bGw7XG4gIGxldCBjb21taXRtZW50U3R5bGU9J3BsYXlmdWwnO1xuICBsZXQgZWRpdGluZz1udWxsLCBlZGl0QW1vdW50PScnLCBlZGl0RGF0ZT0nJywgZWRpdENhdGVnb3J5PScnLCBlZGl0U3ViY2F0ZWdvcnk9JycsIGVkaXRNZXJjaGFudElkPScnLCBlZGl0QWNjb3VudElkPScnLCBzYXZpbmc9ZmFsc2UsIGRlbGV0aW5nPW51bGw7XG4gIGxldCBlZGl0T3B0aW9ucz17Y2F0ZWdvcmllczpbXSxtZXJjaGFudHM6W10sYWNjb3VudHM6W119LCBvcHRpb25zU3RhdHVzPSdpZGxlJywgb3B0aW9uc0Vycm9yPScnO1xuICBsZXQgc3RvcnlDb250cm9scz17c3BlbmRpbmc6dHJ1ZSxpbnZlc3RtZW50czp0cnVlLHBsYW5uaW5nOnRydWV9O1xuICBsZXQgc2hvd0xvYW5Gb3JtPWZhbHNlLCBsb2FuRXJyb3I9JycsIGxvYW5TdGF0dXM9J2lkbGUnLCBsb2FuRWRpdGluZ0lkPW51bGwsIGxvYW5TYXZpbmc9ZmFsc2UsIGxvYW5EZWxldGluZ0lkPW51bGwsIHNob3dDbG9zZWRMb2Fucz1mYWxzZTtcbiAgbGV0IGxvYW5Gb3JtPXtsb2FuTmFtZTonJyxsb2FuVHlwZTonSE9NRScsbGVuZGVyTmFtZTonJyxvcmlnaW5hbFByaW5jaXBhbDonJyxtb250aGx5RW1pQW1vdW50OicnLHRvdGFsVGVudXJlTW9udGhzOicnLGZpcnN0RW1pRHVlRGF0ZTonJyxub3RlczonJ307XG4gIGxldCBsb2Fucz1bXTtcbiAgbGV0IGxvYW5IaXN0b3J5PW51bGwsIGxvYW5IaXN0b3J5U3RhdHVzPSdpZGxlJywgbG9hbkhpc3RvcnlFcnJvcj0nJztcbiAgbGV0IGNvbW1pdG1lbnRzPVtdLCBjb21taXRtZW50U3RhdHVzPSdpZGxlJywgY29tbWl0bWVudEVycm9yPScnLCBzaG93Q29tbWl0bWVudEZvcm09ZmFsc2UsIGNvbW1pdG1lbnRTYXZpbmc9ZmFsc2UsIGNvbW1pdG1lbnRFZGl0aW5nSWQ9bnVsbCwgY29tbWl0bWVudERlbGV0aW5nSWQ9bnVsbCwgY29tcGxldGluZ0NvbW1pdG1lbnRJZD1udWxsO1xuICBsZXQgY29tbWl0bWVudEhpc3Rvcnk9bnVsbCwgY29tbWl0bWVudEhpc3RvcnlTdGF0dXM9J2lkbGUnLCBjb21taXRtZW50SGlzdG9yeUVycm9yPScnO1xuICBsZXQgY29tbWl0bWVudEZvcm09e2xhYmVsOicnLHBsYW5uaW5nQW1vdW50OicnLGR1ZURheTonJyxhbW91bnRNb2RlOidGSVhFRCcscmVjdXJyZW5jZVVuaXQ6J01PTlRIJyxyZWN1cnJlbmNlSW50ZXJ2YWw6JzEnLGZsZXhpYmxlU2NoZWR1bGU6ZmFsc2UsbmV4dEV4cGVjdGVkRGF0ZTonJ307XG4gIGxldCBjb21wbGV0aW9uQ29tbWl0bWVudD1udWxsLCBjb21wbGV0aW9uRm9ybT17YWN0dWFsQW1vdW50OicnLGNvbXBsZXRlZEF0OicnLG5leHRFeHBlY3RlZERhdGU6Jyd9O1xuICBsZXQgY3JlZGl0Q2FyZHM9W10sIGNyZWRpdENhcmRTdGF0dXM9J2lkbGUnLCBjcmVkaXRDYXJkRXJyb3I9JycsIHNob3dDcmVkaXRDYXJkRm9ybT1mYWxzZSwgY3JlZGl0Q2FyZFNhdmluZz1mYWxzZSwgY3JlZGl0Q2FyZEVkaXRpbmdJZD1udWxsO1xuICBsZXQgY3JlZGl0Q2FyZEZvcm09e2FjY291bnRSZWZlcmVuY2VJZDonJyxjYXJkTmFtZTonJyxpc3N1ZXJOYW1lOicnLHN0YXRlbWVudERheTonJyxkdWVEYXk6Jyd9O1xuICBsZXQgc2hvd0NvbW1pdG1lbnRSZXZpZXc9ZmFsc2UsIGNvbW1pdG1lbnRSZXZpZXc9W10sIGNvbW1pdG1lbnRSZXZpZXdTdGF0dXM9J2lkbGUnLCByZXNvbHZpbmdDYW5kaWRhdGU9bnVsbDtcbiAgbGV0IGluY29tZU91dGxvb2s9e3NhbGFyeTpudWxsfSwgaW5jb21lU3RhdHVzPSdpZGxlJywgaW5jb21lRXJyb3I9JycsIGluY29tZVNhdmluZz1mYWxzZSwgc2hvd0luY29tZUZsb3c9ZmFsc2U7XG4gIGxldCBzYWxhcnlGb3JtPXtzYWxhcnlWaXNpYmlsaXR5OidSQU5HRScsc2FsYXJ5UmFuZ2U6J0ZST01fNTAwMDBfVE9fMTAwMDAwJyxleGFjdE1vbnRobHlTYWxhcnk6Jycsc2FsYXJ5RnJlcXVlbmN5OidNT05USExZJ307XG4gIGxldCBzaG93TXV0dWFsRnVuZEZvcm09ZmFsc2UsIHNjaGVtZVF1ZXJ5PScnLCBzaG93U2NoZW1lTWVudT1mYWxzZSwgc2VsZWN0ZWRTY2hlbWU9bnVsbCwgZnVuZEVycm9yPScnLCBmdW5kU2F2ZWQ9ZmFsc2UsIGZ1bmRTYXZpbmc9ZmFsc2UsIHNjaGVtZVNlYXJjaFN0YXR1cz0naWRsZScsIHNjaGVtZVJlc3VsdHM9W10sIHNjaGVtZVNlYXJjaFJlcXVlc3Q9MDtcbiAgbGV0IG11dHVhbEZ1bmRzPVtdLCBtdXR1YWxGdW5kU3RhdHVzPSdpZGxlJywgbXV0dWFsRnVuZEVycm9yPScnLCBtdXR1YWxGdW5kRGVsZXRpbmdJZD1udWxsO1xuICBsZXQgc3RvY2tzPVtdLCBzdG9ja1N0YXR1cz0naWRsZScsIHN0b2NrRXJyb3I9JycsIHNob3dTdG9ja0Zvcm09ZmFsc2UsIHN0b2NrUXVlcnk9JycsIHNlbGVjdGVkU3RvY2s9bnVsbCwgc3RvY2tSZXN1bHRzPVtdLCBzdG9ja1NlYXJjaFN0YXR1cz0naWRsZScsIHN0b2NrU2VhcmNoUmVxdWVzdD0wLCBzdG9ja1NhdmluZz1mYWxzZSwgc3RvY2tEZWxldGluZ0lkPW51bGw7XG4gIGxldCBzdG9ja1BsYW5UYXJnZXQ9bnVsbCxzdG9ja1BsYW5Gb3JtPXthbW91bnQ6JycsZGF5OicnLHN0YXJ0TW9udGg6Jyd9LHN0b2NrUGxhblNhdmluZz1mYWxzZSxzdG9ja1BsYW5Db25maXJtYXRpb25UYXJnZXQ9bnVsbCxzdG9ja1BsYW5Db25maXJtYXRpb249e2Ftb3VudDonJyxwcmljZTonJ30sc3RvY2tEZXRhaWw9bnVsbCxzdG9ja0RldGFpbFN0YXR1cz0naWRsZScsaGlnaGxpZ2h0ZWRTdG9ja0lkPW51bGw7XG4gIGxldCBzdG9ja0Zvcm09e3F1YW50aXR5OicnLHRvdGFsSW52ZXN0ZWQ6Jyd9O1xuICBsZXQgYWN0aW9ucz1bXSwgYWN0aW9uc1N0YXR1cz0naWRsZScsIGFjdGlvbnNFcnJvcj0nJywgY29tcGxldGluZ0FjdGlvbklkPW51bGwsIGhpZ2hsaWdodGVkTG9hbklkPW51bGwsIGhpZ2hsaWdodGVkRnVuZElkPW51bGw7XG4gIGxldCBjb25maXJtaW5nU2lwPW51bGwsIHNpcENvbmZpcm1FcnJvcj0nJywgc2lwQ29uZmlybVNhdmluZz1mYWxzZSwgc2lwQ29uZmlybUZvcm09e2Ftb3VudDonJyx0cmFuc2FjdGlvbkRhdGU6bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsMTApLG5hdjonJ307XG4gIGxldCBmdW5kRGV0YWlsPW51bGwsIGZ1bmREZXRhaWxTdGF0dXM9J2lkbGUnLCBmdW5kRGV0YWlsRXJyb3I9JycsIGx1bXBTdW1GdW5kPW51bGwsIGx1bXBTdW1TYXZpbmc9ZmFsc2UsIGx1bXBTdW1FcnJvcj0nJywgbHVtcFN1bUZvcm09e2Ftb3VudDonJyx0cmFuc2FjdGlvbkRhdGU6JycsbmF2OicnfTtcbiAgbGV0IGVkaXRpbmdGdW5kVHJhbnNhY3Rpb249bnVsbCwgZnVuZFRyYW5zYWN0aW9uU2F2aW5nPWZhbHNlLCBmdW5kVHJhbnNhY3Rpb25FcnJvcj0nJywgZnVuZFRyYW5zYWN0aW9uRm9ybT17YW1vdW50OicnLHRyYW5zYWN0aW9uRGF0ZTonJyxuYXY6Jyd9O1xuICBjb25zdCBNT05FWV9NT0RVTEVTX0NBQ0hFX0tFWT0nbW9uZXktc3Rvcmllcy5tb25leS1tb2R1bGVzLWNhY2hlLnYxJztcbiAgbGV0IGZ1bmRGb3JtPXtoYXNTaXA6J1lFUycsc2lwQW1vdW50OicyNTAwMCcsc2lwRGF0ZTonNScsc3RhcnRNb250aDonMjAyNi0xMCcsaGFzSG9sZGluZzonWUVTJyxjdXJyZW50VW5pdHM6JzEyOC40NTYnLHRvdGFsSW52ZXN0ZWQ6JzEwMDAwJ307XG4gIGxldCBmdW5kU2lwVGFyZ2V0PW51bGwsIGZ1bmRTaXBGb3JtPXthbW91bnQ6JycsZGF5OicnLHN0YXJ0TW9udGg6Jyd9LCBmdW5kU2lwU2F2aW5nPWZhbHNlO1xuICAkOiBkYXRhPWNhbGVuZGFyU2VjdGlvbi5kYXRhfHx7fTsgJDogY3VycmVuY3k9ZGF0YS5jdXJyZW5jeXx8J0lOUic7ICQ6IGNhbGVuZGFyPWJ1aWxkQ2FsZW5kYXIoc2VsZWN0ZWRNb250aCxkYXRhLmRheXN8fFtdKTtcbiAgJDogcmVjZW50RGF0YT1yZWNlbnRTZWN0aW9uLmRhdGF8fHt9OyAkOiByZWNlbnRJdGVtcz0ocmVjZW50RGF0YS5pdGVtc3x8cmVjZW50RGF0YS5leHBlbnNlc3x8W10pLnNsaWNlKDAsNSk7XG4gICQ6IHN0b3J5RGF0YT1zdG9yaWVzU2VjdGlvbi5kYXRhfHx7fTsgJDogc3Rvcmllcz1zdG9yeURhdGEuc3Rvcmllc3x8c3RvcnlEYXRhLm1vbmV5U3Rvcmllc3x8c3RvcnlEYXRhLnN0b3J5Q2FyZHN8fFtdO1xuICAkOiBmaWx0ZXJlZFN0b3JpZXM9c3RvcnlGaWx0ZXI9PT0nQWxsJz9zdG9yaWVzOnN0b3JpZXMuZmlsdGVyKHN0b3J5PT5zdG9yeVNvdXJjZShzdG9yeSkudG9Mb3dlckNhc2UoKT09PXN0b3J5RmlsdGVyLnRvTG93ZXJDYXNlKCkpO1xuICAkOiBob21lU3Rvcmllcz1zdG9yaWVzLnNsaWNlKDAsMyk7XG4gICQ6IGlmKGhvbWVTdG9yeUluZGV4Pj1ob21lU3Rvcmllcy5sZW5ndGgpaG9tZVN0b3J5SW5kZXg9MDtcbiAgJDogaWYoc3Rvcmllc1JhaWxJbmRleD49ZmlsdGVyZWRTdG9yaWVzLmxlbmd0aClzdG9yaWVzUmFpbEluZGV4PTA7XG4gICQ6IHNlbGVjdGVkPXNlbGVjdGVkRGF5PT1udWxsP251bGw6Y2FsZW5kYXIuZGF5cy5maW5kKGRheT0+ZGF5LmRheT09PXNlbGVjdGVkRGF5KTsgJDogYWN0aXZlSXRlbXM9YWN0aXZpdHlUYWI9PT0ncmVjZW50Jz9yZWNlbnRJdGVtczpkYXlJdGVtczsgJDogdmlzaWJsZUl0ZW1zPXNob3dBbGw/YWN0aXZlSXRlbXM6YWN0aXZlSXRlbXMuc2xpY2UoMCw1KTtcbiAgJDogZWRpdFN1YmNhdGVnb3JpZXM9ZWRpdE9wdGlvbnMuY2F0ZWdvcmllcy5maW5kKG9wdGlvbj0+b3B0aW9uLm5hbWU9PT1lZGl0Q2F0ZWdvcnkpPy5zdWJjYXRlZ29yaWVzfHxbXTtcbiAgJDogYWN0aXZlTG9hbnM9bG9hbnMuZmlsdGVyKGxvYW49PmxvYW4uc3RhdHVzPT09J0FDVElWRScpOyAkOiBjbG9zZWRMb2Fucz1sb2Fucy5maWx0ZXIobG9hbj0+bG9hbi5zdGF0dXM9PT0nQ0xPU0VEJyk7ICQ6IHRvdGFsTW9udGhseUVtaT1hY3RpdmVMb2Fucy5yZWR1Y2UoKHRvdGFsLGxvYW4pPT50b3RhbCtOdW1iZXIobG9hbi5tb250aGx5RW1pQW1vdW50fHwwKSwwKTtcbiAgJDogbXV0dWFsUG9ydGZvbGlvPXtpbnZlc3RlZDptdXR1YWxGdW5kcy5yZWR1Y2UoKHRvdGFsLGZ1bmQpPT50b3RhbCtOdW1iZXIoZnVuZC5pbnZlc3RlZHx8MCksMCksY3VycmVudDptdXR1YWxGdW5kcy5zb21lKGZ1bmQ9PmZ1bmQuY3VycmVudFZhbHVlIT09bnVsbCk/bXV0dWFsRnVuZHMucmVkdWNlKCh0b3RhbCxmdW5kKT0+dG90YWwrTnVtYmVyKGZ1bmQuY3VycmVudFZhbHVlfHwwKSwwKTpudWxsLHBubDptdXR1YWxGdW5kcy5zb21lKGZ1bmQ9PmZ1bmQucHJvZml0T3JMb3NzIT09bnVsbCk/bXV0dWFsRnVuZHMucmVkdWNlKCh0b3RhbCxmdW5kKT0+dG90YWwrTnVtYmVyKGZ1bmQucHJvZml0T3JMb3NzfHwwKSwwKTpudWxsfTtcbiAgJDogc3RvY2tQb3J0Zm9saW89e2ludmVzdGVkOnN0b2Nrcy5yZWR1Y2UoKHRvdGFsLHN0b2NrKT0+dG90YWwrTnVtYmVyKHN0b2NrLmludmVzdGVkfHwwKSwwKSxjdXJyZW50OnN0b2Nrcy5zb21lKHN0b2NrPT5zdG9jay5jdXJyZW50VmFsdWUhPT1udWxsKT9zdG9ja3MucmVkdWNlKCh0b3RhbCxzdG9jayk9PnRvdGFsK051bWJlcihzdG9jay5jdXJyZW50VmFsdWV8fDApLDApOm51bGwscG5sOnN0b2Nrcy5zb21lKHN0b2NrPT5zdG9jay5wcm9maXRPckxvc3MhPT1udWxsKT9zdG9ja3MucmVkdWNlKCh0b3RhbCxzdG9jayk9PnRvdGFsK051bWJlcihzdG9jay5wcm9maXRPckxvc3N8fDApLDApOm51bGx9O1xuICAkOiB2aXNpYmxlQWN0aW9ucz1hY3Rpb25zLm1hcChhY3Rpb249Pih7YWN0aW9uLHByZXNlbnRhdGlvbjphY3Rpb25QcmVzZW50YXRpb24oYWN0aW9uKX0pKS5maWx0ZXIoaXRlbT0+aXRlbS5wcmVzZW50YXRpb24pO1xuICAkOiBoaWdobGlnaHRlZExvYW5BY3Rpb249YWN0aW9ucy5maW5kKGFjdGlvbj0+U3RyaW5nKGFjdGlvbi5yZWZlcmVuY2VJZCk9PT1TdHJpbmcoaGlnaGxpZ2h0ZWRMb2FuSWQpJiZhY3Rpb24uYWN0aW9uVHlwZT09PSdMT0FOX0NMT1NVUkVfQ09ORklSTUFUSU9OJyk7XG4gIGNvbnN0IG1vbmV5PXZhbHVlPT5uZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2VuLUlOJyx7c3R5bGU6J2N1cnJlbmN5JyxjdXJyZW5jeSxtYXhpbXVtRnJhY3Rpb25EaWdpdHM6MH0pLmZvcm1hdChOdW1iZXIodmFsdWV8fDApKTtcbiAgY29uc3QgbW9uZXlEZWNpbWFsPXZhbHVlPT5uZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2VuLUlOJyx7c3R5bGU6J2N1cnJlbmN5JyxjdXJyZW5jeSxtaW5pbXVtRnJhY3Rpb25EaWdpdHM6MixtYXhpbXVtRnJhY3Rpb25EaWdpdHM6Mn0pLmZvcm1hdChOdW1iZXIodmFsdWV8fDApKTtcbiAgY29uc3QgY29tcGFjdE1vbmV5PXZhbHVlPT5uZXcgSW50bC5OdW1iZXJGb3JtYXQoJ2VuLUlOJyx7c3R5bGU6J2N1cnJlbmN5JyxjdXJyZW5jeSxub3RhdGlvbjonY29tcGFjdCcsbWF4aW11bUZyYWN0aW9uRGlnaXRzOjJ9KS5mb3JtYXQoTnVtYmVyKHZhbHVlfHwwKSk7XG4gIGNvbnN0IGZ1bmRTdWJ0aXRsZT1uYW1lPT4vZ3Jvd3RoL2kudGVzdChuYW1lKT8nR3Jvd3RoIMK3IERpcmVjdCBwbGFuJzonVmVyaWZpZWQgc2NoZW1lJzsgY29uc3QgZnVuZEFjY2VudD1pZD0+Wydjb3JhbCcsJ2dvbGQnLCd2aW9sZXQnLCdibHVlJ11bTnVtYmVyKGlkfHwwKSU0XTtcbiAgY29uc3QgbWVyY2hhbnQ9aXRlbT0+aXRlbS5tZXJjaGFudHx8aXRlbS5tZXJjaGFudE5hbWV8fGl0ZW0uZGVzY3JpcHRpb258fGl0ZW0ub3JpZ2luYWxNZXNzYWdlfHwnRXhwZW5zZSc7IGNvbnN0IGNhdGVnb3J5PWl0ZW09Pml0ZW0uY2F0ZWdvcnk/Lm5hbWV8fGl0ZW0uY2F0ZWdvcnl8fCdVbmNhdGVnb3Jpc2VkJzsgY29uc3QgdHJhbnNhY3Rpb25EYXRlPWl0ZW09Pml0ZW0udHJhbnNhY3Rpb25EYXRlfHxpdGVtLnRyYW5zYWN0aW9uVGltZXx8aXRlbS5kYXRlO1xuICBjb25zdCBkYXRlTGFiZWw9dmFsdWU9PnZhbHVlP25ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHVuZGVmaW5lZCx7ZGF5OidudW1lcmljJyxtb250aDonc2hvcnQnfSkuZm9ybWF0KG5ldyBEYXRlKHZhbHVlKSk6Jyc7XG4gIGNvbnN0IG1vbnRoTGFiZWw9dmFsdWU9Pntjb25zdFt5LG1dPXZhbHVlLnNwbGl0KCctJykubWFwKE51bWJlcik7cmV0dXJuIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHVuZGVmaW5lZCx7bW9udGg6J2xvbmcnLHllYXI6J251bWVyaWMnfSkuZm9ybWF0KG5ldyBEYXRlKHksbS0xKSk7fTtcbiAgY29uc3QgZ3JlZXRpbmc9KCk9Pm5ldyBEYXRlKCkuZ2V0SG91cnMoKTwxMj8nR29vZCBtb3JuaW5nJzpuZXcgRGF0ZSgpLmdldEhvdXJzKCk8MTc/J0dvb2QgYWZ0ZXJub29uJzonR29vZCBldmVuaW5nJzsgY29uc3QgaXNvRGF0ZT1kYXk9PmAke3NlbGVjdGVkTW9udGh9LSR7U3RyaW5nKGRheSkucGFkU3RhcnQoMiwnMCcpfWA7XG4gIGNvbnN0IGhhc0RlY2s9c3Rvcnk9PkFycmF5LmlzQXJyYXkoc3RvcnkuY2FyZHMpJiZzdG9yeS5jYXJkcy5sZW5ndGg+MDsgY29uc3Qgc3RvcnlOYW1lPXN0b3J5PT5TdHJpbmcoc3Rvcnkuc3RvcnlUeXBlfHxzdG9yeS50eXBlfHwnTW9uZXkgc3RvcnknKS5yZXBsYWNlQWxsKCdfJywnICcpOyBjb25zdCBzdG9yeVRvbmU9c3Rvcnk9PnN0b3J5LmNhcmRGYWNlPy50aGVtZXx8J2NhbG0nOyBjb25zdCBzdG9yeUNhcmRGYWNlPXN0b3J5PT5zdG9yeS5jYXJkRmFjZXx8e2hlYWRpbmc6J01vbmV5IHN0b3J5JyxkaXNwbGF5VmFsdWU6J1ZpZXcnLHRoZW1lOidjYWxtJ307IGNvbnN0IHN0b3J5U291cmNlPXN0b3J5PT5zdG9yeS5zb3VyY2V8fHN0b3J5LmRvbWFpbnx8KHN0b3J5LnN0b3J5VHlwZT09PSdNT05USExZX0NPTU1JVE1FTlQnPydQbGFubmluZyc6J1NwZW5kaW5nJyk7XG4gIGNvbnN0IGlzQ29tbWl0bWVudD1zdG9yeT0+c3Rvcnk/LnN0b3J5VHlwZT09PSdNT05USExZX0NPTU1JVE1FTlQnOyBjb25zdCBzdG9yeUljb249c3Rvcnk9PmlzQ29tbWl0bWVudChzdG9yeSk/J/CfjqwnOicnOyBjb25zdCBzdG9yeUhlYWRpbmc9c3Rvcnk9PnN0b3J5Q2FyZEZhY2Uoc3RvcnkpLmhlYWRpbmc7XG4gIGZ1bmN0aW9uIHNldENvbW1pdG1lbnRTdHlsZShzdHlsZSl7Y29tbWl0bWVudFN0eWxlPXN0eWxlO3RyeXtsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbW9uZXktc3Rvcmllcy5jb21taXRtZW50LXN0eWxlJyxzdHlsZSk7fWNhdGNoe319XG4gICQ6IGNvbm5lY3Rpb25MYWJlbD1jb25uZWN0aW9uU3RhdHVzPT09J29ubGluZSc/J09ubGluZSc6Y29ubmVjdGlvblN0YXR1cz09PSdvZmZsaW5lJz8nT2ZmbGluZSc6J0NoZWNraW5nJztcbiAgJDogZXZpZGVuY2VJdGVtcz0oY29tbWl0bWVudHMsZXZpZGVuY2VGb3Iob3BlbmVkU3Rvcnksc3RvcnlTbGlkZSkpO1xuICBmdW5jdGlvbiBsb2NhbElucHV0RGF0ZSh2YWx1ZSl7aWYoIXZhbHVlKXJldHVybiAnJztjb25zdCB0ZXh0PVN0cmluZyh2YWx1ZSk7aWYoL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvLnRlc3QodGV4dCkpcmV0dXJuIHRleHQ7Y29uc3QgZGF0ZT1uZXcgRGF0ZSh0ZXh0KTtyZXR1cm4gTnVtYmVyLmlzTmFOKGRhdGUuZ2V0VGltZSgpKT90ZXh0LnNsaWNlKDAsMTApOmAke2RhdGUuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoZGF0ZS5nZXRNb250aCgpKzEpLnBhZFN0YXJ0KDIsJzAnKX0tJHtTdHJpbmcoZGF0ZS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsJzAnKX1gO31cbiAgZnVuY3Rpb24gZXZpZGVuY2VGb3Ioc3Rvcnksc2xpZGU9MCl7Y29uc3QgY2FyZD1zdG9yeT8uY2FyZHM/LnNsaWNlKCkuc29ydCgoYSxiKT0+KGEuc2VxdWVuY2V8fDApLShiLnNlcXVlbmNlfHwwKSlbc2xpZGVdO2NvbnN0IGV2aWRlbmNlPXN0b3J5Py5ldmlkZW5jZT8uYnlDYXJkPy5bY2FyZD8uY2FyZElkXXx8c3Rvcnk/LmV2aWRlbmNlO2NvbnN0IHJhdz1BcnJheS5pc0FycmF5KGV2aWRlbmNlKT9ldmlkZW5jZTpldmlkZW5jZT8udHJhbnNhY3Rpb25zfHxldmlkZW5jZT8uaXRlbXN8fHN0b3J5Py50cmFuc2FjdGlvbnN8fFtdO3JldHVybiByYXcubWFwKGl0ZW09Pntjb25zdFtpZFR5cGUsaWRdPVN0cmluZyhpdGVtLnRyYW5zYWN0aW9uSWR8fGl0ZW0uaWR8fCcnKS5zcGxpdCgnOicpO3JldHVybntzb3VyY2VUeXBlOmlkVHlwZSxzb3VyY2VJZDppZCxtZXJjaGFudDppdGVtLm1lcmNoYW50TGFiZWx8fGl0ZW0ubWVyY2hhbnR8fGl0ZW0ubWVyY2hhbnROYW1lfHxpdGVtLmRlc2NyaXB0aW9ufHwnRXhwZW5zZScsY2F0ZWdvcnk6aXRlbS5jYXRlZ29yeUxhYmVsfHxpdGVtLmNhdGVnb3J5Py5uYW1lfHxpdGVtLmNhdGVnb3J5fHwnVW5jYXRlZ29yaXNlZCcsZGV0YWlsOml0ZW0uc3ViY2F0ZWdvcnlMYWJlbHx8aXRlbS5kZXRhaWx8fCcnLGRhdGU6aXRlbS5kYXRlTGFiZWx8fGRhdGVMYWJlbChpdGVtLnRyYW5zYWN0aW9uRGF0ZXx8aXRlbS50cmFuc2FjdGlvblRpbWV8fGl0ZW0uZGF0ZSksYW1vdW50Oml0ZW0uYW1vdW50Py5kaXNwbGF5VmFsdWV8fGl0ZW0uZGlzcGxheUFtb3VudHx8bW9uZXkoaXRlbS5hbW91bnQpfX0pO31cbiAgZnVuY3Rpb24gbG9hblNjaGVkdWxlKGxvYW4pe2NvbnN0IGZpcnN0PW5ldyBEYXRlKGAke2xvYW4uZmlyc3RFbWlEdWVEYXRlfVQxMjowMDowMGApO2lmKE51bWJlci5pc05hTihmaXJzdC5nZXRUaW1lKCkpKXJldHVybiBudWxsO2NvbnN0IHRlbnVyZT1OdW1iZXIobG9hbi50b3RhbFRlbnVyZU1vbnRocyl8fDAsZHVlPU51bWJlci5pc0ludGVnZXIobG9hbi5jb21wbGV0ZWRFbWlDb3VudCk/bG9hbi5jb21wbGV0ZWRFbWlDb3VudDowLHJlbWFpbmluZz1OdW1iZXIuaXNJbnRlZ2VyKGxvYW4ucmVtYWluaW5nRW1pQ291bnQpP2xvYW4ucmVtYWluaW5nRW1pQ291bnQ6TWF0aC5tYXgoMCx0ZW51cmUtZHVlKSxmaW5hbER1ZT1uZXcgRGF0ZShmaXJzdC5nZXRGdWxsWWVhcigpLGZpcnN0LmdldE1vbnRoKCkrTWF0aC5tYXgoMCx0ZW51cmUtMSksZmlyc3QuZ2V0RGF0ZSgpKTtyZXR1cm57ZHVlLHJlbWFpbmluZyx0ZW51cmUscGVyY2VudDp0ZW51cmU/TWF0aC5yb3VuZChkdWUvdGVudXJlKjEwMCk6MCxlbmRMYWJlbDpuZXcgSW50bC5EYXRlVGltZUZvcm1hdCh1bmRlZmluZWQse21vbnRoOidzaG9ydCcseWVhcjonbnVtZXJpYyd9KS5mb3JtYXQoZmluYWxEdWUpfTt9XG4gIGZ1bmN0aW9uIGFjdGlvblByZXNlbnRhdGlvbihhY3Rpb24pe2lmKGFjdGlvbi5hY3Rpb25UeXBlPT09J0xPQU5fQ0xPU1VSRV9DT05GSVJNQVRJT04nKXtjb25zdCBzY2hlZHVsZWQ9YWN0aW9uLnNjaGVkdWxlZENvbXBsZXRpb25EYXRlP25ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHVuZGVmaW5lZCx7ZGF5OidudW1lcmljJyxtb250aDonc2hvcnQnLHllYXI6J251bWVyaWMnfSkuZm9ybWF0KG5ldyBEYXRlKGAke2FjdGlvbi5zY2hlZHVsZWRDb21wbGV0aW9uRGF0ZX1UMTI6MDA6MDBgKSk6Jyc7Y29uc3QgZGVzY3JpcHRpb249KGFjdGlvbi5kZXNjcmlwdGlvbnx8YEVNSSB3YXMgc2NoZWR1bGVkIHRvIGZpbmlzaCBvbiAke3NjaGVkdWxlZH0uYCkucmVwbGFjZShhY3Rpb24uc2NoZWR1bGVkQ29tcGxldGlvbkRhdGV8fCcnLHNjaGVkdWxlZCkucmVwbGFjZSgvXFxzKk1hcmsgaXQgY2xvc2VkIGlmIHRoZSBmaW5hbCBFTUkgd2FzIHBhaWRcXC4/XFxzKiQvaSwnJyk7cmV0dXJue3RpdGxlOidMb2FuIGNsb3N1cmUgY29uZmlybWF0aW9uJyxkZXNjcmlwdGlvbixjdGE6J1JldmlldyBsb2FuJ307fXJldHVybiBudWxsO31cbiAgY29uc3QgbW9uZXlNb2R1bGVzQ2FjaGVLZXk9KCk9PmAke01PTkVZX01PRFVMRVNfQ0FDSEVfS0VZfS4ke2RlbW9Nb2RlPydkZW1vJzoncmVhbCd9YDtcbiAgZnVuY3Rpb24gcmVhZE1vbmV5TW9kdWxlc0NhY2hlKCl7dHJ5e2NvbnN0IGNhY2hlZD1KU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKG1vbmV5TW9kdWxlc0NhY2hlS2V5KCkpfHwnbnVsbCcpO2lmKCFjYWNoZWQpcmV0dXJuIGZhbHNlO2lmKEFycmF5LmlzQXJyYXkoY2FjaGVkLmxvYW5zKSl7bG9hbnM9Y2FjaGVkLmxvYW5zO2xvYW5TdGF0dXM9J3JlYWR5Jzt9aWYoQXJyYXkuaXNBcnJheShjYWNoZWQubXV0dWFsRnVuZHMpKXttdXR1YWxGdW5kcz1jYWNoZWQubXV0dWFsRnVuZHM7bXV0dWFsRnVuZFN0YXR1cz0ncmVhZHknO31pZihBcnJheS5pc0FycmF5KGNhY2hlZC5zdG9ja3MpKXtzdG9ja3M9Y2FjaGVkLnN0b2NrcztzdG9ja1N0YXR1cz0ncmVhZHknO31yZXR1cm4gdHJ1ZTt9Y2F0Y2h7cmV0dXJuIGZhbHNlO319XG4gIGZ1bmN0aW9uIHNhdmVNb25leU1vZHVsZXNDYWNoZSgpe3RyeXtsb2NhbFN0b3JhZ2Uuc2V0SXRlbShtb25leU1vZHVsZXNDYWNoZUtleSgpLEpTT04uc3RyaW5naWZ5KHt1cGRhdGVkQXQ6bmV3IERhdGUoKS50b0lTT1N0cmluZygpLGxvYW5zLG11dHVhbEZ1bmRzLHN0b2Nrc30pKTt9Y2F0Y2h7LyogVGhlIGxpdmUgbW9kdWxlcyBzdGlsbCB3b3JrIGlmIHN0b3JhZ2UgaXMgdW5hdmFpbGFibGUuICovfX1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZExvYW5zKCl7bG9hblN0YXR1cz1sb2Fucy5sZW5ndGg/J3JlZnJlc2hpbmcnOidsb2FkaW5nJzt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldExvYW5zKCk7bG9hbnM9cmVzdWx0LmxvYW5zfHxbXTtsb2FuU3RhdHVzPSdyZWFkeSc7c2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCk7fWNhdGNoKGNhdXNlKXtpZihsb2Fucy5sZW5ndGgpe2xvYW5TdGF0dXM9J3JlYWR5JztyZXR1cm47fWxvYW5TdGF0dXM9J2Vycm9yJztsb2FuRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBsb2Fucy4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIGxvYWRDb21taXRtZW50cygpe2NvbW1pdG1lbnRTdGF0dXM9J2xvYWRpbmcnO2NvbW1pdG1lbnRFcnJvcj0nJzt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldFJlY3VycmluZ0NvbW1pdG1lbnRzKCk7Y29tbWl0bWVudHM9cmVzdWx0Lml0ZW1zfHxbXTtjb21taXRtZW50U3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtjb21taXRtZW50U3RhdHVzPSdlcnJvcic7Y29tbWl0bWVudEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgY29tbWl0bWVudHMuJzt9fVxuICBjb25zdCByZWN1cnJlbmNlTGFiZWw9aXRlbT0+e2NvbnN0IG49TnVtYmVyKGl0ZW0ucmVjdXJyZW5jZUludGVydmFsfHwxKSx1bml0PVN0cmluZyhpdGVtLnJlY3VycmVuY2VVbml0fHwnTU9OVEgnKS50b0xvd2VyQ2FzZSgpO2NvbnN0IHRleHQ9YCR7bj09PTE/Jyc6YCR7bn0gYH0ke3VuaXR9JHtuPT09MT8nJzoncyd9YDtyZXR1cm4gaXRlbS5mbGV4aWJsZVNjaGVkdWxlP2BVc3VhbGx5IGV2ZXJ5ICR7dGV4dH1gOmBFdmVyeSAke3RleHR9YDt9O1xuICBjb25zdCBleHBlY3RlZExhYmVsPWRhdGU9PmRhdGU/bmV3IEludGwuRGF0ZVRpbWVGb3JtYXQodW5kZWZpbmVkLHtkYXk6J251bWVyaWMnLG1vbnRoOidzaG9ydCcseWVhcjonbnVtZXJpYyd9KS5mb3JtYXQobmV3IERhdGUoYCR7ZGF0ZX1UMTI6MDA6MDBgKSk6Jyc7XG4gIGZ1bmN0aW9uIG9wZW5Db21taXRtZW50Rm9ybShpdGVtPW51bGwpe2NvbnN0IGVkaXRpbmdFeGlzdGluZz1Cb29sZWFuKGl0ZW0mJidwbGFubmluZ0Ftb3VudCcgaW4gaXRlbSk7Y29tbWl0bWVudEVycm9yPScnO2NvbW1pdG1lbnRFZGl0aW5nSWQ9ZWRpdGluZ0V4aXN0aW5nP2l0ZW0uaWQ6bnVsbDtjb21taXRtZW50Rm9ybT1pdGVtP3tsYWJlbDplZGl0aW5nRXhpc3Rpbmc/aXRlbS5sYWJlbDptZXJjaGFudChpdGVtKSxwbGFubmluZ0Ftb3VudDpTdHJpbmcoZWRpdGluZ0V4aXN0aW5nP2l0ZW0ucGxhbm5pbmdBbW91bnQ6aXRlbS5hbW91bnR8fCcnKSxkdWVEYXk6U3RyaW5nKGVkaXRpbmdFeGlzdGluZz9pdGVtLmR1ZURheT8/Jyc6bmV3IERhdGUodHJhbnNhY3Rpb25EYXRlKGl0ZW0pKS5nZXREYXRlKCl8fCcnKSxhbW91bnRNb2RlOmVkaXRpbmdFeGlzdGluZz9pdGVtLmFtb3VudE1vZGV8fCdGSVhFRCc6J0ZJWEVEJyxyZWN1cnJlbmNlVW5pdDplZGl0aW5nRXhpc3Rpbmc/aXRlbS5yZWN1cnJlbmNlVW5pdHx8J01PTlRIJzonTU9OVEgnLHJlY3VycmVuY2VJbnRlcnZhbDpTdHJpbmcoZWRpdGluZ0V4aXN0aW5nP2l0ZW0ucmVjdXJyZW5jZUludGVydmFsfHwxOjEpLGZsZXhpYmxlU2NoZWR1bGU6ZWRpdGluZ0V4aXN0aW5nP0Jvb2xlYW4oaXRlbS5mbGV4aWJsZVNjaGVkdWxlKTpmYWxzZSxuZXh0RXhwZWN0ZWREYXRlOmVkaXRpbmdFeGlzdGluZz9pdGVtLm5leHRFeHBlY3RlZERhdGV8fCcnOnNlbGVjdGVkTW9udGgrJy0wMScsLi4uKGVkaXRpbmdFeGlzdGluZz97fTp7c291cmNlVHJhbnNhY3Rpb25JZDppdGVtLmlkfSl9OntsYWJlbDonJyxwbGFubmluZ0Ftb3VudDonJyxkdWVEYXk6JycsYW1vdW50TW9kZTonRklYRUQnLHJlY3VycmVuY2VVbml0OidNT05USCcscmVjdXJyZW5jZUludGVydmFsOicxJyxmbGV4aWJsZVNjaGVkdWxlOmZhbHNlLG5leHRFeHBlY3RlZERhdGU6c2VsZWN0ZWRNb250aCsnLTAxJ307c2hvd0NvbW1pdG1lbnRGb3JtPXRydWU7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlQ29tbWl0bWVudCgpe2NvbnN0IHBsYW5uaW5nQW1vdW50PU51bWJlcihjb21taXRtZW50Rm9ybS5wbGFubmluZ0Ftb3VudCksZHVlRGF5PWNvbW1pdG1lbnRGb3JtLmR1ZURheT9OdW1iZXIoY29tbWl0bWVudEZvcm0uZHVlRGF5KTpudWxsLHJlY3VycmVuY2VJbnRlcnZhbD1OdW1iZXIoY29tbWl0bWVudEZvcm0ucmVjdXJyZW5jZUludGVydmFsKTtpZighY29tbWl0bWVudEZvcm0ubGFiZWwudHJpbSgpfHwhKHBsYW5uaW5nQW1vdW50PjApfHwhKHJlY3VycmVuY2VJbnRlcnZhbD4wKXx8IWNvbW1pdG1lbnRGb3JtLm5leHRFeHBlY3RlZERhdGV8fGR1ZURheSE9PW51bGwmJihkdWVEYXk8MXx8ZHVlRGF5PjI4KSl7Y29tbWl0bWVudEVycm9yPSdBZGQgYSBuYW1lLCBwb3NpdGl2ZSBwbGFubmluZyBhbW91bnQsIGZyZXF1ZW5jeSwgYW5kIG5leHQgZXhwZWN0ZWQgZGF0ZS4nO3JldHVybjt9Y29tbWl0bWVudFNhdmluZz10cnVlO3RyeXtjb25zdCBwYXlsb2FkPXsuLi5jb21taXRtZW50Rm9ybSxsYWJlbDpjb21taXRtZW50Rm9ybS5sYWJlbC50cmltKCkscGxhbm5pbmdBbW91bnQsZHVlRGF5LHJlY3VycmVuY2VJbnRlcnZhbCxlZmZlY3RpdmVNb250aDpzZWxlY3RlZE1vbnRofTtpZihjb21taXRtZW50RWRpdGluZ0lkIT09bnVsbClkZWxldGUgcGF5bG9hZC5zb3VyY2VUcmFuc2FjdGlvbklkO2F3YWl0IChjb21taXRtZW50RWRpdGluZ0lkPT09bnVsbD9jcmVhdGVSZWN1cnJpbmdDb21taXRtZW50KHBheWxvYWQpOnVwZGF0ZVJlY3VycmluZ0NvbW1pdG1lbnQoY29tbWl0bWVudEVkaXRpbmdJZCxwYXlsb2FkKSk7c2hvd0NvbW1pdG1lbnRGb3JtPWZhbHNlO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkQ29tbWl0bWVudHMoKSxyZWZyZXNoU3RvcmllcygpXSk7fWNhdGNoKGNhdXNlKXtjb21taXRtZW50RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc2F2ZSB0aGlzIGNvbW1pdG1lbnQuJzt9ZmluYWxseXtjb21taXRtZW50U2F2aW5nPWZhbHNlO319XG4gIGZ1bmN0aW9uIG9wZW5Db21wbGV0aW9uKGNvbW1pdG1lbnQpe2NvbXBsZXRpb25Db21taXRtZW50PWNvbW1pdG1lbnQ7Y29uc3QgdG9kYXk9bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsMTApO2NvbXBsZXRpb25Gb3JtPXthY3R1YWxBbW91bnQ6U3RyaW5nKGNvbW1pdG1lbnQucGxhbm5pbmdBbW91bnQpLGNvbXBsZXRlZEF0OnRvZGF5LG5leHRFeHBlY3RlZERhdGU6Y29tbWl0bWVudC5uZXh0RXhwZWN0ZWREYXRlfHx0b2RheX07fVxuICBmdW5jdGlvbiBhZGRNb250aHMobW9udGhzKXtjb25zdCBkYXRlPW5ldyBEYXRlKGAke2NvbXBsZXRpb25Gb3JtLmNvbXBsZXRlZEF0fVQxMjowMDowMGApO2RhdGUuc2V0TW9udGgoZGF0ZS5nZXRNb250aCgpK21vbnRocyk7Y29tcGxldGlvbkZvcm0ubmV4dEV4cGVjdGVkRGF0ZT1kYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwxMCk7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlQ29tcGxldGlvbigpe2lmKCFjb21wbGV0aW9uQ29tbWl0bWVudClyZXR1cm47dHJ5e2F3YWl0IHJlY29yZFJlY3VycmluZ0NvbW1pdG1lbnRDb21wbGV0aW9uKGNvbXBsZXRpb25Db21taXRtZW50LmlkLHthY3R1YWxBbW91bnQ6TnVtYmVyKGNvbXBsZXRpb25Gb3JtLmFjdHVhbEFtb3VudCksY29tcGxldGVkQXQ6Y29tcGxldGlvbkZvcm0uY29tcGxldGVkQXQsbmV4dEV4cGVjdGVkRGF0ZTpjb21wbGV0aW9uRm9ybS5uZXh0RXhwZWN0ZWREYXRlfSk7Y29tcGxldGlvbkNvbW1pdG1lbnQ9bnVsbDthd2FpdCBQcm9taXNlLmFsbChbbG9hZENvbW1pdG1lbnRzKCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7Y29tbWl0bWVudEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgY29tcGxldGlvbi4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIHJlbW92ZUNvbW1pdG1lbnQoY29tbWl0bWVudCl7aWYoY29tbWl0bWVudERlbGV0aW5nSWQhPT1udWxsKXJldHVybjtjb21taXRtZW50RGVsZXRpbmdJZD1jb21taXRtZW50LmlkO2NvbW1pdG1lbnRFcnJvcj0nJzt0cnl7YXdhaXQgZGVsZXRlUmVjdXJyaW5nQ29tbWl0bWVudChjb21taXRtZW50LmlkKTtjb21taXRtZW50cz1jb21taXRtZW50cy5maWx0ZXIoaXRlbT0+aXRlbS5pZCE9PWNvbW1pdG1lbnQuaWQpO2F3YWl0IHJlZnJlc2hTdG9yaWVzKCk7fWNhdGNoKGNhdXNlKXtjb21taXRtZW50RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgZGVsZXRlIHRoaXMgY29tbWl0bWVudC4nO31maW5hbGx5e2NvbW1pdG1lbnREZWxldGluZ0lkPW51bGw7fX1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZE11dHVhbEZ1bmRzKCl7bXV0dWFsRnVuZFN0YXR1cz1tdXR1YWxGdW5kcy5sZW5ndGg/J3JlZnJlc2hpbmcnOidsb2FkaW5nJzttdXR1YWxGdW5kRXJyb3I9Jyc7dHJ5e2NvbnN0IHJlc3VsdD1hd2FpdCBnZXRNdXR1YWxGdW5kcygpO211dHVhbEZ1bmRzPXJlc3VsdC5tdXR1YWxGdW5kc3x8W107bXV0dWFsRnVuZFN0YXR1cz0ncmVhZHknO3NhdmVNb25leU1vZHVsZXNDYWNoZSgpO31jYXRjaChjYXVzZSl7aWYobXV0dWFsRnVuZHMubGVuZ3RoKXttdXR1YWxGdW5kU3RhdHVzPSdyZWFkeSc7cmV0dXJuO31tdXR1YWxGdW5kU3RhdHVzPSdlcnJvcic7bXV0dWFsRnVuZEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgbXV0dWFsIGZ1bmRzLic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZFN0b2Nrcygpe3N0b2NrU3RhdHVzPXN0b2Nrcy5sZW5ndGg/J3JlZnJlc2hpbmcnOidsb2FkaW5nJztzdG9ja0Vycm9yPScnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0U3RvY2tzKCk7c3RvY2tzPXJlc3VsdC5zdG9ja3N8fFtdO3N0b2NrU3RhdHVzPSdyZWFkeSc7c2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCk7fWNhdGNoKGNhdXNlKXtpZihzdG9ja3MubGVuZ3RoKXtzdG9ja1N0YXR1cz0ncmVhZHknO3JldHVybjt9c3RvY2tTdGF0dXM9J2Vycm9yJztzdG9ja0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgc3RvY2tzLic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZEFjdGlvbnMoKXthY3Rpb25zU3RhdHVzPWFjdGlvbnMubGVuZ3RoPydyZWZyZXNoaW5nJzonbG9hZGluZyc7YWN0aW9uc0Vycm9yPScnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0QWN0aW9ucygpO2FjdGlvbnM9cmVzdWx0LmFjdGlvbnN8fFtdO2FjdGlvbnNTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2FjdGlvbnNTdGF0dXM9J2Vycm9yJzthY3Rpb25zRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBhY3Rpb25zLic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gY29tcGxldGVPcGVuQWN0aW9uKGFjdGlvbil7aWYoY29tcGxldGluZ0FjdGlvbklkIT09bnVsbClyZXR1cm47Y29tcGxldGluZ0FjdGlvbklkPWFjdGlvbi5pZDthY3Rpb25zRXJyb3I9Jyc7dHJ5e2F3YWl0IGNvbXBsZXRlQWN0aW9uKGFjdGlvbi5pZCk7YWN0aW9ucz1hY3Rpb25zLmZpbHRlcihpdGVtPT5pdGVtLmlkIT09YWN0aW9uLmlkKTthd2FpdCBQcm9taXNlLmFsbChbbG9hZExvYW5zKCksbG9hZEFjdGlvbnMoKV0pO31jYXRjaChjYXVzZSl7YWN0aW9uc0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGNvbXBsZXRlIHRoaXMgYWN0aW9uLic7fWZpbmFsbHl7Y29tcGxldGluZ0FjdGlvbklkPW51bGw7fX1cbiAgZnVuY3Rpb24gbW9uZXlSZXZpZXdUYXJnZXQodHlwZSxpZCl7aWYodHlwZT09PSdsb2FuJyl7Y29uc3QgbG9hbj1sb2Fucy5maW5kKGl0ZW09PlN0cmluZyhpdGVtLmlkKT09PVN0cmluZyhpZCkpO3JldHVybiBsb2FuJiZbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtdGVzdGlkPVwibG9hbnMtc2VjdGlvblwiXSAubG9hbi1yb3cnKV0uZmluZChyb3c9PnJvdy5xdWVyeVNlbGVjdG9yKCcubG9hbi1uYW1lJyk/LnRleHRDb250ZW50LnRyaW0oKS5zdGFydHNXaXRoKGxvYW4ubG9hbk5hbWUpKTt9aWYodHlwZT09PSdjb21taXRtZW50JylyZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgW2RhdGEtdGVzdGlkPVwiY29tbWl0bWVudC0ke2lkfVwiXWApO2lmKHR5cGU9PT0nc3RvY2snKXJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBbZGF0YS10ZXN0aWQ9XCJzdG9jay1jYXJkLSR7aWR9XCJdYCk7Y29uc3QgZnVuZD1mdW5kU3VtbWFyeShpZCk7cmV0dXJuIGZ1bmQmJlsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcubXV0dWFsLWZ1bmRzLW1vZHVsZTpub3QoLnN0b2Nrcy1tb2R1bGUpIC5mdW5kLWNhcmQnKV0uZmluZChjYXJkPT5jYXJkLmdldEF0dHJpYnV0ZSgnYXJpYS1sYWJlbCcpPT09YE9wZW4gJHtmdW5kLnNjaGVtZU5hbWV9IGRldGFpbHNgKTt9XG4gIGFzeW5jIGZ1bmN0aW9uIGZvY3VzTW9uZXlUYXJnZXQodHlwZSxpZCl7YXdhaXQgdGljaygpO2F3YWl0IG5ldyBQcm9taXNlKHJlc29sdmU9PnJlcXVlc3RBbmltYXRpb25GcmFtZShyZXNvbHZlKSk7Y29uc3QgdGFyZ2V0PW1vbmV5UmV2aWV3VGFyZ2V0KHR5cGUsaWQpO2lmKCF0YXJnZXQpcmV0dXJuO3RhcmdldC50YWJJbmRleD0tMTt0YXJnZXQuc2Nyb2xsSW50b1ZpZXcoe2JlaGF2aW9yOidzbW9vdGgnLGJsb2NrOidjZW50ZXInfSk7dGFyZ2V0LmZvY3VzKHtwcmV2ZW50U2Nyb2xsOnRydWV9KTt9XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5Mb2FuRHVlQWN0aW9uKGFjdGlvbil7aGlnaGxpZ2h0ZWRMb2FuSWQ9YWN0aW9uLnJlZmVyZW5jZUlkO3Nob3dNb25leT10cnVlO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkTG9hbnMoKSxsb2FkQWN0aW9ucygpXSk7YXdhaXQgZm9jdXNNb25leVRhcmdldCgnbG9hbicsYWN0aW9uLnJlZmVyZW5jZUlkKTt9XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5Db21taXRtZW50U291cmNlcygpe3Nob3dTdG9yeUV2aWRlbmNlPXRydWU7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRNdXR1YWxGdW5kcygpLGxvYWRDb21taXRtZW50cygpXSk7fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuSW5jbHVkZWRMb2FuKGV2ZW50KXtjb25zdCBsb2FuSXRlbXM9ZXZpZGVuY2VJdGVtcy5maWx0ZXIoaXRlbT0+L2xvYW4vaS50ZXN0KGl0ZW0uY2F0ZWdvcnkpKTtjb25zdCBidXR0b25zPVsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10ZXN0aWQ9XCJpbmNsdWRlZC1sb2FuLWNvbW1pdG1lbnRcIl0nKV07Y29uc3QgaXRlbT1sb2FuSXRlbXNbYnV0dG9ucy5pbmRleE9mKGV2ZW50LmN1cnJlbnRUYXJnZXQpXTtpZighaXRlbSlyZXR1cm47c2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2U7b3BlbmVkU3Rvcnk9bnVsbDthd2FpdCBvcGVuTW9uZXkoKTthd2FpdCBmb2N1c01vbmV5VGFyZ2V0KCdsb2FuJyxpdGVtLnNvdXJjZUlkKTt9XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5JbmNsdWRlZE11dHVhbEZ1bmQoaXRlbSl7aGlnaGxpZ2h0ZWRGdW5kSWQ9aXRlbS5zb3VyY2VJZDtzaG93U3RvcnlFdmlkZW5jZT1mYWxzZTtvcGVuZWRTdG9yeT1udWxsO2F3YWl0IG9wZW5Nb25leSgpO2F3YWl0IGZvY3VzTW9uZXlUYXJnZXQoJ2Z1bmQnLGl0ZW0uc291cmNlSWQpO31cbiAgYXN5bmMgZnVuY3Rpb24gb3BlbkluY2x1ZGVkU3RvY2soaXRlbSl7aGlnaGxpZ2h0ZWRTdG9ja0lkPWl0ZW0uc291cmNlSWQ7c2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2U7b3BlbmVkU3Rvcnk9bnVsbDthd2FpdCBvcGVuTW9uZXkoKTthd2FpdCBmb2N1c01vbmV5VGFyZ2V0KCdzdG9jaycsaXRlbS5zb3VyY2VJZCk7fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuSW5jbHVkZWRDb21taXRtZW50KGl0ZW0pe3Nob3dTdG9yeUV2aWRlbmNlPWZhbHNlO29wZW5lZFN0b3J5PW51bGw7YXdhaXQgb3Blbk1vbmV5KCk7YXdhaXQgZm9jdXNNb25leVRhcmdldCgnY29tbWl0bWVudCcsaXRlbS5zb3VyY2VJZCk7fVxuICBjb25zdCByZWN1cnJpbmdPY2N1cnJlbmNlPWl0ZW09Pntjb25zdCBpZD10eXBlb2YgaXRlbT09PSdvYmplY3QnP2l0ZW0uc291cmNlSWQ6aXRlbTtjb25zdCBtYXRjaD1jb21taXRtZW50cy5maW5kKHZhbHVlPT5TdHJpbmcodmFsdWUuaWQpPT09U3RyaW5nKGlkKSl8fGNvbW1pdG1lbnRzLmZpbmQodmFsdWU9PnZhbHVlLmxhYmVsPT09aXRlbT8ubWVyY2hhbnQpO3JldHVybiAobWF0Y2h8fGNvbW1pdG1lbnRzLmxlbmd0aD09PTEmJmNvbW1pdG1lbnRzWzBdKT8uY3VycmVudE9jY3VycmVuY2U7fTtcbiAgYXN5bmMgZnVuY3Rpb24gbWFya0NvbW1pdG1lbnREb25lKGNvbW1pdG1lbnQpe2lmKGNvbXBsZXRpbmdDb21taXRtZW50SWQhPT1udWxsKXJldHVybjtjb25zdCBvY2N1cnJlbmNlPWNvbW1pdG1lbnQuY3VycmVudE9jY3VycmVuY2U7aWYoIW9jY3VycmVuY2U/Lm1vbnRoKXJldHVybjtjb21wbGV0aW5nQ29tbWl0bWVudElkPWNvbW1pdG1lbnQuaWQ7Y29tbWl0bWVudEVycm9yPScnO3RyeXthd2FpdCBjb21wbGV0ZVJlY3VycmluZ0NvbW1pdG1lbnQoY29tbWl0bWVudC5pZCxvY2N1cnJlbmNlLm1vbnRoKTthd2FpdCBQcm9taXNlLmFsbChbbG9hZENvbW1pdG1lbnRzKCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7Y29tbWl0bWVudEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IG1hcmsgdGhpcyBjb21taXRtZW50IGRvbmUuJzt9ZmluYWxseXtjb21wbGV0aW5nQ29tbWl0bWVudElkPW51bGw7fX1cbiAgZnVuY3Rpb24gc2lwSXNEdWUoaXRlbSl7cmV0dXJuIG11dHVhbEZ1bmRzLmZpbmQoZnVuZD0+U3RyaW5nKGZ1bmQuaWQpPT09U3RyaW5nKGl0ZW0uc291cmNlSWQpKT8uY3VycmVudFNpcD8uc3RhdHVzPT09J0RVRSc7fVxuICBmdW5jdGlvbiBzaXBJc0NvbmZpcm1lZChpdGVtKXtyZXR1cm4gbXV0dWFsRnVuZHMuZmluZChmdW5kPT5TdHJpbmcoZnVuZC5pZCk9PT1TdHJpbmcoaXRlbS5zb3VyY2VJZCkpPy5jdXJyZW50U2lwPy5zdGF0dXM9PT0nQ09ORklSTUVEJzt9XG4gIGZ1bmN0aW9uIGN1cnJlbnRDb21taXRtZW50SXNEdWUoKXtjb25zdCBjYXJkPW9wZW5lZFN0b3J5Py5jYXJkcz8uc2xpY2UoKS5zb3J0KChhLGIpPT4oYS5zZXF1ZW5jZXx8MCktKGIuc2VxdWVuY2V8fDApKVtzdG9yeVNsaWRlXTtyZXR1cm4gY2FyZD8uY29tcG9uZW50cz8uc29tZShjb21wb25lbnQ9PmNvbXBvbmVudC5sYWJlbD09PSdUaGlzIG1vbnRoJyYmY29tcG9uZW50LmRpc3BsYXlWYWx1ZT8uc3RhcnRzV2l0aCgnRHVlJykpO31cbiAgY29uc3QgaW5jb21lUmFuZ2VMYWJlbD12YWx1ZT0+KHtVTkRFUl8yNTAwMDonVW5kZXIg4oK5MjVrJyxGUk9NXzI1MDAwX1RPXzUwMDAwOifigrkyNWvigJPigrk1MGsnLEZST01fNTAwMDBfVE9fMTAwMDAwOifigrk1MGvigJPigrkxTCcsRlJPTV8xMDAwMDBfVE9fMjAwMDAwOifigrkxTOKAk+KCuTJMJyxPVkVSXzIwMDAwMDonT3ZlciDigrkyTCd9KVt2YWx1ZV18fCdOb3Qgc2hhcmVkJztcbiAgYXN5bmMgZnVuY3Rpb24gbG9hZEluY29tZU91dGxvb2soKXtpbmNvbWVTdGF0dXM9J2xvYWRpbmcnO2luY29tZUVycm9yPScnO3RyeXtpbmNvbWVPdXRsb29rPWF3YWl0IGdldEluY29tZU91dGxvb2soKTtpbmNvbWVTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2luY29tZVN0YXR1cz0nZXJyb3InO2luY29tZUVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgeW91ciBpbmNvbWUgb3V0bG9vay4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5Nb25leSgpe3Nob3dNb25leT10cnVlO3JlYWRNb25leU1vZHVsZXNDYWNoZSgpO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkTG9hbnMoKSxsb2FkTXV0dWFsRnVuZHMoKSxsb2FkU3RvY2tzKCksbG9hZEluY29tZU91dGxvb2soKSxsb2FkQ29tbWl0bWVudHMoKSxsb2FkQ3JlZGl0Q2FyZHMoKSxsb2FkRXhwZW5zZU9wdGlvbnMoKV0pO31cbiAgZnVuY3Rpb24gY2xvc2VNb25leSgpe3Nob3dNb25leT1mYWxzZTtoaWdobGlnaHRlZExvYW5JZD1udWxsO2hpZ2hsaWdodGVkRnVuZElkPW51bGw7fVxuICBjb25zdCBmdW5kU3VtbWFyeT1pZD0+bXV0dWFsRnVuZHMuZmluZChmdW5kPT5TdHJpbmcoZnVuZC5pZCk9PT1TdHJpbmcoaWQpKTtcbiAgYXN5bmMgZnVuY3Rpb24gbG9hZENyZWRpdENhcmRzKCl7Y3JlZGl0Q2FyZFN0YXR1cz0nbG9hZGluZyc7Y3JlZGl0Q2FyZEVycm9yPScnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0Q3JlZGl0Q2FyZHMoKTtjcmVkaXRDYXJkcz1yZXN1bHQuY2FyZHN8fFtdO2NyZWRpdENhcmRTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2NyZWRpdENhcmRTdGF0dXM9J2Vycm9yJztjcmVkaXRDYXJkRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBjcmVkaXQgY2FyZHMuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBsb2FkRXhwZW5zZU9wdGlvbnMoKXtpZihvcHRpb25zU3RhdHVzPT09J2xvYWRpbmcnKXJldHVybjt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IGdldEV4cGVuc2VPcHRpb25zKCk7ZWRpdE9wdGlvbnM9e2NhdGVnb3JpZXM6cmVzdWx0LmNhdGVnb3JpZXN8fFtdLG1lcmNoYW50czpyZXN1bHQubWVyY2hhbnRzfHxbXSxhY2NvdW50czpyZXN1bHQuYWNjb3VudHN8fFtdfTtvcHRpb25zU3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtvcHRpb25zU3RhdHVzPSdlcnJvcic7b3B0aW9uc0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGxvYWQgYWNjb3VudHMuJzt9fVxuICBmdW5jdGlvbiBvcGVuQ3JlZGl0Q2FyZEZvcm0oY2FyZD1udWxsKXtjcmVkaXRDYXJkRXJyb3I9Jyc7Y3JlZGl0Q2FyZEVkaXRpbmdJZD1jYXJkPy5pZD8/bnVsbDtjcmVkaXRDYXJkRm9ybT1jYXJkP3thY2NvdW50UmVmZXJlbmNlSWQ6U3RyaW5nKGNhcmQuYWNjb3VudFJlZmVyZW5jZUlkKSxjYXJkTmFtZTpjYXJkLmNhcmROYW1lLGlzc3Vlck5hbWU6Y2FyZC5pc3N1ZXJOYW1lLHN0YXRlbWVudERheTpTdHJpbmcoY2FyZC5zdGF0ZW1lbnREYXkpLGR1ZURheTpTdHJpbmcoY2FyZC5kdWVEYXkpfTp7YWNjb3VudFJlZmVyZW5jZUlkOicnLGNhcmROYW1lOicnLGlzc3Vlck5hbWU6Jycsc3RhdGVtZW50RGF5OicnLGR1ZURheTonJ307c2hvd0NyZWRpdENhcmRGb3JtPXRydWU7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlQ3JlZGl0Q2FyZCgpe2NvbnN0IHN0YXRlbWVudERheT1OdW1iZXIoY3JlZGl0Q2FyZEZvcm0uc3RhdGVtZW50RGF5KSxkdWVEYXk9TnVtYmVyKGNyZWRpdENhcmRGb3JtLmR1ZURheSk7aWYoIWNyZWRpdENhcmRGb3JtLmFjY291bnRSZWZlcmVuY2VJZHx8IWNyZWRpdENhcmRGb3JtLmNhcmROYW1lLnRyaW0oKXx8IWNyZWRpdENhcmRGb3JtLmlzc3Vlck5hbWUudHJpbSgpfHxzdGF0ZW1lbnREYXk8MXx8c3RhdGVtZW50RGF5PjI4fHxkdWVEYXk8MXx8ZHVlRGF5PjI4KXtjcmVkaXRDYXJkRXJyb3I9J0Nob29zZSB0aGUgY2FwdHVyZWQgY2FyZCBhY2NvdW50IGFuZCBlbnRlciBkYXlzIGZyb20gMSB0byAyOC4nO3JldHVybjt9Y3JlZGl0Q2FyZFNhdmluZz10cnVlO2NyZWRpdENhcmRFcnJvcj0nJztjb25zdCBwYXlsb2FkPXthY2NvdW50UmVmZXJlbmNlSWQ6TnVtYmVyKGNyZWRpdENhcmRGb3JtLmFjY291bnRSZWZlcmVuY2VJZCksY2FyZE5hbWU6Y3JlZGl0Q2FyZEZvcm0uY2FyZE5hbWUudHJpbSgpLGlzc3Vlck5hbWU6Y3JlZGl0Q2FyZEZvcm0uaXNzdWVyTmFtZS50cmltKCksc3RhdGVtZW50RGF5LGR1ZURheX07dHJ5e2NvbnN0IHNhdmVkPWNyZWRpdENhcmRFZGl0aW5nSWQ9PT1udWxsP2F3YWl0IGNyZWF0ZUNyZWRpdENhcmQocGF5bG9hZCk6YXdhaXQgdXBkYXRlQ3JlZGl0Q2FyZChjcmVkaXRDYXJkRWRpdGluZ0lkLHBheWxvYWQpO2NyZWRpdENhcmRzPWNyZWRpdENhcmRFZGl0aW5nSWQ9PT1udWxsP1tzYXZlZCwuLi5jcmVkaXRDYXJkc106Y3JlZGl0Q2FyZHMubWFwKGNhcmQ9PmNhcmQuaWQ9PT1zYXZlZC5pZD9zYXZlZDpjYXJkKTtjcmVkaXRDYXJkU3RhdHVzPSdyZWFkeSc7c2hvd0NyZWRpdENhcmRGb3JtPWZhbHNlO2F3YWl0IHJlZnJlc2hTdG9yaWVzKCk7fWNhdGNoKGNhdXNlKXtjcmVkaXRDYXJkRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc2F2ZSB0aGlzIGNyZWRpdCBjYXJkLic7fWZpbmFsbHl7Y3JlZGl0Q2FyZFNhdmluZz1mYWxzZTt9fVxuICBmdW5jdGlvbiBvcGVuSW5jb21lRmxvdygpe2luY29tZUVycm9yPScnO3NhbGFyeUZvcm09e3NhbGFyeVZpc2liaWxpdHk6J1JBTkdFJyxzYWxhcnlSYW5nZTonRlJPTV81MDAwMF9UT18xMDAwMDAnLGV4YWN0TW9udGhseVNhbGFyeTonJyxzYWxhcnlGcmVxdWVuY3k6J01PTlRITFknfTtzaG93SW5jb21lRmxvdz10cnVlO31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZVNhbGFyeSgpe2luY29tZVNhdmluZz10cnVlO2luY29tZUVycm9yPScnO3RyeXthd2FpdCBzYXZlSW5jb21lUHJvZmlsZSh7Li4uc2FsYXJ5Rm9ybSxleGFjdE1vbnRobHlTYWxhcnk6c2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PT09J0VYQUNUJz9OdW1iZXIoc2FsYXJ5Rm9ybS5leGFjdE1vbnRobHlTYWxhcnkpOm51bGx9KTthd2FpdCBsb2FkSW5jb21lT3V0bG9vaygpO3Nob3dJbmNvbWVGbG93PWZhbHNlO31jYXRjaChjYXVzZSl7aW5jb21lRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3Qgc2F2ZSB0aGlzIHByZWZlcmVuY2UuJzt9ZmluYWxseXtpbmNvbWVTYXZpbmc9ZmFsc2U7fX1cbiAgZnVuY3Rpb24gb3BlbkxvYW5Gb3JtKGxvYW49bnVsbCl7bG9hbkVycm9yPScnO2xvYW5FZGl0aW5nSWQ9bG9hbj8uaWQ/P251bGw7bG9hbkZvcm09bG9hbj97bG9hbk5hbWU6bG9hbi5sb2FuTmFtZXx8JycsbG9hblR5cGU6bG9hbi5sb2FuVHlwZXx8J0hPTUUnLGxlbmRlck5hbWU6bG9hbi5sZW5kZXJOYW1lfHwnJyxvcmlnaW5hbFByaW5jaXBhbDpTdHJpbmcobG9hbi5vcmlnaW5hbFByaW5jaXBhbD8/JycpLG1vbnRobHlFbWlBbW91bnQ6U3RyaW5nKGxvYW4ubW9udGhseUVtaUFtb3VudD8/JycpLHRvdGFsVGVudXJlTW9udGhzOlN0cmluZyhsb2FuLnRvdGFsVGVudXJlTW9udGhzPz8nJyksZmlyc3RFbWlEdWVEYXRlOmxvY2FsSW5wdXREYXRlKGxvYW4uZmlyc3RFbWlEdWVEYXRlKSxub3Rlczpsb2FuLm5vdGVzfHwnJ306e2xvYW5OYW1lOicnLGxvYW5UeXBlOidIT01FJyxsZW5kZXJOYW1lOicnLG9yaWdpbmFsUHJpbmNpcGFsOicnLG1vbnRobHlFbWlBbW91bnQ6JycsdG90YWxUZW51cmVNb250aHM6JycsZmlyc3RFbWlEdWVEYXRlOicnLG5vdGVzOicnfTtzaG93TG9hbkZvcm09dHJ1ZTt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVMb2FuKCl7Y29uc3Qgb3JpZ2luYWxQcmluY2lwYWw9TnVtYmVyKGxvYW5Gb3JtLm9yaWdpbmFsUHJpbmNpcGFsKSxtb250aGx5RW1pQW1vdW50PU51bWJlcihsb2FuRm9ybS5tb250aGx5RW1pQW1vdW50KSx0b3RhbFRlbnVyZU1vbnRocz1OdW1iZXIobG9hbkZvcm0udG90YWxUZW51cmVNb250aHMpO2lmKCFsb2FuRm9ybS5sb2FuTmFtZS50cmltKCl8fCFsb2FuRm9ybS5sZW5kZXJOYW1lLnRyaW0oKXx8IWxvYW5Gb3JtLmZpcnN0RW1pRHVlRGF0ZXx8b3JpZ2luYWxQcmluY2lwYWw8PTB8fG1vbnRobHlFbWlBbW91bnQ8PTB8fCFOdW1iZXIuaXNJbnRlZ2VyKHRvdGFsVGVudXJlTW9udGhzKXx8dG90YWxUZW51cmVNb250aHM8PTApe2xvYW5FcnJvcj0nQ29tcGxldGUgZXZlcnkgcmVxdWlyZWQgbG9hbiBkZXRhaWwgd2l0aCB2YWxpZCBwb3NpdGl2ZSBhbW91bnRzLic7cmV0dXJuO31jb25zdCBwYXlsb2FkPXtsb2FuTmFtZTpsb2FuRm9ybS5sb2FuTmFtZS50cmltKCksbG9hblR5cGU6bG9hbkZvcm0ubG9hblR5cGUsbGVuZGVyTmFtZTpsb2FuRm9ybS5sZW5kZXJOYW1lLnRyaW0oKSxvcmlnaW5hbFByaW5jaXBhbCxtb250aGx5RW1pQW1vdW50LHRvdGFsVGVudXJlTW9udGhzLGZpcnN0RW1pRHVlRGF0ZTpsb2FuRm9ybS5maXJzdEVtaUR1ZURhdGUsbm90ZXM6bG9hbkZvcm0ubm90ZXN9O2xvYW5TYXZpbmc9dHJ1ZTtsb2FuRXJyb3I9Jyc7dHJ5e2NvbnN0IHNhdmVkPWxvYW5FZGl0aW5nSWQ9PW51bGw/YXdhaXQgY3JlYXRlTG9hbihwYXlsb2FkKTphd2FpdCB1cGRhdGVMb2FuKGxvYW5FZGl0aW5nSWQscGF5bG9hZCk7bG9hbnM9bG9hbkVkaXRpbmdJZD09bnVsbD9bLi4ubG9hbnMsc2F2ZWRdOmxvYW5zLm1hcChsb2FuPT5sb2FuLmlkPT09c2F2ZWQuaWQ/c2F2ZWQ6bG9hbik7c2hvd0xvYW5Gb3JtPWZhbHNlO2xvYW5TdGF0dXM9J3JlYWR5Jzthd2FpdCByZWZyZXNoU3RvcmllcygpO31jYXRjaChjYXVzZSl7bG9hbkVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgdGhpcyBsb2FuLic7fWZpbmFsbHl7bG9hblNhdmluZz1mYWxzZTt9fVxuICBhc3luYyBmdW5jdGlvbiByZW1vdmVMb2FuKGxvYW4pe2lmKGxvYW5EZWxldGluZ0lkIT09bnVsbClyZXR1cm47bG9hbkRlbGV0aW5nSWQ9bG9hbi5pZDtsb2FuRXJyb3I9Jyc7dHJ5e2F3YWl0IGRlbGV0ZUxvYW4obG9hbi5pZCk7bG9hbnM9bG9hbnMuZmlsdGVyKGl0ZW09Pml0ZW0uaWQhPT1sb2FuLmlkKTtzYXZlTW9uZXlNb2R1bGVzQ2FjaGUoKTthd2FpdCByZWZyZXNoU3RvcmllcygpO31jYXRjaChjYXVzZSl7bG9hbkVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGRlbGV0ZSB0aGlzIGxvYW4uJzt9ZmluYWxseXtsb2FuRGVsZXRpbmdJZD1udWxsO319XG4gIGFzeW5jIGZ1bmN0aW9uIHBheUxvYW5FbWkobG9hbiwgb2NjdXJyZW5jZSl7dHJ5e2F3YWl0IG1hcmtMb2FuRW1pUGFpZChsb2FuLmlkLG9jY3VycmVuY2UubW9udGgpO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkTG9hbnMoKSxyZWZyZXNoU3RvcmllcygpXSk7fWNhdGNoKGNhdXNlKXtsb2FuRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbWFyayB0aGlzIEVNSSBwYWlkLic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gb3BlbkxvYW5IaXN0b3J5KGxvYW4pe2xvYW5IaXN0b3J5PXtsb2FuTmFtZTpsb2FuLmxvYW5OYW1lfTtsb2FuSGlzdG9yeVN0YXR1cz0nbG9hZGluZyc7bG9hbkhpc3RvcnlFcnJvcj0nJzt0cnl7bG9hbkhpc3Rvcnk9YXdhaXQgZ2V0TG9hbkhpc3RvcnkobG9hbi5pZCk7bG9hbkhpc3RvcnlTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2xvYW5IaXN0b3J5U3RhdHVzPSdlcnJvcic7bG9hbkhpc3RvcnlFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIHBheW1lbnQgaGlzdG9yeS4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIHBheUxvYW5IaXN0b3J5RW1pKG9jY3VycmVuY2Upe2lmKCFsb2FuSGlzdG9yeSlyZXR1cm47dHJ5e2F3YWl0IG1hcmtMb2FuRW1pUGFpZChsb2FuSGlzdG9yeS5pZCxvY2N1cnJlbmNlLm1vbnRoKTthd2FpdCBQcm9taXNlLmFsbChbbG9hZExvYW5zKCksb3BlbkxvYW5IaXN0b3J5KGxvYW5IaXN0b3J5KSxyZWZyZXNoU3RvcmllcygpXSk7fWNhdGNoKGNhdXNlKXtsb2FuSGlzdG9yeUVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IG1hcmsgdGhpcyBFTUkgcGFpZC4nO319XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5Db21taXRtZW50SGlzdG9yeShjb21taXRtZW50KXtjb21taXRtZW50SGlzdG9yeT17bGFiZWw6Y29tbWl0bWVudC5sYWJlbH07Y29tbWl0bWVudEhpc3RvcnlTdGF0dXM9J2xvYWRpbmcnO2NvbW1pdG1lbnRIaXN0b3J5RXJyb3I9Jyc7dHJ5e2NvbW1pdG1lbnRIaXN0b3J5PWF3YWl0IGdldFJlY3VycmluZ0NvbW1pdG1lbnRIaXN0b3J5KGNvbW1pdG1lbnQuaWQpO2NvbW1pdG1lbnRIaXN0b3J5U3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtjb21taXRtZW50SGlzdG9yeVN0YXR1cz0nZXJyb3InO2NvbW1pdG1lbnRIaXN0b3J5RXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBwYXltZW50IGhpc3RvcnkuJzt9fVxuICBmdW5jdGlvbiBvcGVuTXV0dWFsRnVuZEZvcm0oKXtmdW5kRXJyb3I9Jyc7ZnVuZFNhdmVkPWZhbHNlO3NjaGVtZVF1ZXJ5PScnO3NlbGVjdGVkU2NoZW1lPW51bGw7c2hvd1NjaGVtZU1lbnU9ZmFsc2U7ZnVuZEZvcm09e2hhc1NpcDonWUVTJyxzaXBBbW91bnQ6JzI1MDAwJyxzaXBEYXRlOic1JyxzdGFydE1vbnRoOicyMDI2LTEwJyxoYXNIb2xkaW5nOidZRVMnLGN1cnJlbnRVbml0czonMTI4LjQ1NicsdG90YWxJbnZlc3RlZDonMTAwMDAnfTtzaG93TXV0dWFsRnVuZEZvcm09dHJ1ZTt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNlYXJjaFNjaGVtZXModmFsdWUpe3NjaGVtZVF1ZXJ5PXZhbHVlO3NlbGVjdGVkU2NoZW1lPW51bGw7c2hvd1NjaGVtZU1lbnU9dHJ1ZTtmdW5kRXJyb3I9Jyc7aWYodmFsdWUudHJpbSgpLmxlbmd0aDwyKXtzY2hlbWVSZXN1bHRzPVtdO3NjaGVtZVNlYXJjaFN0YXR1cz0naWRsZSc7cmV0dXJuO31jb25zdCByZXF1ZXN0SWQ9KytzY2hlbWVTZWFyY2hSZXF1ZXN0O3NjaGVtZVNlYXJjaFN0YXR1cz0nbG9hZGluZyc7dHJ5e2NvbnN0IHJlc3VsdD1hd2FpdCBzZWFyY2hNdXR1YWxGdW5kcyh2YWx1ZS50cmltKCkpO2lmKHJlcXVlc3RJZCE9PXNjaGVtZVNlYXJjaFJlcXVlc3QpcmV0dXJuO3NjaGVtZVJlc3VsdHM9QXJyYXkuaXNBcnJheShyZXN1bHQpP3Jlc3VsdDpyZXN1bHQuc2NoZW1lc3x8W107c2NoZW1lU2VhcmNoU3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtpZihyZXF1ZXN0SWQhPT1zY2hlbWVTZWFyY2hSZXF1ZXN0KXJldHVybjtzY2hlbWVSZXN1bHRzPVtdO3NjaGVtZVNlYXJjaFN0YXR1cz0nZXJyb3InO2Z1bmRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzZWFyY2ggdGhlIHNjaGVtZSBtYXN0ZXIuJzt9fVxuICBmdW5jdGlvbiBzZWxlY3RTY2hlbWUoc2NoZW1lKXtzZWxlY3RlZFNjaGVtZT1zY2hlbWU7c2NoZW1lUXVlcnk9c2NoZW1lLnNjaGVtZU5hbWU7c2hvd1NjaGVtZU1lbnU9ZmFsc2U7ZnVuZEVycm9yPScnO31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZU11dHVhbEZ1bmQoKXtjb25zdCBzaXBBbW91bnQ9TnVtYmVyKGZ1bmRGb3JtLnNpcEFtb3VudCksdW5pdHM9TnVtYmVyKGZ1bmRGb3JtLmN1cnJlbnRVbml0cyksaW52ZXN0ZWQ9TnVtYmVyKGZ1bmRGb3JtLnRvdGFsSW52ZXN0ZWQpO2lmKCFzZWxlY3RlZFNjaGVtZSl7ZnVuZEVycm9yPSdDaG9vc2UgYSBzY2hlbWUgZnJvbSB0aGUgdmVyaWZpZWQgc2NoZW1lIG1hc3Rlci4nO3JldHVybjt9aWYoZnVuZEZvcm0uaGFzU2lwPT09J1lFUycmJihzaXBBbW91bnQ8PTB8fCFmdW5kRm9ybS5zaXBEYXRlfHwhZnVuZEZvcm0uc3RhcnRNb250aCkpe2Z1bmRFcnJvcj0nQWRkIGEgdmFsaWQgbW9udGhseSBhbW91bnQsIFNJUCBkYXRlLCBhbmQgc3RhcnQgbW9udGguJztyZXR1cm47fWlmKGZ1bmRGb3JtLmhhc0hvbGRpbmc9PT0nWUVTJyYmKCEodW5pdHM+MCl8fCEoaW52ZXN0ZWQ+MCkpKXtmdW5kRXJyb3I9J0VudGVyIGN1cnJlbnQgdW5pdHMgYW5kIGludmVzdGVkIGFtb3VudCBncmVhdGVyIHRoYW4gemVyby4nO3JldHVybjt9Y29uc3QgcGF5bG9hZD17c2NoZW1lQ29kZTpzZWxlY3RlZFNjaGVtZS5zY2hlbWVDb2RlLHNjaGVtZU5hbWU6c2VsZWN0ZWRTY2hlbWUuc2NoZW1lTmFtZSwuLi4oZnVuZEZvcm0uaGFzU2lwPT09J1lFUyc/e21vbnRobHlTaXBBbW91bnQ6c2lwQW1vdW50LHNpcERheTpOdW1iZXIoZnVuZEZvcm0uc2lwRGF0ZSksc3RhcnRNb250aDpmdW5kRm9ybS5zdGFydE1vbnRofTp7fSksLi4uKHNlbGVjdGVkU2NoZW1lLmlzaW4/e2lzaW46c2VsZWN0ZWRTY2hlbWUuaXNpbn06e30pLC4uLihmdW5kRm9ybS5oYXNIb2xkaW5nPT09J1lFUyc/e2V4aXN0aW5nSG9sZGluZzp7Y3VycmVudFVuaXRzOnVuaXRzLHRvdGFsSW52ZXN0ZWRBbW91bnQ6aW52ZXN0ZWR9fTp7fSl9O2Z1bmRTYXZpbmc9dHJ1ZTtmdW5kRXJyb3I9Jyc7dHJ5e2F3YWl0IGNyZWF0ZU11dHVhbEZ1bmQocGF5bG9hZCk7ZnVuZFNhdmVkPXRydWU7YXdhaXQgbG9hZE11dHVhbEZ1bmRzKCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe2Z1bmRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBjcmVhdGUgdGhpcyBtdXR1YWwgZnVuZC4nO31maW5hbGx5e2Z1bmRTYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlTXV0dWFsRnVuZChmdW5kKXtpZihtdXR1YWxGdW5kRGVsZXRpbmdJZCE9PW51bGwpcmV0dXJuO211dHVhbEZ1bmREZWxldGluZ0lkPWZ1bmQuaWQ7bXV0dWFsRnVuZEVycm9yPScnO3RyeXthd2FpdCBkZWxldGVNdXR1YWxGdW5kKGZ1bmQuaWQpO211dHVhbEZ1bmRzPW11dHVhbEZ1bmRzLmZpbHRlcihpdGVtPT5pdGVtLmlkIT09ZnVuZC5pZCk7c2F2ZU1vbmV5TW9kdWxlc0NhY2hlKCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe211dHVhbEZ1bmRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBkZWxldGUgdGhpcyBtdXR1YWwgZnVuZC4nO31maW5hbGx5e211dHVhbEZ1bmREZWxldGluZ0lkPW51bGw7fX1cbiAgZnVuY3Rpb24gb3BlbkZ1bmRTaXBQbGFuKGZ1bmQpe2Z1bmRTaXBUYXJnZXQ9ZnVuZDtmdW5kU2lwRm9ybT17YW1vdW50OicnLGRheTonJyxzdGFydE1vbnRoOm5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLDcpfTtmdW5kRXJyb3I9Jyc7fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlRnVuZFNpcFBsYW4oKXtjb25zdCBhbW91bnQ9TnVtYmVyKGZ1bmRTaXBGb3JtLmFtb3VudCksZGF5PU51bWJlcihmdW5kU2lwRm9ybS5kYXkpO2lmKCEoYW1vdW50PjApfHwhKGRheT49MSYmZGF5PD0yOCl8fCFmdW5kU2lwRm9ybS5zdGFydE1vbnRoKXtmdW5kRXJyb3I9J0VudGVyIGEgcG9zaXRpdmUgbW9udGhseSBhbW91bnQsIGEgZGF5IGZyb20gMSB0byAyOCwgYW5kIGEgc3RhcnQgbW9udGguJztyZXR1cm47fWZ1bmRTaXBTYXZpbmc9dHJ1ZTt0cnl7YXdhaXQgY3JlYXRlTXV0dWFsRnVuZFNpcChmdW5kU2lwVGFyZ2V0LmlkLHthbW91bnQsZGF5LHN0YXJ0TW9udGg6ZnVuZFNpcEZvcm0uc3RhcnRNb250aH0pO2Z1bmRTaXBUYXJnZXQ9bnVsbDthd2FpdCBsb2FkTXV0dWFsRnVuZHMoKTthd2FpdCByZWZyZXNoU3RvcmllcygpO31jYXRjaChjYXVzZSl7ZnVuZEVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgdGhpcyBTSVAuJzt9ZmluYWxseXtmdW5kU2lwU2F2aW5nPWZhbHNlO319XG4gIGZ1bmN0aW9uIG9wZW5TdG9ja0Zvcm0oKXtzdG9ja0Vycm9yPScnO3N0b2NrUXVlcnk9Jyc7c2VsZWN0ZWRTdG9jaz1udWxsO3N0b2NrUmVzdWx0cz1bXTtzdG9ja0Zvcm09e3F1YW50aXR5OicnLHRvdGFsSW52ZXN0ZWQ6Jyd9O3Nob3dTdG9ja0Zvcm09dHJ1ZTt9XG4gIGFzeW5jIGZ1bmN0aW9uIGZpbmRTdG9ja3ModmFsdWUpe3N0b2NrUXVlcnk9dmFsdWU7c2VsZWN0ZWRTdG9jaz1udWxsO3N0b2NrRXJyb3I9Jyc7aWYodmFsdWUudHJpbSgpLmxlbmd0aDwyKXtzdG9ja1Jlc3VsdHM9W107c3RvY2tTZWFyY2hTdGF0dXM9J2lkbGUnO3JldHVybjt9Y29uc3QgcmVxdWVzdElkPSsrc3RvY2tTZWFyY2hSZXF1ZXN0O3N0b2NrU2VhcmNoU3RhdHVzPSdsb2FkaW5nJzt0cnl7Y29uc3QgcmVzdWx0PWF3YWl0IHNlYXJjaFN0b2Nrcyh2YWx1ZS50cmltKCkpO2lmKHJlcXVlc3RJZCE9PXN0b2NrU2VhcmNoUmVxdWVzdClyZXR1cm47c3RvY2tSZXN1bHRzPUFycmF5LmlzQXJyYXkocmVzdWx0KT9yZXN1bHQ6W107c3RvY2tTZWFyY2hTdGF0dXM9J3JlYWR5Jzt9Y2F0Y2goY2F1c2Upe2lmKHJlcXVlc3RJZCE9PXN0b2NrU2VhcmNoUmVxdWVzdClyZXR1cm47c3RvY2tSZXN1bHRzPVtdO3N0b2NrU2VhcmNoU3RhdHVzPSdlcnJvcic7c3RvY2tFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzZWFyY2ggc3RvY2sgc3ltYm9scy4nO319XG4gIGZ1bmN0aW9uIHNlbGVjdFN0b2NrKHN0b2NrKXtzZWxlY3RlZFN0b2NrPXN0b2NrO3N0b2NrUXVlcnk9YCR7c3RvY2submFtZX0gKCR7c3RvY2suc3ltYm9sfSlgO3N0b2NrUmVzdWx0cz1bXTtzdG9ja0Vycm9yPScnO31cbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZVN0b2NrKCl7Y29uc3QgcXVhbnRpdHk9TnVtYmVyKHN0b2NrRm9ybS5xdWFudGl0eSksdG90YWxJbnZlc3RlZEFtb3VudD1OdW1iZXIoc3RvY2tGb3JtLnRvdGFsSW52ZXN0ZWQpO2lmKCFzZWxlY3RlZFN0b2NrKXtzdG9ja0Vycm9yPSdDaG9vc2UgYSBzdG9jayBmcm9tIHRoZSBzZWFyY2ggcmVzdWx0cy4nO3JldHVybjt9aWYoIShxdWFudGl0eT4wKXx8ISh0b3RhbEludmVzdGVkQW1vdW50PjApKXtzdG9ja0Vycm9yPSdFbnRlciB2YWxpZCBwb3NpdGl2ZSBxdWFudGl0eSBhbmQgdG90YWwgaW52ZXN0ZWQgYW1vdW50Lic7cmV0dXJuO31zdG9ja1NhdmluZz10cnVlO3N0b2NrRXJyb3I9Jyc7dHJ5e2F3YWl0IGNyZWF0ZVN0b2NrKHtzeW1ib2w6c2VsZWN0ZWRTdG9jay5zeW1ib2wsbmFtZTpzZWxlY3RlZFN0b2NrLm5hbWUsZXhjaGFuZ2U6c2VsZWN0ZWRTdG9jay5leGNoYW5nZSxxdWFudGl0eSx0b3RhbEludmVzdGVkQW1vdW50fSk7c2hvd1N0b2NrRm9ybT1mYWxzZTthd2FpdCBsb2FkU3RvY2tzKCk7fWNhdGNoKGNhdXNlKXtzdG9ja0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGFkZCB0aGlzIHN0b2NrLic7fWZpbmFsbHl7c3RvY2tTYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlU3RvY2soc3RvY2spe2lmKHN0b2NrRGVsZXRpbmdJZCE9PW51bGwpcmV0dXJuO3N0b2NrRGVsZXRpbmdJZD1zdG9jay5pZDtzdG9ja0Vycm9yPScnO3RyeXthd2FpdCBkZWxldGVTdG9jayhzdG9jay5pZCk7c3RvY2tzPXN0b2Nrcy5maWx0ZXIoaXRlbT0+aXRlbS5pZCE9PXN0b2NrLmlkKTtzYXZlTW9uZXlNb2R1bGVzQ2FjaGUoKTt9Y2F0Y2goY2F1c2Upe3N0b2NrRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgZGVsZXRlIHRoaXMgc3RvY2suJzt9ZmluYWxseXtzdG9ja0RlbGV0aW5nSWQ9bnVsbDt9fVxuICBmdW5jdGlvbiBvcGVuU3RvY2tQbGFuKHN0b2NrKXtzdG9ja1BsYW5UYXJnZXQ9c3RvY2s7c3RvY2tQbGFuRm9ybT17YW1vdW50OnN0b2NrLmFjdGl2ZU1vbnRobHlQbGFuPy5hbW91bnR8fCcnLGRheTpzdG9jay5hY3RpdmVNb250aGx5UGxhbj8uZGF5fHwnJyxzdGFydE1vbnRoOnN0b2NrLmFjdGl2ZU1vbnRobHlQbGFuPy5zdGFydE1vbnRofHxuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCw3KX07c3RvY2tFcnJvcj0nJzt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVTdG9ja1BsYW4oKXtjb25zdCBhbW91bnQ9TnVtYmVyKHN0b2NrUGxhbkZvcm0uYW1vdW50KSxkYXk9TnVtYmVyKHN0b2NrUGxhbkZvcm0uZGF5KTtpZighKGFtb3VudD4wKXx8IShkYXk+PTEmJmRheTw9MjgpfHwhc3RvY2tQbGFuRm9ybS5zdGFydE1vbnRoKXtzdG9ja0Vycm9yPSdFbnRlciBhIHBvc2l0aXZlIGFtb3VudCwgYSBkYXkgZnJvbSAxIHRvIDI4LCBhbmQgYSBzdGFydCBtb250aC4nO3JldHVybjt9c3RvY2tQbGFuU2F2aW5nPXRydWU7dHJ5e2F3YWl0IGNyZWF0ZVN0b2NrTW9udGhseVBsYW4oc3RvY2tQbGFuVGFyZ2V0LmlkLHthbW91bnQsZGF5LHN0YXJ0TW9udGg6c3RvY2tQbGFuRm9ybS5zdGFydE1vbnRofSk7c3RvY2tQbGFuVGFyZ2V0PW51bGw7YXdhaXQgbG9hZFN0b2NrcygpO2F3YWl0IHJlZnJlc2hTdG9yaWVzKCk7fWNhdGNoKGNhdXNlKXtzdG9ja0Vycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgdGhpcyBtb250aGx5IHBsYW4uJzt9ZmluYWxseXtzdG9ja1BsYW5TYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gY29uZmlybVN0b2NrUGxhbigpe2NvbnN0IGFtb3VudD1OdW1iZXIoc3RvY2tQbGFuQ29uZmlybWF0aW9uLmFtb3VudCksZXhlY3V0aW9uUHJpY2U9TnVtYmVyKHN0b2NrUGxhbkNvbmZpcm1hdGlvbi5wcmljZSk7aWYoIShhbW91bnQ+MCl8fCEoZXhlY3V0aW9uUHJpY2U+MCkpcmV0dXJuO3RyeXthd2FpdCBjb25maXJtU3RvY2tNb250aGx5UGxhbihzdG9ja1BsYW5Db25maXJtYXRpb25UYXJnZXQuaWQsc3RvY2tQbGFuQ29uZmlybWF0aW9uVGFyZ2V0LmN1cnJlbnRNb250aGx5UGxhbi5tb250aCx7YW1vdW50LGV4ZWN1dGlvblByaWNlLHRyYW5zYWN0aW9uRGF0ZTpuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwxMCl9KTtzdG9ja1BsYW5Db25maXJtYXRpb25UYXJnZXQ9bnVsbDthd2FpdCBsb2FkU3RvY2tzKCk7YXdhaXQgcmVmcmVzaFN0b3JpZXMoKTt9Y2F0Y2goY2F1c2Upe3N0b2NrRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgY29uZmlybSB0aGlzIEVURiBpbnZlc3RtZW50Lic7fX1cbiAgYXN5bmMgZnVuY3Rpb24gb3BlblN0b2NrRGV0YWlsKGlkKXtzdG9ja0RldGFpbD17aWR9O3N0b2NrRGV0YWlsU3RhdHVzPSdsb2FkaW5nJzt0cnl7c3RvY2tEZXRhaWw9YXdhaXQgZ2V0U3RvY2soaWQpO3N0b2NrRGV0YWlsU3RhdHVzPSdyZWFkeSc7fWNhdGNoKGNhdXNlKXtzdG9ja0RldGFpbFN0YXR1cz0nZXJyb3InO3N0b2NrRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCB0aGlzIHN0b2NrLic7fX1cbiAgZnVuY3Rpb24gb3BlblNpcENvbmZpcm1hdGlvbihmdW5kLG9jY3VycmVuY2Upe2NvbmZpcm1pbmdTaXA9e2Z1bmQsb2NjdXJyZW5jZX07c2lwQ29uZmlybUVycm9yPScnO3NpcENvbmZpcm1Gb3JtPXthbW91bnQ6U3RyaW5nKG9jY3VycmVuY2UuYW1vdW50fHxmdW5kLm1vbnRobHlTaXBBbW91bnR8fCcnKSx0cmFuc2FjdGlvbkRhdGU6b2NjdXJyZW5jZS50cmFuc2FjdGlvbkRhdGV8fG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLDEwKSxuYXY6b2NjdXJyZW5jZS5uYXY9PW51bGw/Jyc6U3RyaW5nKG9jY3VycmVuY2UubmF2KX07fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlU2lwQ29uZmlybWF0aW9uKCl7Y29uc3QgYW1vdW50PU51bWJlcihzaXBDb25maXJtRm9ybS5hbW91bnQpLG5hdj1OdW1iZXIoc2lwQ29uZmlybUZvcm0ubmF2KTtpZighKGFtb3VudD4wKXx8IXNpcENvbmZpcm1Gb3JtLnRyYW5zYWN0aW9uRGF0ZXx8IShuYXY+MCkpe3NpcENvbmZpcm1FcnJvcj0nRW50ZXIgYSB2YWxpZCBhbW91bnQsIHRyYW5zYWN0aW9uIGRhdGUsIGFuZCBOQVYuJztyZXR1cm47fXNpcENvbmZpcm1TYXZpbmc9dHJ1ZTtzaXBDb25maXJtRXJyb3I9Jyc7dHJ5e2NvbnN0IHBheWxvYWQ9e2Ftb3VudCx0cmFuc2FjdGlvbkRhdGU6c2lwQ29uZmlybUZvcm0udHJhbnNhY3Rpb25EYXRlLG5hdixjYWxjdWxhdGlvblNvdXJjZTonTkFWX0VTVElNQVRFRCd9O2lmKGNvbmZpcm1pbmdTaXAub2NjdXJyZW5jZS5zdGF0dXM9PT0nQ09ORklSTUVEJylhd2FpdCB1cGRhdGVTaXBPY2N1cnJlbmNlKGNvbmZpcm1pbmdTaXAuZnVuZC5pZCxjb25maXJtaW5nU2lwLm9jY3VycmVuY2Uuc2NoZWR1bGVkTW9udGgscGF5bG9hZCk7ZWxzZSBhd2FpdCBjb25maXJtU2lwT2NjdXJyZW5jZShjb25maXJtaW5nU2lwLmZ1bmQuaWQsY29uZmlybWluZ1NpcC5vY2N1cnJlbmNlLnNjaGVkdWxlZE1vbnRoLHBheWxvYWQpO2NvbmZpcm1pbmdTaXA9bnVsbDthd2FpdCBsb2FkTXV0dWFsRnVuZHMoKTthd2FpdCByZWZyZXNoU3RvcmllcygpO31jYXRjaChjYXVzZSl7c2lwQ29uZmlybUVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IHNhdmUgdGhpcyBTSVAgYWxsb2NhdGlvbi4nO31maW5hbGx5e3NpcENvbmZpcm1TYXZpbmc9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gb3BlbkZ1bmREZXRhaWwoaWQpe2Z1bmREZXRhaWw9e2lkfTtmdW5kRGV0YWlsU3RhdHVzPSdsb2FkaW5nJztmdW5kRGV0YWlsRXJyb3I9Jyc7dHJ5e2Z1bmREZXRhaWw9YXdhaXQgZ2V0TXV0dWFsRnVuZChpZCk7ZnVuZERldGFpbFN0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7ZnVuZERldGFpbFN0YXR1cz0nZXJyb3InO2Z1bmREZXRhaWxFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIHRoaXMgZnVuZC4nO319XG4gIGZ1bmN0aW9uIG9wZW5MdW1wU3VtKGZ1bmQpe2x1bXBTdW1GdW5kPWZ1bmQ7bHVtcFN1bUVycm9yPScnO2x1bXBTdW1Gb3JtPXthbW91bnQ6JycsdHJhbnNhY3Rpb25EYXRlOm5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLDEwKSxuYXY6Jyd9O31cbiAgZnVuY3Rpb24gb3Blbkhpc3RvcnlFZGl0KGZ1bmQsZW50cnkpe2VkaXRpbmdGdW5kVHJhbnNhY3Rpb249e2Z1bmQsZW50cnl9O2Z1bmRUcmFuc2FjdGlvbkVycm9yPScnO2Z1bmRUcmFuc2FjdGlvbkZvcm09e2Ftb3VudDpTdHJpbmcoZW50cnkuYW1vdW50fHwnJyksdHJhbnNhY3Rpb25EYXRlOmVudHJ5LnRyYW5zYWN0aW9uRGF0ZXx8JycsbmF2OmVudHJ5Lm5hdj09bnVsbD8nJzpTdHJpbmcoZW50cnkubmF2KX07fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlRnVuZFRyYW5zYWN0aW9uKCl7Y29uc3QgYW1vdW50PU51bWJlcihmdW5kVHJhbnNhY3Rpb25Gb3JtLmFtb3VudCksbmF2PU51bWJlcihmdW5kVHJhbnNhY3Rpb25Gb3JtLm5hdik7aWYoIShhbW91bnQ+MCl8fCFmdW5kVHJhbnNhY3Rpb25Gb3JtLnRyYW5zYWN0aW9uRGF0ZXx8IShuYXY+MCkpe2Z1bmRUcmFuc2FjdGlvbkVycm9yPSdFbnRlciBhIHZhbGlkIGFtb3VudCwgdHJhbnNhY3Rpb24gZGF0ZSwgYW5kIE5BVi4nO3JldHVybjt9ZnVuZFRyYW5zYWN0aW9uU2F2aW5nPXRydWU7ZnVuZFRyYW5zYWN0aW9uRXJyb3I9Jyc7dHJ5e2F3YWl0IHVwZGF0ZU11dHVhbEZ1bmRUcmFuc2FjdGlvbihlZGl0aW5nRnVuZFRyYW5zYWN0aW9uLmZ1bmQuaWQsZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbi5lbnRyeS5pZCx7YW1vdW50LHRyYW5zYWN0aW9uRGF0ZTpmdW5kVHJhbnNhY3Rpb25Gb3JtLnRyYW5zYWN0aW9uRGF0ZSxuYXYsY2FsY3VsYXRpb25Tb3VyY2U6J1VTRVJfRU5URVJFRCd9KTtjb25zdCBpZD1lZGl0aW5nRnVuZFRyYW5zYWN0aW9uLmZ1bmQuaWQ7ZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbj1udWxsO2F3YWl0IFByb21pc2UuYWxsKFtsb2FkTXV0dWFsRnVuZHMoKSxvcGVuRnVuZERldGFpbChpZCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7ZnVuZFRyYW5zYWN0aW9uRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgdXBkYXRlIHRoaXMgaW52ZXN0bWVudC4nO31maW5hbGx5e2Z1bmRUcmFuc2FjdGlvblNhdmluZz1mYWxzZTt9fVxuICBhc3luYyBmdW5jdGlvbiBzYXZlTHVtcFN1bSgpe2NvbnN0IGFtb3VudD1OdW1iZXIobHVtcFN1bUZvcm0uYW1vdW50KSxuYXY9TnVtYmVyKGx1bXBTdW1Gb3JtLm5hdik7aWYoIShhbW91bnQ+MCl8fCFsdW1wU3VtRm9ybS50cmFuc2FjdGlvbkRhdGV8fCEobmF2PjApKXtsdW1wU3VtRXJyb3I9J0VudGVyIGEgcG9zaXRpdmUgYW1vdW50LCB0cmFuc2FjdGlvbiBkYXRlLCBhbmQgTkFWLic7cmV0dXJuO31sdW1wU3VtU2F2aW5nPXRydWU7dHJ5e2F3YWl0IGNyZWF0ZU11dHVhbEZ1bmRMdW1wU3VtKGx1bXBTdW1GdW5kLmlkLHthbW91bnQsdHJhbnNhY3Rpb25EYXRlOmx1bXBTdW1Gb3JtLnRyYW5zYWN0aW9uRGF0ZSxuYXYsY2FsY3VsYXRpb25Tb3VyY2U6J05BVl9FU1RJTUFURUQnfSk7bHVtcFN1bUZ1bmQ9bnVsbDthd2FpdCBQcm9taXNlLmFsbChbbG9hZE11dHVhbEZ1bmRzKCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7bHVtcFN1bUVycm9yPWNhdXNlPy5tZXNzYWdlfHwnQ291bGQgbm90IGFkZCB0aGlzIGx1bXAgc3VtLic7fWZpbmFsbHl7bHVtcFN1bVNhdmluZz1mYWxzZTt9fVxuICBmdW5jdGlvbiBuYXZpZ2F0ZShuZXh0KXt2aWV3PW5leHQ7aWYobmV4dCE9PSd0cmFuc2FjdGlvbnMnKXtzZWxlY3RlZERheT1udWxsO2FjdGl2aXR5VGFiPSdyZWNlbnQnO313aW5kb3cuc2Nyb2xsVG8oe3RvcDowLGJlaGF2aW9yOidzbW9vdGgnfSk7fVxuICBmdW5jdGlvbiBjdXJyZW50TG9jYWxNb250aCgpe2NvbnN0IG5vdz1uZXcgRGF0ZSgpO3JldHVybiBgJHtub3cuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcobm93LmdldE1vbnRoKCkrMSkucGFkU3RhcnQoMiwnMCcpfWA7fVxuICBmdW5jdGlvbiBjaGFuZ2VNb250aChvZmZzZXQpe2NvbnN0W3ksbV09c2VsZWN0ZWRNb250aC5zcGxpdCgnLScpLm1hcChOdW1iZXIpLG5leHQ9bmV3IERhdGUoRGF0ZS5VVEMoeSxtLTErb2Zmc2V0LDEpKS50b0lTT1N0cmluZygpLnNsaWNlKDAsNyk7aWYobmV4dDw9Y3VycmVudExvY2FsTW9udGgoKSl7c2VsZWN0ZWREYXk9bnVsbDtkYXlJdGVtcz1bXTthY3Rpdml0eVRhYj0ncmVjZW50Jztvbk1vbnRoQ2hhbmdlKG5leHQpO319XG4gIGZ1bmN0aW9uIGJ1aWxkQ2FsZW5kYXIobW9udGhWYWx1ZSxhcGlEYXlzKXtjb25zdFt5LG1dPW1vbnRoVmFsdWUuc3BsaXQoJy0nKS5tYXAoTnVtYmVyKSxjb3VudD1uZXcgRGF0ZSh5LG0sMCkuZ2V0RGF0ZSgpLGxlYWRpbmc9KG5ldyBEYXRlKHksbS0xLDEpLmdldERheSgpKzYpJTcsdmFsdWVzPW5ldyBNYXAoYXBpRGF5cy5tYXAoeD0+W051bWJlcihTdHJpbmcoeC5kYXRlKS5zbGljZSgtMikpLHhdKSksdG9kYXk9bmV3IERhdGUoKSxjdXJyZW50PXRvZGF5LmdldEZ1bGxZZWFyKCk9PT15JiZ0b2RheS5nZXRNb250aCgpKzE9PT1tO3JldHVybntsZWFkaW5nLGRheXM6QXJyYXkuZnJvbSh7bGVuZ3RoOmNvdW50fSwoXyxpKT0+e2NvbnN0IGRheT1pKzEsdj12YWx1ZXMuZ2V0KGRheSl8fHt9O3JldHVybntkYXksdG90YWxTcGVuZDpOdW1iZXIodi50b3RhbFNwZW5kfHwwKSx0cmFuc2FjdGlvbkNvdW50Ok51bWJlcih2LnRyYW5zYWN0aW9uQ291bnR8fDApLGludGVuc2l0eTpNYXRoLm1heCgwLE1hdGgubWluKDQsTnVtYmVyKHYuaW50ZW5zaXR5fHwwKSkpLGZ1dHVyZTpjdXJyZW50JiZkYXk+dG9kYXkuZ2V0RGF0ZSgpfTt9KX07fVxuICBhc3luYyBmdW5jdGlvbiBzZWxlY3REYXRlKGRheSl7aWYoIWRheXx8ZGF5LmZ1dHVyZSlyZXR1cm47c2VsZWN0ZWREYXk9ZGF5LmRheTthY3Rpdml0eVRhYj0nZGF5JztzaG93QWxsPWZhbHNlO2V4cGFuZGVkSWQ9bnVsbDthd2FpdCBsb2FkRGF5KCk7fVxuICBhc3luYyBmdW5jdGlvbiBsb2FkRGF5KCl7aWYoc2VsZWN0ZWREYXk9PW51bGwpcmV0dXJuO2RheVN0YXR1cz0nbG9hZGluZyc7dHJ5e2NvbnN0IHBhZ2U9YXdhaXQgZ2V0RXhwZW5zZXNGb3JEYXRlKHNlbGVjdGVkTW9udGgsaXNvRGF0ZShzZWxlY3RlZERheSksNTApO2RheUl0ZW1zPXBhZ2UuaXRlbXN8fHBhZ2UuZXhwZW5zZXN8fFtdO2RheVN0YXR1cz0ncmVhZHknO31jYXRjaHtkYXlTdGF0dXM9J2Vycm9yJzt9fVxuICBhc3luYyBmdW5jdGlvbiBvcGVuU3Rvcnkoc3Rvcnkpe29wZW5lZFN0b3J5PXN0b3J5O3N0b3J5U2xpZGU9MDtzaG93U3RvcnlFdmlkZW5jZT1mYWxzZTtjb25zdCBoYXNSZXZpZXc9KHN0b3J5LmNhcmRzfHxbXSkuc29tZShjYXJkPT4oY2FyZC5hY3Rpb25zfHxbXSkuc29tZShhY3Rpb249PmFjdGlvbi50eXBlPT09J09QRU5fQ09NTUlUTUVOVF9SRVZJRVcnKSk7aWYoaGFzUmV2aWV3KXtjb21taXRtZW50UmV2aWV3U3RhdHVzPSdsb2FkaW5nJztzaG93Q29tbWl0bWVudFJldmlldz10cnVlO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0Q29tbWl0bWVudFJldmlldyhzZWxlY3RlZE1vbnRoKTtjb21taXRtZW50UmV2aWV3PXJlc3VsdC5pdGVtc3x8W107Y29tbWl0bWVudFJldmlld1N0YXR1cz0ncmVhZHknO31jYXRjaChjYXVzZSl7Y29tbWl0bWVudFJldmlld1N0YXR1cz0nZXJyb3InO2NvbW1pdG1lbnRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBsb2FkIHBheW1lbnRzIG5lZWRpbmcgcmV2aWV3Lic7fX19XG4gIGZ1bmN0aW9uIHN0b3J5SGFzTG9hbihzdG9yeSl7cmV0dXJuIGlzQ29tbWl0bWVudChzdG9yeSkmJmV2aWRlbmNlRm9yKHN0b3J5LHN0b3J5U2xpZGUpLnNvbWUoaXRlbT0+L2xvYW4vaS50ZXN0KGl0ZW0uY2F0ZWdvcnkpKTt9XG4gIGFzeW5jIGZ1bmN0aW9uIHJlc29sdmVDYW5kaWRhdGUodHJhbnNhY3Rpb25JZCxjb21taXRtZW50SWQpe3Jlc29sdmluZ0NhbmRpZGF0ZT10cmFuc2FjdGlvbklkO3RyeXthd2FpdCByZXNvbHZlQ29tbWl0bWVudFJldmlldyh0cmFuc2FjdGlvbklkLGNvbW1pdG1lbnRJZCk7Y29tbWl0bWVudFJldmlldz1jb21taXRtZW50UmV2aWV3LmZpbHRlcihpdGVtPT5pdGVtLnRyYW5zYWN0aW9uSWQhPT10cmFuc2FjdGlvbklkKTthd2FpdCByZWZyZXNoU3RvcmllcygpO2lmKCFjb21taXRtZW50UmV2aWV3Lmxlbmd0aClzaG93Q29tbWl0bWVudFJldmlldz1mYWxzZTt9Y2F0Y2goY2F1c2Upe2NvbW1pdG1lbnRFcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzYXZlIHRoaXMgcmV2aWV3Lic7fWZpbmFsbHl7cmVzb2x2aW5nQ2FuZGlkYXRlPW51bGw7fX1cbiAgZnVuY3Rpb24gZW5kU3RvcnlTd2lwZShldmVudCxsZW5ndGgpe2lmKHN0b3J5VG91Y2hTdGFydD09PW51bGwpcmV0dXJuO2NvbnN0IGRpc3RhbmNlPWV2ZW50LmNoYW5nZWRUb3VjaGVzWzBdLmNsaWVudFgtc3RvcnlUb3VjaFN0YXJ0O2lmKE1hdGguYWJzKGRpc3RhbmNlKT40NSlzdG9yeVNsaWRlPU1hdGgubWF4KDAsTWF0aC5taW4obGVuZ3RoLTEsc3RvcnlTbGlkZSsoZGlzdGFuY2U8MD8xOi0xKSkpO3N0b3J5VG91Y2hTdGFydD1udWxsO31cbiAgZnVuY3Rpb24gZW5kUmFpbFN3aXBlKGV2ZW50LGxlbmd0aCxyYWlsKXtpZihzdG9yeVJhaWxUb3VjaFN0YXJ0PT09bnVsbClyZXR1cm47Y29uc3QgZGlzdGFuY2U9ZXZlbnQuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WC1zdG9yeVJhaWxUb3VjaFN0YXJ0O2lmKE1hdGguYWJzKGRpc3RhbmNlKT40NSl7Y29uc3QgbmV4dD1NYXRoLm1heCgwLE1hdGgubWluKGxlbmd0aC0xLChyYWlsPT09J2hvbWUnP2hvbWVTdG9yeUluZGV4OnN0b3JpZXNSYWlsSW5kZXgpKyhkaXN0YW5jZTwwPzE6LTEpKSk7aWYocmFpbD09PSdob21lJylob21lU3RvcnlJbmRleD1uZXh0O2Vsc2Ugc3Rvcmllc1JhaWxJbmRleD1uZXh0O31zdG9yeVJhaWxUb3VjaFN0YXJ0PW51bGw7fVxuICBhc3luYyBmdW5jdGlvbiBzdGFydEVkaXQoaXRlbSl7ZWRpdGluZz1pdGVtO2VkaXRBbW91bnQ9U3RyaW5nKGl0ZW0uYW1vdW50Pz8nJyk7ZWRpdERhdGU9bG9jYWxJbnB1dERhdGUodHJhbnNhY3Rpb25EYXRlKGl0ZW0pKTtlZGl0Q2F0ZWdvcnk9Y2F0ZWdvcnkoaXRlbSk9PT0nVW5jYXRlZ29yaXNlZCc/Jyc6Y2F0ZWdvcnkoaXRlbSk7ZWRpdFN1YmNhdGVnb3J5PWl0ZW0uc3ViY2F0ZWdvcnk/Lm5hbWV8fGl0ZW0uc3ViY2F0ZWdvcnl8fCcnO2VkaXRNZXJjaGFudElkPVN0cmluZyhpdGVtLm1lcmNoYW50SWQ/P2l0ZW0ubWVyY2hhbnQ/LmlkPz8nJyk7ZWRpdEFjY291bnRJZD1TdHJpbmcoaXRlbS5hY2NvdW50SWQ/P2l0ZW0uYWNjb3VudD8uaWQ/P2l0ZW0uc291cmNlQWNjb3VudElkPz8nJyk7YWN0aW9uRXJyb3I9Jyc7b3B0aW9uc0Vycm9yPScnO2lmKG9wdGlvbnNTdGF0dXM9PT0ncmVhZHknKXtzZWxlY3RDdXJyZW50UmVmZXJlbmNlcyhpdGVtKTtyZXR1cm47fW9wdGlvbnNTdGF0dXM9J2xvYWRpbmcnO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgZ2V0RXhwZW5zZU9wdGlvbnMoKTtlZGl0T3B0aW9ucz17Y2F0ZWdvcmllczpyZXN1bHQuY2F0ZWdvcmllc3x8W10sbWVyY2hhbnRzOnJlc3VsdC5tZXJjaGFudHN8fFtdLGFjY291bnRzOnJlc3VsdC5hY2NvdW50c3x8W119O29wdGlvbnNTdGF0dXM9J3JlYWR5JztzZWxlY3RDdXJyZW50UmVmZXJlbmNlcyhpdGVtKTt9Y2F0Y2goY2F1c2Upe29wdGlvbnNTdGF0dXM9J2Vycm9yJztvcHRpb25zRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgbG9hZCBleHBlbnNlIG9wdGlvbnMuJzt9fVxuICBmdW5jdGlvbiBzZWxlY3RDdXJyZW50UmVmZXJlbmNlcyhpdGVtKXtpZighZWRpdE1lcmNoYW50SWQpe2NvbnN0IG1hdGNoPWVkaXRPcHRpb25zLm1lcmNoYW50cy5maW5kKG9wdGlvbj0+b3B0aW9uLm5hbWU/LnRvTG93ZXJDYXNlKCk9PT1tZXJjaGFudChpdGVtKS50b0xvd2VyQ2FzZSgpKTtpZihtYXRjaCllZGl0TWVyY2hhbnRJZD1TdHJpbmcobWF0Y2guaWQpO31pZighZWRpdEFjY291bnRJZCl7Y29uc3QgY3VycmVudD1TdHJpbmcoaXRlbS5hY2NvdW50Py5uYW1lPz9pdGVtLnNvdXJjZUFjY291bnQ/Lm5hbWU/P2l0ZW0uYWNjb3VudE5hbWU/PycnKS50b0xvd2VyQ2FzZSgpLG1hdGNoPWVkaXRPcHRpb25zLmFjY291bnRzLmZpbmQob3B0aW9uPT5vcHRpb24ubmFtZT8udG9Mb3dlckNhc2UoKT09PWN1cnJlbnQpO2lmKG1hdGNoKWVkaXRBY2NvdW50SWQ9U3RyaW5nKG1hdGNoLmlkKTt9fVxuICBmdW5jdGlvbiBjaGFuZ2VFZGl0Q2F0ZWdvcnkoZXZlbnQpe2VkaXRDYXRlZ29yeT1ldmVudC5jdXJyZW50VGFyZ2V0LnZhbHVlO2lmKCFlZGl0U3ViY2F0ZWdvcmllcy5pbmNsdWRlcyhlZGl0U3ViY2F0ZWdvcnkpKWVkaXRTdWJjYXRlZ29yeT0nJzt9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVFZGl0KCl7Y29uc3QgYW1vdW50PU51bWJlcihlZGl0QW1vdW50KSxtZXJjaGFudElkPU51bWJlcihlZGl0TWVyY2hhbnRJZCksYWNjb3VudElkPU51bWJlcihlZGl0QWNjb3VudElkKTtpZighZWRpdGluZ3x8c2F2aW5nfHxvcHRpb25zU3RhdHVzIT09J3JlYWR5J3x8IU51bWJlci5pc0Zpbml0ZShhbW91bnQpfHxhbW91bnQ8PTB8fCFlZGl0RGF0ZXx8IWVkaXRDYXRlZ29yeXx8IWVkaXRTdWJjYXRlZ29yeXx8IU51bWJlci5pc0Zpbml0ZShtZXJjaGFudElkKXx8IU51bWJlci5pc0Zpbml0ZShhY2NvdW50SWQpKXJldHVybjtzYXZpbmc9dHJ1ZTthY3Rpb25FcnJvcj0nJzt0cnl7YXdhaXQgdXBkYXRlRXhwZW5zZShlZGl0aW5nLmlkLHthbW91bnQsdHJhbnNhY3Rpb25EYXRlOmVkaXREYXRlLGNhdGVnb3J5OmVkaXRDYXRlZ29yeSxzdWJjYXRlZ29yeTplZGl0U3ViY2F0ZWdvcnksbWVyY2hhbnRJZCxhY2NvdW50SWR9KTtlZGl0aW5nPW51bGw7YXdhaXQgUHJvbWlzZS5hbGwoW2xvYWREYXkoKSxyZWZyZXNoUmVjZW50KCkscmVmcmVzaENhbGVuZGFyKCkscmVmcmVzaFN0b3JpZXMoKV0pO31jYXRjaChjYXVzZSl7YWN0aW9uRXJyb3I9Y2F1c2U/Lm1lc3NhZ2V8fCdDb3VsZCBub3QgdXBkYXRlIHRoZSB0cmFuc2FjdGlvbi4nO31maW5hbGx5e3NhdmluZz1mYWxzZTt9fVxuICBhc3luYyBmdW5jdGlvbiBjb25maXJtRGVsZXRlKCl7aWYoIWRlbGV0aW5nKXJldHVybjt0cnl7YXdhaXQgZGVsZXRlRXhwZW5zZShkZWxldGluZy5pZCk7ZGVsZXRpbmc9bnVsbDthd2FpdCBQcm9taXNlLmFsbChbbG9hZERheSgpLHJlZnJlc2hSZWNlbnQoKSxyZWZyZXNoQ2FsZW5kYXIoKSxyZWZyZXNoU3RvcmllcygpXSk7fWNhdGNoKGNhdXNlKXthY3Rpb25FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBkZWxldGUgdGhlIHRyYW5zYWN0aW9uLic7ZGVsZXRpbmc9bnVsbDt9fVxuICBhc3luYyBmdW5jdGlvbiBhZGRNaXNzaW5nRGF0ZSgpe2lmKCFzZWxlY3RlZHx8YWRkaW5nQ29udGV4dClyZXR1cm47YWRkaW5nQ29udGV4dD10cnVlO3RyeXtjb25zdCByZXN1bHQ9YXdhaXQgY3JlYXRlTWlzc2luZ0RhdGVDb250ZXh0KGlzb0RhdGUoc2VsZWN0ZWQuZGF5KSxkYXRhLnRpbWV6b25lfHxJbnRsLkRhdGVUaW1lRm9ybWF0KCkucmVzb2x2ZWRPcHRpb25zKCkudGltZVpvbmUpO2hhbmRvZmY9ey4uLnJlc3VsdCxkYXRlOmlzb0RhdGUoc2VsZWN0ZWQuZGF5KX07fWNhdGNoKGNhdXNlKXthY3Rpb25FcnJvcj1jYXVzZSBpbnN0YW5jZW9mIEFwaUVycm9yP2NhdXNlLm1lc3NhZ2U6J0NvdWxkIG5vdCBwcmVwYXJlIFdoYXRzQXBwIHJlY29yZGluZy4nO31maW5hbGx5e2FkZGluZ0NvbnRleHQ9ZmFsc2U7fX1cbiAgYXN5bmMgZnVuY3Rpb24gc2lnbk91dCgpe2xvZ2dpbmdPdXQ9dHJ1ZTt0cnl7YXdhaXQgbG9nb3V0KCk7dHJ5e2xvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGAke01PTkVZX01PRFVMRVNfQ0FDSEVfS0VZfS5yZWFsYCk7bG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oYCR7TU9ORVlfTU9EVUxFU19DQUNIRV9LRVl9LmRlbW9gKTt9Y2F0Y2h7fW9uTG9nb3V0KCk7fWNhdGNoe2xvZ2dpbmdPdXQ9ZmFsc2U7c2lnbk91dEVycm9yPSdDb3VsZCBub3Qgc2lnbiBvdXQuJzt9fVxuICBhc3luYyBmdW5jdGlvbiBzd2l0Y2hEZW1vTW9kZSgpe2lmKGRlbW9Td2l0Y2hpbmcpcmV0dXJuO2RlbW9Td2l0Y2hpbmc9dHJ1ZTtkZW1vRXJyb3I9Jyc7dHJ5e2F3YWl0IG9uRGVtb01vZGVDaGFuZ2UoIWRlbW9Nb2RlKTtsb2Fucz1bXTttdXR1YWxGdW5kcz1bXTtzdG9ja3M9W107YWN0aW9ucz1bXTtsb2FuU3RhdHVzPSdpZGxlJzttdXR1YWxGdW5kU3RhdHVzPSdpZGxlJztzdG9ja1N0YXR1cz0naWRsZSc7YWN0aW9uc1N0YXR1cz0naWRsZSc7ZnVuZERldGFpbD1udWxsO2RheUl0ZW1zPVtdO3NlbGVjdGVkRGF5PW51bGw7ZWRpdE9wdGlvbnM9e2NhdGVnb3JpZXM6W10sbWVyY2hhbnRzOltdLGFjY291bnRzOltdfTtvcHRpb25zU3RhdHVzPSdpZGxlJztzaG93TW9uZXk9ZmFsc2U7YXdhaXQgbG9hZEFjdGlvbnMoKTt9Y2F0Y2goY2F1c2Upe2RlbW9FcnJvcj1jYXVzZT8ubWVzc2FnZXx8J0NvdWxkIG5vdCBzd2l0Y2ggcHJvZmlsZXMuJzt9ZmluYWxseXtkZW1vU3dpdGNoaW5nPWZhbHNlO319XG4gIG9uTW91bnQoKCk9Pnt0cnl7Y29tbWl0bWVudFN0eWxlPWxvY2FsU3RvcmFnZS5nZXRJdGVtKCdtb25leS1zdG9yaWVzLmNvbW1pdG1lbnQtc3R5bGUnKXx8J3BsYXlmdWwnO31jYXRjaHt9bG9hZEFjdGlvbnMoKTt9KTtcbjwvc2NyaXB0PlxueyNpZiBsb2FuSGlzdG9yeX08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgZnVuZC1mb3JtLWJhY2tkcm9wXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBmdW5kLWRldGFpbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+bG9hbkhpc3Rvcnk9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TE9BTiBERVRBSUxTPC9wPjxoMj57bG9hbkhpc3RvcnkubG9hbk5hbWV9PC9oMj57I2lmIGxvYW5IaXN0b3J5U3RhdHVzPT09J2xvYWRpbmcnfTxwPkxvYWRpbmcgcGF5bWVudCBoaXN0b3J54oCmPC9wPns6ZWxzZSBpZiBsb2FuSGlzdG9yeVN0YXR1cz09PSdlcnJvcid9PHA+e2xvYW5IaXN0b3J5RXJyb3J9PC9wPns6ZWxzZX08c2VjdGlvbiBjbGFzcz1cImludmVzdG1lbnQtaGlzdG9yeVwiPjxoMz5FTUkgdGltZWxpbmU8L2gzPnsjaWYgbG9hbkhpc3RvcnkuaGlzdG9yeT8ubGVuZ3RofXsjZWFjaCBsb2FuSGlzdG9yeS5oaXN0b3J5IGFzIGVudHJ5fTxkaXYgY2xhc3M9XCJpbnZlc3RtZW50LWhpc3Rvcnktcm93XCIgY2xhc3M6ZHVlPXtlbnRyeS5zdGF0dXM9PT0nRFVFJ30+PHNwYW4+e2RhdGVMYWJlbChlbnRyeS5kdWVEYXRlKX08L3NwYW4+PHN0cm9uZz57bW9udGhMYWJlbChlbnRyeS5tb250aCl9IEVNSTwvc3Ryb25nPjxzcGFuIGNsYXNzPVwiaGlzdG9yeS1hbW91bnRcIj48Yj57bW9uZXkoZW50cnkucGFpZEFtb3VudHx8ZW50cnkucGxhbm5lZEFtb3VudCl9PC9iPjwvc3Bhbj48c21hbGw+e2VudHJ5LnN0YXR1cz09PSdQQUlEJz9gUGFpZCBvbiAke2RhdGVMYWJlbChlbnRyeS5wYWlkQXQpfWA6ZW50cnkuc3RhdHVzPT09J0RVRSc/J0R1ZSBub3cnOmVudHJ5LnN0YXR1cy50b0xvd2VyQ2FzZSgpfTwvc21hbGw+eyNpZiBlbnRyeS5zdGF0dXM9PT0nRFVFJ308ZGl2IGNsYXNzPVwibG9hbi1oaXN0b3J5LWFjdGlvblwiPjxEdWVSZW1pbmRlciBkZXRhaWw9e2BEdWUgbm93IMK3ICR7bW9uZXkoZW50cnkucGxhbm5lZEFtb3VudCl9YH0gYWN0aW9uTGFiZWw9e2BNYXJrICR7bW9udGhMYWJlbChlbnRyeS5tb250aCl9IEVNSSBwYWlkYH0gb25BY3Rpb249eygpPT5wYXlMb2FuSGlzdG9yeUVtaShlbnRyeSl9Lz48L2Rpdj57L2lmfTwvZGl2PnsvZWFjaH17OmVsc2V9PHA+Tm8gcGF5bWVudHMgcmVjb3JkZWQgeWV0LjwvcD57L2lmfTwvc2VjdGlvbj57L2lmfTwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBjb21taXRtZW50SGlzdG9yeX08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgZnVuZC1mb3JtLWJhY2tkcm9wXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBmdW5kLWRldGFpbFwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+Y29tbWl0bWVudEhpc3Rvcnk9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+Q09NTUlUTUVOVCBERVRBSUxTPC9wPjxoMj57Y29tbWl0bWVudEhpc3RvcnkubGFiZWx9PC9oMj57I2lmIGNvbW1pdG1lbnRIaXN0b3J5U3RhdHVzPT09J2xvYWRpbmcnfTxwPkxvYWRpbmcgcGF5bWVudCBoaXN0b3J54oCmPC9wPns6ZWxzZSBpZiBjb21taXRtZW50SGlzdG9yeVN0YXR1cz09PSdlcnJvcid9PHA+e2NvbW1pdG1lbnRIaXN0b3J5RXJyb3J9PC9wPns6ZWxzZX08c2VjdGlvbiBjbGFzcz1cImludmVzdG1lbnQtaGlzdG9yeVwiPjxoMz5QYXltZW50IGhpc3Rvcnk8L2gzPnsjaWYgY29tbWl0bWVudEhpc3RvcnkuaGlzdG9yeT8ubGVuZ3RofXsjZWFjaCBjb21taXRtZW50SGlzdG9yeS5oaXN0b3J5IGFzIGVudHJ5fTxkaXYgY2xhc3M9XCJpbnZlc3RtZW50LWhpc3Rvcnktcm93XCI+PHNwYW4+e2RhdGVMYWJlbChlbnRyeS5kdWVEYXRlKX08L3NwYW4+PHN0cm9uZz57bW9udGhMYWJlbChlbnRyeS5tb250aCl9IHBheW1lbnQ8L3N0cm9uZz48c3BhbiBjbGFzcz1cImhpc3RvcnktYW1vdW50XCI+PGI+e21vbmV5KGVudHJ5LmFjdHVhbEFtb3VudHx8Y29tbWl0bWVudEhpc3RvcnkucGxhbm5pbmdBbW91bnQpfTwvYj48L3NwYW4+PHNtYWxsPkRvbmUgb24ge2RhdGVMYWJlbChlbnRyeS5jb21wbGV0ZWRBdCl9PC9zbWFsbD48L2Rpdj57L2VhY2h9ezplbHNlfTxwPk5vIHBheW1lbnRzIHJlY29yZGVkIHlldC48L3A+ey9pZn08L3NlY3Rpb24+ey9pZn08L3NlY3Rpb24+PC9kaXY+ey9pZn1cblxuPEFwcEhlYWRlciB7Y29ubmVjdGlvblN0YXR1c30ge2Nvbm5lY3Rpb25MYWJlbH0gb25SZXRyeT17b25SZXRyeUNvbm5lY3Rpb259IG9uSG9tZT17KCkgPT4gbmF2aWdhdGUoJ2hvbWUnKX0gb25Qcm9maWxlPXsoKSA9PiBuYXZpZ2F0ZSgneW91Jyl9IC8+XG48bWFpbiBjbGFzcz1cImFwcC1zaGVsbFwiPlxueyNpZiBjb25uZWN0aW9uU3RhdHVzPT09J29mZmxpbmUnfTxzZWN0aW9uIGNsYXNzPVwib2ZmbGluZS1ub3RpY2VcIj48c3Bhbj7il4w8L3NwYW4+PGRpdj48c3Ryb25nPntjYWNoZVVwZGF0ZWRBdD8nU2hvd2luZyB5b3VyIGxhc3Qgc2F2ZWQgdmlldyc6J1lvdeKAmXJlIG9mZmxpbmUnfTwvc3Ryb25nPjxwPntjYWNoZVVwZGF0ZWRBdD8nV2XigJlsbCByZWZyZXNoIGF1dG9tYXRpY2FsbHkgd2hlbiB0aGUgc2VydmljZSBpcyBiYWNrLic6J1lvdXIgbGF5b3V0IGlzIHJlYWR5LiBDb25uZWN0IG9uY2UgdG8gbG9hZCB5b3VyIGV4cGVuc2VzIGFuZCBzdG9yaWVzLid9PC9wPjwvZGl2PjxidXR0b24gb246Y2xpY2s9e29uUmV0cnlDb25uZWN0aW9ufT5SZXRyeTwvYnV0dG9uPjwvc2VjdGlvbj57L2lmfVxueyNpZiB2aWV3PT09J2hvbWUnfVxuICA8c2VjdGlvbiBjbGFzcz1cImFwcC1oZWFkaW5nXCI+PGRpdj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+e21vbnRoTGFiZWwoc2VsZWN0ZWRNb250aCkudG9VcHBlckNhc2UoKX08L3A+PGgxPntncmVldGluZygpfTwvaDE+PHA+SGVyZeKAmXMgaG93IHlvdXIgbW9udGggaXMgdW5mb2xkaW5nLjwvcD48L2Rpdj48L3NlY3Rpb24+XG4gIDxTZWN0aW9uU3RhdGUgc2VjdGlvbj17Y2FsZW5kYXJTZWN0aW9ufSB0aXRsZT1cIlNwZW5kaW5nIG92ZXJ2aWV3XCIgcmV0cnk9e3JlZnJlc2hDYWxlbmRhcn0+PGJ1dHRvbiBjbGFzcz1cInNwZW5kaW5nLWhlcm9cIiBvbjpjbGljaz17KCk9Pm5hdmlnYXRlKCd0cmFuc2FjdGlvbnMnKX0+PHNwYW4+TU9OVEhMWSBTUEVORElORzwvc3Bhbj48c3Ryb25nPnttb25leShkYXRhLnRvdGFsU3BlbmQpfSA8c21hbGw+c3BlbnQ8L3NtYWxsPjwvc3Ryb25nPjxiPntkYXRhLnRyYW5zYWN0aW9uQ291bnR8fDB9IHRyYW5zYWN0aW9ucyDCtyBWaWV3IHRyYW5zYWN0aW9ucyDihpI8L2I+PC9idXR0b24+PC9TZWN0aW9uU3RhdGU+XG4gIDxzZWN0aW9uIGNsYXNzPVwiaG9tZS1zZWN0aW9uXCI+PGRpdiBjbGFzcz1cInNlY3Rpb24tdGl0bGVcIj48ZGl2PjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5ZT1VSIFNUT1JJRVM8L3A+PGgyPlNtYWxsIHNpZ25hbHMsIGNsZWFybHkgdG9sZDwvaDI+PC9kaXY+PGJ1dHRvbiBjbGFzcz1cInRleHQtbGlua1wiIG9uOmNsaWNrPXsoKT0+bmF2aWdhdGUoJ3N0b3JpZXMnKX0+U2VlIGFsbDwvYnV0dG9uPjwvZGl2PjxTZWN0aW9uU3RhdGUgc2VjdGlvbj17c3Rvcmllc1NlY3Rpb259IHRpdGxlPVwiWW91ciBzdG9yaWVzXCIgcmV0cnk9e3JlZnJlc2hTdG9yaWVzfT57I2lmIGhvbWVTdG9yaWVzLmxlbmd0aH08ZGl2IGNsYXNzPVwic3RvcnktY2Fyb3VzZWxcIiBhcmlhLWxhYmVsPVwiWW91ciBzdG9yaWVzXCI+PGRpdiBjbGFzcz1cInN0b3J5LWRvdHNcIiBhcmlhLWxhYmVsPVwiQ2hvb3NlIGEgc3RvcnlcIj57I2VhY2ggaG9tZVN0b3JpZXMgYXMgc3RvcnksaW5kZXh9PGJ1dHRvbiBjbGFzczphY3RpdmU9e2luZGV4PT09aG9tZVN0b3J5SW5kZXh9IGFyaWEtbGFiZWw9e2BTaG93IHN0b3J5ICR7aW5kZXgrMX0gb2YgJHtob21lU3Rvcmllcy5sZW5ndGh9OiAke3N0b3J5Q2FyZEZhY2Uoc3RvcnkpLmhlYWRpbmd9YH0gYXJpYS1jdXJyZW50PXtpbmRleD09PWhvbWVTdG9yeUluZGV4Pyd0cnVlJzp1bmRlZmluZWR9IG9uOmNsaWNrPXsoKT0+aG9tZVN0b3J5SW5kZXg9aW5kZXh9PjwvYnV0dG9uPnsvZWFjaH08c3Bhbj57aG9tZVN0b3J5SW5kZXgrMX0gLyB7aG9tZVN0b3JpZXMubGVuZ3RofTwvc3Bhbj48L2Rpdj48ZGl2IGNsYXNzPVwic3RvcnktY2Fyb3VzZWwtdmlld3BvcnRcIiBvbjp0b3VjaHN0YXJ0PXtldmVudD0+KHN0b3J5UmFpbFRvdWNoU3RhcnQ9ZXZlbnQudG91Y2hlc1swXS5jbGllbnRYKX0gb246dG91Y2hlbmQ9e2V2ZW50PT5lbmRSYWlsU3dpcGUoZXZlbnQsaG9tZVN0b3JpZXMubGVuZ3RoLCdob21lJyl9PjxkaXYgY2xhc3M9XCJzdG9yeS1jYXJvdXNlbC10cmFja1wiIHN0eWxlPXtgdHJhbnNmb3JtOnRyYW5zbGF0ZVgoY2FsYygke2hvbWVTdG9yeUluZGV4fSAqIC05MiUpKWB9PnsjZWFjaCBob21lU3RvcmllcyBhcyBzdG9yeSxpbmRleH08YnV0dG9uIGNsYXNzPXtgc3RvcnktY2Fyb3VzZWwtY2FyZCAke3N0b3J5VG9uZShzdG9yeSl9YH0gY2xhc3M6Y3VycmVudD17aW5kZXg9PT1ob21lU3RvcnlJbmRleH0gb246Y2xpY2s9eygpPT5vcGVuU3Rvcnkoc3RvcnkpfT48c3BhbiBjbGFzcz1cInN0b3J5LXNvdXJjZVwiPntzdG9yeVNvdXJjZShzdG9yeSl9PC9zcGFuPjxzdHJvbmc+e3N0b3J5Q2FyZEZhY2Uoc3RvcnkpLmhlYWRpbmd9PC9zdHJvbmc+PGI+e3N0b3J5Q2FyZEZhY2Uoc3RvcnkpLmRpc3BsYXlWYWx1ZX08L2I+PGk+4oC6PC9pPjwvYnV0dG9uPnsvZWFjaH08L2Rpdj48L2Rpdj48L2Rpdj57OmVsc2V9PGRpdiBjbGFzcz1cInN0b3J5LXJhaWwtZW1wdHlcIj5Zb3VyIHN0b3JpZXMgd2lsbCBhcHBlYXIgaGVyZSBhcyB5b3UgYWRkIGV4cGVuc2VzLjwvZGl2PnsvaWZ9PC9TZWN0aW9uU3RhdGU+PC9zZWN0aW9uPlxuICA8c2VjdGlvbiBjbGFzcz1cImhvbWUtc2VjdGlvblwiPjxkaXYgY2xhc3M9XCJzZWN0aW9uLXRpdGxlXCI+PGRpdj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+UkVDRU5UIEFDVElWSVRZPC9wPjxoMj5Zb3VyIGxhdGVzdCBleHBlbnNlczwvaDI+PC9kaXY+PGJ1dHRvbiBjbGFzcz1cInRleHQtbGlua1wiIG9uOmNsaWNrPXsoKT0+bmF2aWdhdGUoJ3RyYW5zYWN0aW9ucycpfT5TZWUgYWxsPC9idXR0b24+PC9kaXY+PGRpdiBjbGFzcz1cImNvbXBhY3QtbGlzdFwiPnsjZWFjaCByZWNlbnRJdGVtcy5zbGljZSgwLDMpIGFzIGl0ZW19PGJ1dHRvbiBjbGFzcz1cInJvdy1tYWluXCIgb246Y2xpY2s9eygpPT57bmF2aWdhdGUoJ3RyYW5zYWN0aW9ucycpO3N0YXJ0RWRpdChpdGVtKTt9fT48ZGl2PjxzdHJvbmc+e21lcmNoYW50KGl0ZW0pfTwvc3Ryb25nPjxzcGFuPntjYXRlZ29yeShpdGVtKX0gwrcge2RhdGVMYWJlbCh0cmFuc2FjdGlvbkRhdGUoaXRlbSkpfTwvc3Bhbj48L2Rpdj48Yj7iiJIge21vbmV5KGl0ZW0uYW1vdW50KX08L2I+PC9idXR0b24+ezplbHNlfTxwIGNsYXNzPVwiZW1wdHktY29weVwiPk5vIGV4cGVuc2VzIHJlY29yZGVkIHlldC48L3A+ey9lYWNofTwvZGl2Pjwvc2VjdGlvbj5cbiAgPGJ1dHRvbiBjbGFzcz1cInlvdXItbW9uZXktY2FyZFwiIG9uOmNsaWNrPXtvcGVuTW9uZXl9PjxzcGFuPuKXkjwvc3Bhbj48ZGl2PjxzdHJvbmc+WW91ciBtb25leTwvc3Ryb25nPjxzbWFsbD5TZWUgeW91ciBpbmNvbWluZyBhbmQgb3V0Z29pbmcgcGxhbiwgb25seSB3aGVuIHlvdeKAmXJlIHJlYWR5Ljwvc21hbGw+PC9kaXY+PGI+RXhwbG9yZSDigLo8L2I+PC9idXR0b24+XG57OmVsc2UgaWYgdmlldz09PSd0cmFuc2FjdGlvbnMnfVxuICA8c2VjdGlvbiBjbGFzcz1cIndvcmtzcGFjZS1oZWFkaW5nXCI+PGRpdj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+RVhQRU5TRSBXT1JLU1BBQ0U8L3A+PGgxPlRyYW5zYWN0aW9uczwvaDE+PHA+QUktY2FwdHVyZWQgZXhwZW5zZXMsIHJlYWR5IGZvciB5b3VyIHJldmlldy48L3A+PC9kaXY+PGxhYmVsIGNsYXNzPVwibW9udGgtc3dpdGNoZXJcIj48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbjpjbGljaz17KCk9PmNoYW5nZU1vbnRoKC0xKX0+4oaQPC9idXR0b24+PGlucHV0IHR5cGU9XCJtb250aFwiIHZhbHVlPXtzZWxlY3RlZE1vbnRofSBtYXg9e2N1cnJlbnRMb2NhbE1vbnRoKCl9IG9uOmNoYW5nZT17ZT0+b25Nb250aENoYW5nZShlLmN1cnJlbnRUYXJnZXQudmFsdWUpfS8+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb246Y2xpY2s9eygpPT5jaGFuZ2VNb250aCgxKX0+4oaSPC9idXR0b24+PC9sYWJlbD48L3NlY3Rpb24+XG4gIDxTZWN0aW9uU3RhdGUgc2VjdGlvbj17Y2FsZW5kYXJTZWN0aW9ufSB0aXRsZT1cIlNwZW5kaW5nIGNhbGVuZGFyXCIgcmV0cnk9e3JlZnJlc2hDYWxlbmRhcn0+PHNlY3Rpb24gY2xhc3M9XCJtb250aC1jYXJkXCI+PGRpdiBjbGFzcz1cIm1vbnRoLXN1bW1hcnlcIj48ZGl2PjxzcGFuPlRvdGFsIHJlY29yZGVkPC9zcGFuPjxzdHJvbmc+e21vbmV5KGRhdGEudG90YWxTcGVuZCl9PC9zdHJvbmc+PC9kaXY+PGRpdj48c3Bhbj5UcmFuc2FjdGlvbnM8L3NwYW4+PHN0cm9uZz57ZGF0YS50cmFuc2FjdGlvbkNvdW50fHwwfTwvc3Ryb25nPjwvZGl2PjxkaXY+PHNwYW4+SGlnaGVzdCBkYXk8L3NwYW4+PHN0cm9uZz57bW9uZXkoZGF0YS5oaWdoZXN0U3BlbmQpfTwvc3Ryb25nPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3M9XCJ3ZWVrZGF5c1wiPnsjZWFjaCBbJ01vbicsJ1R1ZScsJ1dlZCcsJ1RodScsJ0ZyaScsJ1NhdCcsJ1N1biddIGFzIGR9PHNwYW4+e2R9PC9zcGFuPnsvZWFjaH08L2Rpdj48ZGl2IGNsYXNzPVwiY2FsZW5kYXJcIj57I2VhY2ggQXJyYXkoY2FsZW5kYXIubGVhZGluZykgYXMgX308c3Bhbj48L3NwYW4+ey9lYWNofXsjZWFjaCBjYWxlbmRhci5kYXlzIGFzIGR9PGJ1dHRvbiBjbGFzczpmdXR1cmU9e2QuZnV0dXJlfSBjbGFzczpzZWxlY3RlZD17c2VsZWN0ZWREYXk9PT1kLmRheX0gY2xhc3M9e2BsZXZlbC0ke2QuaW50ZW5zaXR5fWB9IGRpc2FibGVkPXtkLmZ1dHVyZX0gb246Y2xpY2s9eygpPT5zZWxlY3REYXRlKGQpfT57ZC5kYXl9PC9idXR0b24+ey9lYWNofTwvZGl2PjxkaXYgY2xhc3M9XCJsZWdlbmRcIj48c3Bhbj5Mb3dlciBzcGVuZDwvc3Bhbj48ZGl2PnsjZWFjaCBbMCwxLDIsMyw0XSBhcyBsfTxpIGNsYXNzPXtgbGV2ZWwtJHtsfWB9PjwvaT57L2VhY2h9PC9kaXY+PHNwYW4+SGlnaGVyIHNwZW5kPC9zcGFuPjwvZGl2Pjwvc2VjdGlvbj48L1NlY3Rpb25TdGF0ZT5cbiAgPHNlY3Rpb24gY2xhc3M9XCJhY3Rpdml0eS1wYW5lbCBhZGFwdGl2ZS1hY3Rpdml0eVwiPjxkaXYgY2xhc3M9XCJhY3Rpdml0eS10YWJzXCI+PGJ1dHRvbiBjbGFzczphY3RpdmU9e2FjdGl2aXR5VGFiPT09J3JlY2VudCd9IG9uOmNsaWNrPXsoKT0+YWN0aXZpdHlUYWI9J3JlY2VudCd9PlJlY2VudDwvYnV0dG9uPjxidXR0b24gY2xhc3M6YWN0aXZlPXthY3Rpdml0eVRhYj09PSdkYXknfSBvbjpjbGljaz17KCk9PmFjdGl2aXR5VGFiPSdkYXknfT57c2VsZWN0ZWQ/YCR7c2VsZWN0ZWQuZGF5fSBzZWxlY3RlZGA6J1NlbGVjdCBhIGRhdGUnfTwvYnV0dG9uPjwvZGl2PnsjaWYgYWN0aXZpdHlUYWI9PT0nZGF5JyYmZGF5U3RhdHVzPT09J2xvYWRpbmcnfTxkaXYgY2xhc3M9XCJhY3Rpdml0eS1sb2FkaW5nXCI+TG9hZGluZyB0cmFuc2FjdGlvbnPigKY8L2Rpdj57OmVsc2UgaWYgYWN0aXZpdHlUYWI9PT0nZGF5JyYmZGF5U3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwic2VjdGlvbi1lcnJvclwiPjxwPkNvdWxkIG5vdCBsb2FkIHRoaXMgZGF0ZS48L3A+PGJ1dHRvbiBvbjpjbGljaz17bG9hZERheX0+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+ezplbHNlfTxkaXYgY2xhc3M9XCJhY3Rpdml0eS1zdW1tYXJ5XCI+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPnthY3Rpdml0eVRhYj09PSdyZWNlbnQnPydSRUNFTlQgRVhQRU5TRVMnOnNlbGVjdGVkP2Ake3NlbGVjdGVkLmRheX0gJHttb250aExhYmVsKHNlbGVjdGVkTW9udGgpfWA6J1NFTEVDVCBBIERBVEUnfTwvcD48aDI+e2FjdGl2aXR5VGFiPT09J3JlY2VudCc/YCR7cmVjZW50SXRlbXMubGVuZ3RofSByZWNlbnQgdHJhbnNhY3Rpb25zYDpzZWxlY3RlZD9gJHtzZWxlY3RlZC50cmFuc2FjdGlvbkNvdW50fSB0cmFuc2FjdGlvbnMgwrcgJHttb25leShzZWxlY3RlZC50b3RhbFNwZW5kKX1gOidDaG9vc2UgYSBkYXRlIGluIHRoZSBjYWxlbmRhcid9PC9oMj48L2Rpdj48ZGl2IGNsYXNzPVwiY29tcGFjdC1saXN0XCI+eyNlYWNoIHZpc2libGVJdGVtcyBhcyBpdGVtfTxhcnRpY2xlIGNsYXNzOmV4cGFuZGVkPXtleHBhbmRlZElkPT09aXRlbS5pZH0gY2xhc3M9XCJjb21wYWN0LXJvd1wiPjxidXR0b24gY2xhc3M9XCJyb3ctbWFpblwiIG9uOmNsaWNrPXsoKT0+ZXhwYW5kZWRJZD1leHBhbmRlZElkPT09aXRlbS5pZD9udWxsOml0ZW0uaWR9PjxkaXY+PHN0cm9uZz57bWVyY2hhbnQoaXRlbSl9PC9zdHJvbmc+PHNwYW4+e2NhdGVnb3J5KGl0ZW0pfSDCtyB7ZGF0ZUxhYmVsKHRyYW5zYWN0aW9uRGF0ZShpdGVtKSl9PC9zcGFuPjwvZGl2PjxkaXYgY2xhc3M9XCJyb3ctdmFsdWVcIj48Yj7iiJIge21vbmV5KGl0ZW0uYW1vdW50KX08L2I+PHNwYW4gY2xhc3M6b3Blbj17ZXhwYW5kZWRJZD09PWl0ZW0uaWR9IGNsYXNzPVwicm93LWNoZXZyb25cIj7ijIQ8L3NwYW4+PC9kaXY+PC9idXR0b24+eyNpZiBleHBhbmRlZElkPT09aXRlbS5pZH08ZGl2IGNsYXNzPVwicm93LWFjdGlvbnNcIj48YnV0dG9uIG9uOmNsaWNrPXsoKT0+c3RhcnRFZGl0KGl0ZW0pfT5FZGl0IHRyYW5zYWN0aW9uPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cImRhbmdlclwiIG9uOmNsaWNrPXsoKT0+ZGVsZXRpbmc9aXRlbX0+RGVsZXRlPC9idXR0b24+PC9kaXY+ey9pZn08L2FydGljbGU+ezplbHNlfTxwIGNsYXNzPVwiZW1wdHktY29weVwiPk5vIHRyYW5zYWN0aW9ucyBmb3IgdGhpcyB2aWV3LjwvcD57L2VhY2h9PC9kaXY+eyNpZiBhY3RpdmVJdGVtcy5sZW5ndGg+NX08YnV0dG9uIGNsYXNzPVwidmlldy1hbGxcIiBvbjpjbGljaz17KCk9PnNob3dBbGw9IXNob3dBbGx9PntzaG93QWxsPydTaG93IGZld2VyIOKGkSc6YFZpZXcgYWxsICR7YWN0aXZlSXRlbXMubGVuZ3RofSB0cmFuc2FjdGlvbnMg4oaTYH08L2J1dHRvbj57L2lmfXsvaWZ9PC9zZWN0aW9uPlxuICA8YnV0dG9uIGNsYXNzPVwid2lkZS1idXR0b25cIiBkaXNhYmxlZD17IXNlbGVjdGVkfHxhZGRpbmdDb250ZXh0fSBvbjpjbGljaz17YWRkTWlzc2luZ0RhdGV9PnthZGRpbmdDb250ZXh0PydQcmVwYXJpbmcgV2hhdHNBcHDigKYnOnNlbGVjdGVkPycrIEFkZCBtaXNzaW5nIGV4cGVuc2UnOidTZWxlY3QgYSBkYXRlIHRvIGFkZCBhbiBleHBlbnNlJ308L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwiY2xlYW51cC1jYXJkXCIgb246Y2xpY2s9eygpPT5zaG93Tm9ybWFsaXphdGlvbj10cnVlfT48c3Bhbj7inKY8L3NwYW4+PGRpdj48c3Ryb25nPkV4cGVuc2UgY2xlYW51cDwvc3Ryb25nPjxzbWFsbD5GaXggbWVyY2hhbnQgYW5kIGFjY291bnQgbmFtZXMgY2FwdHVyZWQgYnkgQUkuPC9zbWFsbD48L2Rpdj48Yj5PcGVuIOKAujwvYj48L2J1dHRvbj5cbns6ZWxzZSBpZiB2aWV3PT09J3N0b3JpZXMnfVxuICA8c2VjdGlvbiBjbGFzcz1cIndvcmtzcGFjZS1oZWFkaW5nXCI+PGRpdj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+WU9VUiBNT05FWSwgRVhQTEFJTkVEPC9wPjxoMT5TdG9yaWVzPC9oMT48cD5JbnNpZ2h0cyBhY3Jvc3MgdGhlIGluZm9ybWF0aW9uIHlvdSBjaG9vc2UgdG8gc2hhcmUuPC9wPjwvZGl2Pjwvc2VjdGlvbj48ZGl2IGNsYXNzPVwic3RvcnktZmlsdGVyc1wiPnsjZWFjaCBbJ0FsbCcsJ1NwZW5kaW5nJywnSW52ZXN0aW5nJywnUGxhbm5pbmcnXSBhcyBmaWx0ZXJ9PGJ1dHRvbiBjbGFzczphY3RpdmU9e3N0b3J5RmlsdGVyPT09ZmlsdGVyfSBvbjpjbGljaz17KCk9PntzdG9yeUZpbHRlcj1maWx0ZXI7c3Rvcmllc1JhaWxJbmRleD0wO319PntmaWx0ZXJ9PC9idXR0b24+ey9lYWNofTwvZGl2PjxkaXYgY2xhc3M9XCJjb21taXRtZW50LXN0eWxlLWNvbnRyb2xcIj48c3Bhbj5Db21taXRtZW50IHN0eWxlPC9zcGFuPjxidXR0b24gY2xhc3M6YWN0aXZlPXtjb21taXRtZW50U3R5bGU9PT0nY2FsbSd9IG9uOmNsaWNrPXsoKT0+c2V0Q29tbWl0bWVudFN0eWxlKCdjYWxtJyl9PkNhbG08L2J1dHRvbj48YnV0dG9uIGNsYXNzOmFjdGl2ZT17Y29tbWl0bWVudFN0eWxlPT09J3BsYXlmdWwnfSBvbjpjbGljaz17KCk9PnNldENvbW1pdG1lbnRTdHlsZSgncGxheWZ1bCcpfT5QbGF5ZnVsIOKcqDwvYnV0dG9uPjwvZGl2PjxTZWN0aW9uU3RhdGUgc2VjdGlvbj17c3Rvcmllc1NlY3Rpb259IHRpdGxlPVwiU3Rvcmllc1wiIHJldHJ5PXtyZWZyZXNoU3Rvcmllc30+eyNpZiBmaWx0ZXJlZFN0b3JpZXMubGVuZ3RofTxkaXYgY2xhc3M9XCJzdG9yeS1jYXJvdXNlbCBzdG9yeS1jYXJvdXNlbC1mdWxsXCIgYXJpYS1sYWJlbD17YCR7c3RvcnlGaWx0ZXJ9IHN0b3JpZXNgfT48ZGl2IGNsYXNzPVwic3RvcnktZG90c1wiIGFyaWEtbGFiZWw9XCJDaG9vc2UgYSBzdG9yeVwiPnsjZWFjaCBmaWx0ZXJlZFN0b3JpZXMgYXMgc3RvcnksaW5kZXh9PGJ1dHRvbiBjbGFzczphY3RpdmU9e2luZGV4PT09c3Rvcmllc1JhaWxJbmRleH0gYXJpYS1sYWJlbD17YFNob3cgc3RvcnkgJHtpbmRleCsxfSBvZiAke2ZpbHRlcmVkU3Rvcmllcy5sZW5ndGh9OiAke3N0b3J5Q2FyZEZhY2Uoc3RvcnkpLmhlYWRpbmd9YH0gYXJpYS1jdXJyZW50PXtpbmRleD09PXN0b3JpZXNSYWlsSW5kZXg/J3RydWUnOnVuZGVmaW5lZH0gb246Y2xpY2s9eygpPT5zdG9yaWVzUmFpbEluZGV4PWluZGV4fT48L2J1dHRvbj57L2VhY2h9PHNwYW4+e3N0b3JpZXNSYWlsSW5kZXgrMX0gLyB7ZmlsdGVyZWRTdG9yaWVzLmxlbmd0aH08L3NwYW4+PC9kaXY+PGRpdiBjbGFzcz1cInN0b3J5LWNhcm91c2VsLXZpZXdwb3J0XCIgb246dG91Y2hzdGFydD17ZXZlbnQ9PihzdG9yeVJhaWxUb3VjaFN0YXJ0PWV2ZW50LnRvdWNoZXNbMF0uY2xpZW50WCl9IG9uOnRvdWNoZW5kPXtldmVudD0+ZW5kUmFpbFN3aXBlKGV2ZW50LGZpbHRlcmVkU3Rvcmllcy5sZW5ndGgsJ2Z1bGwnKX0+PGRpdiBjbGFzcz1cInN0b3J5LWNhcm91c2VsLXRyYWNrXCIgc3R5bGU9e2B0cmFuc2Zvcm06dHJhbnNsYXRlWChjYWxjKCR7c3Rvcmllc1JhaWxJbmRleH0gKiAtOTIlKSlgfT57I2VhY2ggZmlsdGVyZWRTdG9yaWVzIGFzIHN0b3J5LGluZGV4fTxidXR0b24gY2xhc3M9e2BzdG9yeS1jYXJvdXNlbC1jYXJkICR7c3RvcnlUb25lKHN0b3J5KX1gfSBjbGFzczpjb21taXRtZW50LWNhcmQ9e2lzQ29tbWl0bWVudChzdG9yeSl9IGNsYXNzOnBsYXlmdWw9e2lzQ29tbWl0bWVudChzdG9yeSkmJmNvbW1pdG1lbnRTdHlsZT09PSdwbGF5ZnVsJ30gY2xhc3M6Y3VycmVudD17aW5kZXg9PT1zdG9yaWVzUmFpbEluZGV4fSBvbjpjbGljaz17KCk9Pm9wZW5TdG9yeShzdG9yeSl9PjxzcGFuIGNsYXNzPVwic3Rvcnktc291cmNlXCI+e3N0b3J5U291cmNlKHN0b3J5KX08L3NwYW4+eyNpZiBzdG9yeUljb24oc3RvcnkpfTxzcGFuIGNsYXNzPVwiY29tbWl0bWVudC1pY29uXCI+e3N0b3J5SWNvbihzdG9yeSl9PC9zcGFuPnsvaWZ9PHN0cm9uZz57c3RvcnlIZWFkaW5nKHN0b3J5KX08L3N0cm9uZz48Yj57c3RvcnlDYXJkRmFjZShzdG9yeSkuZGlzcGxheVZhbHVlfTwvYj48aT7igLo8L2k+PC9idXR0b24+ey9lYWNofTwvZGl2PjwvZGl2PjwvZGl2Pns6ZWxzZX08ZGl2IGNsYXNzPVwiZW1wdHktc3RhdGVcIj48c3Bhbj7inKY8L3NwYW4+PGgyPk5vIHtzdG9yeUZpbHRlci50b0xvd2VyQ2FzZSgpfSBzdG9yaWVzIHlldDwvaDI+PHA+QXMgeW91IGNob29zZSB0byBhZGQgbW9yZSBpbmZvcm1hdGlvbiwgcmVsZXZhbnQgc3RvcmllcyB3aWxsIGFwcGVhciBoZXJlLjwvcD48L2Rpdj57L2lmfTwvU2VjdGlvblN0YXRlPlxuezplbHNlfVxuICA8UHJvZmlsZVNldHRpbmdzIHtkZW1vTW9kZX0ge2RlbW9Td2l0Y2hpbmd9IHtkZW1vRXJyb3J9IHtsb2dnaW5nT3V0fSB7c2lnbk91dEVycm9yfSB7c3RvcnlDb250cm9sc30gb25OYXZpZ2F0ZT17bmF2aWdhdGV9IG9uT3Blbk1vbmV5PXtvcGVuTW9uZXl9IG9uRGVtb01vZGVDaGFuZ2U9e3N3aXRjaERlbW9Nb2RlfSBvblNpZ25PdXQ9e3NpZ25PdXR9IC8+XG57L2lmfVxuPC9tYWluPlxuPEJvdHRvbU5hdiB7dmlld30gb25OYXZpZ2F0ZT17bmF2aWdhdGV9IC8+XG5cbjwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5X2NsaWNrX2V2ZW50c19oYXZlX2tleV9ldmVudHMgLS0+XG57I2lmIHNob3dNb25leX1cbiAgPGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wXCIgb246Y2xpY2s9e2Nsb3NlTW9uZXl9IG9uOmtleWRvd249eyhldmVudCk9PmV2ZW50LmtleT09PSdFc2NhcGUnJiZjbG9zZU1vbmV5KCl9IHJvbGU9XCJwcmVzZW50YXRpb25cIj5cbiAgICA8c2VjdGlvbiBjbGFzcz1cIm1vZGFsIG1vbmV5LW1vZGFsXCIgb246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIHRhYmluZGV4PVwiLTFcIj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXtjbG9zZU1vbmV5fT7DlzwvYnV0dG9uPlxuICAgICAgPHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPk9QVElPTkFMLCBQUklWQVRFLCBZT1VSUzwvcD48aDI+QnVpbGQgeW91ciBjb21wbGV0ZSBtb25leSBwaWN0dXJlPC9oMj5cbiAgICAgIDxwIGNsYXNzPVwibW9kdWxlLXJlYXNzdXJhbmNlXCI+WW91IGNob29zZSB3aGF0IHRvIGFkZC4gTm90aGluZyBpcyByZXF1aXJlZCwgYW5kIHlvdSBjYW4gcmVtb3ZlIGEgbW9kdWxlIGFueXRpbWUuPC9wPlxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJpbmNvbWUtbW9kdWxlXCI+PGRpdiBjbGFzcz1cImxvYW5zLWhlYWRpbmdcIj48ZGl2PjxzdHJvbmc+U2FsYXJ5IG91dGxvb2s8L3N0cm9uZz48c21hbGw+UHJpdmF0ZSBlc3RpbWF0ZSDigJQgbmV2ZXIgdHJlYXRlZCBhcyB5b3VyIGFjY291bnQgYmFsYW5jZTwvc21hbGw+PC9kaXY+PHNwYW4gY2xhc3M9XCJ2ZXJpZmllZC1waWxsXCI+T3B0aW9uYWw8L3NwYW4+PC9kaXY+eyNpZiBpbmNvbWVTdGF0dXM9PT0nbG9hZGluZyd9PHA+TG9hZGluZyB5b3VyIHByaXZhdGUgb3V0bG9va+KApjwvcD57OmVsc2UgaWYgaW5jb21lU3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwibG9hbi1zdGF0ZSBlcnJvclwiPjxzcGFuPntpbmNvbWVFcnJvcn08L3NwYW4+PGJ1dHRvbiBvbjpjbGljaz17bG9hZEluY29tZU91dGxvb2t9PlRyeSBhZ2FpbjwvYnV0dG9uPjwvZGl2Pns6ZWxzZSBpZiBpbmNvbWVPdXRsb29rLnNhbGFyeX08ZGl2IGNsYXNzPVwiaW5jb21lLXN1bW1hcnkgbWFza2VkXCI+PHNwYW4+U2FsYXJ5IHNhdmVkPC9zcGFuPjxzdHJvbmc+e2luY29tZU91dGxvb2suc2FsYXJ5Lm1hc2tlZFZhbHVlfTwvc3Ryb25nPjxidXR0b24gY2xhc3M9XCJpbmNvbWUtZWRpdFwiIG9uOmNsaWNrPXtvcGVuSW5jb21lRmxvd30gYXJpYS1sYWJlbD1cIlVwZGF0ZSBzYWxhcnkgb3V0bG9va1wiIHRpdGxlPVwiVXBkYXRlIHNhbGFyeSBvdXRsb29rXCI+8J+UpzwvYnV0dG9uPjxzbWFsbD5NYXNrZWQgYmVmb3JlIGl0IHJlYWNoZXMgdGhpcyBzY3JlZW4uPC9zbWFsbD48L2Rpdj57OmVsc2V9PGRpdiBjbGFzcz1cImluY29tZS1zdW1tYXJ5XCI+PHN0cm9uZz5TdGFydCB3aXRoIGEgcmFuZ2U8L3N0cm9uZz48c21hbGw+T25seSB5b3UgZGVjaWRlIHdoZXRoZXIgdG8gc2hhcmUgYSByYW5nZSBvciBhbiBleGFjdCBhbW91bnQuPC9zbWFsbD48L2Rpdj48YnV0dG9uIGNsYXNzPVwiYWRkLWZ1bmQtcm93XCIgb246Y2xpY2s9e29wZW5JbmNvbWVGbG93fT5TZXQgdXAgc2FsYXJ5IG91dGxvb2s8L2J1dHRvbj57L2lmfTwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzPVwibG9hbnMtbW9kdWxlXCIgZGF0YS10ZXN0aWQ9XCJjb21taXRtZW50cy1zZWN0aW9uXCI+PGRpdiBjbGFzcz1cImxvYW5zLWhlYWRpbmdcIj48ZGl2PjxzdHJvbmc+Q29tbWl0bWVudHM8L3N0cm9uZz48c21hbGw+UmVudCwgYmlsbHMsIHN1YnNjcmlwdGlvbnMsIG1haW50ZW5hbmNlLCBhbmQgcmVwZWF0YWJsZSBvYmxpZ2F0aW9uczwvc21hbGw+PC9kaXY+PC9kaXY+eyNpZiBjb21taXRtZW50U3RhdHVzPT09J2xvYWRpbmcnfTxwIGNsYXNzPVwibG9hbi1zdGF0ZVwiPkxvYWRpbmcgY29tbWl0bWVudHPigKY8L3A+ezplbHNlIGlmIGNvbW1pdG1lbnRTdGF0dXM9PT0nZXJyb3InfTxkaXYgY2xhc3M9XCJsb2FuLXN0YXRlIGVycm9yXCI+PHNwYW4+e2NvbW1pdG1lbnRFcnJvcn08L3NwYW4+PGJ1dHRvbiBvbjpjbGljaz17bG9hZENvbW1pdG1lbnRzfT5UcnkgYWdhaW48L2J1dHRvbj48L2Rpdj57OmVsc2UgaWYgY29tbWl0bWVudHMubGVuZ3RofXsjZWFjaCBjb21taXRtZW50cyBhcyBjb21taXRtZW50fTxhcnRpY2xlIGNsYXNzPVwibG9hbi1yb3dcIiBkYXRhLXRlc3RpZD17YGNvbW1pdG1lbnQtJHtjb21taXRtZW50LmlkfWB9IGNsYXNzOmR1ZS1yZWN1cnJpbmc9e2NvbW1pdG1lbnQuY3VycmVudE9jY3VycmVuY2U/LnN0YXR1cz09PSdEVUUnfT48c3Bhbj7ihrs8L3NwYW4+PGRpdj48c3Ryb25nIGNsYXNzPVwibG9hbi1uYW1lXCI+e2NvbW1pdG1lbnQubGFiZWx9PGJ1dHRvbiBjbGFzcz1cImxvYW4tZWRpdFwiIG9uOmNsaWNrPXsoKT0+b3BlbkNvbW1pdG1lbnRGb3JtKGNvbW1pdG1lbnQpfSBhcmlhLWxhYmVsPXtgRWRpdCAke2NvbW1pdG1lbnQubGFiZWx9YH0+8J+UpzwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJsb2FuLWRlbGV0ZVwiIG9uOmNsaWNrPXsoKT0+cmVtb3ZlQ29tbWl0bWVudChjb21taXRtZW50KX0gYXJpYS1sYWJlbD17YERlbGV0ZSAke2NvbW1pdG1lbnQubGFiZWx9YH0gZGlzYWJsZWQ9e2NvbW1pdG1lbnREZWxldGluZ0lkIT09bnVsbH0+e2NvbW1pdG1lbnREZWxldGluZ0lkPT09Y29tbWl0bWVudC5pZD8n4oCmJzon8J+XkSd9PC9idXR0b24+PC9zdHJvbmc+PHNtYWxsPntjb21taXRtZW50LmFtb3VudE1vZGU9PT0nUkVDRU5UX0JJTExfRVNUSU1BVEUnPydSZWNlbnQtYmlsbCBlc3RpbWF0ZSc6J1BsYW5uaW5nIGFtb3VudCd9IMK3IHtyZWN1cnJlbmNlTGFiZWwoY29tbWl0bWVudCl9PC9zbWFsbD48c21hbGw+e2NvbW1pdG1lbnQuY3VycmVudE9jY3VycmVuY2U/LnN0YXR1cz09PSdDT01QTEVURUQnPydDb21wbGV0ZWQnOmNvbW1pdG1lbnQuc3RhdHVzPT09J0FDVElWRSc/J0FjdGl2ZSc6Y29tbWl0bWVudC5zdGF0dXMudG9Mb3dlckNhc2UoKX08L3NtYWxsPnsjaWYgY29tbWl0bWVudC5uZXh0RXhwZWN0ZWREYXRlfTxzbWFsbD5OZXh0IGV4cGVjdGVkOiB7ZXhwZWN0ZWRMYWJlbChjb21taXRtZW50Lm5leHRFeHBlY3RlZERhdGUpfTwvc21hbGw+ey9pZn08L2Rpdj48ZGl2PjxiPnttb25leShjb21taXRtZW50LnBsYW5uaW5nQW1vdW50KX08L2I+PC9kaXY+PFZpZXdEZXRhaWxzTGluayBvbkFjdGlvbj17KCk9Pm9wZW5Db21taXRtZW50SGlzdG9yeShjb21taXRtZW50KX0vPjxidXR0b24gY2xhc3M9XCJ0ZXh0LWxpbmtcIiBvbjpjbGljaz17KCk9Pm9wZW5Db21wbGV0aW9uKGNvbW1pdG1lbnQpfT5NYXJrIGNvbXBsZXRlZDwvYnV0dG9uPjwvYXJ0aWNsZT57L2VhY2h9ezplbHNlfTxwIGNsYXNzPVwibG9hbi1zdGF0ZVwiPk5vIGNvbW1pdG1lbnRzIHlldC48L3A+ey9pZn08YnV0dG9uIGNsYXNzPVwiYWRkLWxvYW4tcm93XCIgb246Y2xpY2s9eygpPT5vcGVuQ29tbWl0bWVudEZvcm0oKX0+77yLIEFkZCBhIGNvbW1pdG1lbnQ8L2J1dHRvbj48L3NlY3Rpb24+XG4gICAgICA8c2VjdGlvbiBjbGFzcz1cImxvYW5zLW1vZHVsZVwiPjxkaXYgY2xhc3M9XCJsb2Fucy1oZWFkaW5nXCI+PGRpdj48c3Ryb25nPkNyZWRpdCBjYXJkczwvc3Ryb25nPjxzbWFsbD5UdXJuIGNhcHR1cmVkIGNhcmQgc3BlbmRpbmcgaW50byB0aGUgYmlsbCBkdWUgbmV4dCBtb250aDwvc21hbGw+PC9kaXY+PC9kaXY+eyNpZiBjcmVkaXRDYXJkU3RhdHVzPT09J2xvYWRpbmcnfTxwIGNsYXNzPVwibG9hbi1zdGF0ZVwiPkxvYWRpbmcgY3JlZGl0IGNhcmRz4oCmPC9wPns6ZWxzZSBpZiBjcmVkaXRDYXJkU3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwibG9hbi1zdGF0ZSBlcnJvclwiPjxzcGFuPntjcmVkaXRDYXJkRXJyb3J9PC9zcGFuPjxidXR0b24gb246Y2xpY2s9e2xvYWRDcmVkaXRDYXJkc30+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+ezplbHNlIGlmIGNyZWRpdENhcmRzLmxlbmd0aH17I2VhY2ggY3JlZGl0Q2FyZHMgYXMgY2FyZH08YXJ0aWNsZSBjbGFzcz1cImxvYW4tcm93XCI+PHNwYW4+4pajPC9zcGFuPjxkaXY+PHN0cm9uZyBjbGFzcz1cImxvYW4tbmFtZVwiPntjYXJkLmNhcmROYW1lfTxidXR0b24gY2xhc3M9XCJsb2FuLWVkaXRcIiBvbjpjbGljaz17KCk9Pm9wZW5DcmVkaXRDYXJkRm9ybShjYXJkKX0gYXJpYS1sYWJlbD17YEVkaXQgJHtjYXJkLmNhcmROYW1lfWB9IHRpdGxlPVwiRWRpdCBjcmVkaXQgY2FyZFwiPvCflKc8L2J1dHRvbj48L3N0cm9uZz48c21hbGw+e2NhcmQuaXNzdWVyTmFtZX0gwrcgY2FwdHVyZWQgYXMge2NhcmQuYWNjb3VudE5hbWV9PC9zbWFsbD48L2Rpdj48ZGl2PjxiPkR1ZSB7Y2FyZC5kdWVEYXl9PC9iPjxzbWFsbD5TdGF0ZW1lbnQge2NhcmQuc3RhdGVtZW50RGF5fTwvc21hbGw+PC9kaXY+PC9hcnRpY2xlPnsvZWFjaH17OmVsc2V9PHAgY2xhc3M9XCJsb2FuLXN0YXRlXCI+QWRkIGEgY2FyZCBvbmNlIGl0IGFwcGVhcnMgYXMgYW4gYWNjb3VudCBpbiB5b3VyIGNhcHR1cmVkIGV4cGVuc2VzLjwvcD57L2lmfTxidXR0b24gY2xhc3M9XCJhZGQtbG9hbi1yb3dcIiBvbjpjbGljaz17KCk9Pm9wZW5DcmVkaXRDYXJkRm9ybSgpfT7vvIsgQWRkIGEgY3JlZGl0IGNhcmQ8L2J1dHRvbj48L3NlY3Rpb24+XG4gICAgICB7I2VhY2ggW1sn4peSJywnRW1lcmdlbmN5IGZ1bmQnLCdUcmFjayB5b3VyIHNhZmV0eSBjdXNoaW9uJ10sWyfil44nLCdHb2FscycsJ1BsYW4gZm9yIHdoYXQgbWF0dGVycyddLFsn4pakJywnQnVkZ2V0cycsJ1NldCBnZW50bGUgc3BlbmRpbmcgbGltaXRzJ11dIGFzIG1vZHVsZX1cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cIm1vZHVsZS1yb3dcIiBvbjpjbGljaz17Y2xvc2VNb25leX0+PHNwYW4+e21vZHVsZVswXX08L3NwYW4+PGRpdj48c3Ryb25nPnttb2R1bGVbMV19PC9zdHJvbmc+PHNtYWxsPnttb2R1bGVbMl19PC9zbWFsbD48L2Rpdj48Yj5Db21pbmcgc29vbjwvYj48L2J1dHRvbj5cbiAgICAgIHsvZWFjaH1cbiAgICAgIDxzZWN0aW9uIGNsYXNzPVwibXV0dWFsLWZ1bmRzLW1vZHVsZVwiPjxkaXYgY2xhc3M9XCJsb2Fucy1oZWFkaW5nXCI+PGRpdj48c3Ryb25nPk11dHVhbCBmdW5kczwvc3Ryb25nPjxzbWFsbD5Qb3J0Zm9saW8gdmFsdWUgZnJvbSB0aGUgbGF0ZXN0IGF2YWlsYWJsZSBOQVY8L3NtYWxsPjwvZGl2PjxzcGFuIGNsYXNzPVwidmVyaWZpZWQtcGlsbFwiPlNjaGVtZSBBUEk8L3NwYW4+PC9kaXY+eyNpZiBtdXR1YWxGdW5kU3RhdHVzPT09J2xvYWRpbmcnfTxwPkxvYWRpbmcgeW91ciBmdW5kc+KApjwvcD57OmVsc2UgaWYgbXV0dWFsRnVuZFN0YXR1cz09PSdlcnJvcid9PGRpdiBjbGFzcz1cImxvYW4tc3RhdGUgZXJyb3JcIj48c3Bhbj57bXV0dWFsRnVuZEVycm9yfTwvc3Bhbj48YnV0dG9uIG9uOmNsaWNrPXtsb2FkTXV0dWFsRnVuZHN9PlRyeSBhZ2FpbjwvYnV0dG9uPjwvZGl2Pns6ZWxzZSBpZiBtdXR1YWxGdW5kcy5sZW5ndGh9PHNlY3Rpb24gY2xhc3M9XCJwb3J0Zm9saW8tdG90YWxcIj48c3Bhbj5Ub3RhbCBwb3J0Zm9saW8gdmFsdWU8L3NwYW4+eyNpZiBtdXR1YWxQb3J0Zm9saW8uY3VycmVudCE9PW51bGx9PHN0cm9uZz57bW9uZXkobXV0dWFsUG9ydGZvbGlvLmN1cnJlbnQpfTwvc3Ryb25nPjxzbWFsbCBjbGFzczpwb3NpdGl2ZT17TnVtYmVyKG11dHVhbFBvcnRmb2xpby5wbmwpPj0wfSBjbGFzczpuZWdhdGl2ZT17TnVtYmVyKG11dHVhbFBvcnRmb2xpby5wbmwpPDB9PnttdXR1YWxQb3J0Zm9saW8ucG5sPj0wPycrJzonJ317bW9uZXkobXV0dWFsUG9ydGZvbGlvLnBubCl9IG92ZXJhbGwgUCZhbXA7TDwvc21hbGw+ezplbHNlfTxzdHJvbmc+e21vbmV5KG11dHVhbFBvcnRmb2xpby5pbnZlc3RlZCl9PC9zdHJvbmc+PHNtYWxsPkN1cnJlbnQgdmFsdWF0aW9uIGlzIHRlbXBvcmFyaWx5IHVuYXZhaWxhYmxlPC9zbWFsbD57L2lmfTwvc2VjdGlvbj48ZGl2IGNsYXNzPVwiZnVuZC1jYXJkLWxpc3RcIj57I2VhY2ggbXV0dWFsRnVuZHMgYXMgZnVuZH08YnV0dG9uIGNsYXNzPXtgZnVuZC1jYXJkICR7ZnVuZEFjY2VudChmdW5kLmlkKX1gfSBvbjpjbGljaz17KCk9Pm9wZW5GdW5kRGV0YWlsKGZ1bmQuaWQpfSBhcmlhLWxhYmVsPXtgT3BlbiAke2Z1bmQuc2NoZW1lTmFtZX0gZGV0YWlsc2B9PjxzcGFuIGNsYXNzPVwiZnVuZC1jYXJkLW9yYlwiPjwvc3Bhbj48ZGl2IGNsYXNzPVwiZnVuZC1jYXJkLXRpdGxlXCI+PHN0cm9uZz57ZnVuZC5zY2hlbWVOYW1lfTwvc3Ryb25nPjxzcGFuIGNsYXNzPVwiZnVuZC1kZWxldGVcIiByb2xlPVwiYnV0dG9uXCIgdGFiaW5kZXg9XCIwXCIgYXJpYS1sYWJlbD17YERlbGV0ZSAke2Z1bmQuc2NoZW1lTmFtZX1gfSB0aXRsZT1cIkRlbGV0ZSBtdXR1YWwgZnVuZFwiIG9uOmNsaWNrfHN0b3BQcm9wYWdhdGlvbj17KCk9PnJlbW92ZU11dHVhbEZ1bmQoZnVuZCl9IG9uOmtleWRvd258c3RvcFByb3BhZ2F0aW9uPXsoZXZlbnQpPT57aWYoZXZlbnQua2V5PT09J0VudGVyJ3x8ZXZlbnQua2V5PT09JyAnKXtldmVudC5wcmV2ZW50RGVmYXVsdCgpO3JlbW92ZU11dHVhbEZ1bmQoZnVuZCk7fX19PnttdXR1YWxGdW5kRGVsZXRpbmdJZD09PWZ1bmQuaWQ/J+KApic6J/Cfl5EnfTwvc3Bhbj48c21hbGw+e2Z1bmRTdWJ0aXRsZShmdW5kLnNjaGVtZU5hbWUpfTwvc21hbGw+PC9kaXY+eyNpZiBmdW5kLmN1cnJlbnRWYWx1ZSE9PW51bGx9PGRpdiBjbGFzcz1cImZ1bmQtY2FyZC12YWx1ZXNcIj48ZGl2IGNsYXNzOnBvc2l0aXZlPXtOdW1iZXIoZnVuZC5wcm9maXRPckxvc3MpPj0wfSBjbGFzczpuZWdhdGl2ZT17TnVtYmVyKGZ1bmQucHJvZml0T3JMb3NzKTwwfT48c3Bhbj5QJmFtcDtMPC9zcGFuPjxiPntOdW1iZXIoZnVuZC5wcm9maXRPckxvc3MpPj0wPycrJzonJ317Y29tcGFjdE1vbmV5KGZ1bmQucHJvZml0T3JMb3NzKX08L2I+PHNtYWxsPntOdW1iZXIoZnVuZC5wcm9maXRPckxvc3NQZXJjZW50KT49MD8nKyc6Jyd9e051bWJlcihmdW5kLnByb2ZpdE9yTG9zc1BlcmNlbnQpLnRvRml4ZWQoMil9JTwvc21hbGw+PC9kaXY+PGRpdj48c3Bhbj5JbnZlc3RlZDwvc3Bhbj48Yj57Y29tcGFjdE1vbmV5KGZ1bmQuaW52ZXN0ZWQpfTwvYj48L2Rpdj48ZGl2PjxzcGFuPkN1cnJlbnQ8L3NwYW4+PGI+e2NvbXBhY3RNb25leShmdW5kLmN1cnJlbnRWYWx1ZSl9PC9iPjwvZGl2PjwvZGl2PjxwIGNsYXNzPVwiZnVuZC1jYXJkLW5hdlwiPkxhdGVzdCBOQVYge21vbmV5RGVjaW1hbChmdW5kLmxhdGVzdE5hdil9IHsjaWYgIWZ1bmQuYWN0aXZlU2lwfTxzcGFuIGNsYXNzPVwic3RvY2stcmVjdXJyaW5nLWJlbGxcIiByb2xlPVwiYnV0dG9uXCIgdGFiaW5kZXg9XCIwXCIgYXJpYS1sYWJlbD17YFNldCBTSVAgZm9yICR7ZnVuZC5zY2hlbWVOYW1lfWB9IHRpdGxlPVwiU2V0IFNJUFwiIG9uOmNsaWNrfHN0b3BQcm9wYWdhdGlvbj17KCk9Pm9wZW5GdW5kU2lwUGxhbihmdW5kKX0gb246a2V5ZG93bnxzdG9wUHJvcGFnYXRpb249eyhldmVudCk9PntpZihldmVudC5rZXk9PT0nRW50ZXInfHxldmVudC5rZXk9PT0nICcpe2V2ZW50LnByZXZlbnREZWZhdWx0KCk7b3BlbkZ1bmRTaXBQbGFuKGZ1bmQpO319fT7wn5SUPC9zcGFuPnsvaWZ9PC9wPns6ZWxzZX08cCBjbGFzcz1cImZ1bmQtdmFsdWF0aW9uLXVuYXZhaWxhYmxlXCI+Q3VycmVudCB2YWx1YXRpb24gaXMgdGVtcG9yYXJpbHkgdW5hdmFpbGFibGUuIFlvdXIgaW52ZXN0ZWQgYW1vdW50IGlzIHttb25leShmdW5kLmludmVzdGVkKX0uPC9wPnsvaWZ9PGZvb3Rlcj48c3BhbiBjbGFzcz1cImZ1bmQtc2lwLXN1bW1hcnlcIj57ZnVuZC5hY3RpdmVTaXA/YDEgU0lQIMK3ICR7Y29tcGFjdE1vbmV5KGZ1bmQuYWN0aXZlU2lwLmFtb3VudCl9IG9uIHRoZSAke2Z1bmQuYWN0aXZlU2lwLmRheX0ke2Z1bmQuYWN0aXZlU2lwLmRheT09PTE/J3N0JzpmdW5kLmFjdGl2ZVNpcC5kYXk9PT0yPyduZCc6ZnVuZC5hY3RpdmVTaXAuZGF5PT09Mz8ncmQnOid0aCd9IG9mIGV2ZXJ5IG1vbnRoYDonTm8gYWN0aXZlIFNJUCd9PC9zcGFuPjxzcGFuIGNsYXNzPVwiZnVuZC1hY3Rpb25zXCI+PHNwYW4+VmlldyBkZXRhaWxzIOKGkjwvc3Bhbj48c3BhbiBjbGFzcz1cImZ1bmQtbHVtcC1zdW1cIiByb2xlPVwiYnV0dG9uXCIgdGFiaW5kZXg9XCIwXCIgb246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uPXsoKT0+b3Blbkx1bXBTdW0oZnVuZCl9Pu+8iyBMdW1wIHN1bTwvc3Bhbj48L3NwYW4+PC9mb290ZXI+eyNpZiBmdW5kLmN1cnJlbnRTaXA/LnN0YXR1cz09PVwiRFVFXCJ9PER1ZVJlbWluZGVyIHRlc3RJZD17YG11dHVhbC1mdW5kLXNpcC0ke2Z1bmQuaWR9YH0gZGV0YWlsPXtgRHVlIG5vdyDCtyAke21vbmV5KGZ1bmQuY3VycmVudFNpcC5hbW91bnQpfWB9IGFjdGlvbkxhYmVsPVwiQ29uZmlybSBhbGxvY2F0aW9uXCIgb25BY3Rpb249eygpPT5vcGVuU2lwQ29uZmlybWF0aW9uKGZ1bmQsZnVuZC5jdXJyZW50U2lwKX0vPnsvaWZ9PC9idXR0b24+ey9lYWNofTwvZGl2Pns6ZWxzZX08cD5DaG9vc2Ugb25lIHZlcmlmaWVkIHNjaGVtZSwgdGhlbiBhZGQgaXRzIGV4aXN0aW5nIGhvbGRpbmcsIGFuIFNJUCwgb3Igb2NjYXNpb25hbCBsdW1wIHN1bXMgd2hlbmV2ZXIgeW91IG5lZWQuPC9wPnsvaWZ9PGJ1dHRvbiBjbGFzcz1cImFkZC1mdW5kLXJvd1wiIG9uOmNsaWNrPXtvcGVuTXV0dWFsRnVuZEZvcm19Pu+8iyBBZGQgYSBtdXR1YWwgZnVuZDwvYnV0dG9uPjwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzPVwibXV0dWFsLWZ1bmRzLW1vZHVsZSBzdG9ja3MtbW9kdWxlXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJsb2Fucy1oZWFkaW5nXCI+PGRpdj48c3Ryb25nPlN0b2Nrczwvc3Ryb25nPjxzbWFsbD5Qb3J0Zm9saW8gdmFsdWUgZnJvbSB0aGUgbGF0ZXN0IGF2YWlsYWJsZSBtYXJrZXQgcHJpY2U8L3NtYWxsPjwvZGl2PjxzcGFuIGNsYXNzPVwidmVyaWZpZWQtcGlsbFwiPk1hcmtldCBkYXRhPC9zcGFuPjwvZGl2PlxuICAgICAgICB7I2lmIHN0b2NrU3RhdHVzPT09J2xvYWRpbmcnfTxwPkxvYWRpbmcgeW91ciBzdG9ja3PigKY8L3A+XG4gICAgICAgIHs6ZWxzZSBpZiBzdG9ja1N0YXR1cz09PSdlcnJvcid9PGRpdiBjbGFzcz1cImxvYW4tc3RhdGUgZXJyb3JcIj48c3Bhbj57c3RvY2tFcnJvcn08L3NwYW4+PGJ1dHRvbiBvbjpjbGljaz17bG9hZFN0b2Nrc30+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+XG4gICAgICAgIHs6ZWxzZSBpZiBzdG9ja3MubGVuZ3RofVxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzPVwicG9ydGZvbGlvLXRvdGFsXCI+PHNwYW4+VG90YWwgc3RvY2sgdmFsdWU8L3NwYW4+eyNpZiBzdG9ja1BvcnRmb2xpby5jdXJyZW50IT09bnVsbH08c3Ryb25nPnttb25leShzdG9ja1BvcnRmb2xpby5jdXJyZW50KX08L3N0cm9uZz48c21hbGwgY2xhc3M6cG9zaXRpdmU9e3N0b2NrUG9ydGZvbGlvLnBubD49MH0gY2xhc3M6bmVnYXRpdmU9e3N0b2NrUG9ydGZvbGlvLnBubDwwfT57c3RvY2tQb3J0Zm9saW8ucG5sPj0wPycrJzonJ317bW9uZXkoc3RvY2tQb3J0Zm9saW8ucG5sKX0gb3ZlcmFsbCBQJmFtcDtMPC9zbWFsbD57OmVsc2V9PHN0cm9uZz57bW9uZXkoc3RvY2tQb3J0Zm9saW8uaW52ZXN0ZWQpfTwvc3Ryb25nPjxzbWFsbD5DdXJyZW50IHZhbHVhdGlvbiBpcyB0ZW1wb3JhcmlseSB1bmF2YWlsYWJsZTwvc21hbGw+ey9pZn08L3NlY3Rpb24+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZ1bmQtY2FyZC1saXN0XCI+eyNlYWNoIHN0b2NrcyBhcyBzdG9ja308YXJ0aWNsZSBjbGFzcz17YGZ1bmQtY2FyZCAke2Z1bmRBY2NlbnQoc3RvY2suaWQpfWB9IGRhdGEtdGVzdGlkPXtgc3RvY2stY2FyZC0ke3N0b2NrLmlkfWB9IGNsYXNzOmR1ZS1zdG9jaz17U3RyaW5nKHN0b2NrLmlkKT09PVN0cmluZyhoaWdobGlnaHRlZFN0b2NrSWQpfT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZnVuZC1jYXJkLW9yYlwiPjwvc3Bhbj48ZGl2IGNsYXNzPVwiZnVuZC1jYXJkLXRpdGxlXCI+PHN0cm9uZz57c3RvY2submFtZX08L3N0cm9uZz48c3BhbiBjbGFzcz1cImZ1bmQtZGVsZXRlXCIgcm9sZT1cImJ1dHRvblwiIHRhYmluZGV4PVwiMFwiIGFyaWEtbGFiZWw9e2BEZWxldGUgJHtzdG9jay5uYW1lfWB9IHRpdGxlPVwiRGVsZXRlIHN0b2NrXCIgb246Y2xpY2s9eygpPT5yZW1vdmVTdG9jayhzdG9jayl9IG9uOmtleWRvd249eyhldmVudCk9PntpZihldmVudC5rZXk9PT0nRW50ZXInfHxldmVudC5rZXk9PT0nICcpe2V2ZW50LnByZXZlbnREZWZhdWx0KCk7cmVtb3ZlU3RvY2soc3RvY2spO319fT57c3RvY2tEZWxldGluZ0lkPT09c3RvY2suaWQ/J+KApic6J/Cfl5EnfTwvc3Bhbj48c21hbGw+e3N0b2NrLnN5bWJvbH17c3RvY2suZXhjaGFuZ2U/YCDCtyAke3N0b2NrLmV4Y2hhbmdlfWA6Jyd9PC9zbWFsbD48L2Rpdj5cbiAgICAgICAgICAgIHsjaWYgc3RvY2suY3VycmVudFZhbHVlIT09bnVsbH08ZGl2IGNsYXNzPVwiZnVuZC1jYXJkLXZhbHVlc1wiPjxkaXYgY2xhc3M6cG9zaXRpdmU9e051bWJlcihzdG9jay5wcm9maXRPckxvc3MpPj0wfSBjbGFzczpuZWdhdGl2ZT17TnVtYmVyKHN0b2NrLnByb2ZpdE9yTG9zcyk8MH0+PHNwYW4+UCZhbXA7TDwvc3Bhbj48Yj57TnVtYmVyKHN0b2NrLnByb2ZpdE9yTG9zcyk+PTA/JysnOicnfXtjb21wYWN0TW9uZXkoc3RvY2sucHJvZml0T3JMb3NzKX08L2I+PHNtYWxsPntOdW1iZXIoc3RvY2sucHJvZml0T3JMb3NzUGVyY2VudCk+PTA/JysnOicnfXtOdW1iZXIoc3RvY2sucHJvZml0T3JMb3NzUGVyY2VudCkudG9GaXhlZCgyKX0lPC9zbWFsbD48L2Rpdj48ZGl2PjxzcGFuPkludmVzdGVkPC9zcGFuPjxiPntjb21wYWN0TW9uZXkoc3RvY2suaW52ZXN0ZWQpfTwvYj48L2Rpdj48ZGl2PjxzcGFuPkN1cnJlbnQ8L3NwYW4+PGI+e2NvbXBhY3RNb25leShzdG9jay5jdXJyZW50VmFsdWUpfTwvYj48L2Rpdj48L2Rpdj48cCBjbGFzcz1cImZ1bmQtY2FyZC1uYXZcIj5MYXRlc3QgcHJpY2Uge21vbmV5RGVjaW1hbChzdG9jay5sYXRlc3RQcmljZSl9IMK3IHtOdW1iZXIoc3RvY2sucXVhbnRpdHkpLnRvRml4ZWQoMyl9IHNoYXJlcyA8YnV0dG9uIGNsYXNzPVwic3RvY2stcmVjdXJyaW5nLWJlbGxcIiBhcmlhLWxhYmVsPXtgU2V0IG1vbnRobHkgcmVjdXJyaW5nIHBsYW4gZm9yICR7c3RvY2submFtZX1gfSB0aXRsZT1cIlNldCBtb250aGx5IHJlY3VycmluZyBwbGFuXCIgb246Y2xpY2s9eygpPT5vcGVuU3RvY2tQbGFuKHN0b2NrKX0+8J+UlDwvYnV0dG9uPjwvcD57OmVsc2V9PHAgY2xhc3M9XCJmdW5kLXZhbHVhdGlvbi11bmF2YWlsYWJsZVwiPkN1cnJlbnQgcHJpY2UgaXMgdGVtcG9yYXJpbHkgdW5hdmFpbGFibGUuIFlvdXIgaW52ZXN0ZWQgYW1vdW50IGlzIHttb25leShzdG9jay5pbnZlc3RlZCl9LjwvcD57L2lmfVxuICAgICAgICAgICAgPGZvb3Rlcj48c3BhbiBjbGFzcz1cImZ1bmQtc2lwLXN1bW1hcnlcIj57c3RvY2suYWN0aXZlTW9udGhseVBsYW4/YE1vbnRobHkgcGxhbiDCtyAke2NvbXBhY3RNb25leShzdG9jay5hY3RpdmVNb250aGx5UGxhbi5hbW91bnQpfSBvbiB0aGUgJHtzdG9jay5hY3RpdmVNb250aGx5UGxhbi5kYXl9JHtzdG9jay5hY3RpdmVNb250aGx5UGxhbi5kYXk9PT0xPydzdCc6c3RvY2suYWN0aXZlTW9udGhseVBsYW4uZGF5PT09Mj8nbmQnOnN0b2NrLmFjdGl2ZU1vbnRobHlQbGFuLmRheT09PTM/J3JkJzondGgnfWA6J05vIG1vbnRobHkgcGxhbid9PC9zcGFuPjxWaWV3RGV0YWlsc0xpbmsgb25BY3Rpb249eygpPT5vcGVuU3RvY2tEZXRhaWwoc3RvY2suaWQpfS8+PC9mb290ZXI+XG4gICAgICAgICAgICB7I2lmIHN0b2NrLmN1cnJlbnRNb250aGx5UGxhbj8uc3RhdHVzPT09J0RVRSd9PER1ZVJlbWluZGVyIHRlc3RJZD17YHN0b2NrLW1vbnRobHktcGxhbi0ke3N0b2NrLmlkfWB9IGRldGFpbD17YER1ZSBub3cgwrcgJHttb25leShzdG9jay5jdXJyZW50TW9udGhseVBsYW4uYW1vdW50KX1gfSBhY3Rpb25MYWJlbD1cIkNvbmZpcm0gYWxsb2NhdGlvblwiIG9uQWN0aW9uPXsoKT0+e3N0b2NrUGxhbkNvbmZpcm1hdGlvblRhcmdldD1zdG9jaztzdG9ja1BsYW5Db25maXJtYXRpb249e2Ftb3VudDpTdHJpbmcoc3RvY2suY3VycmVudE1vbnRobHlQbGFuLmFtb3VudCkscHJpY2U6U3RyaW5nKHN0b2NrLmxhdGVzdFByaWNlfHwnJyl9fX0vPnsvaWZ9XG4gICAgICAgICAgPC9hcnRpY2xlPnsvZWFjaH08L2Rpdj5cbiAgICAgICAgezplbHNlfTxwPlNlYXJjaCBhIGxpc3RlZCBzdG9jaywgdGhlbiBhZGQgdGhlIHNoYXJlcyBhbmQgYW1vdW50IHlvdSBhbHJlYWR5IGludmVzdGVkLjwvcD57L2lmfVxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYWRkLWZ1bmQtcm93XCIgb246Y2xpY2s9e29wZW5TdG9ja0Zvcm19Pu+8iyBBZGQgYSBzdG9jazwvYnV0dG9uPlxuICAgICAgPC9zZWN0aW9uPlxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJsb2Fucy1tb2R1bGVcIiBkYXRhLXRlc3RpZD1cImxvYW5zLXNlY3Rpb25cIj48ZGl2IGNsYXNzPVwibG9hbnMtaGVhZGluZ1wiPjxkaXY+PHN0cm9uZz5Mb2Fuczwvc3Ryb25nPjxzbWFsbD5UcmFjayByZXBheW1lbnRzIGFuZCBtb250aGx5IGNvbW1pdG1lbnRzPC9zbWFsbD48L2Rpdj57I2lmIGFjdGl2ZUxvYW5zLmxlbmd0aH08ZGl2IGNsYXNzPVwibG9hbi10b3RhbFwiPjxzcGFuPlRvdGFsIG1vbnRobHkgRU1JPC9zcGFuPjxiPnttb25leSh0b3RhbE1vbnRobHlFbWkpfS9tbzwvYj48L2Rpdj57L2lmfTwvZGl2PlxuICAgICAgICB7I2lmIGxvYW5TdGF0dXM9PT0nbG9hZGluZyd9PHAgY2xhc3M9XCJsb2FuLXN0YXRlXCI+TG9hZGluZyB5b3VyIGxvYW5z4oCmPC9wPns6ZWxzZSBpZiBsb2FuU3RhdHVzPT09J2Vycm9yJ308ZGl2IGNsYXNzPVwibG9hbi1zdGF0ZSBlcnJvclwiPjxzcGFuPntsb2FuRXJyb3J9PC9zcGFuPjxidXR0b24gb246Y2xpY2s9e2xvYWRMb2Fuc30+VHJ5IGFnYWluPC9idXR0b24+PC9kaXY+ezplbHNlIGlmIGFjdGl2ZUxvYW5zLmxlbmd0aH17I2VhY2ggYWN0aXZlTG9hbnMgYXMgbG9hbn17QGNvbnN0IHNjaGVkdWxlPWxvYW5TY2hlZHVsZShsb2FuKX08YXJ0aWNsZSBjbGFzcz1cImxvYW4tcm93XCIgY2xhc3M6ZHVlLWxvYW49e1N0cmluZyhsb2FuLmlkKT09PVN0cmluZyhoaWdobGlnaHRlZExvYW5JZCl9PjxzcGFuPuKCuTwvc3Bhbj48ZGl2PjxzdHJvbmcgY2xhc3M9XCJsb2FuLW5hbWVcIj57bG9hbi5sb2FuTmFtZX08YnV0dG9uIGNsYXNzPVwibG9hbi1lZGl0XCIgb246Y2xpY2s9eygpPT5vcGVuTG9hbkZvcm0obG9hbil9IGFyaWEtbGFiZWw9e2BFZGl0ICR7bG9hbi5sb2FuTmFtZX1gfSB0aXRsZT1cIkVkaXQgbG9hblwiPvCflKc8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwibG9hbi1kZWxldGVcIiBvbjpjbGljaz17KCk9PnJlbW92ZUxvYW4obG9hbil9IGFyaWEtbGFiZWw9e2BEZWxldGUgJHtsb2FuLmxvYW5OYW1lfWB9IHRpdGxlPVwiRGVsZXRlIGxvYW5cIiBkaXNhYmxlZD17bG9hbkRlbGV0aW5nSWQhPT1udWxsfT57bG9hbkRlbGV0aW5nSWQ9PT1sb2FuLmlkPyfigKYnOifwn5eRJ308L2J1dHRvbj48L3N0cm9uZz48c21hbGw+e2xvYW4ubGVuZGVyTmFtZX0gwrcge2xvYW4ubG9hblR5cGUucmVwbGFjZUFsbCgnXycsJyAnKX0gwrcge2xvYW4udG90YWxUZW51cmVNb250aHN9IG1vbnRoczwvc21hbGw+PC9kaXY+PGRpdj48Yj57bW9uZXkobG9hbi5tb250aGx5RW1pQW1vdW50KX0vbW88L2I+PHNtYWxsPnttb25leShsb2FuLm9yaWdpbmFsUHJpbmNpcGFsKX0gcHJpbmNpcGFsPC9zbWFsbD48L2Rpdj48Vmlld0RldGFpbHNMaW5rIG9uQWN0aW9uPXsoKT0+b3BlbkxvYW5IaXN0b3J5KGxvYW4pfS8+eyNpZiBzY2hlZHVsZX08ZGl2IGNsYXNzPVwibG9hbi1wcm9ncmVzc1wiPjxkaXY+PHNwYW4+e3NjaGVkdWxlLmR1ZX0gb2Yge3NjaGVkdWxlLnRlbnVyZX0gaGlzdG9yaWNhbCBFTUkgbW9udGhzIGNvbXBsZXRlZDwvc3Bhbj48L2Rpdj48aSBzdHlsZT17YC0tbG9hbi1wcm9ncmVzczoke3NjaGVkdWxlLnBlcmNlbnR9JWB9PjwvaT48L2Rpdj57L2lmfXsjaWYgU3RyaW5nKGxvYW4uaWQpPT09U3RyaW5nKGhpZ2hsaWdodGVkTG9hbklkKSYmaGlnaGxpZ2h0ZWRMb2FuQWN0aW9ufTxkaXYgY2xhc3M9XCJsb2FuLWR1ZS1hY3Rpb25cIj48c3Ryb25nPkZpbmFsIEVNSSBkdWU8L3N0cm9uZz48cD5Db25maXJtIHlvdSBwYWlkIHRoZSBmaW5hbCBFTUkgYmVmb3JlIGNsb3NpbmcgdGhpcyBsb2FuLjwvcD48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIGRhdGEtdGVzdGlkPVwibWFyay1maW5hbC1lbWktcGFpZFwiIGRpc2FibGVkPXtjb21wbGV0aW5nQWN0aW9uSWQhPT1udWxsfSBvbjpjbGljaz17KCk9PmNvbXBsZXRlT3BlbkFjdGlvbihoaWdobGlnaHRlZExvYW5BY3Rpb24pfT57Y29tcGxldGluZ0FjdGlvbklkPT09aGlnaGxpZ2h0ZWRMb2FuQWN0aW9uLmlkPydNYXJraW5nIGxvYW4gY2xvc2Vk4oCmJzonTWFyayBmaW5hbCBFTUkgcGFpZCd9PC9idXR0b24+PC9kaXY+ey9pZn08L2FydGljbGU+ey9lYWNofXs6ZWxzZX08cCBjbGFzcz1cImxvYW4tc3RhdGVcIj5ObyBhY3RpdmUgbG9hbnMuPC9wPnsvaWZ9XG4gICAgICAgIHsjaWYgY2xvc2VkTG9hbnMubGVuZ3RofTxidXR0b24gY2xhc3M9XCJjbG9zZWQtbG9hbnMtdG9nZ2xlXCIgZGF0YS10ZXN0aWQ9XCJjbG9zZWQtbG9hbnMtdG9nZ2xlXCIgYXJpYS1leHBhbmRlZD17c2hvd0Nsb3NlZExvYW5zfSBvbjpjbGljaz17KCk9PnNob3dDbG9zZWRMb2Fucz0hc2hvd0Nsb3NlZExvYW5zfT5DbG9zZWQgbG9hbnMgwrcge2Nsb3NlZExvYW5zLmxlbmd0aH08c3Bhbj57c2hvd0Nsb3NlZExvYW5zPyfijIMnOifijIQnfTwvc3Bhbj48L2J1dHRvbj57I2lmIHNob3dDbG9zZWRMb2Fuc308ZGl2IGNsYXNzPVwiY2xvc2VkLWxvYW5zLWxpc3RcIj57I2VhY2ggY2xvc2VkTG9hbnMgYXMgbG9hbn08Q2xvc2VkTG9hblJvdyB7bG9hbn0ge21vbmV5fS8+ey9lYWNofTwvZGl2PnsvaWZ9ey9pZn1cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImFkZC1sb2FuLXJvd1wiIG9uOmNsaWNrPXsoKT0+b3BlbkxvYW5Gb3JtKCl9Pu+8iyBBZGQgYW5vdGhlciBsb2FuPC9idXR0b24+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICA8cCBjbGFzcz1cIm1vZHVsZS1mb290bm90ZVwiPlRoZXNlIG1vZHVsZXMgdXNlIG5vcm1hbCBmb3Jtc+KAlG5vdCBBSSBjbGVhbnVw4oCUYW5kIG9ubHkgaW5mb3JtIHN0b3JpZXMgaWYgeW91IHR1cm4gdGhhdCBvbi48L3A+XG4gICAgPC9zZWN0aW9uPlxuICA8L2Rpdj5cbnsvaWZ9XG57I2lmIHNob3dDb21taXRtZW50Rm9ybX08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGxvYW4tZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd0NvbW1pdG1lbnRGb3JtPWZhbHNlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5DT01NSVRNRU5UPC9wPjxoMj57Y29tbWl0bWVudEVkaXRpbmdJZD09PW51bGw/J0FkZCBhIHJlcGVhdGFibGUgb2JsaWdhdGlvbic6J0VkaXQgY29tbWl0bWVudCd9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPkEgcGxhbm5pbmcgZXN0aW1hdGUsIG5vdCBwcm9vZiB0aGF0IGEgYmlsbCB3YXMgcGFpZC48L3A+PGxhYmVsPk5hbWU8aW5wdXQgYmluZDp2YWx1ZT17Y29tbWl0bWVudEZvcm0ubGFiZWx9IG1heGxlbmd0aD1cIjEyMFwiLz48L2xhYmVsPjxsYWJlbD5QbGFubmluZyBhbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIwLjAxXCIgYmluZDp2YWx1ZT17Y29tbWl0bWVudEZvcm0ucGxhbm5pbmdBbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5GcmVxdWVuY3k8c2VsZWN0IGFyaWEtbGFiZWw9XCJGcmVxdWVuY3lcIiBiaW5kOnZhbHVlPXtjb21taXRtZW50Rm9ybS5yZWN1cnJlbmNlVW5pdH0+eyNlYWNoIFsnREFZJywnV0VFSycsJ01PTlRIJywnWUVBUiddIGFzIHVuaXR9PG9wdGlvbiB2YWx1ZT17dW5pdH0+e3VuaXQudG9Mb3dlckNhc2UoKX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+RXZlcnk8aW5wdXQgYXJpYS1sYWJlbD1cIkV2ZXJ5XCIgdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiBiaW5kOnZhbHVlPXtjb21taXRtZW50Rm9ybS5yZWN1cnJlbmNlSW50ZXJ2YWx9Lz48L2xhYmVsPjxsYWJlbD5OZXh0IGV4cGVjdGVkIGRhdGU8aW5wdXQgdHlwZT1cImRhdGVcIiBiaW5kOnZhbHVlPXtjb21taXRtZW50Rm9ybS5uZXh0RXhwZWN0ZWREYXRlfS8+PC9sYWJlbD48bGFiZWw+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGJpbmQ6Y2hlY2tlZD17Y29tbWl0bWVudEZvcm0uZmxleGlibGVTY2hlZHVsZX0vPiBGbGV4aWJsZSByZW1pbmRlcjwvbGFiZWw+PGxhYmVsPkFtb3VudCBiYXNpczxzZWxlY3QgYmluZDp2YWx1ZT17Y29tbWl0bWVudEZvcm0uYW1vdW50TW9kZX0+PG9wdGlvbiB2YWx1ZT1cIkZJWEVEXCI+Rml4ZWQgYW1vdW50PC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cIlVTRVJfRVNUSU1BVEVcIj5NeSBlc3RpbWF0ZTwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+eyNpZiBjb21taXRtZW50RXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e2NvbW1pdG1lbnRFcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PnNob3dDb21taXRtZW50Rm9ybT1mYWxzZX0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZUNvbW1pdG1lbnR9IGRpc2FibGVkPXtjb21taXRtZW50U2F2aW5nfT57Y29tbWl0bWVudFNhdmluZz8nU2F2aW5n4oCmJzpjb21taXRtZW50RWRpdGluZ0lkPT09bnVsbD8nQWRkIGNvbW1pdG1lbnQnOidTYXZlIGNoYW5nZXMnfTwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBjb21wbGV0aW9uQ29tbWl0bWVudH08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGxvYW4tZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+Y29tcGxldGlvbkNvbW1pdG1lbnQ9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+Q09NUExFVElPTjwvcD48aDI+TWFyayB7Y29tcGxldGlvbkNvbW1pdG1lbnQubGFiZWx9IGNvbXBsZXRlZDwvaDI+PGxhYmVsPkFjdHVhbCBhbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDFcIiBiaW5kOnZhbHVlPXtjb21wbGV0aW9uRm9ybS5hY3R1YWxBbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5Db21wbGV0ZWQgb248aW5wdXQgdHlwZT1cImRhdGVcIiBiaW5kOnZhbHVlPXtjb21wbGV0aW9uRm9ybS5jb21wbGV0ZWRBdH0vPjwvbGFiZWw+PGxhYmVsPk5leHQgZXhwZWN0ZWQgZGF0ZTxpbnB1dCB0eXBlPVwiZGF0ZVwiIGJpbmQ6dmFsdWU9e2NvbXBsZXRpb25Gb3JtLm5leHRFeHBlY3RlZERhdGV9Lz48L2xhYmVsPjxidXR0b24gY2xhc3M9XCJ0ZXh0LWxpbmtcIiBvbjpjbGljaz17KCk9PmFkZE1vbnRocyhOdW1iZXIoY29tcGxldGlvbkNvbW1pdG1lbnQucmVjdXJyZW5jZUludGVydmFsfHwxKSl9PkluIHtjb21wbGV0aW9uQ29tbWl0bWVudC5yZWN1cnJlbmNlSW50ZXJ2YWx8fDF9IHtTdHJpbmcoY29tcGxldGlvbkNvbW1pdG1lbnQucmVjdXJyZW5jZVVuaXR8fCdNT05USCcpLnRvTG93ZXJDYXNlKCl9KHMpPC9idXR0b24+PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5jb21wbGV0aW9uQ29tbWl0bWVudD1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlQ29tcGxldGlvbn0+U2F2ZSBjb21wbGV0aW9uPC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIHNob3dDcmVkaXRDYXJkRm9ybX08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGxvYW4tZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd0NyZWRpdENhcmRGb3JtPWZhbHNlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5DUkVESVQtQ0FSRCBCSUxMSU5HPC9wPjxoMj57Y3JlZGl0Q2FyZEVkaXRpbmdJZD09PW51bGw/J0FkZCBhIGNyZWRpdCBjYXJkJzonRWRpdCBjcmVkaXQgY2FyZCd9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPldlIGFkZCBvbmx5IGV4cGVuc2VzIGNhcHR1cmVkIGFnYWluc3QgdGhpcyBhY2NvdW50IGJldHdlZW4gc3RhdGVtZW50IGRhdGVzIHRvIHRoZSBiaWxsIGR1ZSBpbiB0aGF0IG1vbnRoLjwvcD48bGFiZWw+Q2FwdHVyZWQgYWNjb3VudDxzZWxlY3QgYmluZDp2YWx1ZT17Y3JlZGl0Q2FyZEZvcm0uYWNjb3VudFJlZmVyZW5jZUlkfT48b3B0aW9uIHZhbHVlPVwiXCIgZGlzYWJsZWQ+U2VsZWN0IHRoZSBjYXJkIGFjY291bnQ8L29wdGlvbj57I2VhY2ggZWRpdE9wdGlvbnMuYWNjb3VudHMgYXMgYWNjb3VudH08b3B0aW9uIHZhbHVlPXtTdHJpbmcoYWNjb3VudC5pZCl9PnthY2NvdW50Lm5hbWV9PC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPkNhcmQgbmFtZTxpbnB1dCBiaW5kOnZhbHVlPXtjcmVkaXRDYXJkRm9ybS5jYXJkTmFtZX0gcGxhY2Vob2xkZXI9XCJlLmcuIE1pbGxlbm5pYVwiIG1heGxlbmd0aD1cIjEyMFwiLz48L2xhYmVsPjxsYWJlbD5Jc3N1ZXIgLyB2ZW5kb3I8aW5wdXQgYmluZDp2YWx1ZT17Y3JlZGl0Q2FyZEZvcm0uaXNzdWVyTmFtZX0gcGxhY2Vob2xkZXI9XCJlLmcuIEhERkMgQmFua1wiIG1heGxlbmd0aD1cIjEyMFwiLz48L2xhYmVsPjxsYWJlbD5CaWxsIGdlbmVyYXRpb24gZGF5PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIxXCIgbWF4PVwiMjhcIiBiaW5kOnZhbHVlPXtjcmVkaXRDYXJkRm9ybS5zdGF0ZW1lbnREYXl9Lz48L2xhYmVsPjxsYWJlbD5QYXltZW50IGR1ZSBkYXk8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiBtYXg9XCIyOFwiIGJpbmQ6dmFsdWU9e2NyZWRpdENhcmRGb3JtLmR1ZURheX0vPjwvbGFiZWw+eyNpZiBjcmVkaXRDYXJkRXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e2NyZWRpdENhcmRFcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PnNob3dDcmVkaXRDYXJkRm9ybT1mYWxzZX0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZUNyZWRpdENhcmR9IGRpc2FibGVkPXtjcmVkaXRDYXJkU2F2aW5nfHxvcHRpb25zU3RhdHVzIT09J3JlYWR5J30+e2NyZWRpdENhcmRTYXZpbmc/J1NhdmluZ+KApic6Y3JlZGl0Q2FyZEVkaXRpbmdJZD09PW51bGw/J0FkZCBjcmVkaXQgY2FyZCc6J1NhdmUgY2hhbmdlcyd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIHNob3dJbmNvbWVGbG93fTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBpbmNvbWUtZmxvdy1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgaW5jb21lLWZsb3dcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PnNob3dJbmNvbWVGbG93PWZhbHNlfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5QUklWQVRFIFNBTEFSWSBDT05URVhUPC9wPjxoMj5XaGF0IHJhbmdlIGZlZWxzIGNvbWZvcnRhYmxlIHRvIHNoYXJlPzwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5BIHJhbmdlIGlzIGVub3VnaC4gVGhpcyBpcyBub3QgYSByZXF1ZXN0IGZvciBhIHBheXNsaXAsIGFuZCBpdCBuZXZlciBjaGFuZ2VzIHlvdXIgYmFsYW5jZS48L3A+PGRpdiBjbGFzcz1cInJhbmdlLW9wdGlvbnNcIj57I2VhY2ggWydVTkRFUl8yNTAwMCcsJ0ZST01fMjUwMDBfVE9fNTAwMDAnLCdGUk9NXzUwMDAwX1RPXzEwMDAwMCcsJ0ZST01fMTAwMDAwX1RPXzIwMDAwMCcsJ09WRVJfMjAwMDAwJ10gYXMgcmFuZ2V9PGJ1dHRvbiBjbGFzczphY3RpdmU9e3NhbGFyeUZvcm0uc2FsYXJ5UmFuZ2U9PT1yYW5nZSYmc2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PT09J1JBTkdFJ30gb246Y2xpY2s9eygpPT57c2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PSdSQU5HRSc7c2FsYXJ5Rm9ybS5zYWxhcnlSYW5nZT1yYW5nZTt9fT57aW5jb21lUmFuZ2VMYWJlbChyYW5nZSl9PC9idXR0b24+ey9lYWNofTwvZGl2PjxidXR0b24gY2xhc3M9XCJ0ZXh0LWxpbmsgaW5jb21lLWV4YWN0LXRvZ2dsZVwiIG9uOmNsaWNrPXsoKT0+c2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PXNhbGFyeUZvcm0uc2FsYXJ5VmlzaWJpbGl0eT09PSdFWEFDVCc/J1JBTkdFJzonRVhBQ1QnfT57c2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PT09J0VYQUNUJz8nVXNlIGEgcmFuZ2UgaW5zdGVhZCc6J0nigJltIGNvbWZvcnRhYmxlIHNoYXJpbmcgdGhlIGV4YWN0IGFtb3VudCd9PC9idXR0b24+eyNpZiBzYWxhcnlGb3JtLnNhbGFyeVZpc2liaWxpdHk9PT0nRVhBQ1QnfTxsYWJlbD5Nb250aGx5IHRha2UtaG9tZSBzYWxhcnk8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiBpbnB1dG1vZGU9XCJkZWNpbWFsXCIgYmluZDp2YWx1ZT17c2FsYXJ5Rm9ybS5leGFjdE1vbnRobHlTYWxhcnl9IHBsYWNlaG9sZGVyPVwiT3B0aW9uYWwgZXhhY3QgYW1vdW50XCIvPjwvbGFiZWw+ey9pZn08bGFiZWw+SG93IG9mdGVuIGRvZXMgaXQgYXJyaXZlPzxzZWxlY3QgYmluZDp2YWx1ZT17c2FsYXJ5Rm9ybS5zYWxhcnlGcmVxdWVuY3l9PnsjZWFjaCBbJ01PTlRITFknLCdUV0lDRV9NT05USExZJywnV0VFS0xZJywnSVJSRUdVTEFSJ10gYXMgZnJlcXVlbmN5fTxvcHRpb24gdmFsdWU9e2ZyZXF1ZW5jeX0+e2ZyZXF1ZW5jeS5yZXBsYWNlQWxsKCdfJywnICcpLnRvTG93ZXJDYXNlKCl9PC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+eyNpZiBpbmNvbWVFcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57aW5jb21lRXJyb3J9PC9wPnsvaWZ9PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT57c2FsYXJ5Rm9ybS5zYWxhcnlWaXNpYmlsaXR5PSdTS0lQUEVEJztzYXZlU2FsYXJ5KCk7fX0gZGlzYWJsZWQ9e2luY29tZVNhdmluZ30+U2tpcCBmb3Igbm93PC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZVNhbGFyeX0gZGlzYWJsZWQ9e2luY29tZVNhdmluZ30+e2luY29tZVNhdmluZz8nU2F2aW5n4oCmJzonU2F2ZSBzYWxhcnkgb3V0bG9vayd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIHNob3dMb2FuRm9ybX1cbiAgPGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGxvYW4tZm9ybS1iYWNrZHJvcFwiIHJvbGU9XCJwcmVzZW50YXRpb25cIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGxvYW4tZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIHRhYmluZGV4PVwiLTFcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PnNob3dMb2FuRm9ybT1mYWxzZX0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TE9BTiBERVRBSUxTPC9wPjxoMj57bG9hbkVkaXRpbmdJZD09bnVsbD8nQWRkIGEgbG9hbic6J0VkaXQgbG9hbid9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPllvdXIgbG9hbiBpbmZvcm1hdGlvbiBpcyBzdG9yZWQgc2VjdXJlbHkgaW4geW91ciBhY2NvdW50LjwvcD48bGFiZWw+TG9hbiBuYW1lPGlucHV0IGJpbmQ6dmFsdWU9e2xvYW5Gb3JtLmxvYW5OYW1lfSBwbGFjZWhvbGRlcj1cImUuZy4gSERGQyBIb21lIExvYW5cIiBtYXhsZW5ndGg9XCIyNTVcIiAvPjwvbGFiZWw+PGxhYmVsPkxvYW4gdHlwZTxzZWxlY3QgYmluZDp2YWx1ZT17bG9hbkZvcm0ubG9hblR5cGV9PnsjZWFjaCBbJ0hPTUUnLCdWRUhJQ0xFJywnUEVSU09OQUwnLCdFRFVDQVRJT04nLCdDUkVESVRfQ0FSRF9FTUknLCdPVEhFUiddIGFzIHR5cGV9PG9wdGlvbiB2YWx1ZT17dHlwZX0+e3R5cGUucmVwbGFjZUFsbCgnXycsJyAnKX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+T3JpZ2luYWwgbG9hbiBwcmluY2lwYWw8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIxXCIgYmluZDp2YWx1ZT17bG9hbkZvcm0ub3JpZ2luYWxQcmluY2lwYWx9IHBsYWNlaG9sZGVyPVwiZS5nLiA0MjAwMDAwXCIgLz48L2xhYmVsPjxsYWJlbD5Nb250aGx5IEVNSSBhbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIxXCIgYmluZDp2YWx1ZT17bG9hbkZvcm0ubW9udGhseUVtaUFtb3VudH0gcGxhY2Vob2xkZXI9XCJlLmcuIDM4NjAwXCIgLz48L2xhYmVsPjxsYWJlbD5Ub3RhbCB0ZW51cmUgaW4gbW9udGhzPGlucHV0IHR5cGU9XCJudW1iZXJcIiBpbnB1dG1vZGU9XCJudW1lcmljXCIgbWluPVwiMVwiIGJpbmQ6dmFsdWU9e2xvYW5Gb3JtLnRvdGFsVGVudXJlTW9udGhzfSBwbGFjZWhvbGRlcj1cImUuZy4gMjQwXCIgLz48L2xhYmVsPjxsYWJlbD5GaXJzdCBFTUkgZHVlIGRhdGU8aW5wdXQgdHlwZT1cImRhdGVcIiBiaW5kOnZhbHVlPXtsb2FuRm9ybS5maXJzdEVtaUR1ZURhdGV9IC8+PC9sYWJlbD48bGFiZWw+QmFuayAvIGxlbmRlcjxpbnB1dCBiaW5kOnZhbHVlPXtsb2FuRm9ybS5sZW5kZXJOYW1lfSBwbGFjZWhvbGRlcj1cImUuZy4gSERGQyBCYW5rXCIgbWF4bGVuZ3RoPVwiMjU1XCIgLz48L2xhYmVsPjxsYWJlbD5Ob3RlcyA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsXCI+T3B0aW9uYWw8L3NwYW4+PGlucHV0IGJpbmQ6dmFsdWU9e2xvYW5Gb3JtLm5vdGVzfSBwbGFjZWhvbGRlcj1cImUuZy4gUHJpbWFyeSByZXNpZGVuY2VcIiAvPjwvbGFiZWw+eyNpZiBsb2FuRXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e2xvYW5FcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PnNob3dMb2FuRm9ybT1mYWxzZX0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZUxvYW59IGRpc2FibGVkPXtsb2FuU2F2aW5nfT57bG9hblNhdmluZz8nU2F2aW5n4oCmJzpsb2FuRWRpdGluZ0lkPT1udWxsPydBZGQgbG9hbic6J1NhdmUgY2hhbmdlcyd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2Plxuey9pZn1cbnsjaWYgc2hvd011dHVhbEZ1bmRGb3JtfVxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgZnVuZC1mb3JtLWJhY2tkcm9wXCIgcm9sZT1cInByZXNlbnRhdGlvblwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd011dHVhbEZ1bmRGb3JtPWZhbHNlfT7DlzwvYnV0dG9uPlxuICAgIHsjaWYgZnVuZFNhdmVkfTxkaXYgY2xhc3M9XCJmdW5kLXN1Y2Nlc3NcIj48c3Bhbj7inJM8L3NwYW4+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPntmdW5kRm9ybS5oYXNTaXA9PT0nWUVTJz8nU0lQIFJFQURZJzonRlVORCBBRERFRCd9PC9wPjxoMj57ZnVuZEZvcm0uaGFzU2lwPT09J1lFUyc/J1lvdXIgU0lQIGlzIHNldCB1cCc6J1lvdXIgZnVuZCBpcyByZWFkeSd9PC9oMj48cD57ZnVuZEZvcm0uaGFzU2lwPT09J1lFUyc/YCR7bW9uZXkoZnVuZEZvcm0uc2lwQW1vdW50KX0gd2lsbCBiZSB0cmFja2VkIG1vbnRobHkgZm9yICR7c2VsZWN0ZWRTY2hlbWUuc2NoZW1lTmFtZX0uIFRoZSBmaXJzdCBvY2N1cnJlbmNlIHdpbGwgYmUgZHVlIGluICR7bW9udGhMYWJlbChmdW5kRm9ybS5zdGFydE1vbnRoKX0uYDpgJHtzZWxlY3RlZFNjaGVtZS5zY2hlbWVOYW1lfSBpcyByZWFkeSBmb3Igb2NjYXNpb25hbCBsdW1wIHN1bXMuIFlvdSBjYW4gc2V0IHVwIGEgU0lQIGxhdGVyIGZyb20gaXRzIGJlbGwgYnV0dG9uLmB9PC9wPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9eygpPT5zaG93TXV0dWFsRnVuZEZvcm09ZmFsc2V9PkRvbmU8L2J1dHRvbj48L2Rpdj5cbiAgICB7OmVsc2V9PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPk1VVFVBTCBGVU5EPC9wPjxoMj5BZGQgYSBtdXR1YWwgZnVuZDwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5TZWFyY2ggdGhlIG9mZmljaWFsIHNjaGVtZSBtYXN0ZXIuIEEgcmV0dXJuZWQgbmFtZSBpcyBvbmUgdmVyaWZpZWQgZnVuZCwgcGxhbiBhbmQgb3B0aW9uLjwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJmdW5kLXNlY3Rpb25cIj48c3BhbiBjbGFzcz1cImZ1bmQtc2VjdGlvbi1sYWJlbFwiPjEgwrcgRlVORDwvc3Bhbj48bGFiZWwgY2xhc3M9XCJzY2hlbWUtcGlja2VyXCI+U2VhcmNoIGFuZCBzZWxlY3Qgc2NoZW1lPGlucHV0IHZhbHVlPXtzY2hlbWVRdWVyeX0gb246Zm9jdXM9eygpPT5zaG93U2NoZW1lTWVudT10cnVlfSBvbjppbnB1dD17ZT0+c2VhcmNoU2NoZW1lcyhlLmN1cnJlbnRUYXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIlR5cGUgYXQgbGVhc3QgMiBjaGFyYWN0ZXJzXCIgYXV0b2NvbXBsZXRlPVwib2ZmXCIgLz57I2lmIHNob3dTY2hlbWVNZW51fTxkaXYgY2xhc3M9XCJzY2hlbWUtbWVudVwiPnsjaWYgc2NoZW1lU2VhcmNoU3RhdHVzPT09J2xvYWRpbmcnfTxwPlNlYXJjaGluZyBzY2hlbWVz4oCmPC9wPns6ZWxzZSBpZiBzY2hlbWVRdWVyeS50cmltKCkubGVuZ3RoPDJ9PHA+VHlwZSBhdCBsZWFzdCAyIGNoYXJhY3RlcnMgdG8gc2VhcmNoLjwvcD57OmVsc2V9eyNlYWNoIHNjaGVtZVJlc3VsdHMgYXMgc2NoZW1lfTxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uOm1vdXNlZG93bnxwcmV2ZW50RGVmYXVsdD17KCk9PnNlbGVjdFNjaGVtZShzY2hlbWUpfT48c3Ryb25nPntzY2hlbWUuc2NoZW1lTmFtZX08L3N0cm9uZz48c21hbGw+U2NoZW1lIGNvZGUge3NjaGVtZS5zY2hlbWVDb2RlfSDCtyB7c2NoZW1lLmxhdGVzdE5hdj09bnVsbD8nTGF0ZXN0IE5BViB1bmF2YWlsYWJsZSc6YExhdGVzdCBOQVYgJHttb25leURlY2ltYWwoc2NoZW1lLmxhdGVzdE5hdil9YH08L3NtYWxsPjwvYnV0dG9uPns6ZWxzZX08cD5ObyBtYXRjaGluZyBzY2hlbWUgZm91bmQuPC9wPnsvZWFjaH17L2lmfTwvZGl2PnsvaWZ9PC9sYWJlbD57I2lmIHNlbGVjdGVkU2NoZW1lfTxkaXYgY2xhc3M9XCJzY2hlbWUtdmFsaWRhdGVkXCI+PHNwYW4+4pyTPC9zcGFuPjxkaXY+PHN0cm9uZz5WZXJpZmllZCBieSBzY2hlbWUgbWFzdGVyPC9zdHJvbmc+PHNtYWxsPkNvZGUge3NlbGVjdGVkU2NoZW1lLnNjaGVtZUNvZGV9IMK3IHtzZWxlY3RlZFNjaGVtZS5sYXRlc3ROYXY9PW51bGw/J0xhdGVzdCBOQVYgdW5hdmFpbGFibGUnOmBMYXRlc3QgTkFWICR7bW9uZXlEZWNpbWFsKHNlbGVjdGVkU2NoZW1lLmxhdGVzdE5hdil9YH08L3NtYWxsPjwvZGl2PjwvZGl2PnsvaWZ9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwiZnVuZC1zZWN0aW9uXCI+PHNwYW4gY2xhc3M9XCJmdW5kLXNlY3Rpb24tbGFiZWxcIj4yIMK3IFNJUCA8ZW0+T1BUSU9OQUw8L2VtPjwvc3Bhbj48ZmllbGRzZXQ+PGxlZ2VuZD5EbyB5b3UgaGF2ZSBhbiBhY3R1YWwgU0lQIGZvciB0aGlzIGZ1bmQ/PC9sZWdlbmQ+PGxhYmVsIGNsYXNzPVwiY2hvaWNlXCI+PGlucHV0IHR5cGU9XCJyYWRpb1wiIGJpbmQ6Z3JvdXA9e2Z1bmRGb3JtLmhhc1NpcH0gdmFsdWU9XCJZRVNcIiAvPiBZZXM8L2xhYmVsPjxsYWJlbCBjbGFzcz1cImNob2ljZVwiPjxpbnB1dCB0eXBlPVwicmFkaW9cIiBiaW5kOmdyb3VwPXtmdW5kRm9ybS5oYXNTaXB9IHZhbHVlPVwiTk9cIiAvPiBObzwvbGFiZWw+PC9maWVsZHNldD57I2lmIGZ1bmRGb3JtLmhhc1NpcD09PSdZRVMnfTxsYWJlbD5Nb250aGx5IFNJUCBhbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIxXCIgYmluZDp2YWx1ZT17ZnVuZEZvcm0uc2lwQW1vdW50fSAvPjwvbGFiZWw+PGRpdiBjbGFzcz1cImZ1bmQtZmllbGQtcGFpclwiPjxsYWJlbD5TSVAgZGF0ZTxzZWxlY3QgYmluZDp2YWx1ZT17ZnVuZEZvcm0uc2lwRGF0ZX0+eyNlYWNoIEFycmF5KDI4KSBhcyBfLGluZGV4fTxvcHRpb24gdmFsdWU9e2luZGV4KzF9PntpbmRleCsxfXtpbmRleD09PTA/J3N0JzppbmRleD09PTE/J25kJzppbmRleD09PTI/J3JkJzondGgnfSBvZiBldmVyeSBtb250aDwvb3B0aW9uPnsvZWFjaH08L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5TdGFydCBtb250aDxpbnB1dCB0eXBlPVwibW9udGhcIiBiaW5kOnZhbHVlPXtmdW5kRm9ybS5zdGFydE1vbnRofSAvPjwvbGFiZWw+PC9kaXY+ey9pZn08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmdW5kLXNlY3Rpb25cIj48c3BhbiBjbGFzcz1cImZ1bmQtc2VjdGlvbi1sYWJlbFwiPjMgwrcgRVhJU1RJTkcgSE9MRElORyA8ZW0+T1BUSU9OQUw8L2VtPjwvc3Bhbj48ZmllbGRzZXQ+PGxlZ2VuZD5EbyB5b3UgYWxyZWFkeSBob2xkIHRoaXMgZnVuZD88L2xlZ2VuZD48bGFiZWwgY2xhc3M9XCJjaG9pY2VcIj48aW5wdXQgdHlwZT1cInJhZGlvXCIgYmluZDpncm91cD17ZnVuZEZvcm0uaGFzSG9sZGluZ30gdmFsdWU9XCJOT1wiIC8+IE5vPC9sYWJlbD48bGFiZWwgY2xhc3M9XCJjaG9pY2VcIj48aW5wdXQgdHlwZT1cInJhZGlvXCIgYmluZDpncm91cD17ZnVuZEZvcm0uaGFzSG9sZGluZ30gdmFsdWU9XCJZRVNcIiAvPiBZZXM8L2xhYmVsPjwvZmllbGRzZXQ+eyNpZiBmdW5kRm9ybS5oYXNIb2xkaW5nPT09J1lFUyd9PGRpdiBjbGFzcz1cImZ1bmQtZmllbGQtcGFpclwiPjxsYWJlbD5DdXJyZW50IHVuaXRzPGlucHV0IHR5cGU9XCJudW1iZXJcIiBpbnB1dG1vZGU9XCJkZWNpbWFsXCIgbWluPVwiMC4wMDFcIiBzdGVwPVwiMC4wMDFcIiBiaW5kOnZhbHVlPXtmdW5kRm9ybS5jdXJyZW50VW5pdHN9IC8+PC9sYWJlbD48bGFiZWw+VG90YWwgYW1vdW50IGludmVzdGVkPGlucHV0IHR5cGU9XCJudW1iZXJcIiBpbnB1dG1vZGU9XCJkZWNpbWFsXCIgbWluPVwiMC4wMVwiIGJpbmQ6dmFsdWU9e2Z1bmRGb3JtLnRvdGFsSW52ZXN0ZWR9IC8+PC9sYWJlbD48L2Rpdj48cCBjbGFzcz1cImZ1bmQtZGlzY2xhaW1lclwiPkF2ZXJhZ2UgcHVyY2hhc2UgY29zdCBpcyBjYWxjdWxhdGVkIGJ5IHRoZSBiYWNrZW5kIGFmdGVyIHRoZSBvcGVuaW5nIGJhbGFuY2UgaXMgcmVjb3JkZWQuPC9wPnsvaWZ9PC9kaXY+XG4gICAgICB7I2lmIGZ1bmRFcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57ZnVuZEVycm9yfTwvcD57L2lmfTxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+c2hvd011dHVhbEZ1bmRGb3JtPWZhbHNlfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlTXV0dWFsRnVuZH0gZGlzYWJsZWQ9e2Z1bmRTYXZpbmd9PntmdW5kU2F2aW5nPydDcmVhdGluZ+KApic6J0FkZCBtdXR1YWwgZnVuZCd9PC9idXR0b24+PC9kaXY+XG4gICAgey9pZn08L3NlY3Rpb24+PC9kaXY+XG57L2lmfVxueyNpZiBzaG93U3RvY2tGb3JtfVxuICA8ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgZnVuZC1mb3JtLWJhY2tkcm9wXCIgcm9sZT1cInByZXNlbnRhdGlvblwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd1N0b2NrRm9ybT1mYWxzZX0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+U1RPQ0sgSE9MRElORzwvcD48aDI+QWRkIGEgc3RvY2s8L2gyPjxwIGNsYXNzPVwibW9kdWxlLXJlYXNzdXJhbmNlXCI+U2VhcmNoIG1hcmtldCBzeW1ib2xzLCB0aGVuIHJlY29yZCB0aGUgc2hhcmVzIGFuZCB0b3RhbCBhbW91bnQgeW91IGFscmVhZHkgaW52ZXN0ZWQuIEVkaXRpbmcgYW5kIHNlbGxpbmcgd2lsbCBmb2xsb3cgaW4gYSBsYXRlciB1cGRhdGUuPC9wPjxkaXYgY2xhc3M9XCJmdW5kLXNlY3Rpb25cIj48c3BhbiBjbGFzcz1cImZ1bmQtc2VjdGlvbi1sYWJlbFwiPjEgwrcgU1RPQ0s8L3NwYW4+PGxhYmVsIGNsYXNzPVwic2NoZW1lLXBpY2tlclwiPlNlYXJjaCBhbmQgc2VsZWN0IHN0b2NrPGlucHV0IHZhbHVlPXtzdG9ja1F1ZXJ5fSBvbjppbnB1dD17ZT0+ZmluZFN0b2NrcyhlLmN1cnJlbnRUYXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIlR5cGUgYXQgbGVhc3QgMiBjaGFyYWN0ZXJzXCIgYXV0b2NvbXBsZXRlPVwib2ZmXCIgLz57I2lmIHN0b2NrUXVlcnkudHJpbSgpLmxlbmd0aD49MiYmIXNlbGVjdGVkU3RvY2t9PGRpdiBjbGFzcz1cInNjaGVtZS1tZW51XCI+eyNpZiBzdG9ja1NlYXJjaFN0YXR1cz09PSdsb2FkaW5nJ308cD5TZWFyY2hpbmcgc3RvY2sgc3ltYm9sc+KApjwvcD57OmVsc2UgaWYgc3RvY2tTZWFyY2hTdGF0dXM9PT0nZXJyb3InfTxwPkNvdWxkIG5vdCBzZWFyY2ggc3RvY2tzLjwvcD57OmVsc2V9eyNlYWNoIHN0b2NrUmVzdWx0cyBhcyBzdG9ja308YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbjptb3VzZWRvd258cHJldmVudERlZmF1bHQ9eygpPT5zZWxlY3RTdG9jayhzdG9jayl9PjxzdHJvbmc+e3N0b2NrLm5hbWV8fHN0b2NrLnN5bWJvbH08L3N0cm9uZz48c21hbGw+e3N0b2NrLnN5bWJvbH17c3RvY2suZXhjaGFuZ2U/YCDCtyAke3N0b2NrLmV4Y2hhbmdlfWA6Jyd9IMK3IHtzdG9jay5sYXRlc3RQcmljZT09bnVsbD8nTGF0ZXN0IHByaWNlIHVuYXZhaWxhYmxlJzpgTGF0ZXN0IHByaWNlICR7bW9uZXlEZWNpbWFsKHN0b2NrLmxhdGVzdFByaWNlKX1gfTwvc21hbGw+PC9idXR0b24+ezplbHNlfTxwPk5vIG1hdGNoaW5nIGxpc3RlZCBzdG9jayBmb3VuZC48L3A+ey9lYWNofXsvaWZ9PC9kaXY+ey9pZn08L2xhYmVsPnsjaWYgc2VsZWN0ZWRTdG9ja308ZGl2IGNsYXNzPVwic2NoZW1lLXZhbGlkYXRlZFwiPjxzcGFuPuKckzwvc3Bhbj48ZGl2PjxzdHJvbmc+VmVyaWZpZWQgbWFya2V0IHN5bWJvbDwvc3Ryb25nPjxzbWFsbD57c2VsZWN0ZWRTdG9jay5zeW1ib2x9e3NlbGVjdGVkU3RvY2suZXhjaGFuZ2U/YCDCtyAke3NlbGVjdGVkU3RvY2suZXhjaGFuZ2V9YDonJ30gwrcge3NlbGVjdGVkU3RvY2subGF0ZXN0UHJpY2U9PW51bGw/J0xhdGVzdCBwcmljZSB1bmF2YWlsYWJsZSc6YExhdGVzdCBwcmljZSAke21vbmV5RGVjaW1hbChzZWxlY3RlZFN0b2NrLmxhdGVzdFByaWNlKX1gfTwvc21hbGw+PC9kaXY+PC9kaXY+ey9pZn08L2Rpdj48ZGl2IGNsYXNzPVwiZnVuZC1zZWN0aW9uXCI+PHNwYW4gY2xhc3M9XCJmdW5kLXNlY3Rpb24tbGFiZWxcIj4yIMK3IEhPTERJTkc8L3NwYW4+PGRpdiBjbGFzcz1cImZ1bmQtZmllbGQtcGFpclwiPjxsYWJlbD5TaGFyZXMgaGVsZDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjAuMDAxXCIgc3RlcD1cIjAuMDAxXCIgYmluZDp2YWx1ZT17c3RvY2tGb3JtLnF1YW50aXR5fSAvPjwvbGFiZWw+PGxhYmVsPlRvdGFsIGFtb3VudCBpbnZlc3RlZDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgaW5wdXRtb2RlPVwiZGVjaW1hbFwiIG1pbj1cIjAuMDFcIiBiaW5kOnZhbHVlPXtzdG9ja0Zvcm0udG90YWxJbnZlc3RlZH0gLz48L2xhYmVsPjwvZGl2PjwvZGl2PnsjaWYgc3RvY2tFcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57c3RvY2tFcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PnNob3dTdG9ja0Zvcm09ZmFsc2V9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9e3NhdmVTdG9ja30gZGlzYWJsZWQ9e3N0b2NrU2F2aW5nfT57c3RvY2tTYXZpbmc/J0FkZGluZ+KApic6J0FkZCBzdG9jayd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2Plxuey9pZn1cbnsjaWYgZnVuZFNpcFRhcmdldH08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3AgZnVuZC1mb3JtLWJhY2tkcm9wXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCBmdW5kLWZvcm1cIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIj48YnV0dG9uIGNsYXNzPVwiY2xvc2VcIiBvbjpjbGljaz17KCk9PmZ1bmRTaXBUYXJnZXQ9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TU9OVEhMWSBTSVA8L3A+PGgyPlNldCB1cCBTSVAgZm9yIHtmdW5kU2lwVGFyZ2V0LnNjaGVtZU5hbWV9PC9oMj48cCBjbGFzcz1cIm1vZHVsZS1yZWFzc3VyYW5jZVwiPlRoaXMgY3JlYXRlcyBhIG1vbnRobHkgcGxhbi4gT2NjYXNpb25hbCBsdW1wIHN1bXMgcmVtYWluIHNlcGFyYXRlLjwvcD48bGFiZWw+TW9udGhseSBhbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDFcIiBiaW5kOnZhbHVlPXtmdW5kU2lwRm9ybS5hbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5TSVAgZGF0ZTxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIG1heD1cIjI4XCIgYmluZDp2YWx1ZT17ZnVuZFNpcEZvcm0uZGF5fS8+PC9sYWJlbD48bGFiZWw+U3RhcnQgbW9udGg8aW5wdXQgdHlwZT1cIm1vbnRoXCIgYmluZDp2YWx1ZT17ZnVuZFNpcEZvcm0uc3RhcnRNb250aH0vPjwvbGFiZWw+eyNpZiBmdW5kRXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e2Z1bmRFcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PmZ1bmRTaXBUYXJnZXQ9bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZUZ1bmRTaXBQbGFufSBkaXNhYmxlZD17ZnVuZFNpcFNhdmluZ30+e2Z1bmRTaXBTYXZpbmc/J1NhdmluZ+KApic6J1NhdmUgU0lQJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgc3RvY2tQbGFuVGFyZ2V0fTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c3RvY2tQbGFuVGFyZ2V0PW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPk1PTlRITFkgRVRGIFBMQU48L3A+PGgyPlBsYW4ge3N0b2NrUGxhblRhcmdldC5uYW1lfTwvaDI+PGxhYmVsPk1vbnRobHkgYW1vdW50PGlucHV0IHR5cGU9XCJudW1iZXJcIiBtaW49XCIwLjAxXCIgYmluZDp2YWx1ZT17c3RvY2tQbGFuRm9ybS5hbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5JbnZlc3RtZW50IGRheTxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMVwiIG1heD1cIjI4XCIgYmluZDp2YWx1ZT17c3RvY2tQbGFuRm9ybS5kYXl9Lz48L2xhYmVsPjxsYWJlbD5TdGFydCBtb250aDxpbnB1dCB0eXBlPVwibW9udGhcIiBiaW5kOnZhbHVlPXtzdG9ja1BsYW5Gb3JtLnN0YXJ0TW9udGh9Lz48L2xhYmVsPjxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+c3RvY2tQbGFuVGFyZ2V0PW51bGx9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9e3NhdmVTdG9ja1BsYW59IGRpc2FibGVkPXtzdG9ja1BsYW5TYXZpbmd9PntzdG9ja1BsYW5TYXZpbmc/J1NhdmluZ+KApic6J1NhdmUgbW9udGhseSBwbGFuJ308L2J1dHRvbj48L2Rpdj48L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgc3RvY2tQbGFuQ29uZmlybWF0aW9uVGFyZ2V0fTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c3RvY2tQbGFuQ29uZmlybWF0aW9uVGFyZ2V0PW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkNPTkZJUk0gRVRGIElOVkVTVE1FTlQ8L3A+PGgyPldhcyB0aGlzIGludmVzdG1lbnQgcHJvY2Vzc2VkPzwvaDI+PGxhYmVsPkFtb3VudCBpbnZlc3RlZDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMVwiIGJpbmQ6dmFsdWU9e3N0b2NrUGxhbkNvbmZpcm1hdGlvbi5hbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5FeGVjdXRlZCBtYXJrZXQgcHJpY2U8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDAwMVwiIGJpbmQ6dmFsdWU9e3N0b2NrUGxhbkNvbmZpcm1hdGlvbi5wcmljZX0vPjwvbGFiZWw+PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5zdG9ja1BsYW5Db25maXJtYXRpb25UYXJnZXQ9bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17Y29uZmlybVN0b2NrUGxhbn0+Q29uZmlybSBpbnZlc3RtZW50PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIHN0b2NrRGV0YWlsfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZGV0YWlsXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zdG9ja0RldGFpbD1udWxsfT7DlzwvYnV0dG9uPnsjaWYgc3RvY2tEZXRhaWxTdGF0dXM9PT0nbG9hZGluZyd9PGgyPkxvYWRpbmcgc3RvY2sgZGV0YWlsc+KApjwvaDI+ezplbHNlIGlmIHN0b2NrRGV0YWlsU3RhdHVzPT09J2Vycm9yJ308aDI+Q291bGRu4oCZdCBsb2FkIHRoaXMgc3RvY2s8L2gyPns6ZWxzZX08cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+U1RPQ0sgREVUQUlMUzwvcD48aDI+e3N0b2NrRGV0YWlsLnN0b2NrLm5hbWV9PC9oMj48ZGl2IGNsYXNzPVwiZGV0YWlsLWdyaWRcIj48ZGl2PjxzcGFuPkludmVzdGVkPC9zcGFuPjxiPnttb25leShzdG9ja0RldGFpbC5zdG9jay5pbnZlc3RlZCl9PC9iPjwvZGl2PjxkaXY+PHNwYW4+U2hhcmVzPC9zcGFuPjxiPntOdW1iZXIoc3RvY2tEZXRhaWwuc3RvY2sucXVhbnRpdHkpLnRvRml4ZWQoMyl9PC9iPjwvZGl2PjwvZGl2PjxzZWN0aW9uIGNsYXNzPVwiaW52ZXN0bWVudC1oaXN0b3J5XCI+PGgzPkludmVzdG1lbnQgaGlzdG9yeTwvaDM+eyNlYWNoIHN0b2NrRGV0YWlsLmhpc3RvcnkgYXMgZW50cnl9PGRpdiBjbGFzcz1cImludmVzdG1lbnQtaGlzdG9yeS1yb3dcIj48c3Bhbj57ZGF0ZUxhYmVsKGVudHJ5LnRyYW5zYWN0aW9uRGF0ZSl9PC9zcGFuPjxzdHJvbmc+e2VudHJ5LmtpbmQ9PT0nU0lQJz8nTW9udGhseSBFVEYgcHVyY2hhc2UnOidPcGVuaW5nIGhvbGRpbmcnfTwvc3Ryb25nPjxzcGFuIGNsYXNzPVwiaGlzdG9yeS1hbW91bnRcIj48Yj57bW9uZXkoZW50cnkuYW1vdW50KX08L2I+PC9zcGFuPjxzbWFsbD5QcmljZSB7bW9uZXlEZWNpbWFsKGVudHJ5LmV4ZWN1dGlvblByaWNlKX0gwrcge051bWJlcihlbnRyeS51bml0cykudG9GaXhlZCgzKX0gc2hhcmVzPC9zbWFsbD48L2Rpdj57L2VhY2h9PC9zZWN0aW9uPnsvaWZ9PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG48IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeV9jbGlja19ldmVudHNfaGF2ZV9rZXlfZXZlbnRzIC0tPlxueyNpZiBmdW5kRGV0YWlsfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZGV0YWlsXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5mdW5kRGV0YWlsPW51bGx9PsOXPC9idXR0b24+eyNpZiBmdW5kRGV0YWlsU3RhdHVzPT09J2xvYWRpbmcnfTxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5GVU5EIERFVEFJTFM8L3A+PGgyPkxvYWRpbmcgZnVuZCBkZXRhaWxz4oCmPC9oMj57OmVsc2UgaWYgZnVuZERldGFpbFN0YXR1cz09PSdlcnJvcid9PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkZVTkQgREVUQUlMUzwvcD48aDI+Q291bGRu4oCZdCBsb2FkIHRoaXMgZnVuZDwvaDI+PHA+e2Z1bmREZXRhaWxFcnJvcn08L3A+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17KCk9Pm9wZW5GdW5kRGV0YWlsKGZ1bmREZXRhaWwuaWQpfT5UcnkgYWdhaW48L2J1dHRvbj57OmVsc2V9e0Bjb25zdCBkZXRhaWxTdW1tYXJ5PWZ1bmRTdW1tYXJ5KGZ1bmREZXRhaWwuaWQpfTxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5GVU5EIERFVEFJTFM8L3A+PGgyPntmdW5kRGV0YWlsLnNjaGVtZU5hbWV9PC9oMj48ZGl2IGNsYXNzPVwiZGV0YWlsLXZhbHVlXCI+PHNwYW4+Q3VycmVudCB2YWx1ZTwvc3Bhbj48c3Ryb25nPnttb25leShmdW5kRGV0YWlsLmN1cnJlbnRWYWx1ZSl9PC9zdHJvbmc+PC9kaXY+PGRpdiBjbGFzczpwb3NpdGl2ZT17TnVtYmVyKGZ1bmREZXRhaWwucHJvZml0T3JMb3NzKT49MH0gY2xhc3M6bmVnYXRpdmU9e051bWJlcihmdW5kRGV0YWlsLnByb2ZpdE9yTG9zcyk8MH0gY2xhc3M9XCJkZXRhaWwtcG5sXCI+PHNwYW4+VG90YWwgUCZhbXA7TDwvc3Bhbj48c3Ryb25nPntOdW1iZXIoZnVuZERldGFpbC5wcm9maXRPckxvc3MpPj0wPycrJzonJ317bW9uZXkoZnVuZERldGFpbC5wcm9maXRPckxvc3MpfTwvc3Ryb25nPjxiPntOdW1iZXIoZnVuZERldGFpbC5wcm9maXRPckxvc3NQZXJjZW50KT49MD8nKyc6Jyd9e051bWJlcihmdW5kRGV0YWlsLnByb2ZpdE9yTG9zc1BlcmNlbnQpLnRvRml4ZWQoMil9JTwvYj48L2Rpdj48ZGl2IGNsYXNzPVwiZGV0YWlsLWdyaWRcIj48ZGl2PjxzcGFuPkludmVzdGVkPC9zcGFuPjxiPnttb25leShmdW5kRGV0YWlsLmludmVzdGVkKX08L2I+PC9kaXY+PGRpdj48c3Bhbj5Vbml0czwvc3Bhbj48Yj57TnVtYmVyKGZ1bmREZXRhaWwudW5pdHMpLnRvRml4ZWQoMyl9PC9iPjwvZGl2PjxkaXY+PHNwYW4+QXZlcmFnZSBOQVY8L3NwYW4+PGI+e21vbmV5RGVjaW1hbChmdW5kRGV0YWlsLmF2ZXJhZ2VOYXYpfTwvYj48L2Rpdj48ZGl2PjxzcGFuPkN1cnJlbnQgTkFWPC9zcGFuPjxiPnttb25leURlY2ltYWwoZnVuZERldGFpbC5jdXJyZW50TmF2KX08L2I+PC9kaXY+PC9kaXY+eyNpZiBmdW5kRGV0YWlsLmhpc3Rvcnk/Lmxlbmd0aH08c2VjdGlvbiBjbGFzcz1cImludmVzdG1lbnQtaGlzdG9yeVwiPjxoMz5JbnZlc3RtZW50IGhpc3Rvcnk8L2gzPnsjZWFjaCBmdW5kRGV0YWlsLmhpc3RvcnkgYXMgZW50cnl9PGRpdiBjbGFzcz1cImludmVzdG1lbnQtaGlzdG9yeS1yb3dcIj48c3Bhbj57ZGF0ZUxhYmVsKGVudHJ5LnRyYW5zYWN0aW9uRGF0ZSl9PC9zcGFuPjxzdHJvbmc+e2VudHJ5LmtpbmQ9PT1cIlNJUFwiP1wiU0lQXCI6ZW50cnkua2luZD09PVwiTFVNUFNVTVwiP1wiTHVtcCBzdW1cIjpcIk9wZW5pbmcgaG9sZGluZ1wifTwvc3Ryb25nPjxzcGFuIGNsYXNzPVwiaGlzdG9yeS1hbW91bnRcIj48Yj57bW9uZXkoZW50cnkuYW1vdW50KX08L2I+PGJ1dHRvbiBjbGFzcz1cImhpc3RvcnktZWRpdFwiIG9uOmNsaWNrPXsoKT0+b3Blbkhpc3RvcnlFZGl0KGRldGFpbFN1bW1hcnksZW50cnkpfSBhcmlhLWxhYmVsPVwiRWRpdCB0aGlzIGludmVzdG1lbnRcIiB0aXRsZT1cIkVkaXQgdGhpcyBpbnZlc3RtZW50XCI+8J+UpzwvYnV0dG9uPjwvc3Bhbj48c21hbGw+TkFWIHttb25leURlY2ltYWwoZW50cnkubmF2KX0gwrcge051bWJlcihlbnRyeS51bml0cykudG9GaXhlZCgzKX0gdW5pdHM8L3NtYWxsPjwvZGl2PnsvZWFjaH08L3NlY3Rpb24+ey9pZn08cCBjbGFzcz1cImZ1bmQtZGlzY2xhaW1lclwiPkF2ZXJhZ2UgTkFWIGlzIGJhc2VkIG9uIGNvbmZpcm1lZCBpbnZlc3RtZW50cy4gQ3VycmVudCBOQVYgaXMgdGhlIGxhdGVzdCBhdmFpbGFibGUgTUZBUEkgdmFsdWUuPC9wPnsvaWZ9PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIGx1bXBTdW1GdW5kfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+bHVtcFN1bUZ1bmQ9bnVsbH0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TFVNUC1TVU0gSU5WRVNUTUVOVDwvcD48aDI+QWRkIHRvIHtsdW1wU3VtRnVuZC5zY2hlbWVOYW1lfTwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5UaGlzIGFkZHMgY29uZmlybWVkIHVuaXRzIHRvIHRoaXMgZnVuZCBvbmx5LiBJdCBkb2VzIG5vdCBjaGFuZ2UgdGhlIG1vbnRobHkgU0lQIHBsYW4uPC9wPjxsYWJlbD5BbW91bnQgaW52ZXN0ZWQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDFcIiBzdGVwPVwiMC4wMVwiIGJpbmQ6dmFsdWU9e2x1bXBTdW1Gb3JtLmFtb3VudH0vPjwvbGFiZWw+PGxhYmVsPlRyYW5zYWN0aW9uIGRhdGU8aW5wdXQgdHlwZT1cImRhdGVcIiBiaW5kOnZhbHVlPXtsdW1wU3VtRm9ybS50cmFuc2FjdGlvbkRhdGV9Lz48L2xhYmVsPjxsYWJlbD5OQVY8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDAwMVwiIHN0ZXA9XCIwLjAwMDFcIiBiaW5kOnZhbHVlPXtsdW1wU3VtRm9ybS5uYXZ9IHBsYWNlaG9sZGVyPVwiZS5nLiA4Ny4yNVwiLz48L2xhYmVsPnsjaWYgbHVtcFN1bUVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntsdW1wU3VtRXJyb3J9PC9wPnsvaWZ9PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5sdW1wU3VtRnVuZD1udWxsfT5DYW5jZWw8L2J1dHRvbj48YnV0dG9uIGNsYXNzPVwicHJpbWFyeVwiIG9uOmNsaWNrPXtzYXZlTHVtcFN1bX0gZGlzYWJsZWQ9e2x1bXBTdW1TYXZpbmd9PntsdW1wU3VtU2F2aW5nPydBZGRpbmfigKYnOidBZGQgbHVtcCBzdW0nfTwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBjb25maXJtaW5nU2lwfTxkaXYgY2xhc3M9XCJtb2RhbC1iYWNrZHJvcCBmdW5kLWZvcm0tYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsIGZ1bmQtZm9ybVwiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+Y29uZmlybWluZ1NpcD1udWxsfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5DT05GSVJNIFNJUCBJTlZFU1RNRU5UPC9wPjxoMj5XYXMgdGhpcyBTSVAgcHJvY2Vzc2VkPzwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5Vbml0cyB3aWxsIGJlIGVzdGltYXRlZCBmcm9tIHRoZSBOQVYgYW5kIG1hcmtlZCBhcyBhbiBlc3RpbWF0ZSB1bnRpbCB5b3UgY29ycmVjdCB0aGVtIGZyb20geW91ciBzdGF0ZW1lbnQuPC9wPjxkaXYgY2xhc3M9XCJzb3VyY2Utbm90ZVwiPjxzdHJvbmc+e2NvbmZpcm1pbmdTaXAuZnVuZC5zY2hlbWVOYW1lfTwvc3Ryb25nPjxzcGFuPntjb25maXJtaW5nU2lwLm9jY3VycmVuY2Uuc2NoZWR1bGVkTW9udGh9IG9jY3VycmVuY2U8L3NwYW4+PC9kaXY+PGxhYmVsPkFtb3VudCBpbnZlc3RlZDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMVwiIHN0ZXA9XCIwLjAxXCIgYmluZDp2YWx1ZT17c2lwQ29uZmlybUZvcm0uYW1vdW50fS8+PC9sYWJlbD48bGFiZWw+VHJhbnNhY3Rpb24gZGF0ZTxpbnB1dCB0eXBlPVwiZGF0ZVwiIGJpbmQ6dmFsdWU9e3NpcENvbmZpcm1Gb3JtLnRyYW5zYWN0aW9uRGF0ZX0vPjwvbGFiZWw+PGxhYmVsPk5BViA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsXCI+RXN0aW1hdGVkPC9zcGFuPjxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMDAxXCIgc3RlcD1cIjAuMDAwMVwiIGJpbmQ6dmFsdWU9e3NpcENvbmZpcm1Gb3JtLm5hdn0gcGxhY2Vob2xkZXI9XCJlLmcuIDg3LjI1XCIvPjwvbGFiZWw+eyNpZiBzaXBDb25maXJtRXJyb3J9PHAgY2xhc3M9XCJmb3JtLWVycm9yXCI+e3NpcENvbmZpcm1FcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PmNvbmZpcm1pbmdTaXA9bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZVNpcENvbmZpcm1hdGlvbn0gZGlzYWJsZWQ9e3NpcENvbmZpcm1TYXZpbmd9PntzaXBDb25maXJtU2F2aW5nPydDb25maXJtaW5n4oCmJzonQ29uZmlybSBlc3RpbWF0ZSd9PC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIGVkaXRpbmdGdW5kVHJhbnNhY3Rpb259PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wIGZ1bmQtZm9ybS1iYWNrZHJvcFwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWwgZnVuZC1mb3JtXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5lZGl0aW5nRnVuZFRyYW5zYWN0aW9uPW51bGx9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkVESVQgSU5WRVNUTUVOVDwvcD48aDI+e2VkaXRpbmdGdW5kVHJhbnNhY3Rpb24uZW50cnkua2luZD09PVwiU0lQXCI/XCJFZGl0IFNJUCBhbGxvY2F0aW9uXCI6ZWRpdGluZ0Z1bmRUcmFuc2FjdGlvbi5lbnRyeS5raW5kPT09XCJMVU1QU1VNXCI/XCJFZGl0IGx1bXAgc3VtXCI6XCJFZGl0IG9wZW5pbmcgaG9sZGluZ1wifTwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5VcGRhdGUgdGhpcyByZWNvcmRlZCBpbnZlc3RtZW50LiBZb3VyIGZ1bmQgdG90YWxzIHdpbGwgcmVjYWxjdWxhdGUgYXV0b21hdGljYWxseS48L3A+PGxhYmVsPkFtb3VudCBpbnZlc3RlZDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbWluPVwiMC4wMVwiIHN0ZXA9XCIwLjAxXCIgYmluZDp2YWx1ZT17ZnVuZFRyYW5zYWN0aW9uRm9ybS5hbW91bnR9Lz48L2xhYmVsPjxsYWJlbD5UcmFuc2FjdGlvbiBkYXRlPGlucHV0IHR5cGU9XCJkYXRlXCIgYmluZDp2YWx1ZT17ZnVuZFRyYW5zYWN0aW9uRm9ybS50cmFuc2FjdGlvbkRhdGV9Lz48L2xhYmVsPjxsYWJlbD5OQVY8aW5wdXQgdHlwZT1cIm51bWJlclwiIG1pbj1cIjAuMDAwMVwiIHN0ZXA9XCIwLjAwMDFcIiBiaW5kOnZhbHVlPXtmdW5kVHJhbnNhY3Rpb25Gb3JtLm5hdn0vPjwvbGFiZWw+eyNpZiBmdW5kVHJhbnNhY3Rpb25FcnJvcn08cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57ZnVuZFRyYW5zYWN0aW9uRXJyb3J9PC9wPnsvaWZ9PGRpdiBjbGFzcz1cIm1vZGFsLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgb246Y2xpY2s9eygpPT5lZGl0aW5nRnVuZFRyYW5zYWN0aW9uPW51bGx9PkNhbmNlbDwvYnV0dG9uPjxidXR0b24gY2xhc3M9XCJwcmltYXJ5XCIgb246Y2xpY2s9e3NhdmVGdW5kVHJhbnNhY3Rpb259IGRpc2FibGVkPXtmdW5kVHJhbnNhY3Rpb25TYXZpbmd9PntmdW5kVHJhbnNhY3Rpb25TYXZpbmc/XCJTYXZpbmfigKZcIjpcIlNhdmUgY2hhbmdlc1wifTwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj48L2Rpdj57L2lmfVxuPCEtLSBzdmVsdGUtaWdub3JlIGExMXlfY2xpY2tfZXZlbnRzX2hhdmVfa2V5X2V2ZW50cyAtLT5cbnsjaWYgc2hvd05vcm1hbGl6YXRpb259PGRpdiBjbGFzcz1cImFjY291bnQtcmVwYWlyLWJhY2tkcm9wXCIgcm9sZT1cInByZXNlbnRhdGlvblwiIG9uOmNsaWNrPXsoKT0+c2hvd05vcm1hbGl6YXRpb249ZmFsc2V9IG9uOmtleWRvd249eyhldmVudCk9PmV2ZW50LmtleT09PSdFc2NhcGUnJiYoc2hvd05vcm1hbGl6YXRpb249ZmFsc2UpfT48c2VjdGlvbiBjbGFzcz1cImFjY291bnQtcmVwYWlyLWRpYWxvZ1wiIHJvbGU9XCJkaWFsb2dcIiBhcmlhLW1vZGFsPVwidHJ1ZVwiIHRhYmluZGV4PVwiLTFcIiBvbjpjbGlja3xzdG9wUHJvcGFnYXRpb24+PGhlYWRlciBjbGFzcz1cImFjY291bnQtcmVwYWlyLWJhclwiPjxkaXY+PHNwYW4gY2xhc3M9XCJyZXBhaXItc3ltYm9sXCI+4pymPC9zcGFuPjxzcGFuPjxwPkVYUEVOU0UgREFUQSBPTkxZPC9wPjxzdHJvbmc+RXhwZW5zZSBjbGVhbnVwPC9zdHJvbmc+PC9zcGFuPjwvZGl2PjxidXR0b24gb246Y2xpY2s9eygpPT5zaG93Tm9ybWFsaXphdGlvbj1mYWxzZX0+w5c8L2J1dHRvbj48L2hlYWRlcj48ZGl2IGNsYXNzPVwiYWNjb3VudC1yZXBhaXItY29udGVudFwiPjxOb3JtYWxpemF0aW9uIC8+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG48IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeV9jbGlja19ldmVudHNfaGF2ZV9rZXlfZXZlbnRzIC0tPlxueyNpZiBvcGVuZWRTdG9yeX08ZGl2IGNsYXNzPVwic3RvcnktcmVhZGVyLWJhY2tkcm9wXCIgcm9sZT1cInByZXNlbnRhdGlvblwiIG9uOmNsaWNrPXsoKT0+b3BlbmVkU3Rvcnk9bnVsbH0gb246a2V5ZG93bj17KGV2ZW50KT0+ZXZlbnQua2V5PT09J0VzY2FwZScmJihvcGVuZWRTdG9yeT1udWxsKX0+PHNlY3Rpb24gY2xhc3M9XCJzdG9yeS1kZXRhaWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCIgb246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uPjxidXR0b24gY2xhc3M9XCJiYWNrLWJ1dHRvblwiIG9uOmNsaWNrPXsoKT0+b3BlbmVkU3Rvcnk9bnVsbH0+4oaQIEJhY2sgdG8gc3RvcmllczwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj57c3RvcnlTb3VyY2Uob3BlbmVkU3RvcnkpLnRvVXBwZXJDYXNlKCl9IMK3IHtzdG9yeU5hbWUob3BlbmVkU3RvcnkpfTwvcD57I2lmIGhhc0RlY2t9e0Bjb25zdCBjYXJkcz1vcGVuZWRTdG9yeS5jYXJkcy5zbGljZSgpLnNvcnQoKGEsYik9PihhLnNlcXVlbmNlfHwwKS0oYi5zZXF1ZW5jZXx8MCkpfXtAY29uc3QgY3VycmVudENhcmQ9Y2FyZHNbc3RvcnlTbGlkZV19PGRpdiBjbGFzcz1cInN0b3J5LWRlY2tcIj57I2lmIGNhcmRzLmxlbmd0aD4xfTxkaXYgY2xhc3M9XCJzdG9yeS1wcm9ncmVzc1wiPnsjZWFjaCBjYXJkcyBhcyBfLGluZGV4fTxpIGNsYXNzOmFjdGl2ZT17aW5kZXg9PT1zdG9yeVNsaWRlfT48L2k+ey9lYWNofTwvZGl2PnsvaWZ9PGFydGljbGUgY2xhc3M9e2BzdG9yeS1zbGlkZSBkZWNrLXRoZW1lLSR7Y3VycmVudENhcmQudGhlbWV8fCdDQUxNX0NPTlRFWFQnfWB9IG9uOnRvdWNoc3RhcnQ9e2V2ZW50PT4oc3RvcnlUb3VjaFN0YXJ0PWV2ZW50LnRvdWNoZXNbMF0uY2xpZW50WCl9IG9uOnRvdWNoZW5kPXtldmVudD0+ZW5kU3RvcnlTd2lwZShldmVudCxjYXJkcy5sZW5ndGgpfT57I2lmIGN1cnJlbnRDYXJkLmV5ZWJyb3d9PHAgY2xhc3M9XCJzbGlkZS1leWVicm93XCI+e2N1cnJlbnRDYXJkLmV5ZWJyb3d9PC9wPnsvaWZ9eyNpZiBjdXJyZW50Q2FyZC5sYXlvdXQ9PT0nSEVST19TVEFUJyYmY3VycmVudENhcmQuY29tcG9uZW50cz8uWzBdfTxkaXYgY2xhc3M9XCJzdG9yeS1hbW91bnRcIj48c3Bhbj57Y3VycmVudENhcmQuY29tcG9uZW50c1swXS5sYWJlbH08L3NwYW4+PHN0cm9uZz57Y3VycmVudENhcmQuY29tcG9uZW50c1swXS5kaXNwbGF5VmFsdWV9PC9zdHJvbmc+PC9kaXY+ey9pZn08aDE+e2N1cnJlbnRDYXJkLnRpdGxlfTwvaDE+PHA+e2N1cnJlbnRDYXJkLmJvZHl9PC9wPnsjaWYgY3VycmVudENhcmQuY29tcG9uZW50cz8ubGVuZ3RofTxkaXYgY2xhc3M9XCJvYnNlcnZhdGlvbi1jb21wb25lbnRzXCI+eyNlYWNoIGN1cnJlbnRDYXJkLmNvbXBvbmVudHMgYXMgY29tcG9uZW50fTxkaXY+PHNwYW4+e2NvbXBvbmVudC5sYWJlbH08L3NwYW4+PHN0cm9uZz57Y29tcG9uZW50LmRpc3BsYXlWYWx1ZX08L3N0cm9uZz48L2Rpdj57L2VhY2h9PC9kaXY+ey9pZn17I2VhY2ggY3VycmVudENhcmQuYWN0aW9uc3x8W10gYXMgYWN0aW9ufXsjaWYgYWN0aW9uLnR5cGU9PT0nT1BFTl9FVklERU5DRSd9PGJ1dHRvbiBjbGFzcz1cInN0b3J5LWFjdGlvblwiIGRhdGEtdGVzdGlkPVwidmlldy1pbmNsdWRlZC1jb21taXRtZW50c1wiIG9uOmNsaWNrPXtvcGVuQ29tbWl0bWVudFNvdXJjZXN9PnthY3Rpb24ubGFiZWx9PC9idXR0b24+ezplbHNlIGlmIGFjdGlvbi50eXBlPT09J09QRU5fU0FMQVJZX09VVExPT0snfTxidXR0b24gY2xhc3M9XCJzdG9yeS1hY3Rpb25cIiBvbjpjbGljaz17KCk9PntvcGVuZWRTdG9yeT1udWxsO29wZW5Nb25leSgpO319PnthY3Rpb24ubGFiZWx9PC9idXR0b24+ezplbHNlIGlmIGFjdGlvbi50eXBlPT09J09QRU5fRFVFX0xPQU4nfTxidXR0b24gY2xhc3M9XCJzdG9yeS1hY3Rpb25cIiBkYXRhLXRlc3RpZD1cInJldmlldy1maW5hbC1lbWlcIiBvbjpjbGljaz17b3BlbkR1ZUxvYW5Gcm9tU3Rvcnl9PnthY3Rpb24ubGFiZWx9PC9idXR0b24+ey9pZn17L2VhY2h9PC9hcnRpY2xlPnsjaWYgY2FyZHMubGVuZ3RoPjF9PGRpdiBjbGFzcz1cInN0b3J5LWRlY2stY29udHJvbHNcIj48YnV0dG9uIGRpc2FibGVkPXtzdG9yeVNsaWRlPT09MH0gb246Y2xpY2s9eygpPT5zdG9yeVNsaWRlLT0xfT7ihpA8L2J1dHRvbj48c3Bhbj57c3RvcnlTbGlkZSsxfSBvZiB7Y2FyZHMubGVuZ3RofTwvc3Bhbj48YnV0dG9uIGRpc2FibGVkPXtzdG9yeVNsaWRlPT09Y2FyZHMubGVuZ3RoLTF9IG9uOmNsaWNrPXsoKT0+c3RvcnlTbGlkZSs9MX0+TmV4dCDihpI8L2J1dHRvbj48L2Rpdj57L2lmfTwvZGl2PnsvaWZ9PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG48IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeV9jbGlja19ldmVudHNfaGF2ZV9rZXlfZXZlbnRzIC0tPlxueyNpZiBzaG93Q29tbWl0bWVudFJldmlld308ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCI+PGJ1dHRvbiBjbGFzcz1cImNsb3NlXCIgb246Y2xpY2s9eygpPT5zaG93Q29tbWl0bWVudFJldmlldz1mYWxzZX0+w5c8L2J1dHRvbj48cCBjbGFzcz1cIm1pY3JvLWxhYmVsXCI+TU9OVEhMWSBDT01NSVRNRU5UPC9wPjxoMj5IZWxwIG1hdGNoIHRoaXMgcGF5bWVudDwvaDI+PHAgY2xhc3M9XCJtb2R1bGUtcmVhc3N1cmFuY2VcIj5Zb3VyIGV4cGVuc2Ugd2FzIHNhdmVkIG5vcm1hbGx5LiBMaW5rIGl0IG9ubHkgaWYgaXQgYmVsb25ncyB0byBvbmUgb2YgeW91ciBjb21taXRtZW50cy48L3A+eyNpZiBjb21taXRtZW50UmV2aWV3U3RhdHVzPT09J2xvYWRpbmcnfTxwPkxvYWRpbmcgcGF5bWVudCBjaG9pY2Vz4oCmPC9wPns6ZWxzZSBpZiBjb21taXRtZW50UmV2aWV3U3RhdHVzPT09J2Vycm9yJ308cCBjbGFzcz1cImZvcm0tZXJyb3JcIj57Y29tbWl0bWVudEVycm9yfTwvcD57OmVsc2V9eyNlYWNoIGNvbW1pdG1lbnRSZXZpZXcgYXMgY2FuZGlkYXRlfTxkaXYgY2xhc3M9XCJzb3VyY2Utbm90ZVwiPjxzdHJvbmc+e21vbmV5KGNhbmRpZGF0ZS5hbW91bnQpfSDCtyB7Y2FuZGlkYXRlLmNhdGVnb3J5fSAvIHtjYW5kaWRhdGUuc3ViY2F0ZWdvcnl9PC9zdHJvbmc+PHNwYW4+e2RhdGVMYWJlbChjYW5kaWRhdGUudHJhbnNhY3Rpb25EYXRlKX08L3NwYW4+PC9kaXY+PHA+V2hpY2ggY29tbWl0bWVudCBpcyB0aGlzIGZvcj88L3A+eyNlYWNoIGNhbmRpZGF0ZS5jaG9pY2VzIGFzIGNob2ljZX08YnV0dG9uIGNsYXNzPVwic3RvcnktYWN0aW9uXCIgb246Y2xpY2s9eygpPT5yZXNvbHZlQ2FuZGlkYXRlKGNhbmRpZGF0ZS50cmFuc2FjdGlvbklkLGNob2ljZS5pZCl9IGRpc2FibGVkPXtyZXNvbHZpbmdDYW5kaWRhdGU9PT1jYW5kaWRhdGUudHJhbnNhY3Rpb25JZH0+e2Nob2ljZS5sYWJlbH08L2J1dHRvbj57L2VhY2h9PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+cmVzb2x2ZUNhbmRpZGF0ZShjYW5kaWRhdGUudHJhbnNhY3Rpb25JZCxudWxsKX0gZGlzYWJsZWQ9e3Jlc29sdmluZ0NhbmRpZGF0ZT09PWNhbmRpZGF0ZS50cmFuc2FjdGlvbklkfT5UaGlzIGlzIG5vdCBhIGNvbW1pdG1lbnQ8L2J1dHRvbj57L2VhY2h9eyNpZiAhY29tbWl0bWVudFJldmlldy5sZW5ndGh9PHA+RXZlcnl0aGluZyBpcyByZXZpZXdlZCBmb3IgdGhpcyBtb250aC48L3A+ey9pZn17L2lmfTwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBzaG93U3RvcnlFdmlkZW5jZX08ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIiBvbjpjbGljaz17KCk9PnNob3dTdG9yeUV2aWRlbmNlPWZhbHNlfSBvbjprZXlkb3duPXsoZXZlbnQpPT5ldmVudC5rZXk9PT0nRXNjYXBlJyYmKHNob3dTdG9yeUV2aWRlbmNlPWZhbHNlKX0gcm9sZT1cInByZXNlbnRhdGlvblwiPjxzZWN0aW9uIGNsYXNzPVwibW9kYWxcIiBvbjpjbGlja3xzdG9wUHJvcGFnYXRpb24gcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+c2hvd1N0b3J5RXZpZGVuY2U9ZmFsc2V9PsOXPC9idXR0b24+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPklOQ0xVREVEIENPTU1JVE1FTlRTPC9wPjxoMj57aXNDb21taXRtZW50KG9wZW5lZFN0b3J5KT8nV2hhdCBtYWtlcyB1cCB0aGlzIG1vbnRoJzonU3VwcG9ydGluZyBldmlkZW5jZSd9PC9oMj57I2lmIGV2aWRlbmNlSXRlbXMubGVuZ3RofTxwIGNsYXNzPVwiZXZpZGVuY2UtdG90YWxcIj57ZXZpZGVuY2VJdGVtcy5sZW5ndGh9IGluY2x1ZGVkIHtldmlkZW5jZUl0ZW1zLmxlbmd0aD09PTE/J2NvbW1pdG1lbnQnOidjb21taXRtZW50cyd9PC9wPjxkaXYgY2xhc3M9XCJldmlkZW5jZS1saXN0XCI+eyNlYWNoIGV2aWRlbmNlSXRlbXMgYXMgaXRlbX17QGNvbnN0IGxvYW5JdGVtPS9sb2FuL2kudGVzdChpdGVtLmNhdGVnb3J5KX17QGNvbnN0IGZ1bmRJdGVtPWl0ZW0uc291cmNlVHlwZT09PSdtdXR1YWxfZnVuZF9zaXAnfXtAY29uc3Qgc3RvY2tJdGVtPWl0ZW0uc291cmNlVHlwZT09PSdzdG9ja19tb250aGx5X3BsYW4nfXtAY29uc3QgcmVjdXJyaW5nSXRlbT1pdGVtLnNvdXJjZVR5cGU9PT0ncmVjdXJyaW5nX2NvbW1pdG1lbnQnfXtAY29uc3QgcmVjdXJyaW5nU3RhdHVzPXJlY3VycmluZ09jY3VycmVuY2UoaXRlbS5zb3VyY2VJZCk/LnN0YXR1c308ZGl2IGNsYXNzOmR1ZS1jb21taXRtZW50PXsobG9hbkl0ZW0mJmN1cnJlbnRDb21taXRtZW50SXNEdWUoKSl8fChmdW5kSXRlbSYmc2lwSXNEdWUoaXRlbSkpfHwoc3RvY2tJdGVtJiZzdG9ja3MuZmluZChzdG9jaz0+U3RyaW5nKHN0b2NrLmlkKT09PVN0cmluZyhpdGVtLnNvdXJjZUlkKSk/LmN1cnJlbnRNb250aGx5UGxhbj8uc3RhdHVzPT09J0RVRScpfHwocmVjdXJyaW5nSXRlbSYmcmVjdXJyaW5nU3RhdHVzPT09J0RVRScpfSBjbGFzczpjb25maXJtZWQtY29tbWl0bWVudD17KGZ1bmRJdGVtJiZzaXBJc0NvbmZpcm1lZChpdGVtKSl8fChyZWN1cnJpbmdJdGVtJiZyZWN1cnJpbmdTdGF0dXM9PT0nQ09NUExFVEVEJyl9IGNsYXNzPVwiZXZpZGVuY2Utcm93XCI+PGRpdj48c3Ryb25nPntpdGVtLm1lcmNoYW50fTwvc3Ryb25nPjxzcGFuPntpdGVtLmRhdGV9e2l0ZW0uZGF0ZSYmaXRlbS5jYXRlZ29yeT8nIMK3ICc6Jyd9e2l0ZW0uY2F0ZWdvcnl9PC9zcGFuPjwvZGl2PjxiPntpdGVtLmFtb3VudH08L2I+eyNpZiBsb2FuSXRlbX08YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgZGF0YS10ZXN0aWQ9XCJpbmNsdWRlZC1sb2FuLWNvbW1pdG1lbnRcIiBvbjpjbGljaz17b3BlbkluY2x1ZGVkTG9hbn0+UmV2aWV3PC9idXR0b24+ezplbHNlIGlmIGZ1bmRJdGVtfTxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBkYXRhLXRlc3RpZD17YGluY2x1ZGVkLW11dHVhbC1mdW5kLWNvbW1pdG1lbnQtJHtpdGVtLnNvdXJjZUlkfWB9IG9uOmNsaWNrPXsoKT0+b3BlbkluY2x1ZGVkTXV0dWFsRnVuZChpdGVtKX0+UmV2aWV3PC9idXR0b24+ezplbHNlIGlmIHN0b2NrSXRlbX08YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgZGF0YS10ZXN0aWQ9e2BpbmNsdWRlZC1zdG9jay1jb21taXRtZW50LSR7aXRlbS5zb3VyY2VJZH1gfSBvbjpjbGljaz17KCk9Pm9wZW5JbmNsdWRlZFN0b2NrKGl0ZW0pfT5SZXZpZXc8L2J1dHRvbj57OmVsc2UgaWYgcmVjdXJyaW5nSXRlbX08YnV0dG9uIGNsYXNzPVwic2Vjb25kYXJ5XCIgZGF0YS10ZXN0aWQ9e2BpbmNsdWRlZC1yZWN1cnJpbmctY29tbWl0bWVudC0ke2l0ZW0uc291cmNlSWR9YH0gb246Y2xpY2s9eygpPT5vcGVuSW5jbHVkZWRDb21taXRtZW50KGl0ZW0pfT5SZXZpZXc8L2J1dHRvbj57L2lmfTwvZGl2PnsvZWFjaH08L2Rpdj57OmVsc2V9PGRpdiBjbGFzcz1cImVtcHR5LXN0YXRlIGV2aWRlbmNlLWVtcHR5XCI+PHNwYW4+4peMPC9zcGFuPjxoMj5ObyBjb21taXRtZW50cyBhdHRhY2hlZDwvaDI+PHA+VGhpcyBzdG9yeSBkb2VzIG5vdCBpbmNsdWRlIHNvdXJjZXMgdG8gZGlzcGxheS48L3A+PC9kaXY+ey9pZn08L3NlY3Rpb24+PC9kaXY+ey9pZn1cbnsjaWYgZWRpdGluZ308ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+ZWRpdGluZz1udWxsfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5BSS1DQVBUVVJFRCBFWFBFTlNFPC9wPjxoMj5FZGl0IHRyYW5zYWN0aW9uPC9oMj48ZGl2IGNsYXNzPVwic291cmNlLW5vdGVcIj48c3Ryb25nPkNhcHR1cmVkIGZyb20geW91ciBtZXNzYWdlPC9zdHJvbmc+PHNwYW4+UmV2aWV3IHRoZSBkZXRhaWxzIGJlbG93IGJlZm9yZSBzYXZpbmcuPC9zcGFuPjwvZGl2PjxsYWJlbD5BbW91bnQ8aW5wdXQgdHlwZT1cIm51bWJlclwiIGlucHV0bW9kZT1cImRlY2ltYWxcIiBtaW49XCIwLjAxXCIgc3RlcD1cIjAuMDFcIiBiaW5kOnZhbHVlPXtlZGl0QW1vdW50fS8+PC9sYWJlbD48bGFiZWw+VHJhbnNhY3Rpb24gZGF0ZTxpbnB1dCB0eXBlPVwiZGF0ZVwiIG1heD17bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsMTApfSBiaW5kOnZhbHVlPXtlZGl0RGF0ZX0vPjwvbGFiZWw+eyNpZiBvcHRpb25zU3RhdHVzPT09J2xvYWRpbmcnfTxwIGNsYXNzPVwiZWRpdC1vcHRpb25zLXN0YXR1c1wiPkxvYWRpbmcgY2F0ZWdvcmllcywgbWVyY2hhbnRzLCBhbmQgYWNjb3VudHPigKY8L3A+ezplbHNlIGlmIG9wdGlvbnNTdGF0dXM9PT0nZXJyb3InfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPntvcHRpb25zRXJyb3J9PC9wPns6ZWxzZX08bGFiZWw+Q2F0ZWdvcnk8c2VsZWN0IHZhbHVlPXtlZGl0Q2F0ZWdvcnl9IG9uOmNoYW5nZT17Y2hhbmdlRWRpdENhdGVnb3J5fT48b3B0aW9uIHZhbHVlPVwiXCIgZGlzYWJsZWQ+U2VsZWN0IGEgY2F0ZWdvcnk8L29wdGlvbj57I2VhY2ggZWRpdE9wdGlvbnMuY2F0ZWdvcmllcyBhcyBvcHRpb259PG9wdGlvbiB2YWx1ZT17b3B0aW9uLm5hbWV9PntvcHRpb24ubmFtZX08L29wdGlvbj57L2VhY2h9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+U3ViY2F0ZWdvcnk8c2VsZWN0IGJpbmQ6dmFsdWU9e2VkaXRTdWJjYXRlZ29yeX0gZGlzYWJsZWQ9eyFlZGl0Q2F0ZWdvcnl9PjxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5TZWxlY3QgYSBzdWJjYXRlZ29yeTwvb3B0aW9uPnsjZWFjaCBlZGl0U3ViY2F0ZWdvcmllcyBhcyBvcHRpb259PG9wdGlvbiB2YWx1ZT17b3B0aW9ufT57b3B0aW9ufTwvb3B0aW9uPnsvZWFjaH08L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5NZXJjaGFudDxzZWxlY3QgYmluZDp2YWx1ZT17ZWRpdE1lcmNoYW50SWR9PjxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZD5TZWxlY3QgYSBtZXJjaGFudDwvb3B0aW9uPnsjZWFjaCBlZGl0T3B0aW9ucy5tZXJjaGFudHMgYXMgb3B0aW9ufTxvcHRpb24gdmFsdWU9e1N0cmluZyhvcHRpb24uaWQpfT57b3B0aW9uLm5hbWV9PC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPlNvdXJjZSBhY2NvdW50PHNlbGVjdCBiaW5kOnZhbHVlPXtlZGl0QWNjb3VudElkfT48b3B0aW9uIHZhbHVlPVwiXCIgZGlzYWJsZWQ+U2VsZWN0IGFuIGFjY291bnQ8L29wdGlvbj57I2VhY2ggZWRpdE9wdGlvbnMuYWNjb3VudHMgYXMgb3B0aW9ufTxvcHRpb24gdmFsdWU9e1N0cmluZyhvcHRpb24uaWQpfT57b3B0aW9uLm5hbWV9PC9vcHRpb24+ey9lYWNofTwvc2VsZWN0PjwvbGFiZWw+ey9pZn17I2lmIGFjdGlvbkVycm9yfTxwIGNsYXNzPVwiZm9ybS1lcnJvclwiPnthY3Rpb25FcnJvcn08L3A+ey9pZn08ZGl2IGNsYXNzPVwibW9kYWwtYWN0aW9uc1wiPjxidXR0b24gY2xhc3M9XCJzZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PmVkaXRpbmc9bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnlcIiBvbjpjbGljaz17c2F2ZUVkaXR9IGRpc2FibGVkPXtzYXZpbmd8fG9wdGlvbnNTdGF0dXMhPT0ncmVhZHknfT57c2F2aW5nPydTYXZpbmfigKYnOidTYXZlIGNoYW5nZXMnfTwvYnV0dG9uPjwvZGl2Pjwvc2VjdGlvbj48L2Rpdj57L2lmfVxueyNpZiBkZWxldGluZ308ZGl2IGNsYXNzPVwibW9kYWwtYmFja2Ryb3BcIj48c2VjdGlvbiBjbGFzcz1cIm1vZGFsXCIgcm9sZT1cImFsZXJ0ZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiB0YWJpbmRleD1cIi0xXCI+PHAgY2xhc3M9XCJtaWNyby1sYWJlbFwiPkRFTEVURSBUUkFOU0FDVElPTjwvcD48aDI+RGVsZXRlIHttZXJjaGFudChkZWxldGluZyl9PzwvaDI+PHA+VGhpcyB1cGRhdGVzIHRoZSBjYWxlbmRhciBhbmQgbW9udGhseSB0b3RhbHMuPC9wPjxkaXYgY2xhc3M9XCJtb2RhbC1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uOmNsaWNrPXsoKT0+ZGVsZXRpbmc9bnVsbH0+Q2FuY2VsPC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInByaW1hcnkgZGVsZXRlLWNvbmZpcm1cIiBvbjpjbGljaz17Y29uZmlybURlbGV0ZX0+RGVsZXRlPC9idXR0b24+PC9kaXY+PC9zZWN0aW9uPjwvZGl2PnsvaWZ9XG57I2lmIGhhbmRvZmZ9PGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wXCI+PHNlY3Rpb24gY2xhc3M9XCJtb2RhbCB3aGF0c2FwcC1oYW5kb2ZmXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgdGFiaW5kZXg9XCItMVwiPjxidXR0b24gY2xhc3M9XCJjbG9zZVwiIG9uOmNsaWNrPXsoKT0+aGFuZG9mZj1udWxsfT7DlzwvYnV0dG9uPjxwIGNsYXNzPVwibWljcm8tbGFiZWxcIj5XSEFUU0FQUCBSRUFEWTwvcD48aDI+Q29udGludWUgaW4gV2hhdHNBcHA8L2gyPjxwPlNlbmQgdGhlIG1pc3NpbmcgdHJhbnNhY3Rpb24gZm9yIHtkYXRlTGFiZWwoYCR7aGFuZG9mZi5kYXRlfVQxMjowMDowMGApfS48L3A+eyNpZiBoYW5kb2ZmLndoYXRzYXBwVXJsfTxhIGNsYXNzPVwiY2VudGVyLWFjdGlvbiB3aGF0c2FwcC1hY3Rpb25cIiBocmVmPXtoYW5kb2ZmLndoYXRzYXBwVXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiPk9wZW4gV2hhdHNBcHA8L2E+ey9pZn08YnV0dG9uIGNsYXNzPVwiYXV0aC1zZWNvbmRhcnlcIiBvbjpjbGljaz17KCk9PmhhbmRvZmY9bnVsbH0+RG9uZTwvYnV0dG9uPjwvc2VjdGlvbj48L2Rpdj57L2lmfVxuIl0sImZpbGUiOiIvVXNlcnMvZGVlbmEvRG9jdW1lbnRzL0dpdEh1Yi9wZXJzb25hbC1haS9mcm9udGVuZC9zcmMvSG9tZS5zdmVsdGUifQ==